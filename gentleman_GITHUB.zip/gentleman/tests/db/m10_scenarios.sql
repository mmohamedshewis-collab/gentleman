\set ON_ERROR_STOP off
\pset pager off
\t on
UPDATE product_items SET status='AVAILABLE' WHERE item_code IN ('SUIT-0001','SUIT-0002','SUIT-0003');

\echo '=== R1: إنشاء حجز صحيح ==='
INSERT INTO reservations (reservation_no, customer_id, event_date, pickup_date, return_date, deposit_amount, created_by)
VALUES ('RES-2026-000001', 2, CURRENT_DATE+12, CURRENT_DATE+10, CURRENT_DATE+12, 300, 1);
INSERT INTO reservation_items (reservation_id, item_id, agreed_price)
SELECT id, 1, 750 FROM reservations WHERE reservation_no='RES-2026-000001';
INSERT INTO item_bookings (item_id, start_date, end_date, source_type, source_id)
SELECT 1, CURRENT_DATE+10, CURRENT_DATE+12, 'RESERVATION', id FROM reservations WHERE reservation_no='RES-2026-000001';
SELECT 'الحجز: ' || reservation_no || ' حالة=' || status || ' عربون=' || deposit_amount FROM reservations WHERE reservation_no='RES-2026-000001';

\echo ''
\echo '=== R2: ★ حجز آخر متعارض لنفس القطعة (يجب أن يُرفض) ==='
INSERT INTO item_bookings (item_id, start_date, end_date, source_type, source_id)
VALUES (1, CURRENT_DATE+11, CURRENT_DATE+13, 'RESERVATION', 999);

\echo '=== R2ب: ★ تأجير متعارض مع الحجز (يجب أن يُرفض) ==='
INSERT INTO item_bookings (item_id, start_date, end_date, source_type, source_id)
VALUES (1, CURRENT_DATE+9, CURRENT_DATE+11, 'RENTAL', 888);

\echo '=== R2ج: فترة غير متقاطعة (يجب أن تنجح) ==='
INSERT INTO item_bookings (item_id, start_date, end_date, source_type, source_id)
VALUES (1, CURRENT_DATE+20, CURRENT_DATE+22, 'RESERVATION', 777);

\echo ''
\echo '=== R3: تاريخ المناسبة قبل الاستلام (يجب أن يُرفض) ==='
INSERT INTO reservations (reservation_no, customer_id, event_date, pickup_date, return_date, created_by)
VALUES ('RES-BAD1', 2, CURRENT_DATE+5, CURRENT_DATE+10, CURRENT_DATE+12, 1);

\echo '=== R3ب: تاريخ إرجاع قبل الاستلام (يجب أن يُرفض) ==='
INSERT INTO reservations (reservation_no, customer_id, event_date, pickup_date, return_date, created_by)
VALUES ('RES-BAD2', 2, CURRENT_DATE+12, CURRENT_DATE+10, CURRENT_DATE+5, 1);

\echo '=== R3ج: عربون سالب (يجب أن يُرفض) ==='
INSERT INTO reservations (reservation_no, customer_id, event_date, pickup_date, return_date, deposit_amount, created_by)
VALUES ('RES-BAD3', 2, CURRENT_DATE+12, CURRENT_DATE+10, CURRENT_DATE+12, -100, 1);

\echo ''
\echo '=== R4: ★ D2 — كتابة حالة EXPIRED (يجب أن تُرفض إنشاءً وتحديثًا) ==='
INSERT INTO reservations (reservation_no, customer_id, event_date, pickup_date, return_date, status, created_by)
VALUES ('RES-EXP', 2, CURRENT_DATE+12, CURRENT_DATE+10, CURRENT_DATE+12, 'EXPIRED', 1);
UPDATE reservations SET status='EXPIRED' WHERE reservation_no='RES-2026-000001';

\echo ''
\echo '=== R5: إلغاء بلا سبب (يجب أن يُرفض) ==='
UPDATE reservations SET status='CANCELLED' WHERE reservation_no='RES-2026-000001';
\echo '=== R5ب: إلغاء بسبب (يجب أن ينجح) ==='
UPDATE reservations SET status='CANCELLED', cancel_reason='إلغاء من المحل' WHERE reservation_no='RES-2026-000001';
SELECT 'بعد الإلغاء: ' || status || ' السبب=' || cancel_reason FROM reservations WHERE reservation_no='RES-2026-000001';

\echo ''
\echo '=== R6: إعادة فتح حجز ملغى (يجب أن يُرفض) ==='
UPDATE reservations SET status='PENDING' WHERE reservation_no='RES-2026-000001';

\echo ''
\echo '=== R7: تحويل بلا عقد مرتبط (يجب أن يُرفض) ==='
INSERT INTO reservations (reservation_no, customer_id, event_date, pickup_date, return_date, created_by)
VALUES ('RES-2026-000002', 2, CURRENT_DATE+12, CURRENT_DATE+10, CURRENT_DATE+12, 1);
UPDATE reservations SET status='CONVERTED' WHERE reservation_no='RES-2026-000002';

\echo ''
\echo '=== R8: ★ D3 — رد عربون مربوط بحجز ==='
INSERT INTO payments (payment_no, purpose, reservation_id, customer_id, amount, payment_method_id, created_by)
SELECT 'PAY-RES1', 'RESERVATION_DEPOSIT', id, 2, 300, 1, 1 FROM reservations WHERE reservation_no='RES-2026-000001';
SELECT 'العربون محصَّل: ' || amount FROM payments WHERE payment_no='PAY-RES1';
\echo '--> رد العربون (يجب أن ينجح بعد توسيع القيد):'
INSERT INTO payments (payment_no, direction, purpose, reservation_id, customer_id, amount, payment_method_id, created_by)
SELECT 'PAY-RES1R', 'OUT', 'CUSTOMER_REFUND', id, 2, 300, 1, 1 FROM reservations WHERE reservation_no='RES-2026-000001';
SELECT 'رُدَّ: ' || amount FROM payments WHERE payment_no='PAY-RES1R';

\echo ''
\echo '=== R9: رد بلا أي مصدر (يجب أن يُرفض) ==='
INSERT INTO payments (payment_no, direction, purpose, customer_id, amount, payment_method_id, created_by)
VALUES ('PAY-NOSRC', 'OUT', 'CUSTOMER_REFUND', 2, 100, 1, 1);

\echo ''
\echo '=== R10: حذف حجز (يجب أن يُرفض) ==='
DELETE FROM reservations WHERE reservation_no='RES-2026-000001';
