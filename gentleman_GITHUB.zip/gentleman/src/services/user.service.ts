import { z } from 'zod';
import { prisma } from '@/lib/db';
import { Errors } from '@/lib/errors';
import { hashPassword, validatePasswordStrength } from '@/lib/auth/password';
import { writeAudit, redact } from '@/lib/audit';
import { requirePermission } from '@/lib/auth/rbac';

export const createUserSchema = z.object({
  username: z.string().min(3).max(40).regex(/^[a-zA-Z0-9._-]+$/, 'اسم المستخدم بحروف إنجليزية وأرقام فقط'),
  fullName: z.string().min(2),
  password: z.string(),
  roleId: z.number().int().positive(),
});

export const updateUserSchema = z.object({
  id: z.number().int().positive(),
  fullName: z.string().min(2).optional(),
  roleId: z.number().int().positive().optional(),
  isActive: z.boolean().optional(),
  newPassword: z.string().optional(),
});

export async function listUsers() {
  await requirePermission('users.view');
  return prisma.user.findMany({
    select: {
      id: true, username: true, fullName: true, isActive: true,
      lastLoginAt: true, createdAt: true,
      role: { select: { id: true, nameAr: true, code: true } },
    },
    orderBy: { id: 'asc' },
  });
}

export async function listRoles() {
  await requirePermission('users.view');
  return prisma.role.findMany({
    select: {
      id: true, code: true, nameAr: true,
      _count: { select: { permissions: true, users: true } },
    },
    orderBy: { id: 'asc' },
  });
}

export async function createUser(input: z.infer<typeof createUserSchema>) {
  const actor = await requirePermission('users.manage');

  const pwError = validatePasswordStrength(input.password);
  if (pwError) throw Errors.rule(pwError);

  const exists = await prisma.user.findUnique({ where: { username: input.username } });
  if (exists) throw Errors.conflict('اسم المستخدم مستخدم بالفعل.');

  const role = await prisma.role.findUnique({ where: { id: input.roleId } });
  if (!role) throw Errors.notFound('الدور');

  return prisma.$transaction(async (tx) => {
    const user = await tx.user.create({
      data: {
        username: input.username,
        fullName: input.fullName,
        passwordHash: await hashPassword(input.password),
        roleId: input.roleId,
      },
    });
    await writeAudit(
      { userId: actor.id, action: 'user.create', entityType: 'User', entityId: user.id, after: redact(user) },
      tx,
    );
    return { id: user.id, username: user.username };
  });
}

export async function updateUser(input: z.infer<typeof updateUserSchema>) {
  const actor = await requirePermission('users.manage');

  const before = await prisma.user.findUnique({ where: { id: input.id } });
  if (!before) throw Errors.notFound('المستخدم');

  // حماية: لا يعطّل المستخدم حسابه بنفسه ولا يغيّر دوره بنفسه
  if (actor.id === input.id && (input.isActive === false || input.roleId)) {
    throw Errors.rule('لا يمكنك تعطيل حسابك أو تغيير دورك بنفسك.');
  }

  const data: Record<string, unknown> = {};
  if (input.fullName) data.fullName = input.fullName;
  if (input.roleId) data.roleId = input.roleId;
  if (typeof input.isActive === 'boolean') data.isActive = input.isActive;
  if (input.newPassword) {
    const pwError = validatePasswordStrength(input.newPassword);
    if (pwError) throw Errors.rule(pwError);
    data.passwordHash = await hashPassword(input.newPassword);
  }

  return prisma.$transaction(async (tx) => {
    const after = await tx.user.update({ where: { id: input.id }, data });
    // تعطيل المستخدم يُنهي جلساته فورًا
    if (input.isActive === false || input.newPassword) {
      await tx.userSession.updateMany({
        where: { userId: input.id, revokedAt: null },
        data: { revokedAt: new Date() },
      });
    }
    await writeAudit(
      {
        userId: actor.id,
        action: 'user.update',
        entityType: 'User',
        entityId: input.id,
        before: redact(before),
        after: redact(after),
      },
      tx,
    );
    return { id: after.id };
  });
}
