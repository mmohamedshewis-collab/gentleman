\set ON_ERROR_STOP off
\t on
\echo '=== R8 (بعد الإصلاح): رد عربون حجز ملغى ==='
INSERT INTO payments (payment_no, direction, purpose, reservation_id, customer_id, amount, payment_method_id, created_by)
SELECT 'PAY-R2', 'OUT', 'CUSTOMER_REFUND', id, 2, 300, 1, 1 FROM reservations WHERE reservation_no='RES-2026-000001';
SELECT 'رُدَّ: ' || amount FROM payments WHERE payment_no='PAY-R2';
\echo '=== R8ب: ★ رد ثانٍ (يجب أن يُرفض — القابل للرد صار صفرًا) ==='
INSERT INTO payments (payment_no, direction, purpose, reservation_id, customer_id, amount, payment_method_id, created_by)
SELECT 'PAY-R3', 'OUT', 'CUSTOMER_REFUND', id, 2, 1, 1, 1 FROM reservations WHERE reservation_no='RES-2026-000001';
\echo '=== R8ج: ★ رد يتجاوز المحصَّل (يجب أن يُرفض) ==='
INSERT INTO reservations (reservation_no, customer_id, event_date, pickup_date, return_date, status, cancel_reason, created_by)
VALUES ('RES-X', 2, CURRENT_DATE+12, CURRENT_DATE+10, CURRENT_DATE+12, 'PENDING', NULL, 1);
INSERT INTO payments (payment_no, purpose, reservation_id, customer_id, amount, payment_method_id, created_by)
SELECT 'PAY-X', 'RESERVATION_DEPOSIT', id, 2, 200, 1, 1 FROM reservations WHERE reservation_no='RES-X';
UPDATE reservations SET status='CANCELLED', cancel_reason='إلغاء' WHERE reservation_no='RES-X';
INSERT INTO payments (payment_no, direction, purpose, reservation_id, customer_id, amount, payment_method_id, created_by)
SELECT 'PAY-XR', 'OUT', 'CUSTOMER_REFUND', id, 2, 500, 1, 1 FROM reservations WHERE reservation_no='RES-X';
\echo '=== R8د: ★ رد على حجز قائم غير ملغى (يجب أن يُرفض) ==='
INSERT INTO reservations (reservation_no, customer_id, event_date, pickup_date, return_date, created_by)
VALUES ('RES-Y', 2, CURRENT_DATE+12, CURRENT_DATE+10, CURRENT_DATE+12, 1);
INSERT INTO payments (payment_no, purpose, reservation_id, customer_id, amount, payment_method_id, created_by)
SELECT 'PAY-Y', 'RESERVATION_DEPOSIT', id, 2, 200, 1, 1 FROM reservations WHERE reservation_no='RES-Y';
INSERT INTO payments (payment_no, direction, purpose, reservation_id, customer_id, amount, payment_method_id, created_by)
SELECT 'PAY-YR', 'OUT', 'CUSTOMER_REFUND', id, 2, 200, 1, 1 FROM reservations WHERE reservation_no='RES-Y';
