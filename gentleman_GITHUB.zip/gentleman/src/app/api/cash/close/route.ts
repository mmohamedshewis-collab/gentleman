import { route } from '@/lib/api';
import { closeDay, closeSchema } from '@/services/cash.service';

export const POST = route({ schema: closeSchema, handler: ({ input }) => closeDay(input) });
