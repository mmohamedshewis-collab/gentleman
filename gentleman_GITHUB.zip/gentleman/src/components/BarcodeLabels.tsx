'use client';

import { useEffect, useRef } from 'react';
import JsBarcode from 'jsbarcode';

export interface LabelItem {
  id: number;
  itemCode: string;
  barcode: string;
  product: { nameAr: string; size: string | null; color: string | null };
}

function Label({ item }: { item: LabelItem }) {
  const svgRef = useRef<SVGSVGElement>(null);

  useEffect(() => {
    if (!svgRef.current) return;
    try {
      JsBarcode(svgRef.current, item.barcode, {
        format: 'CODE128',
        width: 1.6,
        height: 42,
        displayValue: true,
        fontSize: 12,
        margin: 0,
      });
    } catch {
      /* باركود غير صالح للترميز — يظهر الملصق بلا رسم */
    }
  }, [item.barcode]);

  return (
    <div className="label-card">
      <div className="label-name">{item.product.nameAr}</div>
      <div className="label-meta">
        {item.product.size ? `مقاس ${item.product.size}` : ''}
        {item.product.color ? ` · ${item.product.color}` : ''}
      </div>
      <svg ref={svgRef} />
      <div className="label-code">{item.itemCode}</div>
    </div>
  );
}

export default function BarcodeLabels({ items }: { items: LabelItem[] }) {
  return (
    <>
      <div className="no-print mb-4 flex gap-3">
        <button className="btn-primary" onClick={() => window.print()}>طباعة الملصقات</button>
        <span className="text-sm text-slate-500 self-center">
          عدد الملصقات: <span className="num">{items.length}</span>
        </span>
      </div>

      <div className="labels-grid">
        {items.map((it) => <Label key={it.id} item={it} />)}
      </div>

      <style jsx global>{`
        .labels-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(190px, 1fr));
          gap: 8px;
        }
        .label-card {
          border: 1px dashed #cbd5e1;
          border-radius: 6px;
          padding: 8px;
          text-align: center;
          background: #fff;
          break-inside: avoid;
        }
        .label-name { font-size: 12px; font-weight: 700; margin-bottom: 2px; }
        .label-meta { font-size: 10px; color: #64748b; margin-bottom: 4px; }
        .label-code { font-size: 10px; color: #334155; direction: ltr; }
        @media print {
          .no-print, aside { display: none !important; }
          body { background: #fff; }
          main { padding: 0 !important; }
          .label-card { border: 1px solid #e2e8f0; }
        }
      `}</style>
    </>
  );
}
