import { listUsers, listRoles } from '@/services/user.service';
import { formatDateTime } from '@/lib/date';
import UserForm from '@/components/UserForm';
import { getSession } from '@/lib/auth/session';

export const dynamic = 'force-dynamic';

export default async function UsersPage() {
  const [users, roles, session] = await Promise.all([listUsers(), listRoles(), getSession()]);
  const canManage = session?.permissions.has('users.manage') ?? false;

  return (
    <div className="space-y-6">
      <h1 className="section-title">المستخدمون والصلاحيات</h1>

      <div className="card overflow-hidden">
        <div className="card-header">قائمة المستخدمين</div>
        <table className="table">
          <thead>
            <tr>
              <th>#</th><th>اسم المستخدم</th><th>الاسم</th><th>الدور</th>
              <th>الحالة</th><th>آخر دخول</th>
            </tr>
          </thead>
          <tbody>
            {users.map((u) => (
              <tr key={u.id}>
                <td className="num">{u.id}</td>
                <td className="num">{u.username}</td>
                <td>{u.fullName}</td>
                <td>{u.role.nameAr}</td>
                <td>
                  <span className={`badge ${u.isActive ? 'bg-green-100 text-ok' : 'bg-red-100 text-danger'}`}>
                    {u.isActive ? 'نشط' : 'معطّل'}
                  </span>
                </td>
                <td className="num">{u.lastLoginAt ? formatDateTime(u.lastLoginAt) : '—'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="card overflow-hidden">
        <div className="card-header">الأدوار</div>
        <table className="table">
          <thead><tr><th>الدور</th><th>الكود</th><th>عدد الصلاحيات</th><th>عدد المستخدمين</th></tr></thead>
          <tbody>
            {roles.map((r) => (
              <tr key={r.id}>
                <td>{r.nameAr}</td>
                <td className="num">{r.code}</td>
                <td className="num">{r._count.permissions}</td>
                <td className="num">{r._count.users}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {canManage && <UserForm roles={roles.map((r) => ({ id: r.id, nameAr: r.nameAr }))} />}
    </div>
  );
}
