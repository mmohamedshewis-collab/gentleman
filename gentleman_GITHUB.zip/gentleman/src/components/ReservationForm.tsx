'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

interface Line { itemId: number; itemCode: string; productName: string; agreedPrice: string }

/** حجز جديد: عميل بالجوال · قطع بالباركود · تواريخ · عربون اختياري. */
export default function ReservationForm({ methods }: { methods: { id: number; nameAr: string }[] }) {
  const router = useRouter();
  const [phone, setPhone] = useState('');
  const [customerId, setCustomerId] = useState<number | null>(null);
  const [customerName, setCustomerName] = useState('');
  const [barcode, setBarcode] = useState('');
  const [lines, setLines] = useState<Line[]>([]);
  const [eventDate, setEventDate] = useState('');
  const [pickupDate, setPickupDate] = useState('');
  const [returnDate, setReturnDate] = useState('');
  const [deposit, setDeposit] = useState('');
  const [methodId, setMethodId] = useState(methods[0]?.id ?? 0);
  const [msg, setMsg] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  const total = lines.reduce((a, l) => a + Number(l.agreedPrice || 0), 0);

  async function findCustomer() {
    if (!phone.trim()) return;
    const res = await fetch(`/api/customers/lookup?phone=${encodeURIComponent(phone)}`);
    const json = await res.json();
    if (json.ok && json.data.found) {
      setCustomerId(json.data.customer.id);
      setCustomerName(json.data.customer.fullName);
    } else {
      setCustomerId(null);
      setCustomerName('غير مسجّل — سجّله من شاشة العملاء أولًا');
    }
  }

  async function addItem() {
    if (!barcode.trim()) return;
    setMsg(null);
    const res = await fetch(`/api/items/scan?barcode=${encodeURIComponent(barcode)}`);
    const json = await res.json();
    if (!json.ok) { setMsg({ type: 'err', text: json.error?.message ?? 'تعذّر المسح.' }); return; }
    const d = json.data;
    if (lines.some((l) => l.itemId === d.id)) {
      setMsg({ type: 'err', text: 'القطعة مضافة بالفعل في هذا الحجز.' });
      setBarcode(''); return;
    }
    setLines([...lines, {
      itemId: d.id, itemCode: d.itemCode, productName: d.productName,
      agreedPrice: String(d.rentalPrice ?? 0),
    }]);
    setBarcode('');
  }

  async function checkAvailability() {
    if (lines.length === 0 || !pickupDate || !returnDate) return;
    const ids = lines.map((l) => l.itemId).join(',');
    const res = await fetch(
      `/api/reservations/availability?itemIds=${ids}&pickupDate=${pickupDate}&returnDate=${returnDate}`,
    );
    const json = await res.json();
    if (!json.ok) return;
    setMsg(json.data.allAvailable
      ? { type: 'ok', text: 'كل القطع متاحة في هذه الفترة.' }
      : {
          type: 'err',
          text: `تعارض: ${json.data.conflicts.map((c: { itemCode: string }) => c.itemCode).join('، ')}`,
        });
  }

  async function submit() {
    setBusy(true); setMsg(null);
    const res = await fetch('/api/reservations', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        customerId,
        eventDate, pickupDate, returnDate,
        items: lines.map((l) => ({ itemId: l.itemId, agreedPrice: Number(l.agreedPrice) })),
        depositAmount: Number(deposit || 0),
        paymentMethodId: Number(deposit || 0) > 0 ? methodId : undefined,
      }),
    });
    const json = await res.json();
    setBusy(false);
    if (!json.ok) { setMsg({ type: 'err', text: json.error?.message ?? 'تعذّر الحجز.' }); return; }
    setMsg({ type: 'ok', text: `تم الحجز ${json.data.reservationNo}` });
    setLines([]); setPhone(''); setCustomerId(null); setCustomerName('');
    setEventDate(''); setPickupDate(''); setReturnDate(''); setDeposit('');
    router.refresh();
  }

  const update = (i: number, v: string) => {
    const copy = [...lines];
    copy[i] = { ...copy[i], agreedPrice: v };
    setLines(copy);
  };

  return (
    <div className="card">
      <div className="card-header">حجز جديد</div>
      <div className="p-5 space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="label">رقم جوال العميل</label>
            <input className="input num" dir="ltr" value={phone}
                   onChange={(e) => setPhone(e.target.value)}
                   onBlur={findCustomer}
                   onKeyDown={(e) => e.key === 'Enter' && findCustomer()} />
            {customerName && <p className="text-xs text-slate-600 mt-1">{customerName}</p>}
          </div>
          <div>
            <label className="label">امسح باركود القطعة</label>
            <input className="input num" dir="ltr" value={barcode}
                   onChange={(e) => setBarcode(e.target.value)}
                   onKeyDown={(e) => e.key === 'Enter' && addItem()} />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="label">تاريخ الاستلام</label>
            <input className="input num" type="date" value={pickupDate}
                   onChange={(e) => setPickupDate(e.target.value)} onBlur={checkAvailability} />
          </div>
          <div>
            <label className="label">تاريخ الإرجاع</label>
            <input className="input num" type="date" value={returnDate}
                   onChange={(e) => setReturnDate(e.target.value)} onBlur={checkAvailability} />
          </div>
          <div>
            <label className="label">تاريخ المناسبة</label>
            <input className="input num" type="date" value={eventDate}
                   onChange={(e) => setEventDate(e.target.value)} />
          </div>
        </div>

        {lines.length > 0 && (
          <table className="table">
            <thead><tr><th>القطعة</th><th>المنتج</th><th>السعر المتفق عليه</th><th></th></tr></thead>
            <tbody>
              {lines.map((l, i) => (
                <tr key={l.itemId}>
                  <td className="num">{l.itemCode}</td>
                  <td>{l.productName}</td>
                  <td>
                    <input className="input num w-28" dir="ltr" value={l.agreedPrice}
                           onChange={(e) => update(i, e.target.value)} />
                  </td>
                  <td>
                    <button className="text-danger font-semibold"
                            onClick={() => setLines(lines.filter((x) => x.itemId !== l.itemId))}>
                      حذف
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end border-t border-slate-200 pt-4">
          <div>
            <label className="label">العربون (اختياري)</label>
            <input className="input num" dir="ltr" inputMode="decimal" value={deposit}
                   onChange={(e) => setDeposit(e.target.value)} />
          </div>
          {Number(deposit || 0) > 0 && (
            <div>
              <label className="label">طريقة الدفع</label>
              <select className="input" value={methodId}
                      onChange={(e) => setMethodId(Number(e.target.value))}>
                {methods.map((m) => <option key={m.id} value={m.id}>{m.nameAr}</option>)}
              </select>
            </div>
          )}
          <div className="text-lg font-bold text-brand">
            إجمالي الحجز: <span className="num">{total.toFixed(2)}</span>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <button className="btn-primary" onClick={submit}
                  disabled={busy || !customerId || lines.length === 0 || !pickupDate || !returnDate || !eventDate}>
            {busy ? 'جارٍ الحفظ…' : 'تأكيد الحجز'}
          </button>
          <button className="btn-secondary" onClick={checkAvailability}
                  disabled={lines.length === 0 || !pickupDate || !returnDate}>
            فحص التوفر
          </button>
          {msg && (
            <span className={`text-sm font-semibold ${msg.type === 'ok' ? 'text-ok' : 'text-danger'}`}>
              {msg.text}
            </span>
          )}
        </div>

        <p className="text-xs text-slate-400">
          الحجز لا يغيّر حالة القطعة ولا يُنشئ إيرادًا. العربون دخول نقدي يُخصم من العقد عند التحويل.
        </p>
      </div>
    </div>
  );
}
