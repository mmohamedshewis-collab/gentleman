import { route } from '@/lib/api';
import { requireSession } from '@/lib/auth/session';

export const GET = route({
  handler: async () => {
    const s = await requireSession();
    return {
      id: s.id,
      username: s.username,
      fullName: s.fullName,
      role: s.roleNameAr,
      permissions: [...s.permissions],
    };
  },
});
