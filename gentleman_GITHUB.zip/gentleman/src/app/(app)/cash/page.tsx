import Link from 'next/link';
import { dayCashStatement, cashCountPreview } from '@/services/cash.service';
import { getSession } from '@/lib/auth/session';
import { formatEGP } from '@/lib/money';
import { formatDateTime } from '@/lib/date';
import CashCountForm from '@/components/CashCountForm';

export const dynamic = 'force-dynamic';

export default async function CashPage({ searchParams }: { searchParams: { date?: string } }) {
  const session = await getSession();
  const canCount = session?.permissions.has('cash.count') ?? false;
  const canClose = session?.permissions.has('cash.close') ?? false;
  const canTransfer = session?.permissions.has('cash.transfer') ?? false;

  const statement = await dayCashStatement(searchParams.date);
  const preview = canCount ? await cashCountPreview(searchParams.date) : null;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="section-title">كشف الحركات النقدية اليوم</h1>
          <p className="text-sm text-slate-600 mt-1 num">{statement.date}</p>
        </div>
        {(session?.permissions.has('cash.reconcile.view') ?? false) && (
          <Link className="btn-secondary" href="/cash/reconcile">مطابقة الخزينة الشهرية</Link>
        )}
      </div>

      <div className="card overflow-hidden">
        <div className="card-header">حركات اليوم</div>
        <div className="overflow-x-auto">
          <table className="table">
            <thead>
              <tr>
                <th>الوقت</th><th>نوع العملية</th><th>الوصف</th>
                <th>المقبوض</th><th>المدفوع</th><th>العملية المرتبطة</th><th>المستخدم</th>
              </tr>
            </thead>
            <tbody>
              {statement.rows.map((r, i) => (
                <tr key={i}>
                  <td className="num">{formatDateTime(r.at).slice(11)}</td>
                  <td>{r.typeLabel}</td>
                  <td className="text-slate-600">{r.description}</td>
                  <td className="num text-ok">{r.inflow ? formatEGP(r.inflow) : '—'}</td>
                  <td className="num text-danger">{r.outflow ? formatEGP(r.outflow) : '—'}</td>
                  <td className="num">{r.refType ? `${r.refType} #${r.refId}` : '—'}</td>
                  <td>{r.userName ?? '—'}</td>
                </tr>
              ))}
              {statement.rows.length === 0 && (
                <tr><td colSpan={7} className="text-center text-slate-500 py-8">لا توجد حركات نقدية اليوم.</td></tr>
              )}
            </tbody>
            <tfoot>
              <tr className="font-bold bg-brand-soft">
                <td colSpan={3}>الإجمالي</td>
                <td className="num text-ok">{formatEGP(statement.totals.inflow)}</td>
                <td className="num text-danger">{formatEGP(statement.totals.outflow)}</td>
                <td colSpan={2} className="num">
                  صافي الحركة: {formatEGP(statement.totals.net)}
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>

      {preview && (
        <CashCountForm
          preview={preview}
          canClose={canClose}
          canTransfer={canTransfer}
        />
      )}
    </div>
  );
}
