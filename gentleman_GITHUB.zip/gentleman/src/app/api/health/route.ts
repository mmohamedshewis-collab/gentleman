import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

/**
 * فحص الصحة للمراقبة الخارجية.
 * يعيد الحالة فقط بلا أي بيانات أو إصدارات أو أعداد — لا تسريب معلومات.
 */
export async function GET() {
  try {
    await prisma.$queryRaw`SELECT 1`;
    return NextResponse.json({ status: 'ok' }, { headers: { 'Cache-Control': 'no-store' } });
  } catch {
    return NextResponse.json({ status: 'error' }, { status: 503, headers: { 'Cache-Control': 'no-store' } });
  }
}
