import { z } from 'zod';
import { route } from '@/lib/api';
import { availabilityCheck } from '@/services/reservation.service';

export const GET = route({
  schema: z.object({
    itemIds: z.string(),
    pickupDate: z.string(),
    returnDate: z.string(),
  }),
  handler: ({ input }) => availabilityCheck({
    itemIds: input.itemIds.split(',').map(Number).filter(Number.isFinite),
    pickupDate: input.pickupDate,
    returnDate: input.returnDate,
  }),
});
