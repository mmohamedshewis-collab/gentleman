import { route } from '@/lib/api';
import { paySalary, salarySchema } from '@/services/advance.service';

export const POST = route({ schema: salarySchema, handler: ({ input }) => paySalary(input) });
