BEGIN;
SELECT pg_sleep(0.15);
INSERT INTO item_bookings (item_id, start_date, end_date, source_type, source_id)
VALUES (3, CURRENT_DATE+30, CURRENT_DATE+32, 'RESERVATION', floor(random()*100000)::int);
COMMIT;
