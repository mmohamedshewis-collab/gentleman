import { route } from '@/lib/api';
import { listCategories, createCategory, categorySchema } from '@/services/catalog.service';

export const GET = route({ handler: () => listCategories() });
export const POST = route({ schema: categorySchema, handler: ({ input }) => createCategory(input) });
