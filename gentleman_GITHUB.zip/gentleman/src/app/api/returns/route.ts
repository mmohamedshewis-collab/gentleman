import { route } from '@/lib/api';
import {
  createReturn, createReturnSchema,
  voidReturn, voidReturnSchema,
  listReturns, returnQuerySchema,
} from '@/services/return.service';

export const GET = route({ schema: returnQuerySchema, handler: ({ input }) => listReturns(input) });
export const POST = route({ schema: createReturnSchema, handler: ({ input }) => createReturn(input) });
export const PATCH = route({ schema: voidReturnSchema, handler: ({ input }) => voidReturn(input) });
