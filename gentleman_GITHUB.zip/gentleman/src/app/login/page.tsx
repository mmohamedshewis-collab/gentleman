'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function LoginPage() {
  const router = useRouter();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function submit() {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
      });
      const json = await res.json();
      if (!json.ok) {
        setError(json.error?.message ?? 'تعذّر تسجيل الدخول.');
        return;
      }
      router.replace('/');
      router.refresh();
    } catch {
      setError('تعذّر الاتصال بالخادم.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="min-h-screen grid place-items-center bg-brand px-4">
      <div className="w-full max-w-sm">
        <div className="text-center mb-6">
          <h1 className="text-white text-3xl font-bold tracking-wide">Gentleman</h1>
          <p className="text-brand-soft text-sm mt-1">نظام إدارة تأجير وبيع البدلات</p>
        </div>

        <div className="card p-6">
          <h2 className="section-title mb-4">تسجيل الدخول</h2>

          <label className="label" htmlFor="u">اسم المستخدم</label>
          <input
            id="u" className="input mb-4" autoFocus dir="ltr"
            value={username} onChange={(e) => setUsername(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && submit()}
          />

          <label className="label" htmlFor="p">كلمة المرور</label>
          <input
            id="p" type="password" className="input mb-4" dir="ltr"
            value={password} onChange={(e) => setPassword(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && submit()}
          />

          {error && (
            <p className="text-danger text-sm font-semibold mb-3 bg-red-50 rounded-lg px-3 py-2">
              {error}
            </p>
          )}

          <button className="btn-primary w-full" onClick={submit} disabled={loading}>
            {loading ? 'جارٍ الدخول…' : 'دخول'}
          </button>
        </div>
      </div>
    </main>
  );
}
