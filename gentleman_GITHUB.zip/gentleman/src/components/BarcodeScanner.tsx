'use client';

import { useEffect, useRef, useState } from 'react';

/**
 * قارئ الباركود يعمل كلوحة مفاتيح: يكتب الكود بسرعة ثم Enter.
 * الحقل يبقى مركّزًا تلقائيًا حتى لا يحتاج الموظف للماوس إطلاقًا.
 */
export default function BarcodeScanner({
  onScan, placeholder = 'امسح الباركود أو اكتب كود القطعة…', autoFocus = true,
}: {
  onScan: (code: string) => void | Promise<void>;
  placeholder?: string;
  autoFocus?: boolean;
}) {
  const ref = useRef<HTMLInputElement>(null);
  const [value, setValue] = useState('');

  useEffect(() => {
    if (autoFocus) ref.current?.focus();
  }, [autoFocus]);

  // إعادة التركيز عند أي ضغطة مفتاح خارج حقول الإدخال الأخرى
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      const typingElsewhere = ['INPUT', 'TEXTAREA', 'SELECT'].includes(target.tagName);
      if (!typingElsewhere && e.key.length === 1) ref.current?.focus();
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, []);

  return (
    <div className="flex gap-2">
      <input
        ref={ref}
        className="input text-lg num"
        dir="ltr"
        placeholder={placeholder}
        value={value}
        onChange={(e) => setValue(e.target.value)}
        onKeyDown={async (e) => {
          if (e.key === 'Enter' && value.trim()) {
            const code = value.trim();
            setValue('');
            await onScan(code);
            ref.current?.focus();
          }
        }}
      />
      <button
        className="btn-primary shrink-0"
        onClick={async () => {
          if (!value.trim()) return;
          const code = value.trim();
          setValue('');
          await onScan(code);
          ref.current?.focus();
        }}
      >
        بحث
      </button>
    </div>
  );
}
