import { z } from 'zod';
import { route } from '@/lib/api';
import { scanForSale } from '@/services/sale.service';

export const GET = route({
  schema: z.object({ barcode: z.string().min(1) }),
  handler: ({ input }) => scanForSale(input.barcode),
});
