import { z } from 'zod';
import { prisma } from '@/lib/db';
import { Errors } from '@/lib/errors';
import { writeAudit } from '@/lib/audit';
import { requirePermission } from '@/lib/auth/rbac';
import { formatDateTime } from '@/lib/date';
import { getStorage, isR2Configured } from '@/lib/storage/object-storage';
import {
  EXPORT_TABLES, buildExportKey, buildManifest, validateExport,
  EXPORT_NOTICE, type ExportTable,
} from '@/lib/backup/export-plan';

/**
 * تصدير البيانات.
 *
 * ⛔ **لا يوجد مسار استعادة في هذا الملف ولا في النظام كله.**
 *    استعادة قاعدة البيانات تتم خارج التطبيق عبر Neon PITR بإجراء موثّق،
 *    لأن الاستعادة فوق قاعدة حية عملية تدميرية لا رجعة فيها.
 */

export const exportHistorySchema = z.object({
  limit: z.coerce.number().int().min(1).max(100).default(20),
});

/** قارئ كل جدول — يقرأ فقط ولا يكتب. */
const READERS: Record<ExportTable, () => Promise<unknown[]>> = {
  customers: () => prisma.customer.findMany(),
  products: () => prisma.product.findMany(),
  productItems: () => prisma.productItem.findMany(),
  rentals: () => prisma.rental.findMany(),
  rentalItems: () => prisma.rentalItem.findMany(),
  returns: () => prisma.return.findMany(),
  returnItems: () => prisma.returnItem.findMany(),
  sales: () => prisma.sale.findMany(),
  saleItems: () => prisma.saleItem.findMany(),
  payments: () => prisma.payment.findMany(),
  insuranceTransactions: () => prisma.insuranceTransaction.findMany(),
  expenses: () => prisma.expense.findMany(),
  employees: () => prisma.employee.findMany(),
  commissions: () => prisma.commission.findMany(),
  employeeAdvances: () => prisma.employeeAdvance.findMany(),
  employeeAdvanceRepayments: () => prisma.employeeAdvanceRepayment.findMany(),
  dailyCashClosings: () => prisma.dailyCashClosing.findMany(),
  cashTransfers: () => prisma.cashTransfer.findMany(),
  itemStatusHistory: () => prisma.itemStatusHistory.findMany(),
  inventoryTransactions: () => prisma.inventoryTransaction.findMany(),
};

/** يحوّل Decimal و Date إلى نصوص حتى لا تفقد الدقة في JSON. */
const serialize = (value: unknown): unknown =>
  JSON.parse(JSON.stringify(value, (_k, v) => {
    if (v instanceof Date) return v.toISOString();
    if (typeof v === 'bigint') return v.toString();
    if (v && typeof v === 'object' && 'toFixed' in (v as object)) return String(v);
    return v;
  }));

/**
 * ★ نواة التصدير — **مصدر الحقيقة الوحيد**.
 *   يستدعيها مساران: التصدير اليدوي (بصلاحية `backup.run`)
 *   والمهمة المجدولة (بسر `CRON_SECRET`). لا تكرار لقائمة الجداول
 *   ولا للتحقق ولا لكتابة `backup_runs`.
 *
 * ⛔ لا تفحص صلاحية بنفسها — الفحص مسؤولية المستدعي.
 */
export async function performDataExport(triggeredBy: number | null) {
  const startedAt = new Date();

  const run = await prisma.backupRun.create({
    data: { startedAt, status: 'RUNNING', triggeredBy },
  });

  try {
    const payload: Record<string, unknown[]> = {};
    const counts: { name: string; rowCount: number }[] = [];

    for (const table of EXPORT_TABLES) {
      const rows = await READERS[table]();
      payload[table] = serialize(rows) as unknown[];
      counts.push({ name: table, rowCount: rows.length });
    }

    const manifest = buildManifest(counts, startedAt);
    const validation = validateExport(manifest, Object.keys(payload));
    if (!validation.ok) throw new Error(validation.message);

    const key = buildExportKey(startedAt);
    const body = JSON.stringify({ manifest, data: payload }, null, 2);
    await getStorage().put(key, body, 'application/json');

    const finished = await prisma.backupRun.update({
      where: { id: run.id },
      data: {
        finishedAt: new Date(),
        status: 'SUCCESS',
        storageKey: key,
        validationResult: validation.message,
        rowCount: manifest.totalRows,
      },
    });

    await writeAudit({
      userId: triggeredBy,
      action: 'backup.export',
      entityType: 'BackupRun',
      entityId: run.id,
      after: {
        storageKey: key,
        rowCount: manifest.totalRows,
        tables: counts.length,
        validation: validation.message,
        storage: isR2Configured() ? 'R2' : 'memory',
      },
    });

    return {
      id: finished.id,
      status: finished.status,
      storageKey: key,
      rowCount: manifest.totalRows,
      tables: counts.length,
      validationResult: validation.message,
      notice: EXPORT_NOTICE,
      storageConfigured: isR2Configured(),
    };
  } catch (e) {
    const message = (e as Error).message;
    await prisma.backupRun.update({
      where: { id: run.id },
      data: { finishedAt: new Date(), status: 'FAILED', errorMessage: message },
    });
    await writeAudit({
      userId: triggeredBy,
      action: 'backup.export_failed',
      entityType: 'BackupRun',
      entityId: run.id,
      after: { error: message },
    });
    throw Errors.rule(`فشل تصدير البيانات: ${message}`);
  }
}

/** التصدير اليدوي — يفحص الصلاحية ثم يستدعي النواة نفسها. */
export async function runDataExport() {
  const actor = await requirePermission('backup.run');
  return performDataExport(actor.id);
}

export async function exportHistory(input: z.infer<typeof exportHistorySchema>) {
  await requirePermission('backup.run');
  const rows = await prisma.backupRun.findMany({
    orderBy: { id: 'desc' },
    take: input.limit,
  });

  return {
    notice: EXPORT_NOTICE,
    storageConfigured: isR2Configured(),
    rows: rows.map((r) => ({
      id: r.id,
      startedAt: formatDateTime(r.startedAt),
      finishedAt: r.finishedAt ? formatDateTime(r.finishedAt) : null,
      status: r.status,
      storageKey: r.storageKey,
      rowCount: r.rowCount,
      validationResult: r.validationResult,
      errorMessage: r.errorMessage,
    })),
  };
}
