\set ON_ERROR_STOP off
\t on
\echo '--- تعطيل Trigger منع الحذف مؤقتًا لعزل اختبار المفتاح الأجنبي ---'
ALTER TABLE rentals DISABLE TRIGGER trg_no_delete;
\echo '--- الآن الحذف يواجه ON DELETE RESTRICT وحده ---'
DELETE FROM rentals WHERE rental_no='R-M13-1';
\echo '--- إعادة تفعيل الحماية ---'
ALTER TABLE rentals ENABLE TRIGGER trg_no_delete;
SELECT '  العقد ما زال موجودًا: ' || count(*) FROM rentals WHERE rental_no='R-M13-1';
SELECT '  Trigger أُعيد تفعيله: ' || tgenabled::text FROM pg_trigger WHERE tgname='trg_no_delete' AND tgrelid='rentals'::regclass;
