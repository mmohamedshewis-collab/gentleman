/**
 * كتالوج الإعدادات — تعريفات خالصة بلا أي اعتماد على قاعدة البيانات.
 * لا توجد أي قيمة مالية مثبتة داخل الكود خارج هذا الملف، وكلها قابلة للتعديل.
 * (قرارات Q4 / Q9 / Q11 / Q13 / Q14 + الضريبة الاختيارية)
 */
export const SETTING_DEFS = [
  // بيانات المحل
  { key: 'shop.name', nameAr: 'اسم المحل', group: 'المحل', dataType: 'STRING', value: 'Gentleman' },
  { key: 'shop.brand', nameAr: 'اسم البراند', group: 'المحل', dataType: 'STRING', value: 'Gentleman' },
  { key: 'shop.phone', nameAr: 'هاتف المحل', group: 'المحل', dataType: 'STRING', value: '' },
  { key: 'shop.address', nameAr: 'عنوان المحل', group: 'المحل', dataType: 'STRING', value: '' },
  { key: 'shop.logo_path', nameAr: 'مسار الشعار', group: 'المحل', dataType: 'STRING', value: '' },

  // التأجير
  { key: 'rental.default_days', nameAr: 'مدة التأجير الافتراضية (أيام)', group: 'التأجير', dataType: 'NUMBER', value: 1 },
  { key: 'rental.late_fee_per_item_per_day', nameAr: 'رسوم التأخير لكل قطعة في اليوم', group: 'التأجير', dataType: 'NUMBER', value: 0 },
  { key: 'rental.late_fee_cap_per_item', nameAr: 'الحد الأقصى لغرامة التأخير للقطعة (0 = بلا حد)', group: 'التأجير', dataType: 'NUMBER', value: 0 },
  { key: 'rental.default_insurance', nameAr: 'قيمة التأمين الافتراضية', group: 'التأجير', dataType: 'NUMBER', value: 0 },
  { key: 'rental.deposit_refundable_on_shop_cancel', nameAr: 'رد العربون عند إلغاء المحل', group: 'التأجير', dataType: 'BOOLEAN', value: true },
  { key: 'rental.deposit_refundable_on_customer_cancel', nameAr: 'رد العربون عند إلغاء العميل', group: 'التأجير', dataType: 'BOOLEAN', value: false },

  // التنظيف والصيانة
  { key: 'cleaning.enabled', nameAr: 'تفعيل مرحلة التنظيف بعد الإرجاع', group: 'التشغيل', dataType: 'BOOLEAN', value: false },

  // التأمين — أموال العملاء، سجل مستقل عن إيرادات المحل
  { key: 'insurance.dormant_days', nameAr: 'أيام ركود التأمين قبل التنبيه', group: 'التأمين', dataType: 'NUMBER', value: 90 },
  { key: 'insurance.opening_balance', nameAr: 'رصيد التأمينات الافتتاحي', group: 'التأمين', dataType: 'NUMBER', value: 0 },


  // ضريبة القيمة المضافة — المحل غير خاضع لها حاليًا.
  // النسبة محفوظة للمستقبل فقط ولا تُقرأ ولا تُطبَّق ما دام vat.enabled = false.
  { key: 'vat.enabled', nameAr: 'خضوع المحل لضريبة القيمة المضافة', group: 'الضريبة', dataType: 'BOOLEAN', value: false },
  { key: 'vat.rate', nameAr: 'نسبة ضريبة القيمة المضافة % (للمستقبل)', group: 'الضريبة', dataType: 'NUMBER', value: 14 },
  { key: 'vat.label', nameAr: 'مسمى الضريبة في الفاتورة', group: 'الضريبة', dataType: 'STRING', value: 'ضريبة القيمة المضافة' },
  { key: 'vat.registration_no', nameAr: 'رقم التسجيل الضريبي', group: 'الضريبة', dataType: 'STRING', value: '' },
  { key: 'vat.activated_at', nameAr: 'تاريخ تفعيل الضريبة', group: 'الضريبة', dataType: 'STRING', value: '' },

  // العمولات والخصم
  { key: 'commission.rental_percent', nameAr: 'نسبة عمولة التأجير %', group: 'الموظفون', dataType: 'NUMBER', value: 0 },
  { key: 'commission.sales_percent', nameAr: 'نسبة عمولة البيع %', group: 'الموظفون', dataType: 'NUMBER', value: 0 },
  { key: 'expenses.staff_max_amount', nameAr: 'أقصى مبلغ مصروف يسجّله الموظف (0 = ممنوع)', group: 'المصروفات', dataType: 'NUMBER', value: 0 },
  { key: 'discount.staff_max_percent', nameAr: 'أقصى خصم مسموح للموظف %', group: 'الموظفون', dataType: 'NUMBER', value: 0 },

  // عام
  { key: 'app.currency', nameAr: 'العملة', group: 'عام', dataType: 'STRING', value: 'EGP' },
  { key: 'app.timezone', nameAr: 'المنطقة الزمنية', group: 'عام', dataType: 'STRING', value: 'Africa/Cairo' },
] as const;

export type SettingKey = (typeof SETTING_DEFS)[number]['key'];
