'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export interface PayableEmployee {
  id: number;
  code: string;
  fullName: string;
  jobTitle: string | null;
  monthlySalary: string;
}

export interface CommissionRow {
  employeeId: number;
  fullName: string;
  payable: string;
  paid: string;
  isPaid: boolean;
  carryForward: string;
  priorVarianceTotal: string;
  expense: { expenseNo: string } | null;
}

interface Props {
  employees: PayableEmployee[];
  methods: { id: number; nameAr: string }[];
  commissions: CommissionRow[];
  periodMonth: string;
  canPayCommission: boolean;
  canPaySalary: boolean;
  canCreateAdvance: boolean;
}

const egp = (v: string | number) =>
  new Intl.NumberFormat('ar-EG', { numberingSystem: 'latn', minimumFractionDigits: 2 })
    .format(Number(v));

/**
 * لوحة صرف واحدة للموظفين — تُستخدم للعمولة والراتب والسلفة.
 * اختيار الموظف موحّد فلا تتكرر الشاشات.
 */
export default function EmployeePaymentPanel({
  employees, methods, commissions, periodMonth,
  canPayCommission, canPaySalary, canCreateAdvance,
}: Props) {
  const router = useRouter();
  const [employeeId, setEmployeeId] = useState<number | null>(employees[0]?.id ?? null);
  const [kind, setKind] = useState<'COMMISSION' | 'SALARY' | 'ADVANCE'>('COMMISSION');
  const [methodId, setMethodId] = useState(methods[0]?.id ?? 0);
  const [amount, setAmount] = useState('');
  const [notes, setNotes] = useState('');
  const [msg, setMsg] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  const selected = employees.find((e) => e.id === employeeId) ?? null;
  const row = commissions.find((c) => c.employeeId === employeeId) ?? null;

  async function submit() {
    if (!employeeId) return;
    setBusy(true); setMsg(null);

    let url = '';
    let body: Record<string, unknown> = {};

    if (kind === 'COMMISSION') {
      url = '/api/commissions/pay';
      body = { employeeId, periodMonth, paymentMethodId: methodId, notes };
    } else if (kind === 'SALARY') {
      url = '/api/salaries';
      body = {
        employeeId,
        grossSalary: Number(amount || selected?.monthlySalary || 0),
        advanceIds: [],
        otherDeductions: 0,
        paymentMethodId: methodId,
        notes,
      };
    } else {
      url = '/api/advances';
      body = { employeeId, amount: Number(amount), paymentMethodId: methodId, notes };
    }

    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    const json = await res.json();
    setBusy(false);
    if (!json.ok) { setMsg({ type: 'err', text: json.error?.message ?? 'تعذّر التنفيذ.' }); return; }

    setMsg({ type: 'ok', text: 'تمت العملية وسُجِّلت في سجل التدقيق.' });
    setAmount(''); setNotes('');
    router.refresh();
  }

  return (
    <div className="card">
      <div className="card-header">صرف مستحقات موظف</div>
      <div className="p-5 space-y-4">
        <div>
          <label className="label">اختر الموظف</label>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {employees.map((e) => (
              <button
                key={e.id}
                onClick={() => setEmployeeId(e.id)}
                className={`rounded-lg border p-3 text-right transition ${
                  employeeId === e.id
                    ? 'border-brand bg-brand-soft'
                    : 'border-slate-200 hover:border-brand-light'
                }`}
              >
                <div className="flex items-center gap-2">
                  <span className="grid place-items-center w-8 h-8 rounded-full bg-brand text-white text-xs font-bold shrink-0">
                    {e.fullName.trim().charAt(0)}
                  </span>
                  <span className="min-w-0">
                    <span className="block font-semibold text-sm truncate">{e.fullName}</span>
                    <span className="block text-xs text-slate-500 num">{e.code}</span>
                  </span>
                </div>
              </button>
            ))}
            {employees.length === 0 && (
              <p className="text-sm text-slate-500 col-span-4">لا يوجد موظفون نشطون.</p>
            )}
          </div>
        </div>

        {selected && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end border-t border-slate-200 pt-4">
            <div>
              <label className="label">نوع الصرف</label>
              <select className="input" value={kind}
                      onChange={(e) => setKind(e.target.value as typeof kind)}>
                {canPayCommission && <option value="COMMISSION">عمولة</option>}
                {canPaySalary && <option value="SALARY">راتب</option>}
                {canCreateAdvance && <option value="ADVANCE">سلفة</option>}
              </select>
            </div>

            <div>
              <label className="label">
                {kind === 'COMMISSION' ? 'المبلغ المستحق' : 'المبلغ'}
              </label>
              {kind === 'COMMISSION' ? (
                <input className="input num" dir="ltr" readOnly
                       value={row ? egp(row.payable) : '0.00'} />
              ) : (
                <input
                  className="input num" dir="ltr" inputMode="decimal"
                  placeholder={kind === 'SALARY' ? egp(selected.monthlySalary) : ''}
                  value={amount} onChange={(e) => setAmount(e.target.value)}
                />
              )}
            </div>

            <div>
              <label className="label">طريقة الدفع</label>
              <select className="input" value={methodId}
                      onChange={(e) => setMethodId(Number(e.target.value))}>
                {methods.map((m) => <option key={m.id} value={m.id}>{m.nameAr}</option>)}
              </select>
            </div>

            <div>
              <label className="label">ملاحظات</label>
              <input className="input" value={notes} onChange={(e) => setNotes(e.target.value)} />
            </div>
          </div>
        )}

        {kind === 'COMMISSION' && row && (
          <div className="rounded-lg bg-brand-soft border border-brand-light/30 p-4 text-sm space-y-1">
            <div>عمولة الفترة المستحقة: <span className="num font-bold">{egp(row.payable)}</span></div>
            {Number(row.priorVarianceTotal) !== 0 && (
              <div className={Number(row.priorVarianceTotal) < 0 ? 'text-danger' : 'text-ok'}>
                فروق فترات سابقة: <span className="num font-bold">{egp(row.priorVarianceTotal)}</span>
              </div>
            )}
            {Number(row.carryForward) !== 0 && (
              <div className="text-warn">
                مُرحَّل للفترة التالية: <span className="num font-bold">{egp(row.carryForward)}</span>
              </div>
            )}
            {row.isPaid && (
              <div className="text-slate-600">
                مصروفة بالفعل بمصروف <span className="num">{row.expense?.expenseNo}</span>
              </div>
            )}
          </div>
        )}

        <div className="flex items-center gap-4">
          <button
            className="btn-primary"
            disabled={
              busy || !employeeId ||
              (kind === 'COMMISSION' && (!row || row.isPaid || Number(row.payable) <= 0)) ||
              (kind === 'ADVANCE' && !amount)
            }
            onClick={submit}
          >
            {busy ? 'جارٍ التنفيذ…' : 'تنفيذ الصرف'}
          </button>
          {msg && (
            <span className={`text-sm font-semibold ${msg.type === 'ok' ? 'text-ok' : 'text-danger'}`}>
              {msg.text}
            </span>
          )}
        </div>

        <p className="text-xs text-slate-400">
          صرف العمولة يُنشئ مصروفًا واحدًا في تصنيف «عمولات» مربوطًا بسجل الصرف، وهو نفسه
          الخروج النقدي. السلفة خروج نقدي وليست مصروفًا.
        </p>
      </div>
    </div>
  );
}
