import { describe, it, expect, vi, beforeEach } from 'vitest';

/** اختبارات خدمة المدفوعات والمصروفات: الصلاحيات، الرفض، التدقيق، الأثر. */

const auditSpy = vi.fn();
let currentUser: { id: number; employeeId: number | null; permissions: Set<string> };
let rentalRow: { id: number; rental_no: string; status: string; total_due: string; paid_amount: string } | null;
let paymentRow: { id: number; payment_no: string; is_voided: boolean; amount: string; is_insurance: boolean } | null;
let expenseRow: { id: number; expense_no: string; is_voided: boolean; amount: string } | null;
let linkedCommission: { id: number } | null;
let settings: Record<string, number>;

const created: Record<string, unknown[]> = {};
const record = (k: string) => (a: { data: Record<string, unknown> }) => {
  (created[k] ??= []).push(a.data);
  return { id: created[k].length, ...a.data };
};

const tx = {
  $queryRaw: vi.fn(async (strings: TemplateStringsArray) => {
    const q = strings.join(' ');
    if (q.includes('FROM rentals')) return rentalRow ? [rentalRow] : [];
    if (q.includes('FROM payments')) return paymentRow ? [paymentRow] : [];
    if (q.includes('FROM expenses')) return expenseRow ? [expenseRow] : [];
    return [];
  }),
  $executeRaw: vi.fn(async () => 1),
  paymentMethod: { findUnique: vi.fn(async () => ({ id: 1, nameAr: 'نقدي', isActive: true })) },
  expenseCategory: { findUnique: vi.fn(async () => ({ id: 1, nameAr: 'كهرباء', isActive: true })) },
  payment: {
    findFirst: vi.fn(async () => null),
    create: vi.fn(record('payment')),
    update: vi.fn(async (a: any) => ({ id: 1, paymentNo: 'PAY-2026-000001', ...a.data })),
  },
  expense: {
    findFirst: vi.fn(async () => null),
    create: vi.fn(record('expense')),
    update: vi.fn(async (a: any) => ({ id: 1, expenseNo: 'EXP-2026-000001', ...a.data })),
  },
  commission: { findFirst: vi.fn(async () => linkedCommission) },
  rental: { findUnique: vi.fn(async () => ({ paidAmount: '400', remainingAmount: '600' })) },
};

vi.mock('@/lib/db', () => ({
  prisma: {
    $transaction: (fn: any) => fn(tx),
    payment: { findMany: vi.fn(async () => []), count: vi.fn(async () => 0) },
    expense: {
      findMany: vi.fn(async () => []),
      count: vi.fn(async () => 0),
      aggregate: vi.fn(async () => ({ _sum: { amount: 0 } })),
    },
  },
}));

vi.mock('@/lib/audit', () => ({ writeAudit: (...a: any[]) => auditSpy(...a), redact: (x: any) => x }));

vi.mock('@/lib/settings', () => ({
  getNumberSetting: async (k: string) => {
    const { Decimal } = await import('decimal.js');
    return new Decimal(settings[k] ?? 0);
  },
  getBoolSetting: async () => false,
  getStringSetting: async () => '',
}));

vi.mock('@/lib/auth/rbac', async (importOriginal) => {
  const actual = await importOriginal<typeof import('@/lib/auth/rbac')>();
  return {
    ...actual,
    requirePermission: async (perm: string) => {
      if (!currentUser.permissions.has(perm)) {
        const { Errors } = await import('@/lib/errors');
        throw Errors.forbidden(perm);
      }
      return currentUser as never;
    },
  };
});

const asStaff = () => { currentUser = { id: 9, employeeId: 3, permissions: new Set(['payments.view', 'payments.create', 'expenses.view', 'expenses.create']) }; };
const asAdmin = () => {
  currentUser = {
    id: 1, employeeId: 1,
    permissions: new Set([
      'payments.view', 'payments.create', 'payments.void',
      'expenses.view', 'expenses.create', 'expenses.void',
      'expenses.limit.override',
    ]),
  };
};

beforeEach(() => {
  auditSpy.mockClear();
  for (const k of Object.keys(created)) delete created[k];
  for (const m of Object.values(tx)) {
    if (typeof m === 'object' && m !== null) {
      for (const f of Object.values(m)) if (typeof f === 'function' && 'mockClear' in f) (f as any).mockClear();
    } else if (typeof m === 'function' && 'mockClear' in m) (m as any).mockClear();
  }
  rentalRow = { id: 1, rental_no: 'R-2026-000001', status: 'ACTIVE', total_due: '1000', paid_amount: '300' };
  paymentRow = { id: 1, payment_no: 'PAY-2026-000001', is_voided: false, amount: '300', is_insurance: false };
  expenseRow = { id: 1, expense_no: 'EXP-2026-000001', is_voided: false, amount: '500' };
  linkedCommission = null;
  settings = { 'expenses.staff_max_amount': 0 };
  asAdmin();
});

describe('تحصيل دفعة على عقد', () => {
  it('يسجّل الدفعة ويسجّل التدقيق ولا يكتب المدفوع يدويًا', async () => {
    const { collectRentalPayment } = await import('@/services/finance.service');
    const r = await collectRentalPayment({ rentalId: 1, amount: 400, paymentMethodId: 1 });

    expect(created.payment[0]).toMatchObject({
      purpose: 'RENTAL', isInsurance: false, amount: '400', rentalId: 1,
    });
    // المدفوع والمتبقي يأتيان من القاعدة لا من الكود
    expect(r.rentalPaid).toBe('400');
    expect(r.rentalRemaining).toBe('600');
    expect(auditSpy.mock.calls[0][0]).toMatchObject({ action: 'payment.create', entityType: 'Payment' });
  });

  it('يرفض دفعة تتجاوز المتبقي', async () => {
    const { collectRentalPayment } = await import('@/services/finance.service');
    await expect(collectRentalPayment({ rentalId: 1, amount: 900, paymentMethodId: 1 }))
      .rejects.toMatchObject({ code: 'BUSINESS_RULE' });
    expect(created.payment).toBeUndefined();
    expect(auditSpy).not.toHaveBeenCalled();
  });

  it('يقبل السداد الكامل للمتبقي بالضبط', async () => {
    const { collectRentalPayment } = await import('@/services/finance.service');
    await expect(collectRentalPayment({ rentalId: 1, amount: 700, paymentMethodId: 1 })).resolves.toBeTruthy();
  });

  it('يرفض الدفعة على عقد ملغى', async () => {
    rentalRow!.status = 'VOIDED';
    const { collectRentalPayment } = await import('@/services/finance.service');
    await expect(collectRentalPayment({ rentalId: 1, amount: 100, paymentMethodId: 1 }))
      .rejects.toMatchObject({ code: 'BUSINESS_RULE' });
  });

  it('يسمح بالتحصيل على عقد مغلق عليه متبقٍ', async () => {
    rentalRow!.status = 'CLOSED';
    const { collectRentalPayment } = await import('@/services/finance.service');
    await expect(collectRentalPayment({ rentalId: 1, amount: 700, paymentMethodId: 1 })).resolves.toBeTruthy();
  });

  it('يرفض عقدًا غير موجود قبل أي كتابة', async () => {
    rentalRow = null;
    const { collectRentalPayment } = await import('@/services/finance.service');
    await expect(collectRentalPayment({ rentalId: 99, amount: 100, paymentMethodId: 1 }))
      .rejects.toMatchObject({ code: 'NOT_FOUND' });
    expect(auditSpy).not.toHaveBeenCalled();
  });

  it('يرفض المبلغ الصفري أو السالب من التحقق', async () => {
    const { rentalPaymentSchema } = await import('@/services/finance.service');
    expect(rentalPaymentSchema.safeParse({ rentalId: 1, amount: 0, paymentMethodId: 1 }).success).toBe(false);
    expect(rentalPaymentSchema.safeParse({ rentalId: 1, amount: -5, paymentMethodId: 1 }).success).toBe(false);
  });

  it('التحصيل يحتاج صلاحية payments.create', async () => {
    currentUser = { id: 4, employeeId: null, permissions: new Set(['payments.view']) };
    const { collectRentalPayment } = await import('@/services/finance.service');
    await expect(collectRentalPayment({ rentalId: 1, amount: 100, paymentMethodId: 1 }))
      .rejects.toMatchObject({ code: 'PERM_DENIED' });
  });
});

describe('إلغاء دفعة', () => {
  it('يلغي ولا يحذف ويسجّل التدقيق', async () => {
    const { voidPayment } = await import('@/services/finance.service');
    const r = await voidPayment({ paymentId: 1, reason: 'خطأ في المبلغ' });
    expect(r.status).toBe('ملغاة');
    expect(tx.payment.update).toHaveBeenCalledWith(
      expect.objectContaining({ data: expect.objectContaining({ isVoided: true }) }),
    );
    expect(auditSpy.mock.calls[0][0]).toMatchObject({
      action: 'payment.void', before: { isVoided: false }, after: { isVoided: true }, reason: 'خطأ في المبلغ',
    });
  });

  it('يرفض إلغاء دفعة ملغاة', async () => {
    paymentRow!.is_voided = true;
    const { voidPayment } = await import('@/services/finance.service');
    await expect(voidPayment({ paymentId: 1, reason: 'محاولة ثانية' }))
      .rejects.toMatchObject({ code: 'BUSINESS_RULE' });
  });

  it('يرفض إلغاء دفعة تأمين من هذا المسار', async () => {
    paymentRow!.is_insurance = true;
    const { voidPayment } = await import('@/services/finance.service');
    await expect(voidPayment({ paymentId: 1, reason: 'محاولة' }))
      .rejects.toMatchObject({ code: 'BUSINESS_RULE' });
  });

  it('الموظف لا يستطيع إلغاء دفعة', async () => {
    asStaff();
    const { voidPayment } = await import('@/services/finance.service');
    await expect(voidPayment({ paymentId: 1, reason: 'محاولة' }))
      .rejects.toMatchObject({ code: 'PERM_DENIED', details: { permission: 'payments.void' } });
  });

  it('سبب الإلغاء إلزامي', async () => {
    const { voidPaymentSchema } = await import('@/services/finance.service');
    expect(voidPaymentSchema.safeParse({ paymentId: 1 }).success).toBe(false);
    expect(voidPaymentSchema.safeParse({ paymentId: 1, reason: 'سبب' }).success).toBe(true);
  });
});

describe('المصروفات', () => {
  it('يسجّل المصروف ويسجّل التدقيق', async () => {
    const { createExpense } = await import('@/services/finance.service');
    const r = await createExpense({ categoryId: 1, amount: 500, paymentMethodId: 1 });
    expect(r.amount).toBe('500');
    expect(created.expense[0]).toMatchObject({ amount: '500', categoryId: 1 });
    expect(auditSpy.mock.calls[0][0]).toMatchObject({ action: 'expense.create', entityType: 'Expense' });
  });

  it('يرفض المبلغ الصفري أو السالب', async () => {
    const { expenseSchema } = await import('@/services/finance.service');
    expect(expenseSchema.safeParse({ categoryId: 1, amount: 0, paymentMethodId: 1 }).success).toBe(false);
    expect(expenseSchema.safeParse({ categoryId: 1, amount: -1, paymentMethodId: 1 }).success).toBe(false);
  });

  it('يرفض التاريخ المستقبلي', async () => {
    const { createExpense } = await import('@/services/finance.service');
    const future = new Date(Date.now() + 5 * 86400000).toISOString().slice(0, 10);
    await expect(createExpense({ categoryId: 1, amount: 100, paymentMethodId: 1, expenseDate: future }))
      .rejects.toMatchObject({ code: 'BUSINESS_RULE' });
  });

  it('★ الموظف ممنوع من تسجيل المصروف ما دام السقف صفرًا (الافتراضي)', async () => {
    asStaff();
    const { createExpense } = await import('@/services/finance.service');
    await expect(createExpense({ categoryId: 1, amount: 50, paymentMethodId: 1 }))
      .rejects.toMatchObject({ code: 'PERM_DENIED' });
  });

  it('عند تحديد سقف: الموظف يسجّل تحته ويُرفض فوقه', async () => {
    asStaff();
    settings['expenses.staff_max_amount'] = 200;
    const { createExpense } = await import('@/services/finance.service');
    await expect(createExpense({ categoryId: 1, amount: 150, paymentMethodId: 1 })).resolves.toBeTruthy();
    await expect(createExpense({ categoryId: 1, amount: 250, paymentMethodId: 1 }))
      .rejects.toMatchObject({ code: 'PERM_DENIED' });
  });

  it('المدير غير مقيّد بالسقف', async () => {
    settings['expenses.staff_max_amount'] = 200;
    const { createExpense } = await import('@/services/finance.service');
    await expect(createExpense({ categoryId: 1, amount: 5000, paymentMethodId: 1 })).resolves.toBeTruthy();
  });
});

describe('إلغاء مصروف', () => {
  it('يلغي ولا يحذف ويسجّل التدقيق', async () => {
    const { voidExpense } = await import('@/services/finance.service');
    const r = await voidExpense({ expenseId: 1, reason: 'مسجَّل بالخطأ' });
    expect(r.status).toBe('ملغى');
    expect(auditSpy.mock.calls[0][0]).toMatchObject({ action: 'expense.void', reason: 'مسجَّل بالخطأ' });
  });

  it('يرفض إلغاء مصروف ملغى', async () => {
    expenseRow!.is_voided = true;
    const { voidExpense } = await import('@/services/finance.service');
    await expect(voidExpense({ expenseId: 1, reason: 'ثانية' }))
      .rejects.toMatchObject({ code: 'BUSINESS_RULE' });
  });

  it('★ يرفض إلغاء مصروف مرتبط بصرف عمولة', async () => {
    linkedCommission = { id: 5 };
    const { voidExpense } = await import('@/services/finance.service');
    await expect(voidExpense({ expenseId: 1, reason: 'محاولة' }))
      .rejects.toMatchObject({ code: 'BUSINESS_RULE' });
    expect(auditSpy).not.toHaveBeenCalled();
  });

  it('الموظف لا يستطيع إلغاء مصروف', async () => {
    asStaff();
    const { voidExpense } = await import('@/services/finance.service');
    await expect(voidExpense({ expenseId: 1, reason: 'محاولة' }))
      .rejects.toMatchObject({ code: 'PERM_DENIED', details: { permission: 'expenses.void' } });
  });
});

describe('★ D6/D7 — فصل صلاحية تجاوز حد المصروف عن الإلغاء', () => {
  it('expenses.void وحدها لا تتجاوز الحد', async () => {
    // مستخدم يملك الإلغاء لكن لا يملك تجاوز الحد، والحد = 0 (ممنوع)
    currentUser = {
      id: 7, employeeId: 3,
      permissions: new Set(['expenses.view', 'expenses.create', 'expenses.void']),
    };
    const { createExpense } = await import('@/services/finance.service');
    await expect(createExpense({ categoryId: 1, amount: 100, paymentMethodId: 1 }))
      .rejects.toMatchObject({
        code: 'PERM_DENIED', details: { permission: 'expenses.limit.override' },
      });
  });

  it('expenses.limit.override وحدها تتجاوز الحد', async () => {
    currentUser = {
      id: 8, employeeId: 3,
      permissions: new Set(['expenses.view', 'expenses.create', 'expenses.limit.override']),
    };
    const { createExpense } = await import('@/services/finance.service');
    await expect(createExpense({ categoryId: 1, amount: 100, paymentMethodId: 1 }))
      .resolves.toBeTruthy();
  });
});
