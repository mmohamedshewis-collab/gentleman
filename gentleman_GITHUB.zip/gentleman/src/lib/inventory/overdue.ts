import type { Prisma } from '@prisma/client';
import { businessToday } from '@/lib/date';

/**
 * مصدر الحقيقة الوحيد للتأخير.
 *
 * ★ التأخير **مشتق** من العقد ولا يُخزَّن على القطعة:
 *   عقد نشط أو مُرجَع جزئيًا · تاريخ الإرجاع المتوقع مضى · والسطر ما زال مفتوحًا.
 *
 * تستهلكه تقارير M7 وشاشة المخزون معًا، فلا يوجد تعريفان للتأخير.
 * ⛔ لا يغيّر آلة الحالة ولا يكتب حالة على القطعة.
 */

/** حالات العقد التي يُحتسب فيها التأخير. */
export const OVERDUE_RENTAL_STATUSES = ['ACTIVE', 'PARTIALLY_RETURNED'] as const;

/** شرط العقد المتأخر — يُستخدم في `where` مباشرةً. */
export function overdueRentalWhere(today: Date = businessToday()): Prisma.RentalWhereInput {
  return {
    status: { in: [...OVERDUE_RENTAL_STATUSES] },
    expectedReturnDate: { lt: today },
  };
}

/** أيام التأخير بالأيام التقويمية الكاملة — لا قيم سالبة. */
export function daysLateOf(expectedReturnDate: Date, today: Date = businessToday()): number {
  const diff = Math.floor((today.getTime() - expectedReturnDate.getTime()) / 86_400_000);
  return diff > 0 ? diff : 0;
}

export interface OverdueItemRef {
  itemId: number;
  rentalId: number;
  rentalNo: string;
  expectedReturnDate: Date;
  daysLate: number;
}

/**
 * معرّفات القطع المتأخرة الآن.
 * تُستخدم في شاشة المخزون لعرض «متأخرة» دون تغيير حالة القطعة المخزَّنة.
 */
export async function overdueItemRefs(
  db: {
    rental: {
      findMany: (args: unknown) => Promise<
        {
          id: number;
          rentalNo: string;
          expectedReturnDate: Date;
          items: { itemId: number }[];
        }[]
      >;
    };
  },
  today: Date = businessToday(),
): Promise<OverdueItemRef[]> {
  const rentals = await db.rental.findMany({
    where: overdueRentalWhere(today),
    select: {
      id: true,
      rentalNo: true,
      expectedReturnDate: true,
      items: { where: { status: 'OUT' }, select: { itemId: true } },
    },
    orderBy: { expectedReturnDate: 'asc' },
  });

  const refs: OverdueItemRef[] = [];
  for (const r of rentals) {
    const daysLate = daysLateOf(r.expectedReturnDate, today);
    for (const li of r.items) {
      refs.push({
        itemId: li.itemId,
        rentalId: r.id,
        rentalNo: r.rentalNo,
        expectedReturnDate: r.expectedReturnDate,
        daysLate,
      });
    }
  }
  return refs;
}

/** خريطة سريعة: معرّف القطعة ← تفاصيل تأخيرها. */
export const overdueMap = (refs: OverdueItemRef[]): Map<number, OverdueItemRef> =>
  new Map(refs.map((r) => [r.itemId, r]));
