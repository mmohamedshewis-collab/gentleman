import { route } from '@/lib/api';
import { cancelReservation, cancelReservationSchema } from '@/services/reservation.service';

export const POST = route({ schema: cancelReservationSchema, handler: ({ input }) => cancelReservation(input) });
