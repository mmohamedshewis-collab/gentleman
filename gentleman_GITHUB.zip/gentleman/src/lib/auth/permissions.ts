/**
 * كتالوج الصلاحيات — مصدر وحيد للحقيقة.
 * تُطبَّق على الخادم (Service/API) وليس بإخفاء الأزرار.  BR-17
 */
export const PERMISSIONS = [
  // لوحة التحكم
  { code: 'dashboard.view', module: 'لوحة التحكم', nameAr: 'عرض لوحة التحكم' },

  // العملاء
  { code: 'customers.view', module: 'العملاء', nameAr: 'عرض العملاء' },
  { code: 'customers.create', module: 'العملاء', nameAr: 'إضافة عميل' },
  { code: 'customers.edit', module: 'العملاء', nameAr: 'تعديل عميل' },
  { code: 'customers.deactivate', module: 'العملاء', nameAr: 'تعطيل عميل' },

  // الكتالوج والمخزون
  { code: 'products.view', module: 'المخزون', nameAr: 'عرض المنتجات' },
  { code: 'products.manage', module: 'المخزون', nameAr: 'إدارة المنتجات والأسعار' },
  { code: 'items.view', module: 'المخزون', nameAr: 'عرض القطع' },
  { code: 'items.manage', module: 'المخزون', nameAr: 'إدارة القطع والباركود' },
  { code: 'items.status.override', module: 'المخزون', nameAr: 'تعديل حالة قطعة يدويًا' },

  // التأجير والإرجاع
  { code: 'rentals.view', module: 'التأجير', nameAr: 'عرض عمليات التأجير' },
  { code: 'rentals.create', module: 'التأجير', nameAr: 'إنشاء تأجير' },
  { code: 'rentals.void', module: 'التأجير', nameAr: 'إلغاء تأجير' },
  { code: 'returns.create', module: 'التأجير', nameAr: 'تسجيل إرجاع' },
  { code: 'returns.waive_fee', module: 'التأجير', nameAr: 'إعفاء أو تخفيض غرامة التأخير' },
  { code: 'returns.void', module: 'التأجير', nameAr: 'إلغاء إرجاع' },

  // الحجز
  { code: 'reservations.view', module: 'الحجز', nameAr: 'عرض الحجوزات' },
  { code: 'reservations.create', module: 'الحجز', nameAr: 'إنشاء حجز' },
  { code: 'reservations.cancel', module: 'الحجز', nameAr: 'إلغاء حجز' },
  { code: 'reservations.convert', module: 'الحجز', nameAr: 'تحويل حجز إلى تأجير' },

  // البيع
  { code: 'sales.view', module: 'المبيعات', nameAr: 'عرض المبيعات' },
  { code: 'sales.create', module: 'المبيعات', nameAr: 'إنشاء فاتورة بيع' },
  { code: 'sales.void', module: 'المبيعات', nameAr: 'إلغاء فاتورة بيع' },

  // المدفوعات والنقدية
  { code: 'payments.view', module: 'المالية', nameAr: 'عرض المدفوعات' },
  { code: 'payments.create', module: 'المالية', nameAr: 'تسجيل دفعة' },
  { code: 'payments.void', module: 'المالية', nameAr: 'إلغاء دفعة' },
  { code: 'payments.refund', module: 'المالية', nameAr: 'رد مبلغ لعميل' },
  { code: 'insurance.view', module: 'المالية', nameAr: 'عرض سجل التأمينات ورصيدها' },
  { code: 'insurance.manage', module: 'المالية', nameAr: 'رد ومصادرة وتحويل التأمين' },

  // النقدية اليومية
  { code: 'cash.movement.view', module: 'النقدية', nameAr: 'عرض حركة النقدية اليومية' },
  { code: 'cash.count', module: 'النقدية', nameAr: 'جرد نقدية اليوم' },
  { code: 'cash.close', module: 'النقدية', nameAr: 'إغلاق اليوم' },
  { code: 'cash.transfer', module: 'النقدية', nameAr: 'ترحيل النقدية إلى الخزينة' },
  { code: 'cash.reconcile.view', module: 'النقدية', nameAr: 'عرض مطابقة الخزينة الشهرية' },

  // سلف الموظفين
  { code: 'advances.view', module: 'الموظفون', nameAr: 'عرض سلف الموظفين' },
  { code: 'advances.create', module: 'الموظفون', nameAr: 'صرف سلفة' },
  { code: 'advances.repay', module: 'الموظفون', nameAr: 'تسجيل سداد سلفة' },

  // المصروفات
  { code: 'expenses.view', module: 'المصروفات', nameAr: 'عرض المصروفات' },
  { code: 'expenses.create', module: 'المصروفات', nameAr: 'تسجيل مصروف' },
  { code: 'expenses.void', module: 'المصروفات', nameAr: 'إلغاء مصروف' },
  { code: 'expenses.limit.override', module: 'المصروفات', nameAr: 'تجاوز حد مصروف الموظف' },

  // الموظفون
  { code: 'employees.view', module: 'الموظفون', nameAr: 'عرض الموظفين' },
  { code: 'employees.manage', module: 'الموظفون', nameAr: 'إدارة الموظفين والرواتب' },
  { code: 'commissions.view', module: 'الموظفون', nameAr: 'عرض العمولات' },
  { code: 'commissions.pay', module: 'الموظفون', nameAr: 'صرف العمولات' },

  // التقارير
  { code: 'reports.operational.view', module: 'التقارير', nameAr: 'التقارير التشغيلية' },
  { code: 'reports.financial.view', module: 'التقارير', nameAr: 'التقارير المالية' },
  { code: 'reports.export', module: 'التقارير', nameAr: 'تصدير التقارير' },

  // ملاحظة: حُذفت صلاحيتان بلا تنفيذ في ترقيع M-2:
  //   expenses.approve_over_cap — استُبدلت بـ expenses.limit.override
  //   roles.manage — إدارة الأدوار غير مبنية (الأدوار ثابتة في الكود)
  // لا تُعادان إلا مع تنفيذ فعلي يستخدمهما.
  // النظام
  { code: 'discount.override', module: 'النظام', nameAr: 'تجاوز حد الخصم' },
  { code: 'settings.view', module: 'النظام', nameAr: 'عرض الإعدادات' },
  { code: 'settings.edit', module: 'النظام', nameAr: 'تعديل الإعدادات' },
  { code: 'settings.vat.manage', module: 'النظام', nameAr: 'تفعيل وتعديل ضريبة القيمة المضافة' },
  { code: 'users.view', module: 'النظام', nameAr: 'عرض المستخدمين' },
  { code: 'users.manage', module: 'النظام', nameAr: 'إدارة المستخدمين' },
  { code: 'audit.view', module: 'النظام', nameAr: 'عرض سجل التدقيق' },
  // ملاحظة: لا توجد صلاحية استعادة عمدًا — النظام لا يحتوي أي وظيفة استعادة.
  // استعادة قاعدة البيانات تتم خارج التطبيق عبر Neon PITR.
  { code: 'backup.run', module: 'النظام', nameAr: 'تصدير البيانات' },
] as const;

export type PermissionCode = (typeof PERMISSIONS)[number]['code'];

export const ALL_PERMISSION_CODES = PERMISSIONS.map((p) => p.code) as PermissionCode[];

/** المدير: صلاحية كاملة. */
export const ADMIN_PERMISSIONS = ALL_PERMISSION_CODES;

/** موظف الفرع: العمليات اليومية فقط — مطابق لمصفوفة الصلاحيات المعتمدة. */
export const BRANCH_STAFF_PERMISSIONS: PermissionCode[] = [
  'dashboard.view',
  'customers.view', 'customers.create', 'customers.edit',
  'products.view', 'items.view',
  'rentals.view', 'rentals.create',
  'returns.create',
  'reservations.view', 'reservations.create', 'reservations.convert',
  'sales.view', 'sales.create',
  'payments.view', 'payments.create',
  'reports.operational.view',
  'cash.movement.view', 'cash.count',
];

export const ROLE_DEFS = [
  { code: 'ADMIN', nameAr: 'المدير', permissions: ADMIN_PERMISSIONS },
  { code: 'BRANCH_STAFF', nameAr: 'موظف الفرع', permissions: BRANCH_STAFF_PERMISSIONS },
] as const;

/** دوال تحقق خالصة (بدون أي اعتماد على قاعدة البيانات) — تُستخدم في الاختبارات والواجهة. */
export const hasPermission = (
  granted: ReadonlySet<string>,
  permission: PermissionCode,
): boolean => granted.has(permission);

export const hasAnyPermission = (
  granted: ReadonlySet<string>,
  permissions: PermissionCode[],
): boolean => permissions.some((p) => granted.has(p));
