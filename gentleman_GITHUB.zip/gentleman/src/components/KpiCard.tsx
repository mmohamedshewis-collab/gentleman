import Link from 'next/link';
import { formatEGP, formatNumber } from '@/lib/money';

export interface KpiCardProps {
  label: string;
  value: string;
  kind: 'money' | 'count';
  href: string | null;
  hint?: string;
}

/** بطاقة مؤشر — بأنماط الواجهة القائمة، بلا ألوان أو خطوط جديدة. */
export default function KpiCard({ label, value, kind, href, hint }: KpiCardProps) {
  const negative = kind === 'money' && Number(value) < 0;

  const body = (
    <div className="card h-full p-5">
      <div className="text-sm text-slate-500">{label}</div>
      <div className={`num font-bold text-xl mt-2 ${negative ? 'text-danger' : 'text-brand'}`}>
        {kind === 'money' ? formatEGP(value) : formatNumber(value, 0)}
      </div>
      {hint && <div className="text-[11px] text-slate-400 mt-2 leading-relaxed">{hint}</div>}
    </div>
  );

  return href ? (
    <Link href={href} className="block hover:opacity-90 transition">{body}</Link>
  ) : (
    body
  );
}
