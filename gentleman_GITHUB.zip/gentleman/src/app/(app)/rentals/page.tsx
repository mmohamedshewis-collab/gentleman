import Link from 'next/link';
import { listRentals } from '@/services/rental.service';
import { RENTAL_STATUS_LABELS, type RentalStatus } from '@/lib/rentals/rental-state';
import { formatEGP } from '@/lib/money';
import { formatDate } from '@/lib/date';

export const dynamic = 'force-dynamic';

const TONE: Record<RentalStatus, string> = {
  ACTIVE: 'bg-blue-100 text-brand-light',
  PARTIALLY_RETURNED: 'bg-amber-100 text-warn',
  CLOSED: 'bg-green-100 text-ok',
  VOIDED: 'bg-slate-100 text-slate-500',
};

export default async function RentalsPage({ searchParams }: { searchParams: { q?: string; status?: string } }) {
  const { rows, total } = await listRentals({
    q: searchParams.q, status: searchParams.status, page: 1, pageSize: 50,
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="section-title">عمليات التأجير</h1>
          <p className="text-sm text-slate-600 mt-1">الإجمالي: <span className="num">{total}</span></p>
        </div>
        <Link className="btn-primary" href="/rentals/new">تأجير جديد</Link>
      </div>

      <div className="card overflow-hidden">
        <div className="card-header">القائمة</div>
        <form className="p-4 border-b border-slate-200 flex gap-3" action="/rentals">
          <input name="q" className="input max-w-xs" placeholder="رقم العقد أو اسم العميل أو جواله"
                 defaultValue={searchParams.q ?? ''} />
          <select name="status" className="input max-w-[180px]" defaultValue={searchParams.status ?? ''}>
            <option value="">كل الحالات</option>
            {(Object.keys(RENTAL_STATUS_LABELS) as RentalStatus[]).map((s) => (
              <option key={s} value={s}>{RENTAL_STATUS_LABELS[s]}</option>
            ))}
          </select>
          <button className="btn-secondary">بحث</button>
        </form>
        <div className="overflow-x-auto">
          <table className="table">
            <thead>
              <tr>
                <th>رقم العقد</th><th>العميل</th><th>تاريخ التأجير</th><th>الإرجاع المتوقع</th>
                <th>القطع</th><th>المستحق</th><th>المدفوع</th><th>المتبقي</th><th>التأمين</th><th>الحالة</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.id}>
                  <td className="num font-semibold">{r.rentalNo}</td>
                  <td>{r.customer.fullName}</td>
                  <td className="num">{formatDate(r.rentalDate)}</td>
                  <td className="num">{formatDate(r.expectedReturnDate)}</td>
                  <td className="num">{r._count.items}</td>
                  <td className="num">{formatEGP(r.totalDue.toString())}</td>
                  <td className="num">{formatEGP(r.paidAmount.toString())}</td>
                  <td className="num font-semibold">{formatEGP(r.remainingAmount.toString())}</td>
                  <td className="num text-slate-500">{formatEGP(r.insuranceAmount.toString())}</td>
                  <td><span className={`badge ${TONE[r.status as RentalStatus]}`}>
                    {RENTAL_STATUS_LABELS[r.status as RentalStatus]}
                  </span></td>
                </tr>
              ))}
              {rows.length === 0 && (
                <tr><td colSpan={10} className="text-center text-slate-500 py-8">لا توجد عمليات تأجير.</td></tr>
              )}
            </tbody>
          </table>
        </div>
        <p className="px-4 py-3 text-xs text-slate-500 border-t border-slate-200">
          مبالغ التأمين معروضة للعلم فقط — وهي أمانة العميل ولا تدخل ضمن مستحقات العقد ولا إيرادات المحل.
        </p>
      </div>
    </div>
  );
}
