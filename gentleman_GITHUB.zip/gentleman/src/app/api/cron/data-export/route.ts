import { NextResponse } from 'next/server';
import { headers } from 'next/headers';
import { performDataExport } from '@/services/backup.service';

/**
 * تصدير أسبوعي مجدول.
 *
 * ★ يستدعي نواة التصدير نفسها التي يستدعيها التصدير اليدوي — مصدر واحد.
 *   لا قائمة جداول ولا تحقق ولا كتابة `backup_runs` هنا.
 *
 * محمي بسر المهمة لا بصلاحية مستخدم، ويُرفض بلا تلميح عند فشل التحقق.
 */
export async function POST() {
  const secret = process.env.CRON_SECRET;
  const provided = headers().get('authorization');
  if (!secret || provided !== `Bearer ${secret}`) {
    return NextResponse.json({ status: 'unauthorized' }, { status: 401 });
  }

  try {
    const result = await performDataExport(null);
    return NextResponse.json({
      status: 'ok',
      rowCount: result.rowCount,
      tables: result.tables,
      storageConfigured: result.storageConfigured,
    });
  } catch {
    // لا تسريب لتفاصيل الخطأ — السجل في backup_runs
    return NextResponse.json({ status: 'error' }, { status: 500 });
  }
}
