import { headers } from 'next/headers';
import { prisma } from '@/lib/db';
import type { Prisma, PrismaClient } from '@prisma/client';

type Tx = PrismaClient | Prisma.TransactionClient;

export interface AuditInput {
  userId: number | null;
  action: string;              // مثال: user.create / settings.update / rental.void
  entityType: string;          // اسم الكيان
  entityId?: string | number | null;
  before?: unknown;
  after?: unknown;
  reason?: string | null;
}

const clean = (v: unknown): Prisma.InputJsonValue | undefined => {
  if (v === undefined || v === null) return undefined;
  return JSON.parse(
    JSON.stringify(v, (_k, val) =>
      typeof val === 'bigint' ? val.toString() : val,
    ),
  ) as Prisma.InputJsonValue;
};

/**
 * يُكتب داخل نفس الـ Transaction الخاصة بالعملية كلما أمكن،
 * حتى لا يوجد تعديل حسّاس بلا أثر.  (البند 23)
 */
export async function writeAudit(input: AuditInput, tx: Tx = prisma) {
  let ip: string | undefined;
  try {
    ip = headers().get('x-forwarded-for') ?? undefined;
  } catch {
    ip = undefined; // خارج سياق الطلب (مثل seed أو Job)
  }
  await tx.auditLog.create({
    data: {
      userId: input.userId ?? undefined,
      action: input.action,
      entityType: input.entityType,
      entityId: input.entityId != null ? String(input.entityId) : undefined,
      beforeJson: clean(input.before),
      afterJson: clean(input.after),
      reason: input.reason ?? undefined,
      ipAddress: ip,
    },
  });
}

/** الحقول التي لا تُسجَّل أبدًا في سجل التدقيق. */
export const REDACTED_FIELDS = ['passwordHash', 'password', 'tokenHash'];

export function redact<T extends Record<string, unknown>>(obj: T | null): unknown {
  if (!obj) return obj;
  const copy: Record<string, unknown> = { ...obj };
  for (const f of REDACTED_FIELDS) if (f in copy) copy[f] = '***';
  return copy;
}
