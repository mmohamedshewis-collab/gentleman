# اختبارات قاعدة البيانات — M3

اختبارات تُنفَّذ على PostgreSQL حقيقي (وليس محاكاة) للتحقق من القيود
والـ Triggers والتزامن والتراجع الكامل.

## التشغيل
```bash
createdb gentleman_test
psql -d gentleman_test -f tests/db/m3_schema.sql
psql -d gentleman_test -f prisma/sql/01_constraints.sql
psql -d gentleman_test -f tests/db/m3_scenarios_1.sql   # T1–T6
psql -d gentleman_test -f tests/db/m3_scenarios_2.sql   # T7–T11
psql -d gentleman_test -f tests/db/m3_scenarios_3.sql   # T13–T18
# التزامن: شغّل الملف مرتين في نفس اللحظة
psql -d gentleman_test -f tests/db/m3_concurrency.sql &
psql -d gentleman_test -f tests/db/m3_concurrency.sql &
```

الإجراء `do_rental` يحاكي خطوات `RentalService.createRental` بالترتيب نفسه،
و`do_void` يحاكي `voidRental`.

## M4 — الإرجاع
```bash
psql -d gentleman_test -f tests/db/m4_schema.sql
psql -d gentleman_test -f prisma/sql/01_constraints.sql
psql -d gentleman_test -f tests/db/m4_scenarios_1.sql   # R1–R2  الإرجاع السليم والتالف
psql -d gentleman_test -f tests/db/m4_scenarios_2.sql   # R3–R9  الرفض والتراجع الكامل
psql -d gentleman_test -f tests/db/m4_scenarios_3.sql   # R5–R8  قيود التسوية
psql -d gentleman_test -f tests/db/m4_scenarios_4.sql   # R10–R15 الإلغاء والتدقيق
psql -d gentleman_test -f tests/db/m4_concurrency.sql & \
psql -d gentleman_test -f tests/db/m4_concurrency.sql &   # R16
```

## M5 — البيع
```bash
psql -d gentleman_test -f tests/db/m5_schema.sql
psql -d gentleman_test -f prisma/sql/01_constraints.sql
psql -d gentleman_test -f tests/db/m5_scenarios_1.sql   # S1–S8   البيع والرفض
psql -d gentleman_test -f tests/db/m5_scenarios_2.sql   # S9–S19  الحماية والإلغاء والتراجع
psql -d gentleman_test -f tests/db/m5_scenarios_3.sql   # S18،S20 إعادة البيع بعد الإلغاء
psql -d gentleman_test -f tests/db/m5_concurrency.sql & \
psql -d gentleman_test -f tests/db/m5_concurrency.sql &   # S21
```

## مراجعة أمنية — مسار الخروج من حالة "مباعة"
```bash
psql -d gentleman_test -f tests/db/m5_security.sql   # A1–A7 محاولات استغلال مباشرة
```
النتيجة المتوقعة: كل محاولة تُرفض عدا A5 (العودة إلى الحالة المحفوظة بعد إلغاء فعلي للفاتورة).

## M6 — المدفوعات والمصروفات والموظفون
```bash
psql -d gentleman_test -f tests/db/m5_schema.sql
psql -d gentleman_test -f tests/db/m6_schema.sql
psql -d gentleman_test -f prisma/sql/01_constraints.sql
psql -d gentleman_test -f tests/db/m6_scenarios.sql   # P1–P7 · E1–E4 · C1–C6
psql -d gentleman_test -f tests/db/m6_helpers.sql
psql -d gentleman_test -f tests/db/m6_rollback.sql    # التراجع الكامل
psql -d gentleman_test -f tests/db/m6_concurrency.sql &   # دفعتان متزامنتان
```

## M6 — المدفوعات والمصروفات والموظفون
```bash
psql -d gentleman_test -f tests/db/m6_schema.sql
psql -d gentleman_test -f prisma/sql/01_constraints.sql
psql -d gentleman_test -f tests/db/m6_security_void_flag.sql  # A1–A7 محاولات اختراق حارس البيع
psql -d gentleman_test -f tests/db/m6_scenarios.sql           # F1–F15
psql -d gentleman_test -f tests/db/m6_concurrency.sql & \
psql -d gentleman_test -f tests/db/m6_concurrency.sql &        # F16
```

## النقدية اليومية والسلف والرد
```bash
psql -d gentleman_test -f tests/db/cash_schema.sql
psql -d gentleman_test -f prisma/sql/01_constraints.sql
psql -d gentleman_test -f tests/db/cash_scenarios_1.sql   # الجرد · الإغلاق · الترحيل
psql -d gentleman_test -f tests/db/cash_scenarios_2.sql   # حماية اليوم المغلق (5 جداول)
psql -d gentleman_test -f tests/db/cash_scenarios_3.sql   # السلف · الراتب · الرد
# التزامن:
psql -d gentleman_test -f tests/db/cash_concurrency_advance.sql & \
psql -d gentleman_test -f tests/db/cash_concurrency_advance.sql &
psql -d gentleman_test -f tests/db/cash_concurrency_closing.sql & \
psql -d gentleman_test -f tests/db/cash_concurrency_closing.sql &
```

## صرف العمولة
```bash
psql -d gentleman_test -f tests/db/cash_schema.sql
psql -d gentleman_test -f prisma/sql/01_constraints.sql
psql -d gentleman_test -f tests/db/commission_scenarios.sql     # K1–K4
psql -d gentleman_test -f tests/db/commission_concurrency.sql & \
psql -d gentleman_test -f tests/db/commission_concurrency.sql &
```

## M10 — الحجز المسبق
```bash
psql -d gentleman_test -f tests/db/m10_schema.sql
psql -d gentleman_test -f prisma/sql/01_constraints.sql
psql -d gentleman_test -f tests/db/m10_scenarios.sql   # R1–R10 التعارض والحالات والقيود
psql -d gentleman_test -f tests/db/m10_refund.sql      # D3 رد العربون وضوابطه
# التزامن: شغّل الملف مرتين معًا — واحد فقط ينجح
psql -d gentleman_test -f tests/db/m10_concurrency.sql & \
psql -d gentleman_test -f tests/db/m10_concurrency.sql &
```

## تخصيص عربون الحجز (الإصلاح الحرج)
```bash
psql -d gentleman_test -f tests/db/reservation_deposit.sql
# يثبت: عقد 1,500 وعربون 300 ⟹ المتبقي 1,200 · دفعة واحدة · لا تخصيص مرتين
```

## تزامن تحويل الحجز
```bash
# شغّل الملف مرتين معًا بعقدين مختلفين — واحد فقط ينجح
psql -d gentleman_test -f tests/db/reservation_convert_concurrency.sql &
psql -d gentleman_test -f tests/db/reservation_convert_concurrency.sql &
```

## الصيانة والتنظيف (M-3)
```bash
psql -d gentleman_test -f tests/db/upkeep_scenarios.sql     # A–G
psql -d gentleman_test -f tests/db/upkeep_concurrency.sql & \
psql -d gentleman_test -f tests/db/upkeep_concurrency.sql &   # D: صيانتان متزامنتان
```

## قفل الحساب بعد محاولات فاشلة (Q-1)
```bash
psql -d gentleman_test -f prisma/migrations/20260818_add_login_lockout/migration.sql
# عشر محاولات متزامنة — يجب أن يقف العدّاد عند 5 ويقفل الحساب
for i in $(seq 1 10); do
  psql -d gentleman_test -f tests/db/auth_lockout_concurrency.sql &
done; wait
```

## بوابة الإنتاج
```bash
createdb gentleman_gate && ./tests/db/production_gate.sh gentleman_gate
# يتوقف عند أول فشل — لا يطبع نجاحًا إلا بعد نجاح فعلي
# المتوقع: 47 قيدًا (46 + ck_user_failed_attempts) · 44 Trigger
```

## M13-1: ربط التنظيف بالعقد
```bash
psql -d gentleman_test -f prisma/migrations/20260819_cleaning_rental_link/migration.sql
psql -d gentleman_test -f tests/db/cleaning_rental_link.sql          # A · D · H · I
psql -d gentleman_test -f tests/db/cleaning_rental_delete_guard.sql  # G عبر prevent_hard_delete
psql -d gentleman_test -f tests/db/cleaning_rental_fk_isolated.sql   # G عبر ON DELETE RESTRICT معزولًا
```
