import { route } from '@/lib/api';
import { scanForReturn, scanForReturnSchema } from '@/services/return.service';

export const GET = route({ schema: scanForReturnSchema, handler: ({ input }) => scanForReturn(input.barcode) });
