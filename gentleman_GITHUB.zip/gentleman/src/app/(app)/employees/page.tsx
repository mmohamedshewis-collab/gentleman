import { listEmployees, employeePerformanceReport } from '@/services/employee.service';
import { getSession } from '@/lib/auth/session';
import { formatEGP } from '@/lib/money';
import { businessToday, formatDate } from '@/lib/date';
import { commissionStatement, payableEmployees } from '@/services/commission.service';
import { listPaymentMethods } from '@/services/finance.service';
import EmployeePaymentPanel from '@/components/EmployeePaymentPanel';

export const dynamic = 'force-dynamic';

export default async function EmployeesPage({
  searchParams,
}: { searchParams: { from?: string; to?: string } }) {
  const session = await getSession();
  const canSeeCommissions = session?.permissions.has('commissions.view') ?? false;

  const today = formatDate(businessToday());
  const from = searchParams.from ?? `${today.slice(0, 8)}01`;
  const to = searchParams.to ?? today;

  const employees = await listEmployees();
  const report = canSeeCommissions ? await employeePerformanceReport({ from, to }) : null;

  const canPayCommission = session?.permissions.has('commissions.pay') ?? false;
  const canPaySalary = session?.permissions.has('expenses.create') ?? false;
  const canCreateAdvance = session?.permissions.has('advances.create') ?? false;
  const showPanel = canPayCommission || canPaySalary || canCreateAdvance;

  const periodMonth = today.slice(0, 7);
  const [payable, methods, commissions] = showPanel
    ? await Promise.all([
        payableEmployees(),
        listPaymentMethods(),
        canSeeCommissions ? commissionStatement({ periodMonth }) : Promise.resolve({ rows: [] }),
      ])
    : [[], [], { rows: [] }];

  return (
    <div className="space-y-6">
      <h1 className="section-title">الموظفون</h1>

      <div className="card overflow-hidden">
        <div className="card-header">بيانات الموظفين</div>
        <table className="table">
          <thead>
            <tr>
              <th>الكود</th><th>الاسم</th><th>المسمى</th><th>الراتب</th>
              <th>عمولة التأجير</th><th>عمولة البيع</th><th>الحالة</th>
            </tr>
          </thead>
          <tbody>
            {employees.map((e) => (
              <tr key={e.id}>
                <td className="num">{e.code}</td>
                <td className="font-semibold">{e.fullName}</td>
                <td>{e.jobTitle ?? '—'}</td>
                <td className="num">{formatEGP(e.monthlySalary.toString())}</td>
                <td className="num">{e.rentalCommissionPct.toString()}%</td>
                <td className="num">{e.salesCommissionPct.toString()}%</td>
                <td>
                  <span className={`badge ${e.status === 'ACTIVE' ? 'bg-green-100 text-ok' : 'bg-slate-100 text-slate-500'}`}>
                    {e.status === 'ACTIVE' ? 'نشط' : 'غير نشط'}
                  </span>
                </td>
              </tr>
            ))}
            {employees.length === 0 && (
              <tr><td colSpan={7} className="text-center text-slate-500 py-8">لا يوجد موظفون مسجّلون.</td></tr>
            )}
          </tbody>
        </table>
      </div>

      {showPanel && (
        <EmployeePaymentPanel
          employees={payable}
          methods={methods.map((m) => ({ id: m.id, nameAr: m.nameAr }))}
          commissions={commissions.rows as never}
          periodMonth={periodMonth}
          canPayCommission={canPayCommission}
          canPaySalary={canPaySalary}
          canCreateAdvance={canCreateAdvance}
        />
      )}

      {report && (
        <div className="card overflow-hidden">
          <div className="card-header">
            الأداء والعمولات من {from} إلى {to}
          </div>
          <form className="p-4 flex gap-3 items-end border-b border-slate-200" action="/employees">
            <div><label className="label">من</label><input className="input num" type="date" name="from" defaultValue={from} /></div>
            <div><label className="label">إلى</label><input className="input num" type="date" name="to" defaultValue={to} /></div>
            <button className="btn-primary">عرض</button>
          </form>
          <div className="overflow-x-auto">
            <table className="table">
              <thead>
                <tr>
                  <th>الموظف</th><th>عمليات تأجير</th><th>صافي التأجير</th>
                  <th>فواتير بيع</th><th>صافي البيع</th><th>وعاء العمولة</th>
                  <th>العمولة</th><th>الراتب المخصص</th><th>التكلفة</th><th>مؤشر الأداء</th>
                </tr>
              </thead>
              <tbody>
                {report.rows.map((r) => (
                  <tr key={r.employeeId}>
                    <td className="font-semibold">{r.fullName}</td>
                    <td className="num">{r.rentalCount}</td>
                    <td className="num">{formatEGP(r.netRental)}</td>
                    <td className="num">{r.saleCount}</td>
                    <td className="num">{formatEGP(r.netSales)}</td>
                    <td className="num">{formatEGP(r.base)}</td>
                    <td className="num font-semibold">{formatEGP(r.commissionTotal)}</td>
                    <td className="num">{formatEGP(r.allocatedSalary)}</td>
                    <td className="num">{formatEGP(r.totalCost)}</td>
                    <td className="num font-bold">{r.performanceIndex ?? '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="p-4 text-xs text-warn bg-amber-50 border-t border-amber-200">
            {report.note} — وعاء العمولة لا يشمل التأمين ولا الغرامات ولا الضريبة.
          </p>
        </div>
      )}
    </div>
  );
}
