'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function ProductForm({
  categories, brands,
}: {
  categories: { id: number; nameAr: string }[];
  brands: { id: number; name: string }[];
}) {
  const router = useRouter();
  const empty = {
    code: '', nameAr: '', categoryId: '', brandId: '',
    size: '', color: '', rentalPrice: 0, salePrice: 0, defaultCost: 0,
  };
  const [form, setForm] = useState(empty);
  const [msg, setMsg] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  const set = (k: string, v: string | number) => setForm({ ...form, [k]: v });

  async function submit() {
    setBusy(true); setMsg(null);
    const res = await fetch('/api/products', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ...form,
        categoryId: form.categoryId ? Number(form.categoryId) : null,
        brandId: form.brandId ? Number(form.brandId) : null,
      }),
    });
    const json = await res.json();
    setBusy(false);
    if (!json.ok) { setMsg({ type: 'err', text: json.error?.message ?? 'تعذّر الحفظ.' }); return; }
    setMsg({ type: 'ok', text: 'تم حفظ المنتج.' });
    setForm(empty);
    router.refresh();
  }

  return (
    <div className="card">
      <div className="card-header">إضافة منتج جديد</div>
      <div className="p-5 grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <label className="label">كود المنتج</label>
          <input className="input num" dir="ltr" value={form.code} onChange={(e) => set('code', e.target.value)} />
        </div>
        <div className="md:col-span-2">
          <label className="label">اسم المنتج</label>
          <input className="input" value={form.nameAr} onChange={(e) => set('nameAr', e.target.value)} />
        </div>
        <div>
          <label className="label">التصنيف</label>
          <select className="input" value={form.categoryId} onChange={(e) => set('categoryId', e.target.value)}>
            <option value="">بدون</option>
            {categories.map((c) => <option key={c.id} value={c.id}>{c.nameAr}</option>)}
          </select>
        </div>
        <div>
          <label className="label">الماركة</label>
          <select className="input" value={form.brandId} onChange={(e) => set('brandId', e.target.value)}>
            <option value="">بدون</option>
            {brands.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
          </select>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="label">المقاس</label>
            <input className="input" value={form.size} onChange={(e) => set('size', e.target.value)} />
          </div>
          <div>
            <label className="label">اللون</label>
            <input className="input" value={form.color} onChange={(e) => set('color', e.target.value)} />
          </div>
        </div>
        <div>
          <label className="label">سعر التأجير</label>
          <input className="input num" type="number" dir="ltr" value={form.rentalPrice}
                 onChange={(e) => set('rentalPrice', Number(e.target.value))} />
        </div>
        <div>
          <label className="label">سعر البيع</label>
          <input className="input num" type="number" dir="ltr" value={form.salePrice}
                 onChange={(e) => set('salePrice', Number(e.target.value))} />
        </div>
        <div>
          <label className="label">تكلفة الشراء الافتراضية</label>
          <input className="input num" type="number" dir="ltr" value={form.defaultCost}
                 onChange={(e) => set('defaultCost', Number(e.target.value))} />
        </div>
      </div>
      <div className="px-5 pb-5 flex items-center gap-4">
        <button className="btn-primary" onClick={submit} disabled={busy}>
          {busy ? 'جارٍ الحفظ…' : 'حفظ المنتج'}
        </button>
        {msg && (
          <span className={`text-sm font-semibold ${msg.type === 'ok' ? 'text-ok' : 'text-danger'}`}>
            {msg.text}
          </span>
        )}
      </div>
    </div>
  );
}
