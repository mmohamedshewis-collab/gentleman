import { route } from '@/lib/api';
import { itemsForLabels, labelQuerySchema } from '@/services/inventory.service';

export const GET = route({ schema: labelQuerySchema, handler: ({ input }) => itemsForLabels(input) });
