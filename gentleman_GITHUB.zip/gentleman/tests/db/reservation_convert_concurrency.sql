BEGIN;
-- 1) قفل الحجز (كما تفعل الخدمة)
SELECT pg_sleep(0.3);
DO $$
DECLARE v_status text; v_alloc int; v_rental int;
BEGIN
  SELECT status INTO v_status FROM reservations WHERE reservation_no='RES-CONC2' FOR UPDATE;
  -- 2) حارس: لا تحويل مرتين
  IF v_status = 'CONVERTED' THEN
    RAISE EXCEPTION 'الحجز محوَّل بالفعل — لا يُحوَّل مرتين.';
  END IF;
  SELECT id INTO v_rental FROM rentals WHERE rental_no='R-C2-A';
  -- 3) التخصيص بشرط rental_id IS NULL
  UPDATE payments SET rental_id=v_rental WHERE payment_no='CONC-2' AND rental_id IS NULL;
  GET DIAGNOSTICS v_alloc = ROW_COUNT;
  -- 4) حارس: فشل التخصيص يوقف العملية كلها
  IF v_alloc <> 1 THEN
    RAISE EXCEPTION 'تعذّر تخصيص العربون — أعد المحاولة.';
  END IF;
  UPDATE reservations SET status='CONVERTED', converted_rental_id=v_rental WHERE reservation_no='RES-CONC2';
END $$;
COMMIT;
