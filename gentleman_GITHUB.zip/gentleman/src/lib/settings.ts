import { prisma } from '@/lib/db';
import { Decimal } from 'decimal.js';
import { SETTING_DEFS, type SettingKey } from './settings.defs';

export { SETTING_DEFS };
export type { SettingKey };


export async function getSetting<T = unknown>(key: SettingKey): Promise<T> {
  const row = await prisma.setting.findUnique({ where: { key } });
  if (!row) {
    const def = SETTING_DEFS.find((d) => d.key === key);
    if (!def) throw new Error(`UNKNOWN_SETTING:${key}`);
    return def.value as unknown as T;
  }
  return row.valueJson as unknown as T;
}

export const getNumberSetting = async (key: SettingKey): Promise<Decimal> =>
  new Decimal((await getSetting<number>(key)) ?? 0);

export const getBoolSetting = async (key: SettingKey): Promise<boolean> =>
  Boolean(await getSetting<boolean>(key));

export const getStringSetting = async (key: SettingKey): Promise<string> =>
  String((await getSetting<string>(key)) ?? '');

/** كل الإعدادات دفعة واحدة (لشاشة الإعدادات). */
export async function getAllSettings() {
  const rows = await prisma.setting.findMany({ orderBy: [{ group: 'asc' }, { key: 'asc' }] });
  return rows;
}
