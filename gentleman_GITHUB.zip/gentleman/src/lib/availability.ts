/** منطق التوفر الخالص — بلا اعتماد على قاعدة البيانات (قابل للاختبار مباشرة). */
export interface Period { start: Date; end: Date }

/** هل تتداخل فترتان؟ الحدود مشمولة: القطعة لا تكون في مكانين في نفس اليوم. */
export const overlaps = (a: Period, b: Period): boolean =>
  a.start <= b.end && b.start <= a.end;

/** حالات تمنع أي ارتباط مستقبلي بالقطعة مهما كان التقويم. */
export const BLOCKING_STATUSES = ['SOLD', 'LOST', 'DISPOSED'] as const;
