import { describe, it, expect } from 'vitest';
import {
  ADMIN_PERMISSIONS,
  BRANCH_STAFF_PERMISSIONS,
  ALL_PERMISSION_CODES,
  hasPermission,
} from '../src/lib/auth/permissions';

const mk = (perms: readonly string[]) => ({ permissions: new Set<string>(perms) });
const can = (u: { permissions: Set<string> }, p: string) =>
  hasPermission(u.permissions, p as never);

describe('مصفوفة الصلاحيات المعتمدة', () => {
  const staff = mk(BRANCH_STAFF_PERMISSIONS);
  const admin = mk(ADMIN_PERMISSIONS);

  it('المدير لديه كل الصلاحيات', () => {
    for (const p of ALL_PERMISSION_CODES) expect(can(admin, p)).toBe(true);
  });

  it('موظف الفرع ينفّذ العمليات اليومية', () => {
    expect(can(staff, 'rentals.create')).toBe(true);
    expect(can(staff, 'returns.create')).toBe(true);
    expect(can(staff, 'sales.create')).toBe(true);
    expect(can(staff, 'payments.create')).toBe(true);
  });

  it('موظف الفرع ممنوع من المالية الحساسة والإعدادات', () => {
    const forbidden = [
      'rentals.void', 'sales.void', 'payments.void',
      'insurance.view', 'insurance.manage',
      'cash.close', 'cash.transfer', 'cash.reconcile.view',
      'expenses.limit.override', 'payments.refund',
      'advances.create', 'advances.repay',
      'settings.edit', 'users.manage',
      'audit.view', 'expenses.create',
      'reports.financial.view', 'discount.override', 'backup.run',
    ] as const;
    for (const p of forbidden) expect(can(staff, p)).toBe(false);
  });

  it('★ كل صلاحية مذكورة في اختبارات الحظر موجودة فعلًا في الكتالوج', () => {
    // بدون هذا الفحص يمر اختبار الحظر بقيمة false لمجرد أن الصلاحية غير موجودة
    const mentioned = [
      'rentals.void', 'sales.void', 'payments.void',
      'insurance.view', 'insurance.manage',
      'cash.close', 'cash.transfer', 'cash.reconcile.view',
      'expenses.limit.override', 'payments.refund',
      'advances.create', 'advances.repay',
      'settings.edit', 'users.manage',
      'audit.view', 'expenses.create',
      'reports.financial.view', 'discount.override', 'backup.run',
    ];
    const missing = mentioned.filter((p) => !ALL_PERMISSION_CODES.includes(p as never));
    expect(missing, `صلاحيات مذكورة في الاختبار وغير موجودة في الكتالوج: ${missing.join(', ')}`)
      .toEqual([]);
  });

  it('موظف الفرع يستطيع عرض حركة النقدية وجردها فقط', () => {
    expect(can(staff, 'cash.movement.view')).toBe(true);
    expect(can(staff, 'cash.count')).toBe(true);
    expect(can(staff, 'cash.close')).toBe(false);
    expect(can(staff, 'cash.transfer')).toBe(false);
  });

  it('لا توجد صلاحية في الأدوار خارج الكتالوج', () => {
    for (const p of BRANCH_STAFF_PERMISSIONS) {
      expect(ALL_PERMISSION_CODES).toContain(p);
    }
  });
});
