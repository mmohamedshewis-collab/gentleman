import Link from 'next/link';
import { listProducts, listCategories, listBrands } from '@/services/catalog.service';
import { getSession } from '@/lib/auth/session';
import { formatEGP } from '@/lib/money';
import ProductForm from '@/components/ProductForm';
import AddItemsForm from '@/components/AddItemsForm';

export const dynamic = 'force-dynamic';

export default async function ProductsPage() {
  const [products, categories, brands, session] = await Promise.all([
    listProducts({}), listCategories(), listBrands(), getSession(),
  ]);
  const canManage = session?.permissions.has('products.manage') ?? false;
  const canManageItems = session?.permissions.has('items.manage') ?? false;

  return (
    <div className="space-y-6">
      <h1 className="section-title">المنتجات</h1>

      <div className="card overflow-hidden">
        <div className="card-header">قائمة المنتجات</div>
        <div className="overflow-x-auto">
          <table className="table">
            <thead>
              <tr>
                <th>الكود</th><th>المنتج</th><th>التصنيف</th><th>الماركة</th>
                <th>المقاس</th><th>اللون</th><th>سعر التأجير</th><th>سعر البيع</th>
                <th>عدد القطع</th><th></th>
              </tr>
            </thead>
            <tbody>
              {products.map((p) => (
                <tr key={p.id}>
                  <td className="num font-semibold">{p.code}</td>
                  <td>{p.nameAr}</td>
                  <td>{p.category?.nameAr ?? '—'}</td>
                  <td>{p.brand?.name ?? '—'}</td>
                  <td>{p.size ?? '—'}</td>
                  <td>{p.color ?? '—'}</td>
                  <td className="num">{formatEGP(Number(p.rentalPrice))}</td>
                  <td className="num">{formatEGP(Number(p.salePrice))}</td>
                  <td className="num font-bold">{p._count.items}</td>
                  <td>
                    {canManageItems && p._count.items > 0 && (
                      <Link
                        href={`/inventory/labels?productId=${p.id}`}
                        className="text-brand-light font-semibold"
                      >
                        ملصقات
                      </Link>
                    )}
                  </td>
                </tr>
              ))}
              {products.length === 0 && (
                <tr><td colSpan={10} className="text-center text-slate-500 py-6">لا توجد منتجات بعد.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {canManage && (
        <ProductForm
          categories={categories.map((c) => ({ id: c.id, nameAr: c.nameAr }))}
          brands={brands.map((b) => ({ id: b.id, name: b.name }))}
        />
      )}

      {canManageItems && products.length > 0 && (
        <AddItemsForm products={products.map((p) => ({ id: p.id, code: p.code, nameAr: p.nameAr }))} />
      )}
    </div>
  );
}
