\set ON_ERROR_STOP off
\pset pager off
\t on

\echo '=== R14: التراجع الكامل عند فشل في منتصف الإرجاع ==='
SELECT 'العقد ' || do_rental(ARRAY['SUIT-0012'], 2, 500, 0, 500, 0, 1000, CURRENT_DATE-2, CURRENT_DATE-1);
SELECT 'قبل: إرجاعات=' || (SELECT count(*) FROM returns) ||
       ' سطور إرجاع=' || (SELECT count(*) FROM return_items) ||
       ' سجل حالة=' || (SELECT count(*) FROM item_status_history) ||
       ' حركات مخزون=' || (SELECT count(*) FROM inventory_transactions) ||
       ' حركات تأمين=' || (SELECT count(*) FROM insurance_transactions) ||
       ' تدقيق=' || (SELECT count(*) FROM audit_logs) ||
       ' حجوزات نشطة=' || (SELECT count(*) FROM item_bookings WHERE is_active) ||
       ' غرامات العقد=' || (SELECT extra_charges FROM rentals WHERE id=last_rental());
SELECT 'حالة القطعة قبل=' || status FROM product_items WHERE item_code='SUIT-0012';
SELECT do_return(last_rental(), 'SUIT-0012', 'DAMAGED', 1500, CURRENT_DATE, 100, 0, false, true);
SELECT 'بعد الفشل: إرجاعات=' || (SELECT count(*) FROM returns) ||
       ' سطور إرجاع=' || (SELECT count(*) FROM return_items) ||
       ' سجل حالة=' || (SELECT count(*) FROM item_status_history) ||
       ' حركات مخزون=' || (SELECT count(*) FROM inventory_transactions) ||
       ' حركات تأمين=' || (SELECT count(*) FROM insurance_transactions) ||
       ' تدقيق=' || (SELECT count(*) FROM audit_logs) ||
       ' حجوزات نشطة=' || (SELECT count(*) FROM item_bookings WHERE is_active) ||
       ' غرامات العقد=' || (SELECT extra_charges FROM rentals WHERE id=last_rental());
SELECT 'حالة القطعة بعد الفشل=' || status FROM product_items WHERE item_code='SUIT-0012';
SELECT 'حالة السطر=' || status FROM rental_items WHERE rental_id=last_rental();

\echo ''
\echo '=== R15: إلغاء الإرجاع — عكس كامل ==='
CREATE OR REPLACE FUNCTION do_void_return(p_ret int, p_reason text) RETURNS void AS $$
DECLARE r record; v_bal numeric; v_extra numeric := 0; v_restore numeric := 0;
        v_rental int; v_out int; v_derived "RentalStatus"; v_voided boolean;
BEGIN
  SELECT rental_id, is_voided INTO v_rental, v_voided FROM returns WHERE id=p_ret FOR UPDATE;
  IF v_voided THEN RAISE EXCEPTION 'عملية الإرجاع ملغاة بالفعل.'; END IF;

  FOR r IN SELECT * FROM return_items WHERE return_id=p_ret LOOP
    UPDATE rental_items SET status='OUT' WHERE id=r.rental_item_id;
    UPDATE product_items SET status='RENTED',
           total_fees_revenue = total_fees_revenue - (r.late_fee+r.damage_fee+r.loss_fee)
     WHERE id=r.item_id;
    INSERT INTO item_status_history (item_id, from_status, to_status, reason, ref_type, ref_id, user_id)
    VALUES (r.item_id, 'RENTED', 'RENTED', 'إلغاء إرجاع: '||p_reason, 'Return', p_ret, 1);
    UPDATE item_bookings SET is_active=true
     WHERE item_id=r.item_id AND source_type='RENTAL' AND source_id=v_rental;
    v_extra := v_extra + r.extra_due_from_customer;
    v_restore := v_restore + r.insurance_used + r.insurance_refunded;
  END LOOP;

  IF v_restore > 0 THEN
    SELECT COALESCE((SELECT balance_after FROM insurance_transactions ORDER BY id DESC LIMIT 1),0) INTO v_bal;
    INSERT INTO insurance_transactions (type, rental_id, amount, balance_after, reason, created_by)
    VALUES ('COLLECTED', v_rental, v_restore, v_bal + v_restore, 'عكس تسوية بإلغاء الإرجاع', 1);
  END IF;

  IF v_extra > 0 THEN
    UPDATE rentals SET extra_charges = GREATEST(extra_charges - v_extra, 0),
                       total_due = gross_amount + GREATEST(extra_charges - v_extra, 0),
                       remaining_amount = (gross_amount + GREATEST(extra_charges - v_extra,0)) - paid_amount
     WHERE id=v_rental;
  END IF;

  UPDATE returns SET is_voided=true, void_reason=p_reason, voided_by=1, voided_at=now() WHERE id=p_ret;

  SELECT count(*) INTO v_out FROM rental_items WHERE rental_id=v_rental AND status='OUT';
  IF v_out = 0 THEN v_derived := 'CLOSED';
  ELSIF v_out = (SELECT count(*) FROM rental_items WHERE rental_id=v_rental AND status<>'VOIDED') THEN v_derived := 'ACTIVE';
  ELSE v_derived := 'PARTIALLY_RETURNED'; END IF;
  UPDATE rentals SET status=v_derived WHERE id=v_rental;

  INSERT INTO audit_logs (user_id, action, entity_type, entity_id, reason)
  VALUES (1, 'return.void', 'Return', p_ret::text, p_reason);
END;
$$ LANGUAGE plpgsql;

SELECT 'قبل الإلغاء: العقد 4 المستحق=' || total_due || ' غرامات=' || extra_charges || ' الحالة=' || status FROM rentals WHERE id=4;
SELECT 'رصيد التأمين قبل=' || balance_after FROM insurance_transactions ORDER BY id DESC LIMIT 1;
SELECT do_void_return(4, 'تسجيل خاطئ من الموظف');
SELECT 'بعد الإلغاء: العقد 4 المستحق=' || total_due || ' غرامات=' || extra_charges || ' الحالة=' || status FROM rentals WHERE id=4;
SELECT 'حالة القطعة=' || status FROM product_items WHERE item_code='SUIT-0006';
SELECT 'حالة السطر=' || status FROM rental_items WHERE rental_id=4;
SELECT 'الإرجاع ملغى؟ ' || is_voided || ' السبب=' || void_reason FROM returns WHERE id=4;
SELECT 'رصيد التأمين بعد=' || balance_after FROM insurance_transactions ORDER BY id DESC LIMIT 1;
SELECT 'حجوزات نشطة=' || count(*) FROM item_bookings WHERE source_id=4 AND is_active;

\echo ''
\echo '=== R16: إلغاء الإرجاع مرتين (يجب أن يُرفض) ==='
SELECT do_void_return(4, 'محاولة ثانية');

\echo ''
\echo '=== R17: إعادة تفعيل إرجاع ملغى مباشرة (يجب أن يُرفض) ==='
UPDATE returns SET is_voided=false WHERE id=4;

\echo ''
\echo '=== R18: إعادة إرجاع القطعة بعد إلغاء الإرجاع (يجب أن ينجح) ==='
SELECT 'الإرجاع ' || do_return(4, 'SUIT-0006', 'GOOD', 0, CURRENT_DATE);

\echo ''
\echo '=== R19: حذف سطر إرجاع (يجب أن يُرفض) ==='
DELETE FROM return_items WHERE id = 1;

\echo ''
\echo '=== R20: ★ التأمين لا يختلط بالإيراد — تدقيق شامل ==='
SELECT 'إيراد التأجير (من سطور العقود)=' || COALESCE(SUM(net_price),0) FROM rental_items WHERE status <> 'VOIDED';
SELECT 'إيراد الغرامات (من سطور الإرجاع غير الملغاة)=' ||
       COALESCE(SUM(ri.late_fee+ri.damage_fee+ri.loss_fee),0)
  FROM return_items ri JOIN returns r ON r.id=ri.return_id WHERE r.is_voided=false;
SELECT 'التأمين المستخدم (سداد لا إيراد)=' || COALESCE(SUM(ri.insurance_used),0)
  FROM return_items ri JOIN returns r ON r.id=ri.return_id WHERE r.is_voided=false;
SELECT 'التأمين المردود (خروج التزام)=' || COALESCE(SUM(ri.insurance_refunded),0)
  FROM return_items ri JOIN returns r ON r.id=ri.return_id WHERE r.is_voided=false;
SELECT 'رصيد صندوق التأمين=' || balance_after FROM insurance_transactions ORDER BY id DESC LIMIT 1;
SELECT 'دفعات تأمينية (لا تدخل مدفوع العقود)=' || COALESCE(SUM(amount),0) FROM payments WHERE is_insurance;
SELECT 'مجموع مدفوع العقود=' || COALESCE(SUM(paid_amount),0) FROM rentals;
SELECT 'تحقق: أي سطر يخرق معادلة التسوية=' || count(*) FROM return_items
 WHERE insurance_used + extra_due_from_customer <> late_fee + damage_fee + loss_fee;
