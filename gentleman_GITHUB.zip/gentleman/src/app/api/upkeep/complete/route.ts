import { route } from '@/lib/api';
import { completeUpkeep, completeUpkeepSchema } from '@/services/upkeep.service';

export const POST = route({ schema: completeUpkeepSchema, handler: ({ input }) => completeUpkeep(input) });
