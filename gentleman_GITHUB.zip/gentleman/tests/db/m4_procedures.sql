-- إجراءات تحاكي خطوات ReturnService بالترتيب نفسه (للاختبار على قاعدة حقيقية)

CREATE OR REPLACE FUNCTION do_rental(
  p_item_codes text[], p_customer int, p_price numeric, p_discount numeric,
  p_paid numeric, p_deposit numeric, p_insurance numeric,
  p_start date DEFAULT CURRENT_DATE, p_end date DEFAULT CURRENT_DATE + 1
) RETURNS int AS $$
DECLARE v_rental int; v_item int; v_status text; v_code text;
        v_sub numeric; v_disc numeric; v_net numeric; v_bal numeric; v_n int;
BEGIN
  v_n := array_length(p_item_codes,1);
  v_sub := p_price * v_n; v_disc := p_discount * v_n; v_net := v_sub - v_disc;

  INSERT INTO rentals (rental_no, customer_id, rental_date, expected_return_date,
                       subtotal, discount, net_amount, gross_amount, total_due,
                       remaining_amount, deposit_amount, insurance_amount, created_by)
  VALUES ('R-'||nextval('rental_no_seq'), p_customer, p_start, p_end,
          v_sub, v_disc, v_net, v_net, v_net, v_net, p_deposit, p_insurance, 1)
  RETURNING id INTO v_rental;

  FOREACH v_code IN ARRAY p_item_codes LOOP
    SELECT id, status::text INTO v_item, v_status FROM product_items WHERE item_code=v_code FOR UPDATE;
    IF v_status <> 'AVAILABLE' THEN
      RAISE EXCEPTION 'لا يمكن تأجير القطعة % لأن حالتها %', v_code, v_status;
    END IF;
    INSERT INTO rental_items (rental_id, item_id, unit_rental_price, discount, net_price,
                              gross_amount, insurance_per_item, expected_return_date)
    VALUES (v_rental, v_item, p_price, p_discount, p_price-p_discount,
            p_price-p_discount, p_insurance/v_n, p_end);
    INSERT INTO item_bookings (item_id, start_date, end_date, source_type, source_id)
    VALUES (v_item, p_start, p_end, 'RENTAL', v_rental);
    INSERT INTO item_status_history (item_id, from_status, to_status, reason, ref_type, ref_id, user_id)
    VALUES (v_item, v_status::"ItemStatus", 'RENTED', 'عقد تأجير', 'Rental', v_rental, 1);
    UPDATE product_items SET status='RENTED', rental_count=rental_count+1, last_rental_date=p_start WHERE id=v_item;
    INSERT INTO inventory_transactions (item_id, trx_date, type, ref_type, ref_id, created_by)
    VALUES (v_item, p_start, 'RENT_OUT', 'Rental', v_rental, 1);
  END LOOP;

  IF p_paid > 0 THEN
    INSERT INTO payments (payment_no, purpose, rental_id, customer_id, amount, payment_method_id, created_by)
    VALUES ('PAY-'||nextval('payment_no_seq'), 'RENTAL', v_rental, p_customer, p_paid, 1, 1);
  END IF;
  IF p_insurance > 0 THEN
    INSERT INTO payments (payment_no, purpose, is_insurance, rental_id, customer_id, amount, payment_method_id, created_by)
    VALUES ('PAY-'||nextval('payment_no_seq'), 'INSURANCE_COLLECT', true, v_rental, p_customer, p_insurance, 1, 1);
    SELECT COALESCE((SELECT balance_after FROM insurance_transactions ORDER BY id DESC LIMIT 1),0) INTO v_bal;
    INSERT INTO insurance_transactions (type, customer_id, rental_id, amount, balance_after, created_by)
    VALUES ('COLLECTED', p_customer, v_rental, p_insurance, v_bal+p_insurance, 1);
  END IF;

  INSERT INTO audit_logs (user_id, action, entity_type, entity_id)
  VALUES (1, 'rental.create', 'Rental', v_rental::text);
  RETURN v_rental;
END;
$$ LANGUAGE plpgsql;

-- إرجاع قطعة واحدة (يحاكي ReturnService.createReturn)
CREATE OR REPLACE FUNCTION do_return(
  p_rental int, p_item_code text, p_condition text, p_extra_fee numeric,
  p_return_date date DEFAULT CURRENT_DATE, p_fee_per_day numeric DEFAULT 100,
  p_cap numeric DEFAULT 0, p_cleaning boolean DEFAULT false, p_fail boolean DEFAULT false
) RETURNS int AS $$
DECLARE
  v_ret int; v_line record; v_days int; v_late numeric; v_charges numeric;
  v_ins numeric; v_used numeric; v_ref numeric; v_extra numeric;
  v_new_item "ItemStatus"; v_new_line "RentalItemStatus"; v_bal numeric;
  v_rstatus text; v_out int; v_derived "RentalStatus";
BEGIN
  SELECT status::text INTO v_rstatus FROM rentals WHERE id=p_rental FOR UPDATE;
  IF v_rstatus = 'VOIDED' THEN RAISE EXCEPTION 'العقد ملغى ولا يقبل إرجاعًا.'; END IF;
  IF v_rstatus = 'CLOSED' THEN RAISE EXCEPTION 'العقد مغلق — كل قطعه أُرجعت بالفعل.'; END IF;

  SELECT ri.* INTO v_line FROM rental_items ri
    JOIN product_items pi ON pi.id = ri.item_id
   WHERE ri.rental_id=p_rental AND pi.item_code=p_item_code FOR UPDATE;
  IF v_line IS NULL THEN RAISE EXCEPTION 'القطعة ليست ضمن هذا العقد.'; END IF;
  IF v_line.status <> 'OUT' THEN RAISE EXCEPTION 'القطعة مُرجَعة بالفعل ولا يمكن إرجاعها مرة أخرى.'; END IF;

  v_days := GREATEST((p_return_date - v_line.expected_return_date), 0);
  v_late := v_days * p_fee_per_day;
  IF p_cap > 0 AND v_late > p_cap THEN v_late := p_cap; END IF;

  v_charges := v_late + p_extra_fee;
  v_ins := v_line.insurance_per_item;
  v_used := LEAST(v_charges, v_ins);
  v_ref := v_ins - v_used;
  v_extra := v_charges - v_used;

  INSERT INTO returns (return_no, rental_id, return_date, created_by)
  VALUES ('RT-'||nextval('rental_no_seq'), p_rental, p_return_date, 1) RETURNING id INTO v_ret;

  INSERT INTO return_items (return_id, rental_item_id, item_id, actual_return_date, days_late,
                            late_fee, condition, damage_fee, loss_fee,
                            insurance_used, insurance_refunded, extra_due_from_customer)
  VALUES (v_ret, v_line.id, v_line.item_id, p_return_date, v_days, v_late, p_condition::"ItemCondition",
          CASE WHEN p_condition='DAMAGED' THEN p_extra_fee ELSE 0 END,
          CASE WHEN p_condition='LOST' THEN p_extra_fee ELSE 0 END,
          v_used, v_ref, v_extra);

  v_new_line := CASE WHEN p_condition='LOST' THEN 'LOST' ELSE 'RETURNED' END::"RentalItemStatus";
  v_new_item := CASE p_condition
                  WHEN 'LOST' THEN 'LOST' WHEN 'DAMAGED' THEN 'DAMAGED'
                  ELSE (CASE WHEN p_cleaning THEN 'CLEANING' ELSE 'AVAILABLE' END) END::"ItemStatus";

  UPDATE rental_items SET status=v_new_line WHERE id=v_line.id;
  INSERT INTO item_status_history (item_id, from_status, to_status, reason, ref_type, ref_id, user_id)
  VALUES (v_line.item_id, 'RENTED', v_new_item, 'إرجاع', 'Return', v_ret, 1);
  UPDATE product_items SET status=v_new_item, last_return_date=p_return_date,
         total_fees_revenue = total_fees_revenue + v_charges WHERE id=v_line.item_id;
  INSERT INTO inventory_transactions (item_id, trx_date, type, ref_type, ref_id, created_by)
  VALUES (v_line.item_id, p_return_date,
          CASE WHEN p_condition='LOST' THEN 'WRITE_OFF' ELSE 'RETURN_IN' END::"InventoryTrxType",
          'Return', v_ret, 1);
  UPDATE item_bookings SET is_active=false
   WHERE item_id=v_line.item_id AND source_type='RENTAL' AND source_id=p_rental;

  IF p_fail THEN RAISE EXCEPTION 'فشل متعمّد في منتصف الإرجاع'; END IF;

  IF v_used > 0 THEN
    SELECT COALESCE((SELECT balance_after FROM insurance_transactions ORDER BY id DESC LIMIT 1),0) INTO v_bal;
    INSERT INTO insurance_transactions (type, rental_id, amount, balance_after, reason, created_by)
    VALUES ('DEDUCTED_DAMAGE', p_rental, v_used, v_bal - v_used, 'استقطاع لسداد غرامات', 1);
  END IF;
  IF v_ref > 0 THEN
    SELECT COALESCE((SELECT balance_after FROM insurance_transactions ORDER BY id DESC LIMIT 1),0) INTO v_bal;
    INSERT INTO insurance_transactions (type, rental_id, amount, balance_after, reason, created_by)
    VALUES ('REFUNDED', p_rental, v_ref, v_bal - v_ref, 'رد تأمين للعميل', 1);
  END IF;

  IF v_extra > 0 THEN
    UPDATE rentals SET extra_charges = extra_charges + v_extra,
                       total_due = gross_amount + extra_charges + v_extra,
                       remaining_amount = (gross_amount + extra_charges + v_extra) - paid_amount
     WHERE id = p_rental;
  END IF;

  SELECT count(*) INTO v_out FROM rental_items WHERE rental_id=p_rental AND status='OUT';
  IF v_out = 0 THEN v_derived := 'CLOSED';
  ELSIF v_out = (SELECT count(*) FROM rental_items WHERE rental_id=p_rental AND status<>'VOIDED') THEN v_derived := 'ACTIVE';
  ELSE v_derived := 'PARTIALLY_RETURNED'; END IF;
  UPDATE rentals SET status=v_derived WHERE id=p_rental;

  INSERT INTO audit_logs (user_id, action, entity_type, entity_id, after_json)
  VALUES (1, 'return.create', 'Return', v_ret::text,
          jsonb_build_object('charges', v_charges, 'insurance_used', v_used,
                             'insurance_refunded', v_ref, 'extra_due', v_extra));
  RETURN v_ret;
END;
$$ LANGUAGE plpgsql;

-- دوال مساعدة للاختبار: آخر عقد وآخر إرجاع
CREATE OR REPLACE FUNCTION last_rental() RETURNS int AS $$
  SELECT COALESCE(max(id), 0) FROM rentals;
$$ LANGUAGE sql;

CREATE OR REPLACE FUNCTION last_return() RETURNS int AS $$
  SELECT COALESCE(max(id), 0) FROM returns;
$$ LANGUAGE sql;
