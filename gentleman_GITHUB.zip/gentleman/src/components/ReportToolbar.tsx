'use client';

import { useRouter, useSearchParams } from 'next/navigation';

interface Props {
  catalog: { key: string; title: string; isFinancial: boolean }[];
  current: string;
  from: string;
  to: string;
  canExport: boolean;
}

/**
 * شريط التقارير: اختيار التقرير والفترة، والتصدير بالفلاتر المعروضة نفسها.
 */
export default function ReportToolbar({ catalog, current, from, to, canExport }: Props) {
  const router = useRouter();
  const params = useSearchParams();

  const go = (patch: Record<string, string>) => {
    const next = new URLSearchParams(params.toString());
    for (const [k, v] of Object.entries(patch)) next.set(k, v);
    router.push(`/reports?${next.toString()}`);
  };

  // ★ التصدير يحمل نفس الفلاتر المعروضة حرفيًا
  const exportUrl = (format: 'excel' | 'pdf') => {
    const next = new URLSearchParams(params.toString());
    next.set('key', current);
    next.set('from', from);
    next.set('to', to);
    next.set('format', format);
    return `/api/reports/export?${next.toString()}`;
  };

  return (
    <div className="card">
      <div className="card-header">اختيار التقرير والفترة</div>
      <div className="p-5 grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
        <div className="md:col-span-2">
          <label className="label">التقرير</label>
          <select
            className="input"
            value={current}
            onChange={(e) => go({ key: e.target.value })}
          >
            {catalog.map((r) => (
              <option key={r.key} value={r.key}>
                {r.title}{r.isFinancial ? ' (مالي)' : ''}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="label">من</label>
          <input
            className="input num" type="date" value={from}
            onChange={(e) => go({ from: e.target.value })}
          />
        </div>
        <div>
          <label className="label">إلى</label>
          <input
            className="input num" type="date" value={to}
            onChange={(e) => go({ to: e.target.value })}
          />
        </div>
      </div>

      {canExport && (
        <div className="px-5 pb-5 flex flex-wrap items-center gap-3">
          <a className="btn-primary" href={exportUrl('excel')}>تصدير Excel</a>
          <a className="btn-secondary" href={exportUrl('pdf')} target="_blank" rel="noopener">
            تصدير PDF
          </a>
          <span className="text-xs text-slate-400">
            التصدير يطابق الفلاتر والأرقام المعروضة تمامًا
          </span>
        </div>
      )}
    </div>
  );
}
