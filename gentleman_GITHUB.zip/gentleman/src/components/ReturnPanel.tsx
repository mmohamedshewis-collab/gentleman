'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

type Scanned = {
  rentalItemId: number; rentalId: number; rentalNo: string;
  customer: { fullName: string; phone: string | null };
  itemCode: string; productName: string; size: string | null; color: string | null;
  expectedReturnDate: string; daysLate: number; lateFee: string;
  lateFeeWasCapped: boolean; insuranceAvailable: string;
};

const CONDITIONS = [
  { key: 'GOOD', label: 'سليمة' },
  { key: 'DAMAGED', label: 'تالفة' },
  { key: 'LOST', label: 'مفقودة' },
] as const;

/** شاشة الإرجاع: Scan → يظهر العقد والتأخير → الحالة → إتمام. */
export default function ReturnPanel() {
  const router = useRouter();
  const [barcode, setBarcode] = useState('');
  const [item, setItem] = useState<Scanned | null>(null);
  const [condition, setCondition] = useState<'GOOD' | 'DAMAGED' | 'LOST'>('GOOD');
  const [fee, setFee] = useState('');
  const [description, setDescription] = useState('');
  const [msg, setMsg] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  const charges = Number(item?.lateFee ?? 0) + (condition === 'GOOD' ? 0 : Number(fee || 0));
  const insurance = Number(item?.insuranceAvailable ?? 0);
  const used = Math.min(charges, insurance);
  const refunded = insurance - used;
  const extraDue = charges - used;

  async function scan() {
    setBusy(true); setMsg(null); setItem(null);
    const res = await fetch(`/api/returns/scan?barcode=${encodeURIComponent(barcode)}`);
    const json = await res.json();
    setBusy(false);
    if (!json.ok) { setMsg({ type: 'err', text: json.error?.message ?? 'تعذّر البحث.' }); return; }
    setItem(json.data); setCondition('GOOD'); setFee(''); setDescription('');
  }

  async function submit() {
    if (!item) return;
    setBusy(true); setMsg(null);
    const res = await fetch('/api/returns', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        rentalId: item.rentalId,
        lines: [{
          rentalItemId: item.rentalItemId,
          condition,
          ...(condition === 'DAMAGED' ? { damageFee: Number(fee), damageDescription: description } : {}),
          ...(condition === 'LOST' ? { lossFee: Number(fee), damageDescription: description } : {}),
        }],
      }),
    });
    const json = await res.json();
    setBusy(false);
    if (!json.ok) { setMsg({ type: 'err', text: json.error?.message ?? 'تعذّر إتمام الإرجاع.' }); return; }
    setMsg({
      type: 'ok',
      text: `تم الإرجاع ${json.data.returnNo} — تأمين مردود ${json.data.insuranceRefunded} · مستحق إضافي ${json.data.extraDueFromCustomer}`,
    });
    setItem(null); setBarcode('');
    router.refresh();
  }

  return (
    <div className="space-y-5">
      <div className="card">
        <div className="card-header">إرجاع قطعة</div>
        <div className="p-5 flex gap-3 items-end">
          <div className="flex-1">
            <label className="label">امسح الباركود</label>
            <input
              className="input num" dir="ltr" autoFocus value={barcode}
              placeholder="SUIT-0001"
              onChange={(e) => setBarcode(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && scan()}
            />
          </div>
          <button className="btn-primary" onClick={scan} disabled={busy || !barcode}>بحث</button>
        </div>
      </div>

      {item && (
        <div className="card">
          <div className="card-header">{item.productName} · {item.itemCode}</div>
          <div className="p-5 space-y-5">
            <dl className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
              <div><dt className="text-slate-500">العقد</dt><dd className="font-semibold num">{item.rentalNo}</dd></div>
              <div><dt className="text-slate-500">العميل</dt><dd className="font-semibold">{item.customer.fullName}</dd></div>
              <div><dt className="text-slate-500">تاريخ الاستحقاق</dt><dd className="num">{String(item.expectedReturnDate).slice(0, 10)}</dd></div>
              <div>
                <dt className="text-slate-500">أيام التأخير</dt>
                <dd className={`font-bold num ${item.daysLate > 0 ? 'text-danger' : 'text-ok'}`}>{item.daysLate}</dd>
              </div>
            </dl>

            <div>
              <label className="label">حالة القطعة عند الإرجاع</label>
              <div className="flex gap-2">
                {CONDITIONS.map((c) => (
                  <button
                    key={c.key}
                    className={condition === c.key ? 'btn-primary' : 'btn-secondary'}
                    onClick={() => { setCondition(c.key); setFee(''); }}
                  >
                    {c.label}
                  </button>
                ))}
              </div>
            </div>

            {condition !== 'GOOD' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="label">{condition === 'DAMAGED' ? 'قيمة التلف' : 'قيمة تعويض الفقد'}</label>
                  <input className="input num" dir="ltr" type="number" value={fee}
                         onChange={(e) => setFee(e.target.value)} />
                </div>
                <div>
                  <label className="label">الوصف</label>
                  <input className="input" value={description} onChange={(e) => setDescription(e.target.value)} />
                </div>
              </div>
            )}

            <div className="rounded-lg bg-brand-soft border border-brand-light/30 p-4">
              <div className="grid grid-cols-2 md:grid-cols-5 gap-3 text-sm">
                <div><div className="text-slate-500">غرامة التأخير</div><div className="font-bold num">{item.lateFee}</div></div>
                <div><div className="text-slate-500">إجمالي الغرامات</div><div className="font-bold num">{charges.toFixed(2)}</div></div>
                <div><div className="text-slate-500">التأمين المحصَّل</div><div className="font-bold num">{insurance.toFixed(2)}</div></div>
                <div><div className="text-slate-500">المردود للعميل</div><div className="font-bold num text-ok">{refunded.toFixed(2)}</div></div>
                <div><div className="text-slate-500">مستحق إضافي</div><div className="font-bold num text-danger">{extraDue.toFixed(2)}</div></div>
              </div>
              <p className="text-[11px] text-slate-500 mt-3">
                التأمين المستخدم لسداد الغرامات لا يُحتسب إيرادًا إضافيًا — الإيراد هو الغرامة نفسها.
              </p>
            </div>

            <div className="flex items-center gap-4">
              <button
                className="btn-primary"
                onClick={submit}
                disabled={busy || (condition !== 'GOOD' && Number(fee) <= 0)}
              >
                {busy ? 'جارٍ الحفظ…' : 'إتمام الإرجاع'}
              </button>
              {msg && (
                <span className={`text-sm font-semibold ${msg.type === 'ok' ? 'text-ok' : 'text-danger'}`}>{msg.text}</span>
              )}
            </div>
          </div>
        </div>
      )}

      {!item && msg && (
        <p className={`text-sm font-semibold ${msg.type === 'ok' ? 'text-ok' : 'text-danger'}`}>{msg.text}</p>
      )}
    </div>
  );
}
