import { formatInTimeZone, toZonedTime, fromZonedTime } from 'date-fns-tz';
import { differenceInCalendarDays, addDays } from 'date-fns';

export const APP_TZ = process.env.APP_TIMEZONE || 'Africa/Cairo';

/** تاريخ العمل الحالي بتوقيت مصر (بدون وقت). */
export function businessToday(now: Date = new Date()): Date {
  const zoned = toZonedTime(now, APP_TZ);
  return new Date(
    Date.UTC(zoned.getFullYear(), zoned.getMonth(), zoned.getDate()),
  );
}

/** تحويل "YYYY-MM-DD" إلى تاريخ يوم صافٍ يُخزَّن كـ DATE. */
export function toBusinessDate(input: string | Date): Date {
  if (input instanceof Date) return businessToday(input);
  const [y, mo, d] = input.split('-').map(Number);
  return new Date(Date.UTC(y, mo - 1, d));
}

/** بداية ونهاية فترة تقرير [من 00:00:00 → إلى 23:59:59.999] بتوقيت مصر. */
export function periodBounds(from: string, to: string) {
  const start = fromZonedTime(`${from} 00:00:00`, APP_TZ);
  const end = fromZonedTime(`${to} 23:59:59.999`, APP_TZ);
  if (end < start) throw new Error('PERIOD_INVALID');
  return { start, end };
}

/** أيام التأخير = أيام تقويمية كاملة. الإرجاع في يوم الاستحقاق = 0. */
export function daysLate(expected: Date, actual: Date): number {
  const diff = differenceInCalendarDays(actual, expected);
  return diff > 0 ? diff : 0;
}

export const addBusinessDays = (d: Date, days: number): Date => addDays(d, days);

export const formatDate = (d: Date): string =>
  formatInTimeZone(d, APP_TZ, 'yyyy-MM-dd');

export const formatDateTime = (d: Date): string =>
  formatInTimeZone(d, APP_TZ, 'yyyy-MM-dd HH:mm');
