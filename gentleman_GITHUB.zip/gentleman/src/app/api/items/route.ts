import { route } from '@/lib/api';
import { listItems, itemQuerySchema, createItems, createItemsSchema } from '@/services/item.service';

export const GET = route({ schema: itemQuerySchema, handler: ({ input }) => listItems(input) });
export const POST = route({ schema: createItemsSchema, handler: ({ input }) => createItems(input) });
