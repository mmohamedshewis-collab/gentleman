import { z } from 'zod';
import { prisma } from '@/lib/db';
import { requirePermission } from '@/lib/auth/rbac';
import { periodBounds } from '@/lib/date';

export const auditQuerySchema = z.object({
  from: z.string().optional(),
  to: z.string().optional(),
  entityType: z.string().optional(),
  action: z.string().optional(),
  userId: z.coerce.number().int().optional(),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(10).max(200).default(50),
});

export async function queryAuditLogs(input: z.infer<typeof auditQuerySchema>) {
  await requirePermission('audit.view');

  const where: Record<string, unknown> = {};
  if (input.from && input.to) {
    const { start, end } = periodBounds(input.from, input.to);
    where.createdAt = { gte: start, lte: end };
  }
  if (input.entityType) where.entityType = input.entityType;
  if (input.action) where.action = { contains: input.action };
  if (input.userId) where.userId = input.userId;

  const [rows, total] = await Promise.all([
    prisma.auditLog.findMany({
      where,
      include: { user: { select: { fullName: true, username: true } } },
      orderBy: { createdAt: 'desc' },
      skip: (input.page - 1) * input.pageSize,
      take: input.pageSize,
    }),
    prisma.auditLog.count({ where }),
  ]);

  return { rows, total, page: input.page, pageSize: input.pageSize };
}
