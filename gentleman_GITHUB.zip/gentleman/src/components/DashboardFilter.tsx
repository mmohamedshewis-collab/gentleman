'use client';

import { useRouter } from 'next/navigation';

/** فلتر الفترة — يؤثر على مؤشرات الفترة وحدها، لا على الأرصدة ولا مؤشرات اليوم. */
export default function DashboardFilter({ from, to }: { from: string; to: string }) {
  const router = useRouter();

  const go = (patch: Record<string, string>) => {
    const params = new URLSearchParams({ from, to, ...patch });
    router.push(`/?${params.toString()}`);
  };

  return (
    <div className="card">
      <div className="p-4 flex flex-wrap gap-4 items-end">
        <div>
          <label className="label">من</label>
          <input className="input num" type="date" value={from}
                 onChange={(e) => go({ from: e.target.value })} />
        </div>
        <div>
          <label className="label">إلى</label>
          <input className="input num" type="date" value={to}
                 onChange={(e) => go({ to: e.target.value })} />
        </div>
        <p className="text-xs text-slate-400 pb-2">
          الفلتر يؤثر على مؤشرات الفترة فقط — الأرصدة الحالية ومؤشرات اليوم ثابتة
        </p>
      </div>
    </div>
  );
}
