import { Decimal } from 'decimal.js';
import { round2, add } from '@/lib/money';

/**
 * عقد موحّد لكل التقارير.
 *
 * ★ كل تقرير يُنتج `ReportResult` واحدًا، ويستهلكه العرض و Excel و PDF معًا.
 *   هذا يمنع ازدواج منطق التقارير: مصدر واحد للأرقام، وثلاث واجهات عرض.
 */

export type ColumnType = 'text' | 'number' | 'money' | 'date' | 'percent';

export interface ReportColumn {
  key: string;
  label: string;
  type: ColumnType;
  /** يُجمَع في سطر الإجمالي */
  sum?: boolean;
}

export type ReportCell = string | number | null;
export type ReportRow = Record<string, ReportCell>;

export interface ReportResult {
  key: string;
  title: string;
  /** وصف الفترة كما اختارها المستخدم */
  period: string;
  /** الفلاتر المطبَّقة فعلًا — تظهر في الشاشة وفي التصدير بنفس النص */
  appliedFilters: { label: string; value: string }[];
  columns: ReportColumn[];
  rows: ReportRow[];
  totals: ReportRow | null;
  /** ملاحظات محاسبية تظهر أسفل التقرير وفي التصدير */
  notes: string[];
  generatedAt: string;
}

/** يبني سطر الإجماليات من الأعمدة المعلَّمة بـ sum. */
export function buildTotals(columns: ReportColumn[], rows: ReportRow[]): ReportRow | null {
  const sumCols = columns.filter((c) => c.sum);
  if (sumCols.length === 0 || rows.length === 0) return null;

  const totals: ReportRow = {};
  for (const c of columns) totals[c.key] = null;

  for (const c of sumCols) {
    const values = rows.map((r) => {
      const v = r[c.key];
      if (v === null || v === undefined || v === '') return 0;
      return typeof v === 'number' ? v : Number(v);
    });
    const sum = values.reduce<Decimal>((a, b) => a.plus(Number.isFinite(b) ? b : 0), new Decimal(0));
    totals[c.key] = c.type === 'number' ? sum.toNumber() : round2(sum).toString();
  }

  const first = columns[0];
  if (totals[first.key] === null) totals[first.key] = 'الإجمالي';
  return totals;
}

/** تنسيق خلية للعرض النصي — يُستخدم في PDF و Excel بنفس القواعد. */
export function formatCell(value: ReportCell, type: ColumnType): string {
  if (value === null || value === undefined || value === '') return '—';
  switch (type) {
    case 'money':
      return new Intl.NumberFormat('ar-EG', {
        numberingSystem: 'latn',
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      }).format(Number(value));
    case 'number':
      return new Intl.NumberFormat('ar-EG', { numberingSystem: 'latn' }).format(Number(value));
    case 'percent':
      return `${Number(value)}%`;
    default:
      return String(value);
  }
}

export const money = (v: Decimal.Value): string => round2(v).toString();
export const sumMoney = (v: Decimal.Value[]): string => (v.length ? add(...v).toString() : '0');

/** الملاحظات المحاسبية الثابتة — تظهر كما هي في الشاشة والتصدير. */
export const NOTES = {
  insuranceNotRevenue: 'التأمين المحصَّل ليس إيرادًا ولا يظهر في هذا التقرير.',
  voidedExcluded: 'العمليات الملغاة مستبعدة من كل الأرقام.',
  costForProfitOnly: 'تكلفة الشراء تُستخدم لتحليل الربحية فقط ولا تُسجَّل مصروفًا عند الشراء.',
  cashOnly: 'الأرقام النقدية تشمل النقد فقط — الفيزا والتحويل البنكي مستبعدان.',
  notExpenses: 'السلف وردود العملاء وشراء القطع والترحيل للخزينة خروج نقدي وليست مصروفات.',
  commissionViaExpense: 'العمولة تدخل الربح عبر مصروف الصرف فقط، لا عبر الأرقام التحليلية.',
  lifetimeProfit: 'ربحية القطعة تُحسب عبر عمرها كاملًا، لا في شهر بيعها وحده.',
  estimatedProfit:
    'صافي الربح تقديري: تكلفة شراء القطعة تُحمَّل عند بيعها لا موزّعة على عمرها، ' +
    'فقد يظهر ربح الشهر سالبًا رغم ربحية القطعة الحقيقية. راجع تقرير «ربحية القطعة عبر عمرها».',
};
