import { describe, it, expect, vi, beforeEach } from 'vitest';
import { readFileSync } from 'node:fs';
import {
  UPKEEP_LABELS, UPKEEP_STATUS, UPKEEP_EXPENSE_CATEGORY,
  assertCost, assertDates, requiresExpense, lifetimeProfit, sumCosts, UpkeepError,
} from '../src/lib/inventory/upkeep';

const s = (v: { toString(): string }) => v.toString();

// ============================ الوحدة ============================

describe('منطق الصيانة والتنظيف', () => {
  it('لكل نوع حالته وتصنيف مصروفه', () => {
    expect(UPKEEP_STATUS.MAINTENANCE).toBe('MAINTENANCE');
    expect(UPKEEP_STATUS.CLEANING).toBe('CLEANING');
    expect(UPKEEP_EXPENSE_CATEGORY.MAINTENANCE).toBe('صيانة');
    expect(UPKEEP_EXPENSE_CATEGORY.CLEANING).toBe('تنظيف');
    expect(UPKEEP_LABELS.MAINTENANCE).toBe('صيانة');
  });

  it('يرفض تكلفة سالبة ويقبل الصفر', () => {
    expect(() => assertCost(-1)).toThrowError(UpkeepError);
    expect(s(assertCost(0))).toBe('0');
    expect(s(assertCost(200.5))).toBe('200.5');
  });

  it('★ التكلفة الصفرية لا تُنشئ مصروفًا', () => {
    expect(requiresExpense(0)).toBe(false);
    expect(requiresExpense(200)).toBe(true);
  });

  it('يرفض تاريخ إنهاء قبل البدء', () => {
    const a = new Date('2026-08-10');
    const b = new Date('2026-08-05');
    expect(() => assertDates(a, b)).toThrowError(UpkeepError);
    expect(() => assertDates(a, new Date('2026-08-12'))).not.toThrow();
    expect(() => assertDates(a, null)).not.toThrow();
  });

  it('يجمع تكاليف السجلات', () => {
    expect(s(sumCosts([{ cost: 200 }, { cost: 150.5 }]))).toBe('350.5');
    expect(s(sumCosts([]))).toBe('0');
  });
});

// ==================== ★ تصحيح ربحية القطعة ====================

describe('★ ربحية القطعة عبر عمرها — التصحيح', () => {
  const base = {
    rentalRevenue: 5000, feesRevenue: 0, saleRevenue: 0, purchaseCost: 6000,
  };

  it('★ قبل التصحيح: تكلفة صفرية ⟹ ربحية مبالغ فيها', () => {
    const before = lifetimeProfit({ ...base, maintenanceCost: 0, cleaningCost: 0 });
    expect(s(before.profit)).toBe('-1000');
  });

  it('★ بعد التصحيح: تكلفة صيانة 800 ⟹ ربحية أدق', () => {
    const after = lifetimeProfit({ ...base, maintenanceCost: 800, cleaningCost: 0 });
    expect(s(after.profit)).toBe('-1800');
    expect(s(after.upkeepCost)).toBe('800');
  });

  it('★ تكلفة التنظيف تُحتسب أيضًا', () => {
    const r = lifetimeProfit({ ...base, maintenanceCost: 0, cleaningCost: 450 });
    expect(s(r.profit)).toBe('-1450');
  });

  it('★ الاختبار الشامل: شراء 6,000 · تأجير 9,000 · صيانة 800 · تنظيف 450', () => {
    const r = lifetimeProfit({
      rentalRevenue: 9000, feesRevenue: 500, saleRevenue: 1300,
      purchaseCost: 6000, maintenanceCost: 800, cleaningCost: 450,
    });
    // الإيراد = 9000 + 500 + 1300 = 10,800
    expect(s(r.totalRevenue)).toBe('10800');
    // الصيانة والتنظيف = 1,250
    expect(s(r.upkeepCost)).toBe('1250');
    // التكلفة = 6,000 + 1,250 = 7,250
    expect(s(r.totalCost)).toBe('7250');
    // الربحية = 10,800 − 7,250 = 3,550
    expect(s(r.profit)).toBe('3550');
  });

  it('★ قطعة بلا صيانة ولا تنظيف تحتفظ بنتيجتها السابقة', () => {
    const r = lifetimeProfit({ ...base, maintenanceCost: 0, cleaningCost: 0 });
    // نفس المعادلة القديمة: إيراد − تكلفة شراء
    expect(s(r.profit)).toBe(s(lifetimeProfit({ ...base, maintenanceCost: 0, cleaningCost: 0 }).profit));
    expect(s(r.upkeepCost)).toBe('0');
    expect(s(r.totalCost)).toBe('6000');
  });

  it('★ تعريف الإيراد لم يتغيّر — الإيراد مجموع مصادره الثلاثة فقط', () => {
    const r = lifetimeProfit({
      rentalRevenue: 100, feesRevenue: 20, saleRevenue: 30,
      purchaseCost: 999, maintenanceCost: 888, cleaningCost: 777,
    });
    expect(s(r.totalRevenue)).toBe('150');   // لا تؤثر التكاليف على الإيراد
  });

  it('★ تعريف تكلفة الشراء لم يتغيّر — لا رسملة للصيانة', () => {
    const r = lifetimeProfit({ ...base, maintenanceCost: 800, cleaningCost: 0 });
    // تكلفة الشراء تبقى 6000 والصيانة بند منفصل
    expect(s(r.totalCost.minus(r.upkeepCost))).toBe('6000');
  });

  it('★ تقرير M7 يقرأ السجلات نفسها — التصحيح يسري تلقائيًا', () => {
    const src = readFileSync('src/services/report.service.ts', 'utf8');
    expect(src).toContain('i.maintenance.reduce');
    expect(src).toContain('i.cleaning.reduce');
  });
});

// ============================ الخدمة ============================

const H = vi.hoisted(() => ({ auditSpy: vi.fn() }));
const { auditSpy } = H;

let currentUser: { id: number; employeeId: number | null; permissions: Set<string> };
let itemRow: { id: number; item_code: string; status: string };
let recordRow: Record<string, unknown> | null;
let categoryRow: Record<string, unknown> | null;
const created: Record<string, unknown[]> = {};
const track = (k: string) => (a: { data: Record<string, unknown> }) => {
  (created[k] ??= []).push(a.data);
  return { id: created[k].length, ...a.data };
};

const tx = {
  $queryRaw: vi.fn(async () => [itemRow]),
  $executeRaw: vi.fn(async () => 1),
  expenseCategory: { findFirst: vi.fn(async () => categoryRow) },
  expense: { findFirst: vi.fn(async () => null), create: vi.fn(track('expense')) },
  maintenanceRecord: {
    create: vi.fn(track('maintenance')),
    findUnique: vi.fn(async () => recordRow),
    update: vi.fn(track('maintenanceUpdate')),
  },
  cleaningRecord: {
    create: vi.fn(track('cleaning')),
    findUnique: vi.fn(async () => recordRow),
    update: vi.fn(track('cleaningUpdate')),
  },
  itemStatusHistory: { create: vi.fn(track('history')) },
  productItem: { update: vi.fn(track('itemUpdate')) },
};

vi.mock('@/lib/db', () => ({
  prisma: {
    $transaction: (fn: any) => fn(tx),
    maintenanceRecord: { findMany: vi.fn(async () => []) },
    cleaningRecord: { findMany: vi.fn(async () => []) },
  },
}));

vi.mock('@/lib/audit', () => ({ writeAudit: H.auditSpy, redact: (x: unknown) => x }));

vi.mock('@/lib/auth/rbac', async (importOriginal) => {
  const actual = await importOriginal<typeof import('@/lib/auth/rbac')>();
  return {
    ...actual,
    requirePermission: async (perm: string) => {
      if (!currentUser.permissions.has(perm)) {
        const { Errors } = await import('@/lib/errors');
        throw Errors.forbidden(perm);
      }
      return currentUser as never;
    },
  };
});

beforeEach(() => {
  auditSpy.mockClear();
  for (const k of Object.keys(created)) delete created[k];
  for (const m of Object.values(tx)) {
    if (typeof m === 'object' && m !== null) {
      for (const f of Object.values(m)) if (typeof f === 'function' && 'mockClear' in f) (f as any).mockClear();
    } else if (typeof m === 'function' && 'mockClear' in m) (m as any).mockClear();
  }
  itemRow = { id: 1, item_code: 'SUIT-0001', status: 'AVAILABLE' };
  recordRow = null;
  categoryRow = { id: 5, nameAr: 'صيانة' };
  currentUser = {
    id: 1, employeeId: 1,
    permissions: new Set(['items.view', 'items.manage', 'insurance.view', 'insurance.manage']),
  };
});

describe('تسجيل الصيانة', () => {
  it('★ ينشئ السجل والمصروف وسجل الحالة وينقل القطعة', async () => {
    const { startUpkeep } = await import('@/services/upkeep.service');
    const r = await startUpkeep({
      itemId: 1, kind: 'MAINTENANCE', cost: 800,
      paymentMethodId: 1, description: 'إصلاح بطانة',
    });

    expect(r.cost).toBe('800');
    // ★ التكلفة مربوطة بالقطعة
    expect(created.maintenance[0]).toMatchObject({ itemId: 1, cost: '800' });
    // ★ مصروف واحد بالمسار المعتمد
    expect(created.expense).toHaveLength(1);
    expect(created.expense[0]).toMatchObject({ amount: '800', categoryId: 5 });
    // ★ مربوط بالمصروف
    expect(created.maintenance[0].expenseId).toBe(1);
    // ★ يظهر في تاريخ القطعة
    expect(created.history[0]).toMatchObject({
      itemId: 1, toStatus: 'MAINTENANCE', refType: 'MaintenanceRecord',
    });
    expect(created.itemUpdate[0]).toMatchObject({ status: 'MAINTENANCE' });
  });

  it('★ التكلفة الصفرية لا تُنشئ مصروفًا', async () => {
    const { startUpkeep } = await import('@/services/upkeep.service');
    await startUpkeep({ itemId: 1, kind: 'MAINTENANCE', cost: 0 });
    expect(created.expense).toBeUndefined();
    expect(created.maintenance[0]).toMatchObject({ cost: '0', expenseId: null });
  });

  it('★ الصيانة ليست إيرادًا', async () => {
    const { startUpkeep } = await import('@/services/upkeep.service');
    await startUpkeep({ itemId: 1, kind: 'MAINTENANCE', cost: 800, paymentMethodId: 1 });
    expect(auditSpy.mock.calls[0][0]).toMatchObject({
      action: 'upkeep.start',
      after: { revenueImpact: '0', kind: 'MAINTENANCE' },
    });
  });

  it('يرفض تكلفة بلا طريقة دفع', async () => {
    const { startUpkeep } = await import('@/services/upkeep.service');
    await expect(startUpkeep({ itemId: 1, kind: 'MAINTENANCE', cost: 800 }))
      .rejects.toMatchObject({ code: 'BUSINESS_RULE' });
  });

  it('يرفض فئة مصروف غير موجودة', async () => {
    categoryRow = null;
    const { startUpkeep } = await import('@/services/upkeep.service');
    await expect(startUpkeep({ itemId: 1, kind: 'MAINTENANCE', cost: 800, paymentMethodId: 1 }))
      .rejects.toMatchObject({ code: 'BUSINESS_RULE' });
  });

  it('★ يحترم آلة الحالة القائمة — لا يُنشئ منطق حالة جديد', async () => {
    itemRow = { id: 1, item_code: 'SUIT-0001', status: 'SOLD' };
    const { startUpkeep } = await import('@/services/upkeep.service');
    await expect(startUpkeep({ itemId: 1, kind: 'MAINTENANCE', cost: 0 }))
      .rejects.toMatchObject({ code: 'BUSINESS_RULE' });
    expect(created.maintenance).toBeUndefined();
  });

  it('★ يرفض التكرار — القطعة في الحالة نفسها', async () => {
    itemRow = { id: 1, item_code: 'SUIT-0001', status: 'MAINTENANCE' };
    const { startUpkeep } = await import('@/services/upkeep.service');
    await expect(startUpkeep({ itemId: 1, kind: 'MAINTENANCE', cost: 0 }))
      .rejects.toMatchObject({ code: 'CONFLICT' });
  });

  it('يحتاج صلاحية items.manage', async () => {
    currentUser = { id: 9, employeeId: 3, permissions: new Set(['items.view']) };
    const { startUpkeep } = await import('@/services/upkeep.service');
    await expect(startUpkeep({ itemId: 1, kind: 'MAINTENANCE', cost: 0 }))
      .rejects.toMatchObject({ code: 'PERM_DENIED', details: { permission: 'items.manage' } });
  });
});

describe('تسجيل التنظيف', () => {
  beforeEach(() => {
    itemRow = { id: 1, item_code: 'SUIT-0001', status: 'RENTED' };
    categoryRow = { id: 6, nameAr: 'تنظيف' };
  });

  it('★ ينشئ سجل تنظيف بتكلفته مربوطًا بالقطعة', async () => {
    const { startUpkeep } = await import('@/services/upkeep.service');
    const r = await startUpkeep({
      itemId: 1, kind: 'CLEANING', cost: 150,
      paymentMethodId: 1, refType: 'Return', refId: 42,
    });
    expect(r.status).toBe('CLEANING');
    expect(created.cleaning[0]).toMatchObject({ itemId: 1, cost: '150' });
    expect(created.expense[0]).toMatchObject({ amount: '150', categoryId: 6 });
    // ★ مرتبط بعملية الإرجاع في وصف المصروف
    expect(String(created.expense[0].description)).toContain('Return #42');
  });

  it('★ يظهر في تاريخ القطعة', async () => {
    const { startUpkeep } = await import('@/services/upkeep.service');
    await startUpkeep({ itemId: 1, kind: 'CLEANING', cost: 150, paymentMethodId: 1 });
    expect(created.history[0]).toMatchObject({
      itemId: 1, fromStatus: 'RENTED', toStatus: 'CLEANING', refType: 'CleaningRecord',
    });
  });

  it('★ التنظيف ليس إيرادًا', async () => {
    const { startUpkeep } = await import('@/services/upkeep.service');
    await startUpkeep({ itemId: 1, kind: 'CLEANING', cost: 150, paymentMethodId: 1 });
    expect(auditSpy.mock.calls[0][0]).toMatchObject({ after: { revenueImpact: '0' } });
  });

  it('★ لا يزيد الحقل المجمَّع للصيانة', async () => {
    const { startUpkeep } = await import('@/services/upkeep.service');
    await startUpkeep({ itemId: 1, kind: 'CLEANING', cost: 150, paymentMethodId: 1 });
    expect(created.itemUpdate[0]).not.toHaveProperty('totalMaintenanceCost');
  });
});

describe('إنهاء العملية', () => {
  beforeEach(() => {
    itemRow = { id: 1, item_code: 'SUIT-0001', status: 'MAINTENANCE' };
    recordRow = {
      id: 1, itemId: 1, startDate: new Date('2026-08-10'),
      endDate: null, cost: { toString: () => '800' },
    };
  });

  it('يعيد القطعة إلى الخدمة ويسجّل ذلك', async () => {
    const { completeUpkeep } = await import('@/services/upkeep.service');
    const r = await completeUpkeep({ recordId: 1, kind: 'MAINTENANCE', toStatus: 'AVAILABLE' });
    expect(r.status).toBe('AVAILABLE');
    expect(created.history[0]).toMatchObject({ fromStatus: 'MAINTENANCE', toStatus: 'AVAILABLE' });
    expect(auditSpy.mock.calls[0][0]).toMatchObject({ action: 'upkeep.complete' });
  });

  it('يرفض إنهاء عملية منتهية', async () => {
    recordRow = { ...recordRow, endDate: new Date('2026-08-12') };
    const { completeUpkeep } = await import('@/services/upkeep.service');
    await expect(completeUpkeep({ recordId: 1, kind: 'MAINTENANCE', toStatus: 'AVAILABLE' }))
      .rejects.toMatchObject({ code: 'BUSINESS_RULE' });
  });
});

// ==================== Q13: التأمين الراكد ====================

describe('★ Q13 — تحويل التأمين الراكد', () => {
  it('★ يعيد استخدام آلية M6 نفسها بلا منطق تأمين ثانٍ', () => {
    const src = readFileSync('src/services/finance.service.ts', 'utf8');
    expect(src).toContain("type: 'TRANSFERRED_TO_COMPANY'");
    expect(src).toContain("hashtext('insurance_ledger')");
    expect(src).toContain('balanceAfter');
    // لا دفتر تأمين ثانٍ
    expect(src).not.toContain('dormantLedger');
  });

  it('★ التحويل إيراد بلا تحصيل نقدي — نفس منطق التأمين المُستبقى', () => {
    const src = readFileSync('src/services/finance.service.ts', 'utf8');
    expect(src).toContain("cashInflow: '0'");
    expect(src).toContain('المال في الدرج أصلًا');
  });

  it('★ الاعتماد والسبب إلزاميان', async () => {
    const { transferDormantSchema } = await import('@/services/finance.service');
    expect(transferDormantSchema.safeParse({ rentalId: 1, amount: 500 }).success).toBe(false);
    expect(transferDormantSchema.safeParse({ rentalId: 1, amount: 500, reason: 'راكد' }).success).toBe(true);
    // approvedBy يُضبط من المستخدم المعتمِد في الخدمة
    const src = readFileSync('src/services/finance.service.ts', 'utf8');
    expect(src).toContain('approvedBy: actor.id');
  });

  it('يرفض مبلغًا غير موجب', async () => {
    const { transferDormantSchema } = await import('@/services/finance.service');
    expect(transferDormantSchema.safeParse({ rentalId: 1, amount: 0, reason: 'س' }).success).toBe(false);
  });

  it('★ التقرير يستخدم الإعداد المعتمد insurance.dormant_days', () => {
    const src = readFileSync('src/services/finance.service.ts', 'utf8');
    expect(src).toContain("getNumberSetting('insurance.dormant_days')");
  });
});

// ==================== النطاق ====================

describe('انضباط النطاق', () => {
  it('★ لا صلاحية جديدة', async () => {
    const { PERMISSIONS } = await import('../src/lib/auth/permissions');
    // 56 بعد حذف صلاحيتين بلا تنفيذ في ترقيع M-2
    expect(PERMISSIONS.length).toBe(56);
  });

  it('★ لا منطق محاسبي جديد ولا إهلاك (في الكود لا التعليقات)', () => {
    for (const f of ['src/services/upkeep.service.ts', 'src/lib/inventory/upkeep.ts']) {
      // نستبعد أسطر التعليقات: بعضها ينفي وجود الإهلاك صراحةً
      const code = readFileSync(f, 'utf8')
        .split('\n')
        .filter((l) => !/^\s*(\/\/|\*|\/\*)/.test(l))
        .join('\n');
      expect(/journal|chart_of_accounts|double-entry|depreciat/i.test(code)).toBe(false);
    }
  });

  it('★ لا منطق حالة مكرر — يستخدم canTransition القائمة', () => {
    const src = readFileSync('src/services/upkeep.service.ts', 'utf8');
    expect(src).toContain("from '@/lib/inventory/item-state'");
    expect(src).toContain('canTransition');
    expect(src).not.toContain('ALLOWED_TRANSITIONS = ');
  });

  it('★ خارج النطاق: لا موردون ولا رفع صور', () => {
    const src = readFileSync('src/services/upkeep.service.ts', 'utf8');
    expect(src).not.toContain('supplier');
    expect(src).not.toContain('imageKey');
  });
});

// ==================== ★ الاختبار الشامل من طرف لطرف ====================

describe('★ E2E — التصحيح يسري في تقرير M7 نفسه', () => {
  it('★ تقرير ربحية القطعة يطرح الصيانة والتنظيف الفعليين', async () => {
    // قطعة: شراء 6,000 · تأجير 9,000 · غرامات 500 · بيع 1,300
    //        صيانة 800 · تنظيف 450
    vi.resetModules();
    vi.doMock('@/lib/db', () => ({
      prisma: {
        productItem: {
          findMany: async () => [{
            id: 1, itemCode: 'SUIT-0001', status: 'SOLD', rentalCount: 12,
            purchaseCost: { toString: () => '6000' },
            totalRentalRevenue: { toString: () => '9000' },
            totalFeesRevenue: { toString: () => '500' },
            product: { nameAr: 'بدلة كلاسيك' },
            saleItems: [{ sale: { status: 'COMPLETED' }, netPrice: { toString: () => '1300' } }],
            maintenance: [{ cost: { toString: () => '800' } }],
            cleaning: [
              { cost: { toString: () => '300' } },
              { cost: { toString: () => '150' } },
            ],
          }],
        },
        customer: { findUnique: async () => null },
        employee: { findUnique: async () => null },
        product: { findUnique: async () => null },
        paymentMethod: { findUnique: async () => null },
        expenseCategory: { findUnique: async () => null },
      },
    }));
    vi.doMock('@/lib/auth/rbac', async (importOriginal) => {
      const actual = await importOriginal<typeof import('@/lib/auth/rbac')>();
      return { ...actual, requirePermission: async () => ({ id: 1 }) as never };
    });

    const { runReport } = await import('@/services/report.service');
    const report = await runReport({ key: 'item-profitability' });
    const row = report.rows[0];

    expect(row.rentalRevenue).toBe('9000');
    expect(row.feesRevenue).toBe('500');
    expect(row.saleRevenue).toBe('1300');
    expect(row.purchaseCost).toBe('6000');
    // ★ الصيانة + التنظيف = 800 + 450 = 1,250 — كانت صفرًا قبل M11
    expect(row.upkeepCost).toBe('1250');
    // ★ الربحية = 10,800 − 6,000 − 1,250 = 3,550
    expect(row.lifetimeProfit).toBe('3550');

    vi.doUnmock('@/lib/db');
    vi.doUnmock('@/lib/auth/rbac');
    vi.resetModules();
  });
});
