'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

interface Line {
  itemId: number; itemCode: string; productName: string;
  status: string; statusLabel: string;
  unitPrice: string; discount: string;
}

/** شاشة البيع: Scan → السعر → الخصم → الدفع → تأكيد. */
export default function SalePos() {
  const router = useRouter();
  const [barcode, setBarcode] = useState('');
  const [lines, setLines] = useState<Line[]>([]);
  const [phone, setPhone] = useState('');
  const [customerId, setCustomerId] = useState<number | null>(null);
  const [customerName, setCustomerName] = useState('');
  const [msg, setMsg] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  const net = lines.reduce((a, l) => a + (Number(l.unitPrice) - Number(l.discount)), 0);

  async function scan() {
    if (!barcode.trim()) return;
    setMsg(null);
    const res = await fetch(`/api/sales/scan?barcode=${encodeURIComponent(barcode)}`);
    const json = await res.json();
    if (!json.ok) { setMsg({ type: 'err', text: json.error?.message ?? 'تعذّر المسح.' }); return; }
    const d = json.data;
    if (!d.canBeSold) { setMsg({ type: 'err', text: d.blockedReason }); setBarcode(''); return; }
    if (lines.some((l) => l.itemId === d.itemId)) {
      setMsg({ type: 'err', text: 'القطعة مضافة بالفعل في هذه الفاتورة.' });
      setBarcode(''); return;
    }
    setLines([...lines, {
      itemId: d.itemId, itemCode: d.itemCode, productName: d.productName,
      status: d.status, statusLabel: d.statusLabel,
      unitPrice: d.suggestedPrice, discount: '0',
    }]);
    setBarcode('');
  }

  async function lookupCustomer() {
    if (!phone.trim()) { setCustomerId(null); setCustomerName(''); return; }
    const res = await fetch(`/api/customers/lookup?phone=${encodeURIComponent(phone)}`);
    const json = await res.json();
    if (json.ok && json.data.found) {
      setCustomerId(json.data.customer.id);
      setCustomerName(json.data.customer.fullName);
    } else {
      setCustomerId(null);
      setCustomerName('غير مسجّل — ستُسجَّل الفاتورة على عميل نقدي');
    }
  }

  const update = (i: number, field: 'unitPrice' | 'discount', v: string) => {
    const copy = [...lines];
    copy[i] = { ...copy[i], [field]: v };
    setLines(copy);
  };

  async function confirm() {
    setBusy(true); setMsg(null);
    const res = await fetch('/api/sales', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        customerId,
        items: lines.map((l) => ({
          itemId: l.itemId,
          unitPrice: Number(l.unitPrice),
          discount: Number(l.discount),
        })),
        paidAmount: net,
        paymentMethodId: 1,
      }),
    });
    const json = await res.json();
    setBusy(false);
    if (!json.ok) { setMsg({ type: 'err', text: json.error?.message ?? 'تعذّر إتمام البيع.' }); return; }
    setLines([]); setPhone(''); setCustomerId(null); setCustomerName('');
    router.push(`/sales/${json.data.id}`);
    router.refresh();
  }

  return (
    <div className="card">
      <div className="card-header">بيع جديد</div>
      <div className="p-5 space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="label">امسح الباركود</label>
            <input
              className="input num" dir="ltr" autoFocus value={barcode}
              placeholder="SUIT-0001"
              onChange={(e) => setBarcode(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && scan()}
            />
          </div>
          <div>
            <label className="label">رقم جوال العميل (اختياري)</label>
            <input
              className="input num" dir="ltr" value={phone}
              placeholder="اتركه فارغًا لعميل نقدي"
              onChange={(e) => setPhone(e.target.value)}
              onBlur={lookupCustomer}
              onKeyDown={(e) => e.key === 'Enter' && lookupCustomer()}
            />
            {customerName && <p className="text-xs text-slate-600 mt-1">{customerName}</p>}
          </div>
        </div>

        {lines.length > 0 && (
          <table className="table">
            <thead><tr><th>القطعة</th><th>المنتج</th><th>السعر</th><th>الخصم</th><th>الصافي</th><th></th></tr></thead>
            <tbody>
              {lines.map((l, i) => (
                <tr key={l.itemId}>
                  <td className="num">{l.itemCode}</td>
                  <td>
                    {l.productName}
                    {l.status === 'DAMAGED' && <span className="badge bg-amber-100 text-warn mr-2">تالفة</span>}
                  </td>
                  <td><input className="input num w-28" dir="ltr" value={l.unitPrice}
                             onChange={(e) => update(i, 'unitPrice', e.target.value)} /></td>
                  <td><input className="input num w-24" dir="ltr" value={l.discount}
                             onChange={(e) => update(i, 'discount', e.target.value)} /></td>
                  <td className="num font-semibold">
                    {(Number(l.unitPrice) - Number(l.discount)).toFixed(2)}
                  </td>
                  <td>
                    <button className="text-danger font-semibold"
                            onClick={() => setLines(lines.filter((x) => x.itemId !== l.itemId))}>
                      حذف
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}

        <div className="flex items-center justify-between border-t border-slate-200 pt-4">
          <div className="text-lg font-bold text-brand">
            صافي البيع: <span className="num">{net.toFixed(2)}</span> جنيه
            <span className="text-sm font-normal text-slate-500 mr-3">(يُدفع بالكامل نقدًا)</span>
          </div>
          <button className="btn-primary" onClick={confirm} disabled={busy || lines.length === 0}>
            {busy ? 'جارٍ الحفظ…' : 'تأكيد البيع'}
          </button>
        </div>

        {msg && (
          <p className={`text-sm font-semibold ${msg.type === 'ok' ? 'text-ok' : 'text-danger'}`}>{msg.text}</p>
        )}
      </div>
    </div>
  );
}
