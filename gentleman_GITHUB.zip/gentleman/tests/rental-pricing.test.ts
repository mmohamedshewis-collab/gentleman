import { describe, it, expect } from 'vitest';
import {
  computeRentalTotals, computeLine, exceedsDiscountLimit, buildRentalNo, PricingError,
} from '../src/lib/rentals/pricing';
import {
  canVoidRental, canTransitionRental, isRentalOpen, RENTAL_ALLOWED_TRANSITIONS,
  RENTAL_TERMINAL, type RentalStatus,
} from '../src/lib/rentals/rental-state';

const s = (v: { toString(): string }) => v.toString();

describe('حساب سطر التأجير', () => {
  it('الصافي = السعر − الخصم', () => {
    expect(s(computeLine({ itemId: 1, unitRentalPrice: 500, discount: 50 }).netPrice)).toBe('450');
  });
  it('يرفض خصمًا أكبر من السعر', () => {
    expect(() => computeLine({ itemId: 1, unitRentalPrice: 500, discount: 600 })).toThrowError(PricingError);
  });
  it('يرفض القيم السالبة', () => {
    expect(() => computeLine({ itemId: 1, unitRentalPrice: -1 })).toThrowError(PricingError);
    expect(() => computeLine({ itemId: 1, unitRentalPrice: 500, discount: -5 })).toThrowError(PricingError);
    expect(() => computeLine({ itemId: 1, unitRentalPrice: 500, insurancePerItem: -1 })).toThrowError(PricingError);
  });
});

describe('إجماليات العقد', () => {
  it('عقد بقطعة واحدة: خصم ومدفوع ومتبقٍ', () => {
    const t = computeRentalTotals({
      lines: [{ itemId: 1, unitRentalPrice: 500, discount: 50, insurancePerItem: 1000 }],
      paidAmount: 300,
    });
    expect(s(t.subtotal)).toBe('500');
    expect(s(t.discount)).toBe('50');
    expect(s(t.netAmount)).toBe('450');
    expect(s(t.totalDue)).toBe('450');
    expect(s(t.paidAmount)).toBe('300');
    expect(s(t.remainingAmount)).toBe('150');
  });

  it('★ التأمين لا يدخل الإجمالي ولا المدفوع ولا المتبقي', () => {
    const withIns = computeRentalTotals({
      lines: [{ itemId: 1, unitRentalPrice: 500, insurancePerItem: 5000 }],
      paidAmount: 500,
    });
    const withoutIns = computeRentalTotals({
      lines: [{ itemId: 1, unitRentalPrice: 500, insurancePerItem: 0 }],
      paidAmount: 500,
    });
    expect(s(withIns.totalDue)).toBe(s(withoutIns.totalDue));
    expect(s(withIns.netAmount)).toBe(s(withoutIns.netAmount));
    expect(s(withIns.remainingAmount)).toBe(s(withoutIns.remainingAmount));
    expect(s(withIns.insuranceAmount)).toBe('5000');   // مسجَّل لكنه خارج المعادلة
  });

  it('عقد بعدة قطع يجمع الأسعار والخصومات والتأمينات', () => {
    const t = computeRentalTotals({
      lines: [
        { itemId: 1, unitRentalPrice: 500, discount: 50, insurancePerItem: 1000 },
        { itemId: 2, unitRentalPrice: 400, discount: 40, insurancePerItem: 800 },
        { itemId: 3, unitRentalPrice: 300, discount: 0, insurancePerItem: 500 },
      ],
      paidAmount: 0,
    });
    expect(s(t.subtotal)).toBe('1200');
    expect(s(t.discount)).toBe('90');
    expect(s(t.netAmount)).toBe('1110');
    expect(s(t.insuranceAmount)).toBe('2300');
    expect(s(t.remainingAmount)).toBe('1110');
    expect(t.lines).toHaveLength(3);
  });

  it('يرفض تكرار نفس القطعة في العقد', () => {
    expect(() => computeRentalTotals({
      lines: [{ itemId: 1, unitRentalPrice: 500 }, { itemId: 1, unitRentalPrice: 500 }],
    })).toThrowError(/نفس القطعة/);
  });

  it('يرفض عقدًا بلا قطع', () => {
    expect(() => computeRentalTotals({ lines: [] })).toThrowError(PricingError);
  });

  it('يرفض مدفوعًا أكبر من الإجمالي', () => {
    expect(() => computeRentalTotals({
      lines: [{ itemId: 1, unitRentalPrice: 500 }], paidAmount: 600,
    })).toThrowError(/يتجاوز إجمالي العقد/);
  });

  it('تأجير بلا دفع: المتبقي = الإجمالي', () => {
    const t = computeRentalTotals({ lines: [{ itemId: 1, unitRentalPrice: 500 }] });
    expect(s(t.paidAmount)).toBe('0');
    expect(s(t.remainingAmount)).toBe('500');
  });

  it('لا ضريبة تُحصَّل حاليًا', () => {
    const t = computeRentalTotals({ lines: [{ itemId: 1, unitRentalPrice: 500 }] });
    expect(s(t.vatAmount)).toBe('0');
    expect(s(t.grossAmount)).toBe(s(t.netAmount));
  });

  it('يحسب نسبة الخصم لمقارنتها بحد الموظف', () => {
    const t = computeRentalTotals({ lines: [{ itemId: 1, unitRentalPrice: 1000, discount: 250 }] });
    expect(s(t.discountPercent)).toBe('25');
    expect(exceedsDiscountLimit(t.discountPercent, 10)).toBe(true);
    expect(exceedsDiscountLimit(t.discountPercent, 30)).toBe(false);
  });
});

describe('ترقيم العقود', () => {
  it('R-2026-000001', () => {
    expect(buildRentalNo(2026, 1)).toBe('R-2026-000001');
    expect(buildRentalNo(2026, 1234)).toBe('R-2026-001234');
  });
});

describe('آلة حالة العقد', () => {
  const ALL = Object.keys(RENTAL_ALLOWED_TRANSITIONS) as RentalStatus[];

  it('العقد النشط قابل للإلغاء', () => {
    expect(canVoidRental('ACTIVE').allowed).toBe(true);
  });
  it('العقد المُرجَع جزئيًا غير قابل للإلغاء', () => {
    const r = canVoidRental('PARTIALLY_RETURNED');
    expect(r.allowed).toBe(false);
    expect(r.reason).toContain('أكمل الإرجاع');
  });
  it('العقد المغلق أو الملغى غير قابل للإلغاء', () => {
    expect(canVoidRental('CLOSED').allowed).toBe(false);
    expect(canVoidRental('VOIDED').allowed).toBe(false);
  });
  it('الحالات النهائية بلا مخارج', () => {
    for (const st of RENTAL_TERMINAL) {
      expect(RENTAL_ALLOWED_TRANSITIONS[st]).toHaveLength(0);
      for (const to of ALL) expect(canTransitionRental(st, to).allowed).toBe(false);
    }
  });
  it('الرجوع من مُرجَع جزئيًا إلى نشط مسموح فقط كعكس إرجاع خاطئ', () => {
    expect(canTransitionRental('PARTIALLY_RETURNED', 'ACTIVE').allowed).toBe(true);
  });
  it('العقد المغلق يُعاد فتحه عند إلغاء إرجاع، ولا يُلغى', () => {
    expect(canTransitionRental('CLOSED', 'PARTIALLY_RETURNED').allowed).toBe(true);
    expect(canTransitionRental('CLOSED', 'ACTIVE').allowed).toBe(true);
    expect(canTransitionRental('CLOSED', 'VOIDED').allowed).toBe(false);
  });
  it('العقد المفتوح تشغيليًا = فيه قطع لم تُرجَع', () => {
    expect(isRentalOpen('ACTIVE')).toBe(true);
    expect(isRentalOpen('PARTIALLY_RETURNED')).toBe(true);
    expect(isRentalOpen('CLOSED')).toBe(false);
    expect(isRentalOpen('VOIDED')).toBe(false);
  });
  it('العقد المغلق يقبل سداد غرامات الإرجاع، والملغى لا يقبل شيئًا', async () => {
    const { acceptsPayments } = await import('../src/lib/rentals/rental-state');
    expect(acceptsPayments('CLOSED')).toBe(true);
    expect(acceptsPayments('PARTIALLY_RETURNED')).toBe(true);
    expect(acceptsPayments('VOIDED')).toBe(false);
  });
});
