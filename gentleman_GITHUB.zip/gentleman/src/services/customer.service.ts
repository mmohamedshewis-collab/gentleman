import { z } from 'zod';
import type { Prisma } from '@prisma/client';
import { prisma } from '@/lib/db';
import { Errors } from '@/lib/errors';
import { writeAudit } from '@/lib/audit';
import { requirePermission, can } from '@/lib/auth/rbac';
import {
  normalizePhone, normalizeNationalId, formatPhone, buildCustomerCode,
} from '@/lib/customers/phone';

/**
 * العملاء — أقل بيانات ممكنة وأسرع بحث ممكن.
 * رقم الجوال هو المفتاح: يُوحَّد قبل الحفظ والبحث فلا يتكرر العميل الواحد.
 */

const WALK_IN_CODE = 'WALKIN';

// ============================ التحقق ============================

export const lookupSchema = z.object({ phone: z.string().min(1, 'رقم الجوال مطلوب') });

export const createCustomerSchema = z.object({
  fullName: z.string().trim().min(2, 'اسم العميل مطلوب'),
  phone: z.string().min(1, 'رقم الجوال مطلوب'),
  nationalId: z.string().optional().nullable(),
  notes: z.string().max(500).optional().nullable(),
});

export const updateCustomerSchema = z.object({
  id: z.number().int().positive(),
  fullName: z.string().trim().min(2).optional(),
  phone: z.string().optional(),
  nationalId: z.string().optional().nullable(),
  notes: z.string().max(500).optional().nullable(),
  isActive: z.boolean().optional(),
});

export const customerQuerySchema = z.object({
  q: z.string().optional(),
  includeInactive: z.coerce.boolean().default(false),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(10).max(200).default(50),
});

// ======================= البحث بالجوال =======================

/**
 * البحث السريع في شاشة التأجير: الموظف يكتب الرقم فيظهر العميل فورًا،
 * أو يُعرض عليه إنشاء عميل جديد بنفس الرقم بضغطة واحدة.
 */
export async function lookupByPhone(rawPhone: string) {
  await requirePermission('customers.view');

  const norm = normalizePhone(rawPhone);
  if (!norm.ok) throw Errors.rule(norm.error!);

  const customer = await prisma.customer.findUnique({
    where: { phone: norm.phone },
    select: {
      id: true, code: true, fullName: true, phone: true,
      nationalId: true, notes: true, isActive: true, isWalkIn: true,
    },
  });

  if (!customer) {
    return { found: false as const, normalizedPhone: norm.phone! };
  }
  return {
    found: true as const,
    normalizedPhone: norm.phone!,
    customer: { ...customer, phoneDisplay: formatPhone(customer.phone ?? '') },
  };
}

// ======================= القائمة والبحث =======================

export async function listCustomers(input: z.infer<typeof customerQuerySchema>) {
  await requirePermission('customers.view');

  const q = input.q?.trim();
  // إن كان المدخل أرقامًا فالأرجح أنه بحث بالجوال — نوحّده قبل المطابقة
  const asPhone = q ? normalizePhone(q) : null;

  const where: Prisma.CustomerWhereInput = {
    ...(input.includeInactive ? {} : { isActive: true }),
    ...(q
      ? {
          OR: [
            { fullName: { contains: q } },
            { phone: { contains: asPhone?.ok ? asPhone.phone : q.replace(/\D/g, '') || q } },
            { code: { contains: q.toUpperCase() } },
          ],
        }
      : {}),
  };

  const [rows, total] = await Promise.all([
    prisma.customer.findMany({
      where,
      select: {
        id: true, code: true, fullName: true, phone: true,
        isWalkIn: true, isActive: true, notes: true, createdAt: true,
      },
      orderBy: [{ isWalkIn: 'desc' }, { fullName: 'asc' }],
      skip: (input.page - 1) * input.pageSize,
      take: input.pageSize,
    }),
    prisma.customer.count({ where }),
  ]);

  return {
    rows: rows.map((r) => ({ ...r, phoneDisplay: r.phone ? formatPhone(r.phone) : null })),
    total,
    page: input.page,
    pageSize: input.pageSize,
  };
}

export async function getCustomer(id: number) {
  await requirePermission('customers.view');
  const c = await prisma.customer.findUnique({ where: { id } });
  if (!c) throw Errors.notFound('العميل');
  return { ...c, phoneDisplay: c.phone ? formatPhone(c.phone) : null };
}

// ======================= الإنشاء =======================

export async function createCustomer(input: z.infer<typeof createCustomerSchema>) {
  const actor = await requirePermission('customers.create');

  const phone = normalizePhone(input.phone);
  if (!phone.ok) throw Errors.rule(phone.error!);

  const nid = normalizeNationalId(input.nationalId);
  if (!nid.ok) throw Errors.rule(nid.error!);

  const existing = await prisma.customer.findUnique({
    where: { phone: phone.phone },
    select: { id: true, fullName: true, isActive: true },
  });
  if (existing) {
    throw Errors.conflict(
      `رقم الجوال مسجّل بالفعل باسم "${existing.fullName}". افتح بطاقته بدل إنشاء عميل جديد.`,
    );
  }

  return prisma.$transaction(async (tx) => {
    const last = await tx.customer.findFirst({
      where: { code: { startsWith: 'C-' } },
      orderBy: { code: 'desc' },
      select: { code: true },
    });
    const nextSeq = last ? Number.parseInt(last.code.slice(2), 10) + 1 : 1;

    let created;
    try {
      created = await tx.customer.create({
        data: {
          code: buildCustomerCode(Number.isFinite(nextSeq) ? nextSeq : 1),
          fullName: input.fullName.trim(),
          phone: phone.phone,
          nationalId: nid.phone ?? null,
          notes: input.notes?.trim() || null,
          createdBy: actor.id,
        },
      });
    } catch (e) {
      // P2002 = خرق قيد التفرد في قاعدة البيانات (خط الدفاع الأخير ضد التكرار)
      if ((e as { code?: string })?.code === 'P2002') {
        throw Errors.conflict('رقم الجوال أو كود العميل مستخدم بالفعل.');
      }
      throw e;
    }

    await writeAudit(
      {
        userId: actor.id,
        action: 'customer.create',
        entityType: 'Customer',
        entityId: created.id,
        after: { code: created.code, fullName: created.fullName, phone: created.phone },
      },
      tx,
    );

    return { ...created, phoneDisplay: formatPhone(created.phone!) };
  });
}

// ======================= التعديل =======================

export async function updateCustomer(input: z.infer<typeof updateCustomerSchema>) {
  const actor = await requirePermission('customers.edit');

  const before = await prisma.customer.findUnique({ where: { id: input.id } });
  if (!before) throw Errors.notFound('العميل');

  // العميل النقدي سجل نظامي: لا يُعاد تسميته ولا يُعطَّل ولا يُعطى رقمًا
  if (before.isWalkIn) {
    if (input.phone || input.isActive === false || input.fullName) {
      throw Errors.rule('العميل النقدي سجل ثابت في النظام ولا يمكن تعديله أو تعطيله.');
    }
  }

  const data: Prisma.CustomerUpdateInput = {};

  if (input.fullName) data.fullName = input.fullName.trim();
  if (input.notes !== undefined) data.notes = input.notes?.trim() || null;

  if (input.phone) {
    const phone = normalizePhone(input.phone);
    if (!phone.ok) throw Errors.rule(phone.error!);
    if (phone.phone !== before.phone) {
      const taken = await prisma.customer.findUnique({
        where: { phone: phone.phone },
        select: { id: true, fullName: true },
      });
      if (taken && taken.id !== input.id) {
        throw Errors.conflict(`رقم الجوال مسجّل بالفعل باسم "${taken.fullName}".`);
      }
      data.phone = phone.phone;
    }
  }

  if (input.nationalId !== undefined) {
    const nid = normalizeNationalId(input.nationalId);
    if (!nid.ok) throw Errors.rule(nid.error!);
    data.nationalId = nid.phone ?? null;
  }

  // التعطيل صلاحية إدارية وليست من عمل الموظف اليومي
  if (input.isActive !== undefined && input.isActive !== before.isActive) {
    if (!can(actor, 'customers.deactivate')) throw Errors.forbidden('customers.deactivate');
    data.isActive = input.isActive;
  }

  if (Object.keys(data).length === 0) return { id: before.id, unchanged: true };

  return prisma.$transaction(async (tx) => {
    const after = await tx.customer.update({ where: { id: input.id }, data });
    await writeAudit(
      {
        userId: actor.id,
        action: input.isActive === false ? 'customer.deactivate' : 'customer.update',
        entityType: 'Customer',
        entityId: input.id,
        before: { fullName: before.fullName, phone: before.phone, nationalId: before.nationalId, isActive: before.isActive },
        after: { fullName: after.fullName, phone: after.phone, nationalId: after.nationalId, isActive: after.isActive },
      },
      tx,
    );
    return { ...after, phoneDisplay: after.phone ? formatPhone(after.phone) : null };
  });
}

// ======================= العميل النقدي =======================

export async function getWalkInCustomer() {
  await requirePermission('customers.view');
  const c = await prisma.customer.findUnique({ where: { code: WALK_IN_CODE } });
  if (!c) throw Errors.notFound('العميل النقدي');
  return c;
}
