'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function ReservationActions({
  reservationId, reservationNo, canCancel, canConvert, methods,
}: {
  reservationId: number;
  reservationNo: string;
  canCancel: boolean;
  canConvert: boolean;
  methods: { id: number; nameAr: string }[];
}) {
  const router = useRouter();
  const [mode, setMode] = useState<'none' | 'cancel' | 'convert'>('none');
  const [reason, setReason] = useState('');
  const [byShop, setByShop] = useState(false);
  const [paid, setPaid] = useState('');
  const [insurance, setInsurance] = useState('');
  const [methodId, setMethodId] = useState(methods[0]?.id ?? 0);
  const [msg, setMsg] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function call(url: string, body: Record<string, unknown>) {
    setBusy(true); setMsg(null);
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    const json = await res.json();
    setBusy(false);
    if (!json.ok) { setMsg(json.error?.message ?? 'تعذّر التنفيذ.'); return; }
    setMode('none');
    router.refresh();
  }

  if (mode === 'none') {
    return (
      <div className="flex gap-2">
        {canConvert && (
          <button className="text-brand-light font-semibold text-sm"
                  onClick={() => setMode('convert')}>تحويل</button>
        )}
        {canCancel && (
          <button className="text-danger font-semibold text-sm"
                  onClick={() => setMode('cancel')}>إلغاء</button>
        )}
      </div>
    );
  }

  return (
    <div className="space-y-2 min-w-[240px]">
      {mode === 'cancel' ? (
        <>
          <input className="input text-sm" placeholder="سبب الإلغاء"
                 value={reason} onChange={(e) => setReason(e.target.value)} />
          <label className="flex items-center gap-2 text-xs">
            <input type="checkbox" checked={byShop} onChange={(e) => setByShop(e.target.checked)} />
            الإلغاء من المحل — يُرد العربون كاملًا
          </label>
          {byShop && (
            <select className="input text-sm" value={methodId}
                    onChange={(e) => setMethodId(Number(e.target.value))}>
              {methods.map((m) => <option key={m.id} value={m.id}>{m.nameAr}</option>)}
            </select>
          )}
          <div className="flex gap-2">
            <button className="btn-danger text-xs px-3 py-1" disabled={busy || reason.trim().length < 3}
                    onClick={() => call('/api/reservations/cancel', {
                      reservationId, reason, cancelledByShop: byShop,
                      refundPaymentMethodId: byShop ? methodId : undefined,
                    })}>
              تأكيد الإلغاء
            </button>
            <button className="btn-secondary text-xs px-3 py-1" onClick={() => setMode('none')}>تراجع</button>
          </div>
        </>
      ) : (
        <>
          <input className="input num text-sm" dir="ltr" placeholder="المدفوع الآن"
                 value={paid} onChange={(e) => setPaid(e.target.value)} />
          <input className="input num text-sm" dir="ltr" placeholder="التأمين لكل قطعة"
                 value={insurance} onChange={(e) => setInsurance(e.target.value)} />
          <select className="input text-sm" value={methodId}
                  onChange={(e) => setMethodId(Number(e.target.value))}>
            {methods.map((m) => <option key={m.id} value={m.id}>{m.nameAr}</option>)}
          </select>
          <div className="flex gap-2">
            <button className="btn-primary text-xs px-3 py-1" disabled={busy}
                    onClick={() => call('/api/reservations/convert', {
                      reservationId,
                      paidAmount: Number(paid || 0),
                      insurancePerItem: Number(insurance || 0),
                      paymentMethodId: methodId,
                      insurancePaymentMethodId: methodId,
                    })}>
              تحويل {reservationNo} إلى تأجير
            </button>
            <button className="btn-secondary text-xs px-3 py-1" onClick={() => setMode('none')}>تراجع</button>
          </div>
        </>
      )}
      {msg && <p className="text-xs text-danger">{msg}</p>}
    </div>
  );
}
