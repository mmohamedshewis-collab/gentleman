CREATE OR REPLACE FUNCTION do_payment(p_rental int, p_amount numeric, p_fail boolean DEFAULT false) RETURNS int AS $$
DECLARE v_id int; v_due numeric; v_paid numeric;
BEGIN
  SELECT total_due, paid_amount INTO v_due, v_paid FROM rentals WHERE id = p_rental FOR UPDATE;
  IF v_due IS NULL THEN RAISE EXCEPTION 'العقد غير موجود'; END IF;
  IF p_amount > (v_due - v_paid) THEN
    RAISE EXCEPTION 'الدفعة تتجاوز المتبقي: المتبقي % والمدخل %', v_due - v_paid, p_amount;
  END IF;
  INSERT INTO payments (payment_no, purpose, rental_id, customer_id, amount, payment_method_id, created_by)
  VALUES ('PAY-C' || nextval('payment_no_seq'), 'RENTAL', p_rental, 2, p_amount, 1, 1) RETURNING id INTO v_id;
  INSERT INTO audit_logs (user_id, action, entity_type, entity_id, after_json)
  VALUES (1,'payment.create','Payment',v_id::text, jsonb_build_object('amount', p_amount));
  IF p_fail THEN RAISE EXCEPTION 'فشل متعمّد بعد تسجيل الدفعة'; END IF;
  RETURN v_id;
END; $$ LANGUAGE plpgsql;
