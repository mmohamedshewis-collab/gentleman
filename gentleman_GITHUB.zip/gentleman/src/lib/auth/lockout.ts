/**
 * قفل الحساب بعد محاولات دخول فاشلة — منطق خالص.
 *
 * ★ التخزين في جدول `users` القائم (`failedAttempts` و`lockedUntil`)
 *   لا في الذاكرة: بيئة Serverless متعددة النسخ، والعدّاد في الذاكرة
 *   لا يصمد بينها ولا بعد إعادة التشغيل.
 */

/** عدد المحاولات الفاشلة المسموح بها قبل القفل. */
export const MAX_FAILED_ATTEMPTS = 5;

/** مدة القفل بالدقائق. */
export const LOCK_MINUTES = 15;

/** هل الحساب مقفل الآن؟ */
export function isLocked(lockedUntil: Date | null, now: Date = new Date()): boolean {
  return lockedUntil !== null && lockedUntil > now;
}

/** الدقائق المتبقية على فك القفل — لا تقل عن واحدة. */
export function remainingLockMinutes(lockedUntil: Date, now: Date = new Date()): number {
  const ms = lockedUntil.getTime() - now.getTime();
  return ms <= 0 ? 0 : Math.max(1, Math.ceil(ms / 60_000));
}

/**
 * حالة الحساب بعد محاولة فاشلة.
 * يُقفل عند بلوغ الحد بالضبط، ولا يتجاوز العدّاد الحد.
 */
export function nextFailureState(
  currentAttempts: number,
  now: Date = new Date(),
): { failedAttempts: number; lockedUntil: Date | null } {
  const attempts = currentAttempts + 1;
  if (attempts >= MAX_FAILED_ATTEMPTS) {
    return {
      failedAttempts: attempts,
      lockedUntil: new Date(now.getTime() + LOCK_MINUTES * 60_000),
    };
  }
  return { failedAttempts: attempts, lockedUntil: null };
}

/** حالة الحساب بعد دخول ناجح: يُصفَّر كل شيء. */
export const successState = () => ({ failedAttempts: 0, lockedUntil: null });
