import { route } from '@/lib/api';
import { addRentalPayment, addPaymentSchema } from '@/services/rental.service';

export const POST = route({ schema: addPaymentSchema, handler: ({ input }) => addRentalPayment(input) });
