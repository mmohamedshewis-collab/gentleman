import { route } from '@/lib/api';
import { listDormantInsurance, dormantQuerySchema } from '@/services/finance.service';

export const GET = route({ schema: dormantQuerySchema, handler: ({ input }) => listDormantInsurance(input) });
