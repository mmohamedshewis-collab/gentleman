import { route } from '@/lib/api';
import { todayCashMovement, dateQuerySchema } from '@/services/cash.service';

export const GET = route({ schema: dateQuerySchema, handler: ({ input }) => todayCashMovement(input.date) });
