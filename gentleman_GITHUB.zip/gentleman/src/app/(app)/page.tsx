import { requireSession } from '@/lib/auth/session';
import { getDashboard } from '@/services/dashboard.service';
import KpiCard from '@/components/KpiCard';
import CashMovementBox from '@/components/CashMovementBox';
import DashboardFilter from '@/components/DashboardFilter';
import { formatEGP } from '@/lib/money';

export const dynamic = 'force-dynamic';

export default async function DashboardPage({
  searchParams,
}: {
  searchParams: { from?: string; to?: string };
}) {
  const user = await requireSession();
  const d = await getDashboard({ from: searchParams.from, to: searchParams.to });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-brand">أهلًا، {user.fullName}</h1>
        <p className="text-slate-600 text-sm mt-1">صلاحيتك الحالية: {user.roleNameAr}</p>
      </div>

      <DashboardFilter from={d.from} to={d.to} />

      {d.todayKpis.length > 0 && (
        <section className="space-y-3">
          <h2 className="section-title text-base">
            اليوم <span className="num text-sm font-normal text-slate-500">{d.today}</span>
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {d.todayKpis.map((k) => <KpiCard key={k.key} {...k} />)}
          </div>
        </section>
      )}

      {user.permissions.has('cash.movement.view') && <CashMovementBox />}

      {d.balanceKpis.length > 0 && (
        <section className="space-y-3">
          <h2 className="section-title text-base">
            أرصدة حالية
            <span className="text-sm font-normal text-slate-500 mr-2">
              (لا تتأثر بالفترة المختارة)
            </span>
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {d.balanceKpis.map((k) => <KpiCard key={k.key} {...k} />)}
          </div>
        </section>
      )}

      {d.periodKpis.length > 0 && (
        <section className="space-y-3">
          <h2 className="section-title text-base">
            الفترة <span className="num text-sm font-normal text-slate-500">{d.from} → {d.to}</span>
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {d.periodKpis.map((k) => <KpiCard key={k.key} {...k} />)}
          </div>
        </section>
      )}

      {d.employees.length > 0 && (
        <div className="card overflow-hidden">
          <div className="card-header">أداء الموظفين في الفترة</div>
          <div className="overflow-x-auto">
            <table className="table">
              <thead>
                <tr>
                  <th>الموظف</th><th>صافي التأجير</th><th>صافي البيع</th>
                  <th>العمولة (تحليلية)</th><th>مؤشر الأداء</th>
                </tr>
              </thead>
              <tbody>
                {d.employees.map((e) => (
                  <tr key={e.fullName}>
                    <td className="font-semibold">{e.fullName}</td>
                    <td className="num">{formatEGP(e.netRental)}</td>
                    <td className="num">{formatEGP(e.netSales)}</td>
                    <td className="num">{formatEGP(e.commissionTotal)}</td>
                    <td className="num font-bold">{e.performanceIndex ?? '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {d.notes.length > 0 && (
        <div className="card">
          <div className="p-4 text-xs text-slate-500 space-y-1">
            {d.notes.map((n) => <p key={n}>• {n}</p>)}
          </div>
        </div>
      )}
    </div>
  );
}
