import { describe, it, expect } from 'vitest';
import type { InsuranceTrxType } from '../src/lib/finance';
import {
  documentTotals, remaining, lateFee, commission,
  employeePerformance, itemProfitability, simplifiedNetProfit, insuranceBalance,
} from '../src/lib/finance';

const s = (v: { toString(): string }) => v.toString();

describe('إجمالي العملية والمتبقي', () => {
  it('السعر بعد الخصم والمتبقي بعد المدفوع', () => {
    const t = documentTotals({ subtotal: 800, discount: 50 });
    expect(s(t.netAmount)).toBe('750');
    expect(s(t.grossAmount)).toBe('750');
    expect(s(remaining(t.grossAmount, 300))).toBe('450');
  });

  it('لا ضريبة تُحصَّل من العميل حاليًا', () => {
    const t = documentTotals({ subtotal: 1000, discount: 0 });
    expect(t.vatStatus).toBe('NOT_APPLICABLE');
    expect(s(t.vatAmount)).toBe('0');
    expect(s(t.grossAmount)).toBe('1000');
  });

  it('عند تفعيل الضريبة مستقبلًا: صافي + 14% = الإجمالي', () => {
    const t = documentTotals({ subtotal: 1000, discount: 200, vat: { enabled: true, rate: 14 } });
    expect(s(t.netAmount)).toBe('800');
    expect(s(t.vatAmount)).toBe('112');
    expect(s(t.grossAmount)).toBe('912');
  });
});

describe('رسوم التأخير — لكل قطعة في اليوم', () => {
  it('يومان × 100 = 200', () => expect(s(lateFee(2, 100))).toBe('200'));
  it('لا تأخير = صفر', () => expect(s(lateFee(0, 100))).toBe('0'));
  it('الإرجاع المبكر لا ينتج رسومًا سالبة', () => expect(s(lateFee(-3, 100))).toBe('0'));
  it('الحد الأقصى من الإعدادات يوقف تراكم الغرامة', () => {
    expect(s(lateFee(30, 100, 1500))).toBe('1500');
  });
});

describe('عمولة الموظف', () => {
  it('على صافي التأجير والبيع بنسب مستقلة', () => {
    const c = commission({ netRental: 10000, netSales: 5000, rentalPct: 2, salesPct: 3 });
    expect(s(c.rentalCommission)).toBe('200');
    expect(s(c.salesCommission)).toBe('150');
    expect(s(c.total)).toBe('350');
  });

  it('التأمين والغرامات خارج الوعاء تمامًا', () => {
    const withoutExtras = commission({ netRental: 10000, netSales: 0, rentalPct: 2, salesPct: 3 });
    expect(s(withoutExtras.base)).toBe('10000'); // لا تأمين 1000 ولا غرامة 200
  });

  it('مؤشر الأداء يوزّع الراتب على أيام الفترة', () => {
    const p = employeePerformance({
      netRental: 20000, netSales: 10000, monthlySalary: 6000,
      periodDays: 15, monthDays: 30, commissionAmount: 700,
    });
    expect(s(p.allocatedSalary)).toBe('3000');
    expect(s(p.cost)).toBe('3700');
    expect(s(p.sales)).toBe('30000');
    expect(s(p.index!)).toBe('8.11');
  });
});

describe('ربحية القطعة عبر عمرها', () => {
  it('قطعة قائمة: التكلفة لا تُحمّل قبل البيع', () => {
    const r = itemProfitability({
      purchaseCost: 6000, rentalRevenue: 16000, finesRevenue: 500, maintenanceCost: 800,
    });
    expect(s(r.revenue)).toBe('16500');
    expect(s(r.profit)).toBe('15700');
    expect(s(r.costRecoveryPct!)).toBe('266.67');
  });

  it('قطعة مباعة: التكلفة تُحمّل مرة واحدة عند البيع', () => {
    const r = itemProfitability({
      purchaseCost: 6000, rentalRevenue: 16000, finesRevenue: 0,
      maintenanceCost: 800, saleRevenue: 1500, isSold: true,
    });
    expect(s(r.revenue)).toBe('17500');
    expect(s(r.profit)).toBe('10700');
  });
});

describe('صافي الربح المبسّط', () => {
  it('الإيراد − تكلفة المباع − المصروفات', () => {
    const r = simplifiedNetProfit({
      rentalRevenue: 50000, salesRevenue: 12000, finesRevenue: 1500,
      insuranceRetained: 500, costOfSoldItems: 9000, expenses: 20000,
    });
    expect(s(r.revenue)).toBe('64000');
    expect(s(r.netProfit)).toBe('35000');
  });
});

describe('رصيد التأمين — سجل مستقل', () => {
  const trx: { type: InsuranceTrxType; amount: number }[] = [
    { type: 'COLLECTED', amount: 1000 },
    { type: 'COLLECTED', amount: 1000 },
    { type: 'DEDUCTED_DAMAGE', amount: 250 },
    { type: 'REFUNDED', amount: 750 },
  ];

  it('المحصّل والمردود والمحتجز والرصيد', () => {
    const b = insuranceBalance(trx);
    expect(s(b.collected)).toBe('2000');
    expect(s(b.refunded)).toBe('750');
    expect(s(b.retained)).toBe('250');
    expect(s(b.balance)).toBe('1000');
  });

  it('التأمين المحصّل لا يدخل الإيراد — المحتجز فقط', () => {
    const b = insuranceBalance(trx);
    const profit = simplifiedNetProfit({
      rentalRevenue: 1000, salesRevenue: 0, finesRevenue: 0,
      insuranceRetained: b.retained, costOfSoldItems: 0, expenses: 0,
    });
    expect(s(profit.revenue)).toBe('1250'); // وليس 3000
  });
});
