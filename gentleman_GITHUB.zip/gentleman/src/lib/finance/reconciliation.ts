import { Decimal } from 'decimal.js';
import { round2, add, sub } from '@/lib/money';
import { MOVEMENT_RULES, type CashMovementType } from '@/lib/cash/cash-movement';

/**
 * حارس المطابقة المالية.
 *
 * ★ غرضه ليس فرض `Profit = Cash` — فهما مختلفان عمدًا.
 *   غرضه أن يكون **كل فرق بينهما مفسَّرًا ببند معروف**، فإن بقي جنيه
 *   بلا تفسير كان ذلك دليلًا على خطأ تصنيف.
 *
 * ⛔ لا يعرّف قواعد محاسبية جديدة — يتحقق من القواعد المعتمدة فقط.
 */

// ============ 1) ثوابت التصنيف ============

/** الحركات التي يجوز أن تكون إيرادًا — أي غيرها إيرادًا يعني خطأ تصنيف. */
export const REVENUE_MOVEMENTS: CashMovementType[] = [
  'RENTAL_COLLECTION',
  'SALE_COLLECTION',
  'LATE_FEE_COLLECTION',
  'INSURANCE_RETAINED',
  'INSURANCE_TRANSFERRED',
];

/** الحركات التي يجوز أن تكون مصروفًا. */
export const EXPENSE_MOVEMENTS: CashMovementType[] = [
  'EXPENSE_PAYMENT',
  'SALARY_PAYMENT',
  'COMMISSION_PAYMENT',
];

/** ★ خروج نقدي وليس مصروفًا — القاعدة المعتمدة «ليس كل خروج مصروفًا». */
export const CASH_OUT_NOT_EXPENSE: CashMovementType[] = [
  'EMPLOYEE_ADVANCE',
  'CUSTOMER_REFUND',
  'PRODUCT_PURCHASE',
  'INSURANCE_REFUND',
  'TREASURY_TRANSFER',
  'OTHER_OUT',
];

/** ★ دخول نقدي وليس إيرادًا. */
export const CASH_IN_NOT_REVENUE: CashMovementType[] = [
  'RESERVATION_DEPOSIT',
  'ADVANCE_REPAYMENT',
  'INSURANCE_COLLECTION',
  'OTHER_IN',
];

export interface ClassificationIssue {
  type: CashMovementType;
  problem: string;
}

/**
 * يفحص جدول التصنيف كله ضد القواعد المعتمدة.
 * يكشف: إيرادًا صُنِّف غير إيراد · غير إيراد صُنِّف إيرادًا ·
 *        خروجًا صُنِّف مصروفًا خطأً · أو العكس.
 */
export function auditClassification(): ClassificationIssue[] {
  const issues: ClassificationIssue[] = [];
  const all = Object.keys(MOVEMENT_RULES) as CashMovementType[];

  for (const type of all) {
    const rule = MOVEMENT_RULES[type];

    if (rule.isRevenue && !REVENUE_MOVEMENTS.includes(type)) {
      issues.push({ type, problem: 'مصنَّف إيرادًا وهو ليس من حركات الإيراد المعتمدة.' });
    }
    if (!rule.isRevenue && REVENUE_MOVEMENTS.includes(type)) {
      issues.push({ type, problem: 'حركة إيراد معتمدة لكنها غير مصنَّفة إيرادًا.' });
    }
    if (rule.isExpense && !EXPENSE_MOVEMENTS.includes(type)) {
      issues.push({ type, problem: 'مصنَّف مصروفًا وهو ليس من حركات المصروف المعتمدة.' });
    }
    if (!rule.isExpense && EXPENSE_MOVEMENTS.includes(type)) {
      issues.push({ type, problem: 'حركة مصروف معتمدة لكنها غير مصنَّفة مصروفًا.' });
    }
    if (CASH_OUT_NOT_EXPENSE.includes(type) && rule.isExpense) {
      issues.push({ type, problem: 'خروج نقدي صُنِّف مصروفًا — يخالف «ليس كل خروج مصروفًا».' });
    }
    if (CASH_IN_NOT_REVENUE.includes(type) && rule.isRevenue) {
      issues.push({ type, problem: 'دخول نقدي صُنِّف إيرادًا — يخالف «ليس كل دخول إيرادًا».' });
    }
    // لا حركة تكون إيرادًا ومصروفًا معًا
    if (rule.isRevenue && rule.isExpense) {
      issues.push({ type, problem: 'مصنَّف إيرادًا ومصروفًا في آن واحد.' });
    }
  }

  return issues;
}

// ============ 2) جسر الربح إلى النقدية ============

export interface BridgeInput {
  /** صافي الربح للفترة */
  profit: Decimal.Value;
  /** تكلفة قطع مباعة اشتُريت في فترات سابقة — مصروف بلا نقد */
  priorPeriodCogs: Decimal.Value;
  /** خسائر إعدام القطع — مصروف بلا نقد إطلاقًا */
  writeOffs: Decimal.Value;
  /** شراء قطع مدفوع نقدًا هذه الفترة — نقد بلا مصروف */
  itemPurchasesPaid: Decimal.Value;
  /** الزيادة في مستحقات العملاء — إيراد بلا تحصيل */
  receivablesIncrease: Decimal.Value;
  /** الزيادة في المصروفات المستحقة غير المدفوعة */
  accruedUnpaidIncrease: Decimal.Value;
  /** متحصلات على عمليات ملغاة لم تُرد بعد */
  collectedOnVoided: Decimal.Value;
  /** سلف مصروفة نقدًا — نقد بلا مصروف */
  advancesPaid: Decimal.Value;
  /** سلف مستردة نقدًا */
  advanceRepayments: Decimal.Value;
  /** سلف سُوّيت بخصم الراتب — تسوية غير نقدية */
  advancesSettledByDeduction: Decimal.Value;
  /** عرابين حجوزات محصَّلة ولم تتحول بعد — نقد بلا إيراد */
  reservationDepositsHeld: Decimal.Value;
  /** ★ التأمين المُستبقى والمحوَّل — إيراد بلا تحصيل نقدي جديد */
  insuranceRecognizedNoCash: Decimal.Value;
}

export interface BridgeResult {
  profit: Decimal;
  adjustments: { label: string; amount: Decimal }[];
  expectedCashMovement: Decimal;
}

/**
 * يشتق حركة النقدية المتوقعة من الربح عبر البنود المعتمدة.
 * أي فرق بين الناتج والحركة الفعلية = **مبلغ غير مفسَّر** ⟹ خطأ تصنيف.
 */
export function profitToCashBridge(input: BridgeInput): BridgeResult {
  const profit = round2(input.profit);

  const adjustments = [
    { label: 'تكلفة قطع مباعة اشتُريت سابقًا', amount: round2(input.priorPeriodCogs) },
    { label: 'خسائر إعدام القطع', amount: round2(input.writeOffs) },
    { label: 'سلف مسواة بخصم الراتب', amount: round2(input.advancesSettledByDeduction) },
    { label: 'متحصلات على عمليات ملغاة لم تُرد', amount: round2(input.collectedOnVoided) },
    { label: 'عرابين حجوزات محتفظ بها', amount: round2(input.reservationDepositsHeld) },
    { label: 'سلف مستردة نقدًا', amount: round2(input.advanceRepayments) },
    { label: 'الزيادة في المصروفات المستحقة غير المدفوعة', amount: round2(input.accruedUnpaidIncrease) },
    { label: 'شراء قطع مدفوع نقدًا', amount: round2(input.itemPurchasesPaid).negated() },
    { label: 'الزيادة في مستحقات العملاء', amount: round2(input.receivablesIncrease).negated() },
    { label: 'سلف مصروفة نقدًا', amount: round2(input.advancesPaid).negated() },
    { label: 'تأمين معترف به بلا تحصيل نقدي', amount: round2(input.insuranceRecognizedNoCash).negated() },
  ];

  const expectedCashMovement = adjustments.reduce<Decimal>(
    (acc, a) => acc.plus(a.amount),
    profit,
  );

  return { profit, adjustments, expectedCashMovement: round2(expectedCashMovement) };
}

/** الفرق غير المفسَّر — يجب أن يكون صفرًا دائمًا. */
export function unexplainedDifference(
  bridge: BridgeResult,
  actualCashMovement: Decimal.Value,
): Decimal {
  return sub(actualCashMovement, bridge.expectedCashMovement);
}

// ============ 3) ثوابت العمولة والمصروف ============

/**
 * العمولة تدخل الربح عبر مصروفها فقط.
 * مجموع صرف العمولات يجب أن يساوي مجموع مصروفات تصنيف «عمولات» بالضبط.
 */
export function assertCommissionParity(input: {
  commissionExpenseTotal: Decimal.Value;
  commissionPaidTotal: Decimal.Value;
}): { ok: boolean; difference: Decimal; message: string } {
  const diff = sub(input.commissionExpenseTotal, input.commissionPaidTotal);
  return {
    ok: diff.isZero(),
    difference: diff,
    message: diff.isZero()
      ? 'مطابق: مصروف العمولات = العمولات المصروفة.'
      : `فرق غير مفسَّر بين مصروف العمولات والمصروف فعلًا: ${diff.toString()}`,
  };
}

/** مجموع الحركات التي تدخل الربح من قائمة حركات. */
export function revenueOf(lines: { type: CashMovementType; amount: Decimal.Value }[]): Decimal {
  const rev = lines.filter((l) => MOVEMENT_RULES[l.type].isRevenue);
  return rev.length ? add(...rev.map((l) => l.amount)) : new Decimal(0);
}

export function expenseOf(lines: { type: CashMovementType; amount: Decimal.Value }[]): Decimal {
  const exp = lines.filter((l) => MOVEMENT_RULES[l.type].isExpense);
  return exp.length ? add(...exp.map((l) => l.amount)) : new Decimal(0);
}
