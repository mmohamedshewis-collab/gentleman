\set ON_ERROR_STOP off
\pset pager off
\t on

\echo '=== F1: مصروف بمبلغ صفر أو سالب (يجب أن يُرفض) ==='
INSERT INTO expenses (expense_no, category_id, amount, payment_method_id, created_by)
VALUES ('EXP-1', 1, 0, 1, 1);
INSERT INTO expenses (expense_no, category_id, amount, payment_method_id, created_by)
VALUES ('EXP-2', 1, -500, 1, 1);

\echo '=== F2: مصروف بتاريخ مستقبلي (يجب أن يُرفض) ==='
INSERT INTO expenses (expense_no, expense_date, category_id, amount, payment_method_id, created_by)
VALUES ('EXP-3', CURRENT_DATE + 5, 1, 500, 1, 1);

\echo '=== F3: مصروف صحيح (يجب أن ينجح) ==='
INSERT INTO expenses (expense_no, category_id, amount, payment_method_id, description, created_by)
VALUES ('EXP-4', 1, 5000, 1, 'إيجار المحل', 1);
SELECT 'سُجّل: ' || expense_no || ' بمبلغ ' || amount FROM expenses WHERE expense_no='EXP-4';

\echo ''
\echo '=== F4: إلغاء المصروف ثم إعادة تفعيله (الإعادة يجب أن تُرفض) ==='
UPDATE expenses SET is_voided=true, void_reason='خطأ في الإدخال' WHERE expense_no='EXP-4';
SELECT 'بعد الإلغاء: ملغى=' || is_voided || ' والسجل باقٍ' FROM expenses WHERE expense_no='EXP-4';
UPDATE expenses SET is_voided=false WHERE expense_no='EXP-4';

\echo ''
\echo '=== F5: حذف مصروف (يجب أن يُرفض) ==='
DELETE FROM expenses WHERE expense_no='EXP-4';

\echo ''
\echo '=== F6: نسب عمولة خارج النطاق (يجب أن تُرفض) ==='
UPDATE employees SET rental_commission_pct = 150 WHERE code='E-001';
UPDATE employees SET sales_commission_pct = -5 WHERE code='E-001';
UPDATE employees SET monthly_salary = -100 WHERE code='E-001';

\echo ''
\echo '=== F7: عمولة بمبلغ سالب (يجب أن تُرفض) ==='
INSERT INTO commissions (employee_id, period_month, rental_base, sales_base, commission_amount)
VALUES (1, '2026-08', 1000, 1000, -50);

\echo ''
\echo '=== F8: عمولة صحيحة (يجب أن تنجح) ==='
INSERT INTO commissions (employee_id, period_month, rental_base, sales_base,
                         rental_rate_pct, sales_rate_pct, commission_amount)
VALUES (1, '2026-08', 10000, 5000, 2, 3, 350);
SELECT 'العمولة: وعاء=' || (rental_base + sales_base) || ' مبلغ=' || commission_amount || ' حالة=' || status
  FROM commissions WHERE employee_id=1;

\echo ''
\echo '=== F9: تكرار عمولة نفس الموظف لنفس الشهر (يجب أن يُرفض) ==='
INSERT INTO commissions (employee_id, period_month, commission_amount) VALUES (1, '2026-08', 100);

\echo ''
\echo '=== F10: ★ صرف نفس العمولة مرتين (يجب أن يُرفض) ==='
INSERT INTO expenses (expense_no, category_id, amount, payment_method_id, employee_id, created_by)
VALUES ('EXP-COMM-1', 4, 350, 1, 1, 1);
UPDATE commissions SET status='PAID', paid_expense_id=(SELECT id FROM expenses WHERE expense_no='EXP-COMM-1')
 WHERE employee_id=1 AND period_month='2026-08';
SELECT 'صُرفت العمولة بمصروف ' || (SELECT expense_no FROM expenses WHERE id=paid_expense_id)
  FROM commissions WHERE employee_id=1;
-- محاولة ربط نفس المصروف بعمولة أخرى
INSERT INTO commissions (employee_id, period_month, commission_amount, status, paid_expense_id)
VALUES (1, '2026-09', 200, 'PAID', (SELECT id FROM expenses WHERE expense_no='EXP-COMM-1'));

\echo ''
\echo '=== F11: عمولة مصروفة بلا مصروف مرتبط (يجب أن تُرفض) ==='
INSERT INTO commissions (employee_id, period_month, commission_amount, status)
VALUES (1, '2026-10', 200, 'PAID');

\echo ''
\echo '=== F12: حذف سجل عمولة (يجب أن يُرفض) ==='
DELETE FROM commissions WHERE employee_id=1 AND period_month='2026-08';

\echo ''
\echo '=== F13: دفعة بمبلغ سالب أو صفر (يجب أن تُرفض) ==='
INSERT INTO payments (payment_no, purpose, customer_id, amount, payment_method_id, created_by)
VALUES ('PAY-NEG', 'OTHER', 2, -100, 1, 1);
INSERT INTO payments (payment_no, purpose, customer_id, amount, payment_method_id, created_by)
VALUES ('PAY-ZERO', 'OTHER', 2, 0, 1, 1);

\echo ''
\echo '=== F14: دفعة تأمينية مصنّفة كغير تأمينية (يجب أن تُرفض) ==='
INSERT INTO payments (payment_no, purpose, is_insurance, customer_id, amount, payment_method_id, created_by)
VALUES ('PAY-BAD', 'INSURANCE_COLLECT', false, 2, 500, 1, 1);

\echo ''
\echo '=== F15: حذف دفعة (يجب أن يُرفض) ==='
INSERT INTO payments (payment_no, purpose, customer_id, amount, payment_method_id, created_by)
VALUES ('PAY-OK', 'OTHER', 2, 500, 1, 1);
DELETE FROM payments WHERE payment_no='PAY-OK';
