import { NextResponse } from 'next/server';
import { ZodError, type ZodTypeAny, type z } from 'zod';
import { AppError, Errors } from '@/lib/errors';
import { requirePermission } from '@/lib/auth/rbac';
import type { PermissionCode } from '@/lib/auth/permissions';
import type { SessionUser } from '@/lib/auth/session';

export const ok = (data: unknown, status = 200) =>
  NextResponse.json({ ok: true, data }, { status });

export function fail(err: unknown) {
  if (err instanceof AppError) {
    return NextResponse.json(
      { ok: false, error: { code: err.code, message: err.message, details: err.details } },
      { status: err.status },
    );
  }
  if (err instanceof ZodError) {
    const e = Errors.validation(err.flatten());
    return NextResponse.json(
      { ok: false, error: { code: e.code, message: e.message, details: e.details } },
      { status: e.status },
    );
  }
  console.error('[UNHANDLED]', err);
  return NextResponse.json(
    { ok: false, error: { code: 'INTERNAL', message: 'حدث خطأ غير متوقع. لم يتم حفظ أي بيانات.' } },
    { status: 500 },
  );
}

/**
 * غلاف موحّد لكل مسار API:
 * تحقق من الجلسة → تحقق من الصلاحية → تحقق من صحة المدخلات → تنفيذ.
 * لا يوجد مسار محمي خارج هذا الغلاف.
 */
export function route<S extends ZodTypeAny | undefined = undefined>(opts: {
  permission?: PermissionCode;
  schema?: S;
  handler: (ctx: {
    user: SessionUser | null;
    input: S extends ZodTypeAny ? z.output<S> : undefined;
    req: Request;
    params: Record<string, string>;
  }) => Promise<unknown>;
}) {
  return async (req: Request, context?: { params?: Record<string, string> }) => {
    try {
      const user = opts.permission ? await requirePermission(opts.permission) : null;

      let input = undefined as unknown as S extends ZodTypeAny ? z.output<S> : undefined;
      if (opts.schema) {
        const body =
          req.method === 'GET'
            ? Object.fromEntries(new URL(req.url).searchParams.entries())
            : await req.json().catch(() => ({}));
        input = opts.schema.parse(body) as typeof input;
      }

      const data = await opts.handler({
        user,
        input,
        req,
        params: context?.params ?? {},
      });
      return ok(data);
    } catch (err) {
      return fail(err);
    }
  };
}
