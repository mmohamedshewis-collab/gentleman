import { describe, it, expect } from 'vitest';
import {
  computeSaleLine, computeSaleTotals, assertFullPayment, remainingAfterSale,
  buildInvoiceNo, exceedsDiscountLimit, SalePricingError,
} from '../src/lib/sales/sale-pricing';
import { canVoidSale, assertRestorable, SALE_ALLOWED_TRANSITIONS } from '../src/lib/sales/sale-state';

const s = (v: { toString(): string }) => v.toString();
const line = (o: Partial<Parameters<typeof computeSaleLine>[0]> = {}) =>
  computeSaleLine({ itemId: 1, unitPrice: 1500, discount: 0, purchaseCost: 6000, preSaleStatus: 'AVAILABLE', ...o });

describe('سطر البيع', () => {
  it('الصافي = السعر − الخصم', () => {
    expect(s(line({ discount: 200 }).netPrice)).toBe('1300');
  });
  it('يرفض خصمًا أكبر من السعر', () => {
    expect(() => line({ discount: 2000 })).toThrowError(SalePricingError);
  });
  it('يرفض القيم السالبة', () => {
    expect(() => line({ unitPrice: -1 })).toThrowError(SalePricingError);
    expect(() => line({ discount: -1 })).toThrowError(SalePricingError);
    expect(() => line({ purchaseCost: -1 })).toThrowError(SalePricingError);
  });
  it('يميّز بيع القطعة التالفة', () => {
    expect(line({ preSaleStatus: 'DAMAGED' }).isDamagedSale).toBe(true);
    expect(line({ preSaleStatus: 'AVAILABLE' }).isDamagedSale).toBe(false);
  });
  it('يجمّد تكلفة الشراء وحالة ما قبل البيع', () => {
    const r = line({ purchaseCost: 6000, preSaleStatus: 'MAINTENANCE' });
    expect(s(r.purchaseCost)).toBe('6000');
    expect(r.preSaleStatus).toBe('MAINTENANCE');
  });
});

describe('التدفق المالي: Revenue ≠ Cash ≠ Profit', () => {
  const t = computeSaleTotals([
    { itemId: 1, unitPrice: 1500, discount: 200, purchaseCost: 6000, preSaleStatus: 'AVAILABLE' },
  ]);

  it('صافي البيع هو الإيراد', () => {
    expect(s(t.subtotal)).toBe('1500');
    expect(s(t.discount)).toBe('200');
    expect(s(t.netAmount)).toBe('1300');
  });
  it('التكلفة رقم مستقل عن الإيراد', () => {
    expect(s(t.totalCost)).toBe('6000');
  });
  it('مجمل الربح قد يكون سالبًا ولا يساوي النقدية', () => {
    expect(s(t.grossProfit)).toBe('-4700');
    expect(s(t.netAmount)).not.toBe(s(t.grossProfit));
  });
  it('الضريبة معطّلة: الإجمالي = الصافي', () => {
    expect(t.vatStatus).toBe('NOT_APPLICABLE');
    expect(s(t.vatAmount)).toBe('0');
    expect(s(t.grossAmount)).toBe('1300');
  });
});

describe('إجمالي فاتورة بعدة قطع', () => {
  const t = computeSaleTotals([
    { itemId: 1, unitPrice: 1000, discount: 100, purchaseCost: 4000, preSaleStatus: 'AVAILABLE' },
    { itemId: 2, unitPrice: 2000, discount: 0, purchaseCost: 500, preSaleStatus: 'DAMAGED' },
  ]);
  it('يجمع السطور بدقة', () => {
    expect(s(t.subtotal)).toBe('3000');
    expect(s(t.discount)).toBe('100');
    expect(s(t.netAmount)).toBe('2900');
    expect(s(t.totalCost)).toBe('4500');
    expect(s(t.grossProfit)).toBe('-1600');
  });
  it('يرفض تكرار نفس القطعة', () => {
    expect(() => computeSaleTotals([
      { itemId: 1, unitPrice: 100, purchaseCost: 0, preSaleStatus: 'AVAILABLE' },
      { itemId: 1, unitPrice: 100, purchaseCost: 0, preSaleStatus: 'AVAILABLE' },
    ])).toThrowError(SalePricingError);
  });
  it('يرفض فاتورة فارغة', () => {
    expect(() => computeSaleTotals([])).toThrowError(SalePricingError);
  });
});

describe('البيع نقدي بالكامل — المتبقي = 0', () => {
  it('يقبل السداد الكامل', () => {
    expect(() => assertFullPayment(1300, 1300)).not.toThrow();
    expect(s(remainingAfterSale(1300, 1300))).toBe('0');
  });
  it('يرفض السداد الجزئي', () => {
    expect(() => assertFullPayment(1300, 1000)).toThrowError(SalePricingError);
  });
  it('يرفض السداد الزائد', () => {
    expect(() => assertFullPayment(1300, 1500)).toThrowError(SalePricingError);
  });
});

describe('حد الخصم', () => {
  it('يكتشف تجاوز النسبة', () => {
    expect(exceedsDiscountLimit(1000, 200, 10)).toBe(true);
    expect(exceedsDiscountLimit(1000, 100, 10)).toBe(false);
  });
  it('أي خصم على سعر صفر يُعد تجاوزًا', () => {
    expect(exceedsDiscountLimit(0, 1, 50)).toBe(true);
  });
});

describe('رقم الفاتورة', () => {
  it('يبني الرقم بست خانات', () => {
    expect(buildInvoiceNo(2026, 1)).toBe('INV-2026-000001');
    expect(buildInvoiceNo(2026, 1234)).toBe('INV-2026-001234');
  });
});

describe('آلة حالة الفاتورة والإلغاء', () => {
  it('المكتملة تُلغى فقط، والملغاة نهائية', () => {
    expect(SALE_ALLOWED_TRANSITIONS.COMPLETED).toEqual(['VOIDED']);
    expect(SALE_ALLOWED_TRANSITIONS.VOIDED).toEqual([]);
  });
  it('يسمح بالإلغاء إذا كانت القطع ما زالت مباعة', () => {
    expect(canVoidSale({ status: 'COMPLETED', itemStatuses: ['SOLD'] }).allowed).toBe(true);
  });
  it('يرفض إلغاء فاتورة ملغاة', () => {
    expect(canVoidSale({ status: 'VOIDED', itemStatuses: ['SOLD'] }).allowed).toBe(false);
  });
  it('يرفض الإلغاء إذا تغيّرت حالة القطعة بعد البيع', () => {
    const r = canVoidSale({ status: 'COMPLETED', itemStatuses: ['DISPOSED'] });
    expect(r.allowed).toBe(false);
    expect(r.reason).toContain('تغيّرت');
  });
  it('لا تعود القطعة إلا إلى حالة قابلة للبيع', () => {
    expect(() => assertRestorable('AVAILABLE')).not.toThrow();
    expect(() => assertRestorable('DAMAGED')).not.toThrow();
    expect(() => assertRestorable('MAINTENANCE')).not.toThrow();
    expect(() => assertRestorable('RENTED')).toThrow();
    expect(() => assertRestorable('LOST')).toThrow();
  });
});

describe('الخروج من حالة "مباعة" — الاستثناء الوحيد', () => {
  it('ممنوع بلا عَلَم الإلغاء', async () => {
    const { canTransition } = await import('../src/lib/inventory/item-state');
    expect(canTransition('SOLD', 'AVAILABLE').allowed).toBe(false);
    expect(canTransition('SOLD', 'AVAILABLE', { manual: true }).allowed).toBe(false);
  });

  it('مسموح مع عَلَم الإلغاء وإلى حالة قابلة للبيع فقط', async () => {
    const { canTransition } = await import('../src/lib/inventory/item-state');
    for (const to of ['AVAILABLE', 'DAMAGED', 'MAINTENANCE'] as const) {
      expect(canTransition('SOLD', to, { allowVoidSaleExit: true }).allowed).toBe(true);
    }
    for (const to of ['RENTED', 'LOST', 'DISPOSED', 'RESERVED'] as const) {
      expect(canTransition('SOLD', to, { allowVoidSaleExit: true }).allowed).toBe(false);
    }
  });
});
