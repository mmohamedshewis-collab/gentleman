import { acceptsPayments } from '@/lib/rentals/rental-state';
import { z } from 'zod';
import type { Prisma } from '@prisma/client';
import { prisma } from '@/lib/db';
import { Errors } from '@/lib/errors';
import { writeAudit } from '@/lib/audit';
import { requirePermission, can } from '@/lib/auth/rbac';
import { businessToday, toBusinessDate, addBusinessDays, periodBounds } from '@/lib/date';
import { getNumberSetting, getBoolSetting } from '@/lib/settings';
import { canBeRented, STATUS_LABELS, type ItemStatus } from '@/lib/inventory/item-state';
import { canVoidRental, RENTAL_STATUS_LABELS, type RentalStatus } from '@/lib/rentals/rental-state';
import {
  computeRentalTotals, exceedsDiscountLimit, buildRentalNo, PricingError,
} from '@/lib/rentals/pricing';

const money = z.coerce.number().min(0).max(9_999_999);

// ============================ التحقق من المدخلات ============================

export const createRentalSchema = z.object({
  customerId: z.number().int().positive(),
  employeeId: z.number().int().positive().nullable().optional(),
  rentalDate: z.string().optional(),
  expectedReturnDate: z.string().optional(),
  items: z
    .array(
      z.object({
        itemId: z.number().int().positive(),
        unitRentalPrice: money,
        discount: money.default(0),
        insurancePerItem: money.default(0),
      }),
    )
    .min(1, 'يجب اختيار قطعة واحدة على الأقل'),
  paidAmount: money.default(0),
  paymentMethodId: z.number().int().positive().nullable().optional(),
  insurancePaymentMethodId: z.number().int().positive().nullable().optional(),
  notes: z.string().max(500).optional(),
});

export const voidRentalSchema = z.object({
  rentalId: z.number().int().positive(),
  reason: z.string().trim().min(3, 'سبب الإلغاء مطلوب'),
});

export const addPaymentSchema = z.object({
  rentalId: z.number().int().positive(),
  amount: money.refine((v) => v > 0, 'المبلغ يجب أن يكون أكبر من صفر'),
  paymentMethodId: z.number().int().positive(),
  notes: z.string().max(300).optional(),
});

export const rentalQuerySchema = z.object({
  q: z.string().optional(),
  status: z.string().optional(),
  customerId: z.coerce.number().int().optional(),
  from: z.string().optional(),
  to: z.string().optional(),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(10).max(200).default(50),
});

// ============================ إنشاء عقد تأجير ============================

/**
 * عملية ذرّية واحدة: قفل القطع، فحص الحالة والتعارض الزمني، إنشاء العقد
 * والسطور والحجوزات، تحديث الحالات، تسجيل الدفعة والتأمين، ثم التدقيق.
 * أي فشل في أي خطوة يُرجع كل شيء.
 */
export async function createRental(input: z.infer<typeof createRentalSchema>) {
  const actor = await requirePermission('rentals.create');

  const defaultDays = (await getNumberSetting('rental.default_days')).toNumber();
  const maxDiscountPct = await getNumberSetting('discount.staff_max_percent');
  const vatEnabled = await getBoolSetting('vat.enabled');
  const vatRate = await getNumberSetting('vat.rate');

  const rentalDate = input.rentalDate ? toBusinessDate(input.rentalDate) : businessToday();
  const expectedReturnDate = input.expectedReturnDate
    ? toBusinessDate(input.expectedReturnDate)
    : addBusinessDays(rentalDate, defaultDays);

  if (expectedReturnDate < rentalDate) {
    throw Errors.rule('تاريخ الإرجاع المتوقع لا يمكن أن يسبق تاريخ التأجير.');
  }

  // الحساب قبل أي كتابة — الرفض المبكر لا يلمس قاعدة البيانات
  let totals;
  try {
    totals = computeRentalTotals({
      lines: input.items,
      paidAmount: input.paidAmount,
      vat: vatEnabled ? { enabled: true, rate: vatRate } : null,
    });
  } catch (e) {
    if (e instanceof PricingError) throw Errors.rule(e.message);
    throw e;
  }

  if (
    exceedsDiscountLimit(totals.discountPercent, maxDiscountPct) &&
    !can(actor, 'discount.override')
  ) {
    throw Errors.forbidden('discount.override');
  }

  if (totals.paidAmount.gt(0) && !input.paymentMethodId) {
    throw Errors.rule('يجب اختيار طريقة الدفع عند تحصيل مبلغ.');
  }
  if (totals.insuranceAmount.gt(0) && !input.insurancePaymentMethodId && !input.paymentMethodId) {
    throw Errors.rule('يجب اختيار طريقة دفع للتأمين.');
  }

  const customer = await prisma.customer.findUnique({
    where: { id: input.customerId },
    select: { id: true, isActive: true, fullName: true },
  });
  if (!customer) throw Errors.notFound('العميل');
  if (!customer.isActive) throw Errors.rule('العميل معطّل ولا يمكن التأجير له.');

  // ترتيب المعرّفات تصاعديًا يمنع الجمود بين جلستين تؤجران نفس القطع بترتيب معكوس
  const itemIds = [...totals.lines.map((l) => l.itemId)].sort((a, b) => a - b);

  return prisma.$transaction(async (tx) => {
    // 1) قفل صفوف القطع
    const locked = await tx.$queryRaw<{ id: number; status: ItemStatus; item_code: string }[]>`
      SELECT id, status, item_code FROM product_items
      WHERE id = ANY(${itemIds}::int[])
      ORDER BY id
      FOR UPDATE
    `;
    if (locked.length !== itemIds.length) throw Errors.notFound('إحدى القطع المطلوبة');

    // 2) فحص حالة كل قطعة بعد القفل
    for (const row of locked) {
      if (!canBeRented(row.status)) {
        throw Errors.rule(
          `القطعة ${row.item_code} ${STATUS_LABELS[row.status]} ولا يمكن تأجيرها.`,
        );
      }
    }

    // 3) فحص التعارض الزمني مع أي حجز أو تأجير قائم
    const conflicts = await tx.itemBooking.findMany({
      where: {
        itemId: { in: itemIds },
        isActive: true,
        startDate: { lte: expectedReturnDate },
        endDate: { gte: rentalDate },
      },
      select: { itemId: true, startDate: true, endDate: true, sourceType: true },
    });
    if (conflicts.length > 0) {
      const c = conflicts[0];
      const code = locked.find((l) => l.id === c.itemId)?.item_code ?? c.itemId;
      throw Errors.conflict(
        `القطعة ${code} مرتبطة بالفعل بفترة من ${c.startDate.toISOString().slice(0, 10)} ` +
          `إلى ${c.endDate.toISOString().slice(0, 10)}.`,
      );
    }

    // 4) رقم العقد — قفل استشاري يمنع تكرار الرقم بين جلستين
    await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext('rental_no'))`;
    const year = rentalDate.getUTCFullYear();
    const lastRental = await tx.rental.findFirst({
      where: { rentalNo: { startsWith: `R-${year}-` } },
      orderBy: { rentalNo: 'desc' },
      select: { rentalNo: true },
    });
    const nextSeq = lastRental ? Number.parseInt(lastRental.rentalNo.slice(7), 10) + 1 : 1;

    // 5) رأس العقد
    // ★ D9: تجميد نسبة العمولة السارية على العقد — تغييرها لاحقًا لا يمس الماضي
    const commissionEmployeeId = input.employeeId ?? actor.employeeId ?? null;
    const commissionEmployee = commissionEmployeeId
      ? await tx.employee.findUnique({
          where: { id: commissionEmployeeId },
          select: { rentalCommissionPct: true },
        })
      : null;

    const rental = await tx.rental.create({
      data: {
        rentalNo: buildRentalNo(year, Number.isFinite(nextSeq) ? nextSeq : 1),
        commissionRatePct: commissionEmployee?.rentalCommissionPct.toString() ?? null,
        customerId: customer.id,
        employeeId: input.employeeId ?? actor.employeeId ?? null,
        rentalDate,
        expectedReturnDate,
        subtotal: totals.subtotal.toString(),
        discount: totals.discount.toString(),
        netAmount: totals.netAmount.toString(),
        vatAmount: totals.vatAmount.toString(),
        grossAmount: totals.grossAmount.toString(),
        extraCharges: '0',
        totalDue: totals.totalDue.toString(),
        depositAmount: totals.paidAmount.toString(),
        insuranceAmount: totals.insuranceAmount.toString(),
        paidAmount: '0',
        remainingAmount: totals.totalDue.toString(),
        status: 'ACTIVE',
        notes: input.notes?.trim() || null,
        createdBy: actor.id,
      },
    });

    // 6) السطور + الحجز الزمني + تحديث الحالة + حركة المخزون
    for (const line of totals.lines) {
      await tx.rentalItem.create({
        data: {
          rentalId: rental.id,
          itemId: line.itemId,
          unitRentalPrice: line.unitRentalPrice.toString(),
          discount: line.discount.toString(),
          netPrice: line.netPrice.toString(),
          insurancePerItem: line.insurancePerItem.toString(),
          expectedReturnDate,
          status: 'OUT',
        },
      });

      await tx.itemBooking.create({
        data: {
          itemId: line.itemId,
          startDate: rentalDate,
          endDate: expectedReturnDate,
          sourceType: 'RENTAL',
          sourceId: rental.id,
          isActive: true,
          createdBy: actor.id,
        },
      });

      await tx.productItem.update({
        where: { id: line.itemId },
        data: {
          status: 'RENTED',
          rentalCount: { increment: 1 },
          totalRentalRevenue: { increment: line.netPrice.toString() },
          lastRentalDate: rentalDate,
        },
      });

      await tx.itemStatusHistory.create({
        data: {
          itemId: line.itemId,
          fromStatus: 'AVAILABLE',
          toStatus: 'RENTED',
          reason: `عقد تأجير ${rental.rentalNo}`,
          refType: 'Rental',
          refId: rental.id,
          userId: actor.id,
        },
      });

      await tx.inventoryTransaction.create({
        data: {
          itemId: line.itemId,
          trxDate: rentalDate,
          type: 'RENT_OUT',
          refType: 'Rental',
          refId: rental.id,
          createdBy: actor.id,
        },
      });
    }

    // 7) دفعة الإيجار (العربون) — Trigger القاعدة يتكفّل بتحديث المدفوع والمتبقي
    if (totals.paidAmount.gt(0)) {
      await tx.payment.create({
        data: {
          paymentNo: `PR-${rental.rentalNo}-1`,
          paymentDate: rentalDate,
          direction: 'IN',
          purpose: 'RENTAL',
          isInsurance: false,
          customerId: customer.id,
          rentalId: rental.id,
          amount: totals.paidAmount.toString(),
          paymentMethodId: input.paymentMethodId!,
          createdBy: actor.id,
        },
      });
    }

    // 8) التأمين — سجل مستقل تمامًا، لا يمس إجماليات العقد
    if (totals.insuranceAmount.gt(0)) {
      const methodId = input.insurancePaymentMethodId ?? input.paymentMethodId!;
      const insurancePayment = await tx.payment.create({
        data: {
          paymentNo: `PI-${rental.rentalNo}-1`,
          paymentDate: rentalDate,
          direction: 'IN',
          purpose: 'INSURANCE_COLLECT',
          isInsurance: true,
          customerId: customer.id,
          rentalId: rental.id,
          amount: totals.insuranceAmount.toString(),
          paymentMethodId: methodId,
          createdBy: actor.id,
        },
      });

      const prevBalance = await insuranceBalance(tx);
      await tx.insuranceTransaction.create({
        data: {
          trxDate: rentalDate,
          type: 'COLLECTED',
          customerId: customer.id,
          rentalId: rental.id,
          paymentId: insurancePayment.id,
          paymentMethodId: methodId,
          amount: totals.insuranceAmount.toString(),
          balanceAfter: prevBalance.plus(totals.insuranceAmount.toNumber()).toString(),
          createdBy: actor.id,
        },
      });
    }

    await writeAudit(
      {
        userId: actor.id,
        action: 'rental.create',
        entityType: 'Rental',
        entityId: rental.id,
        after: {
          rentalNo: rental.rentalNo,
          customerId: customer.id,
          items: totals.lines.map((l) => l.itemId),
          totalDue: totals.totalDue.toString(),
          paid: totals.paidAmount.toString(),
          insurance: totals.insuranceAmount.toString(),
        },
      },
      tx,
    );

    return {
      id: rental.id,
      rentalNo: rental.rentalNo,
      customerName: customer.fullName,
      rentalDate,
      expectedReturnDate,
      subtotal: totals.subtotal.toString(),
      discount: totals.discount.toString(),
      totalDue: totals.totalDue.toString(),
      paidAmount: totals.paidAmount.toString(),
      remainingAmount: totals.remainingAmount.toString(),
      insuranceAmount: totals.insuranceAmount.toString(),
      itemCount: totals.lines.length,
    };
  });
}

/** رصيد صندوق التأمين الحالي من آخر حركة. */
async function insuranceBalance(tx: Prisma.TransactionClient) {
  const { Decimal } = await import('decimal.js');
  const last = await tx.insuranceTransaction.findFirst({
    orderBy: { id: 'desc' },
    select: { balanceAfter: true },
  });
  return new Decimal(last?.balanceAfter?.toString() ?? 0);
}

// ============================ إضافة دفعة ============================

export async function addRentalPayment(input: z.infer<typeof addPaymentSchema>) {
  const actor = await requirePermission('payments.create');

  return prisma.$transaction(async (tx) => {
    const rows = await tx.$queryRaw<
      { id: number; status: RentalStatus; total_due: string; paid_amount: string; rental_no: string; customer_id: number }[]
    >`SELECT id, status, total_due, paid_amount, rental_no, customer_id
        FROM rentals WHERE id = ${input.rentalId} FOR UPDATE`;
    if (rows.length === 0) throw Errors.notFound('عقد التأجير');

    const rental = rows[0];
    // العقد المغلق قد يبقى عليه مستحق من غرامات الإرجاع فيقبل السداد.
    // الملغى وحده لا يقبل أي دفعة.
    if (!acceptsPayments(rental.status)) {
      throw Errors.rule(`العقد ${RENTAL_STATUS_LABELS[rental.status]} ولا يقبل دفعات جديدة.`);
    }

    const { Decimal } = await import('decimal.js');
    const remaining = new Decimal(rental.total_due).minus(rental.paid_amount);
    if (new Decimal(input.amount).gt(remaining)) {
      throw Errors.rule(`المبلغ يتجاوز المتبقي على العقد (${remaining.toString()}).`);
    }

    const count = await tx.payment.count({ where: { rentalId: rental.id, isInsurance: false } });

    const payment = await tx.payment.create({
      data: {
        paymentNo: `PR-${rental.rental_no}-${count + 1}`,
        paymentDate: businessToday(),
        direction: 'IN',
        purpose: 'RENTAL',
        isInsurance: false,
        customerId: rental.customer_id,
        rentalId: rental.id,
        amount: String(input.amount),
        paymentMethodId: input.paymentMethodId,
        notes: input.notes?.trim() || null,
        createdBy: actor.id,
      },
    });

    await writeAudit(
      {
        userId: actor.id,
        action: 'rental.payment',
        entityType: 'Payment',
        entityId: payment.id,
        after: { rentalId: rental.id, amount: String(input.amount) },
      },
      tx,
    );

    return { id: payment.id, paymentNo: payment.paymentNo, amount: String(input.amount) };
  });
}

// ============================ إلغاء العقد ============================

/**
 * الإلغاء لا يحذف شيئًا: يعيد القطع، يحرّر الفترات، يلغي الدفعات،
 * يرد التأمين، ويبقي العقد في السجل بحالة "ملغى".
 */
export async function voidRental(input: z.infer<typeof voidRentalSchema>) {
  const actor = await requirePermission('rentals.void');

  return prisma.$transaction(async (tx) => {
    const rows = await tx.$queryRaw<
      { id: number; status: RentalStatus; rental_no: string; insurance_amount: string; customer_id: number }[]
    >`SELECT id, status, rental_no, insurance_amount, customer_id
        FROM rentals WHERE id = ${input.rentalId} FOR UPDATE`;
    if (rows.length === 0) throw Errors.notFound('عقد التأجير');

    const rental = rows[0];
    const check = canVoidRental(rental.status);
    if (!check.allowed) throw Errors.rule(check.reason!);

    const returned = await tx.rentalItem.count({
      where: { rentalId: rental.id, status: { not: 'OUT' } },
    });
    if (returned > 0) throw Errors.rule('تم إرجاع بعض القطع — لا يمكن إلغاء العقد.');

    const lines = await tx.rentalItem.findMany({
      where: { rentalId: rental.id },
      select: { id: true, itemId: true, netPrice: true },
    });

    for (const line of lines) {
      // GREATEST يمنع نزول العدّادات تحت الصفر مهما كانت حالة البيانات
      await tx.$executeRaw`
        UPDATE product_items
           SET status = 'AVAILABLE',
               rental_count = GREATEST(rental_count - 1, 0),
               total_rental_revenue = GREATEST(total_rental_revenue - ${line.netPrice.toString()}::numeric, 0)
         WHERE id = ${line.itemId}
      `;
      await tx.itemStatusHistory.create({
        data: {
          itemId: line.itemId,
          fromStatus: 'RENTED',
          toStatus: 'AVAILABLE',
          reason: `إلغاء عقد ${rental.rental_no}: ${input.reason}`,
          refType: 'Rental',
          refId: rental.id,
          userId: actor.id,
        },
      });
      await tx.inventoryTransaction.create({
        data: {
          itemId: line.itemId,
          trxDate: businessToday(),
          type: 'RETURN_IN',
          refType: 'RentalVoid',
          refId: rental.id,
          note: input.reason,
          createdBy: actor.id,
        },
      });
    }

    await tx.rentalItem.updateMany({
      where: { rentalId: rental.id },
      data: { status: 'RETURNED' },
    });

    // تحرير الفترات الزمنية حتى تعود القطع قابلة للحجز
    await tx.itemBooking.updateMany({
      where: { sourceType: 'RENTAL', sourceId: rental.id, isActive: true },
      data: { isActive: false },
    });

    // إلغاء الدفعات (لا حذف) — Trigger القاعدة يصفّر المدفوع والمتبقي
    await tx.payment.updateMany({
      where: { rentalId: rental.id, isVoided: false },
      data: { isVoided: true, voidReason: input.reason },
    });

    // رد التأمين المحصَّل في سجله المستقل
    const { Decimal } = await import('decimal.js');
    const insurance = new Decimal(rental.insurance_amount);
    if (insurance.gt(0)) {
      const prevBalance = await insuranceBalance(tx);
      await tx.insuranceTransaction.create({
        data: {
          trxDate: businessToday(),
          type: 'REFUNDED',
          customerId: rental.customer_id,
          rentalId: rental.id,
          amount: insurance.toString(),
          balanceAfter: prevBalance.minus(insurance).toString(),
          reason: `إلغاء عقد ${rental.rental_no}`,
          createdBy: actor.id,
        },
      });
    }

    const updated = await tx.rental.update({
      where: { id: rental.id },
      data: {
        status: 'VOIDED',
        voidReason: input.reason,
        voidedBy: actor.id,
        voidedAt: new Date(),
      },
    });

    await writeAudit(
      {
        userId: actor.id,
        action: 'rental.void',
        entityType: 'Rental',
        entityId: rental.id,
        before: { status: rental.status },
        after: { status: 'VOIDED' },
        reason: input.reason,
      },
      tx,
    );

    return { id: updated.id, rentalNo: rental.rental_no, status: 'VOIDED', itemsReleased: lines.length };
  });
}

// ============================ العرض ============================

export async function listRentals(input: z.infer<typeof rentalQuerySchema>) {
  await requirePermission('rentals.view');

  const where: Prisma.RentalWhereInput = {
    status: input.status ? (input.status as RentalStatus) : undefined,
    customerId: input.customerId,
    ...(input.from && input.to
      ? { createdAt: { gte: periodBounds(input.from, input.to).start, lte: periodBounds(input.from, input.to).end } }
      : {}),
    ...(input.q
      ? {
          OR: [
            { rentalNo: { contains: input.q.toUpperCase() } },
            { customer: { fullName: { contains: input.q } } },
            { customer: { phone: { contains: input.q.replace(/\D/g, '') } } },
          ],
        }
      : {}),
  };

  const [rows, total] = await Promise.all([
    prisma.rental.findMany({
      where,
      include: {
        customer: { select: { fullName: true, phone: true } },
        _count: { select: { items: true } },
      },
      orderBy: { id: 'desc' },
      skip: (input.page - 1) * input.pageSize,
      take: input.pageSize,
    }),
    prisma.rental.count({ where }),
  ]);

  return { rows, total, page: input.page, pageSize: input.pageSize };
}

export async function getRental(id: number) {
  await requirePermission('rentals.view');
  const rental = await prisma.rental.findUnique({
    where: { id },
    include: {
      customer: true,
      employee: { select: { fullName: true } },
      items: { include: { item: { include: { product: { select: { nameAr: true, size: true, color: true } } } } } },
      payments: { include: { paymentMethod: { select: { nameAr: true } } }, orderBy: { id: 'asc' } },
      insuranceTransactions: { orderBy: { id: 'asc' } },
    },
  });
  if (!rental) throw Errors.notFound('عقد التأجير');
  return { ...rental, statusLabel: RENTAL_STATUS_LABELS[rental.status as RentalStatus] };
}
