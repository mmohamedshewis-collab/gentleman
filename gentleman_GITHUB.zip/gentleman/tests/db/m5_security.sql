\set ON_ERROR_STOP off
\pset pager off
\t on

UPDATE product_items SET status='AVAILABLE', purchase_cost=6000 WHERE item_code='SUIT-0001';
INSERT INTO sales (invoice_no, customer_id, sale_date, subtotal, discount, net_amount,
                   gross_amount, paid_amount, total_cost, status, created_by)
VALUES ('INV-SEC-1', 2, CURRENT_DATE, 1500, 0, 1500, 1500, 1500, 6000, 'COMPLETED', 1);
INSERT INTO sale_items (sale_id, item_id, unit_price, discount, net_price, gross_amount,
                        purchase_cost, pre_sale_status)
SELECT currval('sales_id_seq'), id, 1500, 0, 1500, 1500, 6000, 'AVAILABLE'
  FROM product_items WHERE item_code='SUIT-0001';
UPDATE product_items SET status='SOLD' WHERE item_code='SUIT-0001';

\echo '=== A1: مهاجم يضبط العَلَم القديم يدويًا ثم يحاول إعادة القطعة ==='
BEGIN;
SELECT set_config('app.void_sale','1',true);
UPDATE product_items SET status='AVAILABLE' WHERE item_code='SUIT-0001';
ROLLBACK;

\echo ''
\echo '=== A2: مهاجم يضبط العَلَم على مستوى الجلسة كلها (is_local=false) ==='
SELECT set_config('app.void_sale','1',false);
UPDATE product_items SET status='AVAILABLE' WHERE item_code='SUIT-0001';
SELECT 'الحالة بعد المحاولة = ' || status FROM product_items WHERE item_code='SUIT-0001';
SELECT set_config('app.void_sale','',false);

\echo ''
\echo '=== A3: تغيير حالة القطعة يدويًا والفاتورة سارية (يجب أن يُرفض) ==='
UPDATE product_items SET status='DAMAGED' WHERE item_code='SUIT-0001';
UPDATE product_items SET status='MAINTENANCE' WHERE item_code='SUIT-0001';
UPDATE product_items SET status='RENTED' WHERE item_code='SUIT-0001';

\echo ''
\echo '=== A4: بعد إلغاء الفاتورة فعلًا — العودة إلى حالة مختلفة عن المحفوظة (يجب أن تُرفض) ==='
UPDATE sales SET status='VOIDED', void_reason='اختبار أمني' WHERE invoice_no='INV-SEC-1';
UPDATE product_items SET status='DAMAGED' WHERE item_code='SUIT-0001';
UPDATE product_items SET status='MAINTENANCE' WHERE item_code='SUIT-0001';

\echo ''
\echo '=== A5: العودة إلى الحالة المحفوظة بالضبط (يجب أن تنجح) ==='
UPDATE product_items SET status='AVAILABLE' WHERE item_code='SUIT-0001';
SELECT 'الحالة النهائية = ' || status FROM product_items WHERE item_code='SUIT-0001';

\echo ''
\echo '=== A6: قطعة مباعة بلا أي فاتورة إطلاقًا (يجب أن تُرفض) ==='
UPDATE product_items SET status='SOLD' WHERE item_code='SUIT-0002';
UPDATE product_items SET status='AVAILABLE' WHERE item_code='SUIT-0002';

\echo ''
\echo '=== A7: هل يبقى أي أثر للعَلَم بعد انتهاء المعاملة؟ ==='
SELECT 'قيمة app.void_sale الآن = [' || COALESCE(current_setting('app.void_sale', true),'غير معرّف') || ']';
