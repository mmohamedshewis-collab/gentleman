import { describe, it, expect, vi, beforeEach } from 'vitest';

/** اختبارات طبقة خدمة العملاء: البحث، منع التكرار، الصلاحيات، حماية العميل النقدي. */

const auditSpy = vi.fn();
let currentUser: { id: number; permissions: Set<string> };
let dbCustomers: any[] = [];

const findUnique = vi.fn(async ({ where }: any) => {
  if (where.phone) return dbCustomers.find((c) => c.phone === where.phone) ?? null;
  if (where.id) return dbCustomers.find((c) => c.id === where.id) ?? null;
  if (where.code) return dbCustomers.find((c) => c.code === where.code) ?? null;
  return null;
});
const createSpy = vi.fn(async ({ data }: any) => ({ id: 100, isWalkIn: false, isActive: true, createdAt: new Date(), ...data }));
const updateSpy = vi.fn(async ({ where, data }: any) => ({
  ...dbCustomers.find((c) => c.id === where.id), ...data,
}));

const tx = {
  customer: {
    findFirst: vi.fn(async () => ({ code: 'C-000007' })),
    create: (a: any) => createSpy(a),
    update: (a: any) => updateSpy(a),
  },
};

vi.mock('@/lib/db', () => ({
  prisma: {
    $transaction: (fn: any) => fn(tx),
    customer: {
      findUnique: (a: any) => findUnique(a),
      findMany: vi.fn(async () => dbCustomers),
      count: vi.fn(async () => dbCustomers.length),
    },
  },
}));

vi.mock('@/lib/audit', () => ({ writeAudit: (...a: any[]) => auditSpy(...a), redact: (x: any) => x }));

vi.mock('@/lib/auth/rbac', async (importOriginal) => {
  const actual = await importOriginal<typeof import('@/lib/auth/rbac')>();
  return {
    ...actual,
    requirePermission: async (perm: string) => {
      if (!currentUser.permissions.has(perm)) {
        const { Errors } = await import('@/lib/errors');
        throw Errors.forbidden(perm);
      }
      return currentUser as never;
    },
  };
});

const asStaff = () => { currentUser = { id: 9, permissions: new Set(['customers.view', 'customers.create', 'customers.edit']) }; };
const asAdmin = () => { currentUser = { id: 1, permissions: new Set(['customers.view', 'customers.create', 'customers.edit', 'customers.deactivate']) }; };

beforeEach(() => {
  auditSpy.mockClear(); createSpy.mockClear(); updateSpy.mockClear();
  dbCustomers = [
    { id: 1, code: 'WALKIN', fullName: 'عميل نقدي', phone: null, isWalkIn: true, isActive: true, nationalId: null, notes: null, createdAt: new Date() },
    { id: 2, code: 'C-000001', fullName: 'أحمد محمد', phone: '01012345678', isWalkIn: false, isActive: true, nationalId: null, notes: null, createdAt: new Date() },
  ];
  asStaff();
});

describe('البحث بالجوال', () => {
  it('يجد العميل بأي صيغة للرقم', async () => {
    const { lookupByPhone } = await import('@/services/customer.service');
    for (const v of ['01012345678', '+201012345678', '010 1234 5678', '١٠١٢٣٤٥٦٧٨']) {
      const r = await lookupByPhone(v);
      expect(r.found).toBe(true);
      expect(r.found && r.customer.fullName).toBe('أحمد محمد');
    }
  });

  it('يعيد "غير موجود" مع الرقم الموحَّد جاهزًا للإنشاء', async () => {
    const { lookupByPhone } = await import('@/services/customer.service');
    const r = await lookupByPhone('0111 111 1111');
    expect(r.found).toBe(false);
    expect(r.normalizedPhone).toBe('01111111111');
  });

  it('يرفض رقمًا غير صالح برسالة عربية', async () => {
    const { lookupByPhone } = await import('@/services/customer.service');
    await expect(lookupByPhone('12345')).rejects.toMatchObject({ code: 'BUSINESS_RULE' });
  });
});

describe('إنشاء عميل', () => {
  it('يُنشئ العميل بالرقم الموحَّد ويسجّل العملية', async () => {
    const { createCustomer } = await import('@/services/customer.service');
    const r = await createCustomer({ fullName: '  سارة علي  ', phone: '+20 111 222 3333' });
    expect(createSpy.mock.calls[0][0].data).toMatchObject({
      fullName: 'سارة علي', phone: '01112223333', code: 'C-000008',
    });
    expect(r.phoneDisplay).toBe('0111 222 3333');
    expect(auditSpy.mock.calls[0][0]).toMatchObject({ action: 'customer.create', entityType: 'Customer' });
  });

  it('يمنع تكرار العميل بنفس الرقم بصيغة مختلفة', async () => {
    const { createCustomer } = await import('@/services/customer.service');
    await expect(
      createCustomer({ fullName: 'أحمد م.', phone: '+201012345678' }),
    ).rejects.toMatchObject({ code: 'CONFLICT' });
    expect(createSpy).not.toHaveBeenCalled();
  });

  it('يرفض رقمًا من شبكة غير مصرية', async () => {
    const { createCustomer } = await import('@/services/customer.service');
    await expect(createCustomer({ fullName: 'خالد', phone: '01312345678' }))
      .rejects.toMatchObject({ code: 'BUSINESS_RULE' });
  });

  it('يرفض رقمًا قوميًا خاطئ الطول', async () => {
    const { createCustomer } = await import('@/services/customer.service');
    await expect(createCustomer({ fullName: 'خالد', phone: '01111111111', nationalId: '123' }))
      .rejects.toMatchObject({ code: 'BUSINESS_RULE' });
  });

  it('لا يُنشئ عميلًا بلا صلاحية', async () => {
    currentUser = { id: 3, permissions: new Set(['customers.view']) };
    const { createCustomer } = await import('@/services/customer.service');
    await expect(createCustomer({ fullName: 'خالد', phone: '01111111111' }))
      .rejects.toMatchObject({ code: 'PERM_DENIED' });
  });
});

describe('حماية العميل النقدي', () => {
  it('لا يُعاد تسميته ولا يُعطى رقمًا ولا يُعطَّل', async () => {
    asAdmin();
    const { updateCustomer } = await import('@/services/customer.service');
    for (const patch of [{ fullName: 'اسم آخر' }, { phone: '01011111111' }, { isActive: false }]) {
      await expect(updateCustomer({ id: 1, ...patch } as never))
        .rejects.toMatchObject({ code: 'BUSINESS_RULE' });
    }
    expect(updateSpy).not.toHaveBeenCalled();
  });
});

describe('تعديل العميل', () => {
  it('يمنع نقل رقم عميل إلى عميل آخر', async () => {
    dbCustomers.push({ id: 3, code: 'C-000002', fullName: 'منى', phone: '01555555555', isWalkIn: false, isActive: true });
    const { updateCustomer } = await import('@/services/customer.service');
    await expect(updateCustomer({ id: 3, phone: '01012345678' }))
      .rejects.toMatchObject({ code: 'CONFLICT' });
  });

  it('تعطيل العميل يحتاج صلاحية إضافية', async () => {
    const { updateCustomer } = await import('@/services/customer.service');
    await expect(updateCustomer({ id: 2, isActive: false }))
      .rejects.toMatchObject({ code: 'PERM_DENIED', details: { permission: 'customers.deactivate' } });
  });

  it('المدير يستطيع التعطيل ويُسجَّل ذلك', async () => {
    asAdmin();
    const { updateCustomer } = await import('@/services/customer.service');
    await updateCustomer({ id: 2, isActive: false });
    expect(auditSpy.mock.calls[0][0]).toMatchObject({ action: 'customer.deactivate', entityType: 'Customer' });
  });

  it('التعديل بلا تغيير فعلي لا يلمس قاعدة البيانات', async () => {
    const { updateCustomer } = await import('@/services/customer.service');
    const r = await updateCustomer({ id: 2 });
    expect(r).toMatchObject({ unchanged: true });
    expect(updateSpy).not.toHaveBeenCalled();
    expect(auditSpy).not.toHaveBeenCalled();
  });
});
