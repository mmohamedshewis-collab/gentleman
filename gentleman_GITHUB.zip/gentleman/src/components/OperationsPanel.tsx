'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { CSV_TEMPLATES } from '@/lib/import/csv';

interface HistoryRow {
  id: number; startedAt: string; finishedAt: string | null;
  status: string; storageKey: string | null; rowCount: number | null;
  validationResult: string | null; errorMessage: string | null;
}

interface Props {
  canExport: boolean;
  canImportItems: boolean;
  canImportCustomers: boolean;
  history: { notice: string; storageConfigured: boolean; rows: HistoryRow[] } | null;
}

const STATUS_LABEL: Record<string, string> = {
  RUNNING: 'قيد التنفيذ', SUCCESS: 'ناجح', FAILED: 'فاشل',
};

export default function OperationsPanel({
  canExport, canImportItems, canImportCustomers, history,
}: Props) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);
  const [csv, setCsv] = useState('');
  const [target, setTarget] = useState<'items' | 'customers'>(
    canImportItems ? 'items' : 'customers',
  );
  const [result, setResult] = useState<{
    total: number; succeeded: number; failed: number;
    outcomes: { row: number; ok: boolean; reference?: string; error?: string }[];
  } | null>(null);

  async function runExport() {
    setBusy(true); setMsg(null);
    const res = await fetch('/api/backup', { method: 'POST' });
    const json = await res.json();
    setBusy(false);
    if (!json.ok) { setMsg({ type: 'err', text: json.error?.message ?? 'تعذّر التصدير.' }); return; }
    setMsg({ type: 'ok', text: `تم التصدير: ${json.data.rowCount} سجلًا من ${json.data.tables} جدولًا.` });
    router.refresh();
  }

  async function runImport() {
    setBusy(true); setMsg(null); setResult(null);
    const res = await fetch(`/api/import/${target}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ csv }),
    });
    const json = await res.json();
    setBusy(false);
    if (!json.ok) { setMsg({ type: 'err', text: json.error?.message ?? 'تعذّر الاستيراد.' }); return; }
    setResult(json.data);
    router.refresh();
  }

  return (
    <div className="space-y-6">
      {canExport && (
        <div className="card">
          <div className="card-header">تصدير البيانات</div>
          <div className="p-5 space-y-4">
            <div className="rounded-lg bg-amber-50 border border-amber-200 p-4 text-sm text-warn">
              {history?.notice}
            </div>
            {history && !history.storageConfigured && (
              <p className="text-xs text-danger">
                تخزين R2 غير مُهيّأ — سيُحفظ التصدير مؤقتًا في الذاكرة ولن يبقى بعد إعادة التشغيل.
              </p>
            )}
            <button className="btn-primary" onClick={runExport} disabled={busy}>
              {busy ? 'جارٍ التصدير…' : 'تصدير الآن'}
            </button>
          </div>

          {history && history.rows.length > 0 && (
            <div className="overflow-x-auto border-t border-slate-200">
              <table className="table">
                <thead>
                  <tr><th>البداية</th><th>النهاية</th><th>الحالة</th><th>السجلات</th><th>المفتاح</th><th>التحقق</th></tr>
                </thead>
                <tbody>
                  {history.rows.map((r) => (
                    <tr key={r.id}>
                      <td className="num">{r.startedAt}</td>
                      <td className="num">{r.finishedAt ?? '—'}</td>
                      <td>
                        <span className={`badge ${
                          r.status === 'SUCCESS' ? 'bg-green-100 text-ok'
                          : r.status === 'FAILED' ? 'bg-red-100 text-danger'
                          : 'bg-slate-100 text-slate-500'}`}>
                          {STATUS_LABEL[r.status] ?? r.status}
                        </span>
                      </td>
                      <td className="num">{r.rowCount ?? '—'}</td>
                      <td className="num text-xs">{r.storageKey ?? '—'}</td>
                      <td className="text-xs text-slate-600">
                        {r.errorMessage ?? r.validationResult ?? '—'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {(canImportItems || canImportCustomers) && (
        <div className="card">
          <div className="card-header">استيراد البيانات الافتتاحية</div>
          <div className="p-5 space-y-4">
            <p className="text-xs text-slate-500">
              كل صف يمر بالخدمة المعتمدة لوحدته — لا تُكتب أي بيانات مباشرةً في قاعدة البيانات،
              والصف الفاشل يُرفض بسببه ولا يُفسد الناجح.
            </p>

            <div className="flex flex-wrap gap-3 items-end">
              <div>
                <label className="label">نوع البيانات</label>
                <select className="input" value={target}
                        onChange={(e) => setTarget(e.target.value as typeof target)}>
                  {canImportItems && <option value="items">القطع</option>}
                  {canImportCustomers && <option value="customers">العملاء</option>}
                </select>
              </div>
              <button className="btn-secondary"
                      onClick={() => setCsv(CSV_TEMPLATES[target])}>
                إدراج قالب
              </button>
            </div>

            <div>
              <label className="label">محتوى الملف (CSV)</label>
              <textarea
                className="input font-mono text-xs" dir="ltr" rows={8}
                value={csv} onChange={(e) => setCsv(e.target.value)}
              />
            </div>

            <button className="btn-primary" onClick={runImport} disabled={busy || !csv.trim()}>
              {busy ? 'جارٍ الاستيراد…' : 'استيراد'}
            </button>

            {result && (
              <div className="space-y-3">
                <div className="text-sm font-semibold">
                  الإجمالي {result.total} — نجح <span className="text-ok">{result.succeeded}</span>
                  {' '}· رُفض <span className="text-danger">{result.failed}</span>
                </div>
                {result.failed > 0 && (
                  <div className="overflow-x-auto">
                    <table className="table">
                      <thead><tr><th>السطر</th><th>سبب الرفض</th></tr></thead>
                      <tbody>
                        {result.outcomes.filter((o) => !o.ok).map((o) => (
                          <tr key={o.row}>
                            <td className="num">{o.row}</td>
                            <td className="text-danger text-sm">{o.error}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {msg && (
        <p className={`text-sm font-semibold ${msg.type === 'ok' ? 'text-ok' : 'text-danger'}`}>
          {msg.text}
        </p>
      )}
    </div>
  );
}
