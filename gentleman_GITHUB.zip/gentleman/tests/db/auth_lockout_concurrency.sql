-- محاكاة محاولة دخول فاشلة كما تنفّذها auth.service بالضبط
BEGIN;
SELECT pg_sleep(0.1);
DO $$
DECLARE v_attempts int; v_locked timestamptz;
BEGIN
  -- قفل صف المستخدم ثم القراءة داخل القفل
  SELECT failed_attempts, locked_until INTO v_attempts, v_locked
    FROM users WHERE username='admin' FOR UPDATE;

  -- الحساب المقفل لا يزيد عدّاده
  IF v_locked IS NOT NULL AND v_locked > now() THEN RETURN; END IF;

  v_attempts := v_attempts + 1;
  IF v_attempts >= 5 THEN
    UPDATE users SET failed_attempts=v_attempts, locked_until=now() + interval '15 minutes'
     WHERE username='admin';
  ELSE
    UPDATE users SET failed_attempts=v_attempts WHERE username='admin';
  END IF;
END $$;
COMMIT;
