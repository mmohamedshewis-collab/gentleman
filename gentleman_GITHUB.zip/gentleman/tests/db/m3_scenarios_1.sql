\set ON_ERROR_STOP off
\pset pager off
\t on

-- إجراء يحاكي معاملة التأجير كما تنفّذها الخدمة بالضبط
CREATE OR REPLACE FUNCTION do_rental(
  p_item_codes text[], p_customer int, p_price numeric, p_discount numeric,
  p_paid numeric, p_deposit numeric, p_insurance numeric,
  p_start date DEFAULT CURRENT_DATE, p_end date DEFAULT CURRENT_DATE + 1,
  p_fail boolean DEFAULT false
) RETURNS int AS $$
DECLARE
  v_rental int; v_item int; v_status text; v_code text;
  v_subtotal numeric := 0; v_discount numeric := 0; v_net numeric := 0; v_bal numeric;
BEGIN
  -- الخدمة تحسب كل الإجماليات أولًا ثم تُدرج رأس العقد مكتملًا
  v_subtotal := p_price * array_length(p_item_codes,1);
  v_discount := p_discount * array_length(p_item_codes,1);
  v_net := v_subtotal - v_discount;

  INSERT INTO rentals (rental_no, customer_id, rental_date, expected_return_date,
                       subtotal, discount, net_amount, gross_amount, total_due,
                       remaining_amount, deposit_amount, insurance_amount, created_by)
  VALUES ('R-' || nextval('rental_no_seq'), p_customer, p_start, p_end,
          v_subtotal, v_discount, v_net, v_net, v_net, v_net, p_deposit, p_insurance, 1)
  RETURNING id INTO v_rental;

  FOREACH v_code IN ARRAY p_item_codes LOOP
    -- 1) قفل القطعة  2) فحص الحالة
    SELECT id, status::text INTO v_item, v_status
      FROM product_items WHERE item_code = v_code FOR UPDATE;
    IF v_item IS NULL THEN RAISE EXCEPTION 'القطعة % غير موجودة', v_code; END IF;
    IF v_status <> 'AVAILABLE' THEN
      RAISE EXCEPTION 'لا يمكن تأجير القطعة % لأن حالتها %', v_code, v_status;
    END IF;

    INSERT INTO rental_items (rental_id, item_id, unit_rental_price, discount, net_price,
                              gross_amount, insurance_per_item, expected_return_date)
    VALUES (v_rental, v_item, p_price, p_discount, p_price - p_discount,
            p_price - p_discount, p_insurance / array_length(p_item_codes,1), p_end);

    INSERT INTO item_bookings (item_id, start_date, end_date, source_type, source_id)
    VALUES (v_item, p_start, p_end, 'RENTAL', v_rental);

    INSERT INTO item_status_history (item_id, from_status, to_status, reason, ref_type, ref_id, user_id)
    VALUES (v_item, v_status::"ItemStatus", 'RENTED', 'عقد تأجير رقم ' || v_rental, 'Rental', v_rental, 1);

    UPDATE product_items
       SET status = 'RENTED', rental_count = rental_count + 1, last_rental_date = p_start
     WHERE id = v_item;

    INSERT INTO inventory_transactions (item_id, trx_date, type, ref_type, ref_id, created_by)
    VALUES (v_item, p_start, 'RENT_OUT', 'Rental', v_rental, 1);

  END LOOP;

  -- فشل متعمّد بعد إنشاء كل شيء تقريبًا (اختبار التراجع)
  IF p_fail THEN RAISE EXCEPTION 'فشل متعمّد في منتصف العملية'; END IF;

  IF p_paid > 0 THEN
    INSERT INTO payments (payment_no, purpose, rental_id, customer_id, amount, payment_method_id, created_by)
    VALUES ('PAY-' || nextval('payment_no_seq'), 'RENTAL', v_rental, p_customer, p_paid, 1, 1);
  END IF;

  IF p_insurance > 0 THEN
    INSERT INTO payments (payment_no, purpose, is_insurance, rental_id, customer_id, amount, payment_method_id, created_by)
    VALUES ('PAY-' || nextval('payment_no_seq'), 'INSURANCE_COLLECT', true, v_rental, p_customer, p_insurance, 1, 1);
    SELECT COALESCE((SELECT balance_after FROM insurance_transactions ORDER BY id DESC LIMIT 1), 0) INTO v_bal;
    INSERT INTO insurance_transactions (type, customer_id, rental_id, amount, balance_after, payment_method_id, created_by)
    VALUES ('COLLECTED', p_customer, v_rental, p_insurance, v_bal + p_insurance, 1, 1);
  END IF;

  INSERT INTO audit_logs (user_id, action, entity_type, entity_id, after_json)
  VALUES (1, 'rental.create', 'Rental', v_rental::text,
          jsonb_build_object('total_due', v_net, 'insurance', p_insurance, 'paid', p_paid));

  RETURN v_rental;
END;
$$ LANGUAGE plpgsql;

\echo '=== T1: تأجير قطعة متاحة ==='
SELECT 'العقد رقم ' || do_rental(ARRAY['SUIT-0001'], 2, 500, 50, 300, 300, 1000);
SELECT 'الإجمالي=' || total_due || ' المدفوع=' || paid_amount || ' المتبقي=' || remaining_amount
       || ' العربون=' || deposit_amount || ' التأمين=' || insurance_amount FROM rentals WHERE id=1;
SELECT 'حالة القطعة=' || status FROM product_items WHERE item_code='SUIT-0001';

\echo ''
\echo '=== T2: محاولة تأجير قطعة مؤجرة (يجب أن تُرفض) ==='
SELECT do_rental(ARRAY['SUIT-0001'], 2, 500, 0, 0, 0, 0);

\echo ''
\echo '=== T3: محاولة تأجير قطعة متأخرة (يجب أن تُرفض) ==='
SELECT 'تهيئة: العقد ' || do_rental(ARRAY['SUIT-0002'], 2, 500, 0, 0, 0, 0);
UPDATE product_items SET status='OVERDUE' WHERE item_code='SUIT-0002';
SELECT 'حالة القطعة الآن=' || status FROM product_items WHERE item_code='SUIT-0002';
SELECT do_rental(ARRAY['SUIT-0002'], 2, 500, 0, 0, 0, 0);

\echo ''
\echo '=== T4: محاولة تأجير قطعة تالفة (يجب أن تُرفض) ==='
SELECT do_rental(ARRAY['SUIT-0005'], 2, 500, 0, 0, 0, 0);

\echo ''
\echo '=== T5: محاولة تأجير قطعة مباعة (يجب أن تُرفض) ==='
SELECT do_rental(ARRAY['SUIT-0004'], 2, 500, 0, 0, 0, 0);

\echo ''
\echo '=== T6: تأجير أكثر من قطعة في عملية واحدة ==='
CREATE TEMP TABLE t6 AS SELECT do_rental(ARRAY['SUIT-0003','SUIT-0006'], 2, 500, 100, 400, 0, 2000) AS id;
SELECT 'العقد رقم ' || id FROM t6;
SELECT 'عدد السطور=' || count(*) FROM rental_items WHERE rental_id = (SELECT id FROM t6);
SELECT 'الإجمالي=' || total_due || ' (2×500 − 2×100) المدفوع=' || paid_amount || ' المتبقي=' || remaining_amount
  FROM rentals WHERE id = (SELECT id FROM t6);
SELECT 'التأمين=' || insurance_amount || ' ورصيد صندوق التأمين=' ||
       (SELECT balance_after FROM insurance_transactions ORDER BY id DESC LIMIT 1)
  FROM rentals WHERE id = (SELECT id FROM t6);
SELECT 'حالات القطع: ' || string_agg(item_code || '=' || status, ', ') FROM product_items WHERE item_code IN ('SUIT-0003','SUIT-0006');
