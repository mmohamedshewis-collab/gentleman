import { route } from '@/lib/api';
import { runReport, reportQuerySchema } from '@/services/report.service';

export const GET = route({ schema: reportQuerySchema, handler: ({ input }) => runReport(input) });
