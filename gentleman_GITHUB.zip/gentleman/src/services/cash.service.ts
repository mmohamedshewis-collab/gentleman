import { z } from 'zod';
import { Decimal } from 'decimal.js';
import { prisma } from '@/lib/db';
import { Errors } from '@/lib/errors';
import { writeAudit } from '@/lib/audit';
import { requirePermission } from '@/lib/auth/rbac';
import { businessToday, toBusinessDate, formatDate } from '@/lib/date';
import { round2, add, sub } from '@/lib/money';
import { getNumberSetting } from '@/lib/settings';
import {
  MOVEMENT_RULES,
  dashboardMovement, companyCashPosition, insuranceCashBalance, countCash,
  requiredTransferAmount, assertFullTransfer, monthlyReconciliation,
  movementLabel, type CashLine, type CashMovementType,
} from '@/lib/cash/cash-movement';

/**
 * النقدية اليومية.
 * لا رصيد افتتاحي ولا ترحيل رصيد: مركز الشركة رقم **مشتق** من الحركات
 * منذ آخر ترحيل. التأمين رصيد متراكم لا حركة يومية.
 * كل الحسابات مقصورة على النقد (`isCash = true`).
 */

export const dateQuerySchema = z.object({
  date: z.string().optional(),
});

export const countSchema = z.object({
  date: z.string().optional(),
  actualCounted: z.coerce.number().nonnegative('الكاش الفعلي لا يمكن أن يكون سالبًا'),
  notes: z.string().max(500).optional(),
});

export const closeSchema = z.object({
  date: z.string().optional(),
});

export const transferSchema = z.object({
  date: z.string().optional(),
  amount: z.coerce.number().nonnegative(),
  notes: z.string().max(500).optional(),
});

export const monthQuerySchema = z.object({
  from: z.string(),
  to: z.string(),
});

interface MovementRow {
  at: Date;
  type: CashMovementType;
  description: string;
  amount: Decimal;
  refType: string | null;
  refId: number | null;
  userId: number | null;
  userName: string | null;
}

// ============ جمع حركات النقد ليوم واحد ============

async function loadDayMovements(date: Date): Promise<MovementRow[]> {
  const rows: MovementRow[] = [];

  // 1) المدفوعات النقدية غير الملغاة
  const payments = await prisma.payment.findMany({
    where: {
      paymentDate: date,
      isVoided: false,
      paymentMethod: { isCash: true },   // ★ الفيزا والتحويل خارج الدرج
    },
    include: {
      paymentMethod: { select: { nameAr: true } },
      customer: { select: { fullName: true } },
      rental: { select: { rentalNo: true } },
      sale: { select: { invoiceNo: true } },
    },
    orderBy: { id: 'asc' },
  });

  for (const p of payments) {
    let type: CashMovementType;
    if (p.isInsurance) {
      type = p.purpose === 'INSURANCE_REFUND' ? 'INSURANCE_REFUND' : 'INSURANCE_COLLECTION';
    } else if (p.purpose === 'CUSTOMER_REFUND') {
      type = 'CUSTOMER_REFUND';
    } else if (p.purpose === 'RESERVATION_DEPOSIT') {
      // دخول نقدي فقط — ليس إيرادًا
      type = 'RESERVATION_DEPOSIT';
    } else if (p.purpose === 'SALE') {
      type = 'SALE_COLLECTION';
    } else if (p.purpose === 'LATE_FEE' || p.purpose === 'DAMAGE_FEE') {
      type = 'LATE_FEE_COLLECTION';
    } else if (p.purpose === 'RENTAL') {
      type = 'RENTAL_COLLECTION';
    } else {
      // ★ D-2: أي غرض آخر (OTHER) لا يُصنَّف تحصيل تأجير ولا يُعد إيرادًا.
      //   الاتجاه من الدفعة نفسها لا من افتراض.
      type = p.direction === 'OUT' ? 'OTHER_OUT' : 'OTHER_IN';
    }
    rows.push({
      at: p.createdAt,
      type,
      description:
        `${movementLabel(type)} — ${p.customer?.fullName ?? 'عميل نقدي'}` +
        (p.rental ? ` · عقد ${p.rental.rentalNo}` : '') +
        (p.sale ? ` · فاتورة ${p.sale.invoiceNo}` : ''),
      amount: round2(p.amount.toString()),
      refType: p.rental ? 'Rental' : p.sale ? 'Sale' : 'Payment',
      refId: p.rentalId ?? p.saleId ?? p.id,
      userId: p.createdBy,
      userName: null,
    });
  }

  // 2) المصروفات النقدية — الخروج الفعلي قد يقل عن المصروف (خصم سلفة)
  const expenses = await prisma.expense.findMany({
    where: { expenseDate: date, isVoided: false, paymentMethod: { isCash: true } },
    include: { category: { select: { nameAr: true } } },
    orderBy: { id: 'asc' },
  });

  for (const e of expenses) {
    const cashOut = e.cashPaidAmount ?? e.amount;
    if (round2(cashOut.toString()).lte(0)) continue;
    const name = e.category.nameAr;
    const type: CashMovementType =
      name.includes('رواتب') ? 'SALARY_PAYMENT'
      : name.includes('عمولات') ? 'COMMISSION_PAYMENT'
      : 'EXPENSE_PAYMENT';
    rows.push({
      at: e.createdAt,
      type,
      description: `${movementLabel(type)} — ${name}${e.description ? ` · ${e.description}` : ''}`,
      amount: round2(cashOut.toString()),
      refType: 'Expense',
      refId: e.id,
      userId: e.createdBy,
      userName: null,
    });
  }

  // 3) حركات التأمين غير النقدية أو التي لا تمر بالمدفوعات (الاستبقاء)
  const insuranceTrx = await prisma.insuranceTransaction.findMany({
    where: { trxDate: date, isVoided: false },
    orderBy: { id: 'asc' },
  });
  for (const t of insuranceTrx) {
    const isRetained = t.type === 'DEDUCTED_DAMAGE' || t.type === 'DEDUCTED_LOSS';
    const isTransferred = t.type === 'TRANSFERRED_TO_COMPANY';
    // ★ D-1: التحويل الراكد (Q13) بنفس آلية الاستبقاء — كان مفقودًا فأنتج فرقًا وهميًا
    if (!isRetained && !isTransferred) continue;
    const insType = isTransferred ? 'INSURANCE_TRANSFERRED' as const : 'INSURANCE_RETAINED' as const;
    // ★ لا يتحرك نقد ماديًا — تنتقل الملكية من العميل إلى المحل
    rows.push({
      at: t.createdAt,
      type: insType,
      description: `${movementLabel(insType)}${t.reason ? ` · ${t.reason}` : ''}`,
      amount: round2(t.amount.toString()),
      refType: 'Rental',
      refId: t.rentalId,
      userId: t.createdBy,
      userName: null,
    });
  }

  // 4) سلف الموظفين النقدية
  const advances = await prisma.employeeAdvance.findMany({
    where: { advanceDate: date, status: { not: 'CANCELLED' }, paymentMethod: { isCash: true } },
    include: { employee: { select: { fullName: true } } },
    orderBy: { id: 'asc' },
  });
  for (const a of advances) {
    rows.push({
      at: a.createdAt,
      type: 'EMPLOYEE_ADVANCE',
      description: `${movementLabel('EMPLOYEE_ADVANCE')} — ${a.employee.fullName}`,
      amount: round2(a.amount.toString()),
      refType: 'EmployeeAdvance',
      refId: a.id,
      userId: a.createdBy,
      userName: null,
    });
  }

  // 5) سداد السلف نقدًا
  const repayments = await prisma.employeeAdvanceRepayment.findMany({
    where: { repaymentDate: date, method: 'CASH' },
    include: { advance: { include: { employee: { select: { fullName: true } } } } },
    orderBy: { id: 'asc' },
  });
  for (const r of repayments) {
    rows.push({
      at: r.createdAt,
      type: 'ADVANCE_REPAYMENT',
      description: `${movementLabel('ADVANCE_REPAYMENT')} — ${r.advance.employee.fullName}`,
      amount: round2(r.amount.toString()),
      refType: 'EmployeeAdvance',
      refId: r.advanceId,
      userId: r.createdBy,
      userName: null,
    });
  }

  // 6) شراء القطع نقدًا
  const purchases = await prisma.productItem.findMany({
    where: { purchaseDate: date, purchasePaymentMethod: { isCash: true } },
    include: { product: { select: { nameAr: true } } },
    orderBy: { id: 'asc' },
  });
  for (const it of purchases) {
    if (round2(it.purchaseCost.toString()).lte(0)) continue;
    rows.push({
      at: it.createdAt,
      type: 'PRODUCT_PURCHASE',
      description: `${movementLabel('PRODUCT_PURCHASE')} — ${it.product.nameAr} (${it.itemCode})`,
      amount: round2(it.purchaseCost.toString()),
      refType: 'ProductItem',
      refId: it.id,
      userId: null,
      userName: null,
    });
  }

  // 7) الترحيل للخزينة
  const transfers = await prisma.cashTransfer.findMany({
    where: { transferDate: date },
    orderBy: { id: 'asc' },
  });
  for (const t of transfers) {
    rows.push({
      at: t.createdAt,
      type: 'TREASURY_TRANSFER',
      description: `${movementLabel('TREASURY_TRANSFER')} — ${t.transferNo}`,
      amount: round2(t.amount.toString()),
      refType: 'CashTransfer',
      refId: t.id,
      userId: t.transferredBy,
      userName: null,
    });
  }

  return rows.sort((a, b) => a.at.getTime() - b.at.getTime());
}

const toLines = (rows: MovementRow[]): CashLine[] =>
  rows.map((r) => ({ type: r.type, amount: r.amount }));

// ============ صندوق لوحة التحكم ============

/** صافي حركة النقدية اليوم — حركة الشركة وحدها، بلا رصيد افتتاحي وبلا تأمين. */
export async function todayCashMovement(dateStr?: string) {
  await requirePermission('cash.movement.view');
  const date = dateStr ? toBusinessDate(dateStr) : businessToday();
  const rows = await loadDayMovements(date);
  const m = dashboardMovement(toLines(rows));

  return {
    date: formatDate(date),
    inflow: m.inflow.toString(),
    outflow: m.outflow.toString(),
    net: m.net.toString(),
  };
}

// ============ كشف الحركات ============

export async function dayCashStatement(dateStr?: string) {
  await requirePermission('cash.movement.view');
  const date = dateStr ? toBusinessDate(dateStr) : businessToday();
  const rows = await loadDayMovements(date);

  const userIds = [...new Set(rows.map((r) => r.userId).filter((x): x is number => x != null))];
  const users = await prisma.user.findMany({
    where: { id: { in: userIds } },
    select: { id: true, fullName: true },
  });
  const nameById = new Map(users.map((u) => [u.id, u.fullName]));

  const m = dashboardMovement(toLines(rows));

  return {
    date: formatDate(date),
    rows: rows
      .filter((r) => r.type !== 'INSURANCE_RETAINED')   // لا حركة نقدية مادية
      .map((r) => {
        const rule = movementLabel(r.type);
        // ★ D-3: الاتجاه من قاعدة النوع نفسها — لا قائمة يدوية تتخلّف عن التصنيف
        const isIn = MOVEMENT_RULES[r.type].direction === 'IN';
        return {
          at: r.at,
          type: r.type,
          typeLabel: rule,
          description: r.description,
          inflow: isIn ? r.amount.toString() : null,
          outflow: isIn ? null : r.amount.toString(),
          refType: r.refType,
          refId: r.refId,
          userName: r.userId ? nameById.get(r.userId) ?? null : null,
        };
      }),
    totals: {
      inflow: m.inflow.toString(),
      outflow: m.outflow.toString(),
      net: m.net.toString(),
    },
  };
}

// ============ مركز الشركة ورصيد التأمين ============

/** مركز نقدية الشركة — مشتق من الحركات منذ آخر ترحيل. لا يُدخله مستخدم. */
export async function currentCompanyPosition(upToDate: Date): Promise<Decimal> {
  const lastTransfer = await prisma.cashTransfer.findFirst({
    orderBy: { transferDate: 'desc' },
    select: { transferDate: true },
  });

  const days: Date[] = [];
  const start = lastTransfer
    ? new Date(lastTransfer.transferDate.getTime() + 86_400_000)
    : upToDate;
  for (let d = new Date(start); d <= upToDate; d = new Date(d.getTime() + 86_400_000)) {
    days.push(new Date(d));
  }
  if (days.length === 0) days.push(upToDate);

  let all: CashLine[] = [];
  for (const d of days) all = all.concat(toLines(await loadDayMovements(d)));
  return companyCashPosition(all);
}

/** رصيد نقدية التأمين بالمحل — رصيد متراكم لا يُصفَّر ولا يُرحَّل. */
export async function currentInsuranceCashBalance(upToDate: Date): Promise<Decimal> {
  const opening = await getNumberSetting('insurance.opening_balance');

  const cashPayments = await prisma.payment.findMany({
    where: {
      isInsurance: true, isVoided: false,
      paymentMethod: { isCash: true },
      paymentDate: { lte: upToDate },
    },
    select: { amount: true, purpose: true },
  });

  let collected = new Decimal(0);
  let refunded = new Decimal(0);
  for (const p of cashPayments) {
    if (p.purpose === 'INSURANCE_REFUND') refunded = refunded.plus(p.amount.toString());
    else collected = collected.plus(p.amount.toString());
  }

  const trx = await prisma.insuranceTransaction.findMany({
    where: { isVoided: false, trxDate: { lte: upToDate } },
    select: { type: true, amount: true },
  });
  let retained = new Decimal(0);
  let forfeited = new Decimal(0);
  for (const t of trx) {
    if (t.type === 'DEDUCTED_DAMAGE' || t.type === 'DEDUCTED_LOSS') {
      retained = retained.plus(t.amount.toString());
    } else if (t.type === 'TRANSFERRED_TO_COMPANY') {
      forfeited = forfeited.plus(t.amount.toString());
    }
  }

  return insuranceCashBalance({
    openingBalance: opening, collected, refunded, retained, forfeited,
  });
}

// ============ الجرد ============

export async function cashCountPreview(dateStr?: string) {
  await requirePermission('cash.count');
  const date = dateStr ? toBusinessDate(dateStr) : businessToday();

  const [movement, position, insurance, existing] = await Promise.all([
    (async () => dashboardMovement(toLines(await loadDayMovements(date))))(),
    currentCompanyPosition(date),
    currentInsuranceCashBalance(date),
    prisma.dailyCashClosing.findUnique({ where: { businessDate: date } }),
  ]);

  return {
    date: formatDate(date),
    todayMovement: movement.net.toString(),
    companyPosition: position.toString(),
    insuranceCashBalance: insurance.toString(),
    expectedPhysical: add(position, insurance).toString(),
    status: existing?.status ?? 'OPEN',
    actualCounted: existing?.actualCounted?.toString() ?? null,
    variance: existing?.variance?.toString() ?? null,
    countedAt: existing?.countedAt ?? null,
    notes: existing?.notes ?? null,
  };
}

export async function recordCashCount(input: z.infer<typeof countSchema>) {
  const actor = await requirePermission('cash.count');
  const date = input.date ? toBusinessDate(input.date) : businessToday();

  const existing = await prisma.dailyCashClosing.findUnique({ where: { businessDate: date } });
  if (existing?.status === 'CLOSED') {
    throw Errors.rule('اليوم مغلق ولا يمكن تعديل جرده.');
  }

  const [position, insurance] = await Promise.all([
    currentCompanyPosition(date),
    currentInsuranceCashBalance(date),
  ]);

  const result = countCash({
    companyPosition: position,
    insuranceBalance: insurance,
    actualCounted: input.actualCounted,
  });

  return prisma.$transaction(async (tx) => {
    const data = {
      expectedCompanyPosition: result.companyPosition.toString(),
      expectedInsuranceCash: result.insuranceBalance.toString(),
      expectedPhysical: result.expectedPhysical.toString(),
      actualCounted: result.actualCounted.toString(),
      variance: result.variance.toString(),
      countedBy: actor.id,
      countedAt: new Date(),
      notes: input.notes?.trim() || null,
    };

    const row = existing
      ? await tx.dailyCashClosing.update({ where: { id: existing.id }, data })
      : await tx.dailyCashClosing.create({ data: { businessDate: date, ...data } });

    await writeAudit(
      {
        userId: actor.id,
        action: 'cash.count',
        entityType: 'DailyCashClosing',
        entityId: row.id,
        after: { ...data, status: result.status },
        reason: input.notes ?? null,
      },
      tx,
    );

    return { ...result, id: row.id, date: formatDate(date) };
  });
}

// ============ الإغلاق ============

export async function closeDay(input: z.infer<typeof closeSchema>) {
  const actor = await requirePermission('cash.close');
  const date = input.date ? toBusinessDate(input.date) : businessToday();

  return prisma.$transaction(async (tx) => {
    const locked = await tx.$queryRaw<{ id: number; status: string; counted_at: Date | null }[]>`
      SELECT id, status, counted_at FROM daily_cash_closings
       WHERE business_date = ${date} FOR UPDATE
    `;
    if (locked.length === 0) throw Errors.rule('يجب إجراء جرد النقدية قبل إغلاق اليوم.');
    const row = locked[0];
    if (row.status === 'CLOSED') throw Errors.rule('اليوم مغلق بالفعل.');
    if (!row.counted_at) throw Errors.rule('يجب إجراء جرد النقدية قبل إغلاق اليوم.');

    const updated = await tx.dailyCashClosing.update({
      where: { id: row.id },
      data: { status: 'CLOSED', closedBy: actor.id, closedAt: new Date() },
    });

    await writeAudit(
      {
        userId: actor.id,
        action: 'cash.close',
        entityType: 'DailyCashClosing',
        entityId: row.id,
        before: { status: 'OPEN' },
        after: { status: 'CLOSED', variance: updated.variance.toString() },
      },
      tx,
    );

    return {
      id: updated.id,
      date: formatDate(date),
      status: updated.status,
      variance: updated.variance.toString(),
      requiredTransfer: requiredTransferAmount({
        actualCounted: updated.actualCounted.toString(),
        insuranceBalance: updated.expectedInsuranceCash.toString(),
      }).toString(),
    };
  });
}

// ============ الترحيل ============

export async function recordTransfer(input: z.infer<typeof transferSchema>) {
  const actor = await requirePermission('cash.transfer');
  const date = input.date ? toBusinessDate(input.date) : businessToday();

  return prisma.$transaction(async (tx) => {
    const closing = await tx.dailyCashClosing.findUnique({ where: { businessDate: date } });
    if (!closing) throw Errors.rule('لا يوجد جرد لهذا اليوم.');
    if (closing.status !== 'CLOSED') throw Errors.rule('لا يمكن الترحيل قبل إغلاق اليوم.');

    const existing = await tx.cashTransfer.findUnique({ where: { closingId: closing.id } });
    if (existing) throw Errors.conflict('تم ترحيل هذا اليوم بالفعل.');

    // الترحيل الكامل إلزامي: كل كاش الشركة، ولا جنيه من التأمين
    try {
      assertFullTransfer({
        amount: input.amount,
        actualCounted: closing.actualCounted.toString(),
        insuranceBalance: closing.expectedInsuranceCash.toString(),
      });
    } catch (e) {
      throw Errors.rule((e as Error).message);
    }

    await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext('cash_transfer_no'))`;
    const year = date.getUTCFullYear();
    const last = await tx.cashTransfer.findFirst({
      where: { transferNo: { startsWith: `TRF-${year}-` } },
      orderBy: { transferNo: 'desc' },
      select: { transferNo: true },
    });
    const seq = last ? Number.parseInt(last.transferNo.slice(9), 10) + 1 : 1;

    const row = await tx.cashTransfer.create({
      data: {
        transferNo: `TRF-${year}-${String(Number.isFinite(seq) ? seq : 1).padStart(6, '0')}`,
        closingId: closing.id,
        transferDate: date,
        amount: round2(input.amount).toString(),
        transferredBy: actor.id,
        notes: input.notes?.trim() || null,
      },
    });

    await writeAudit(
      {
        userId: actor.id,
        action: 'cash.transfer',
        entityType: 'CashTransfer',
        entityId: row.id,
        after: {
          transferNo: row.transferNo,
          amount: row.amount.toString(),
          // ★ الترحيل لا يمس الفرق
          varianceUnchanged: closing.variance.toString(),
        },
      },
      tx,
    );

    return {
      id: row.id,
      transferNo: row.transferNo,
      amount: row.amount.toString(),
      variance: closing.variance.toString(),
    };
  });
}

// ============ المطابقة الشهرية ============

export async function monthlyTreasuryReconciliation(input: z.infer<typeof monthQuerySchema>) {
  await requirePermission('cash.reconcile.view');
  const from = toBusinessDate(input.from);
  const to = toBusinessDate(input.to);
  if (to < from) throw Errors.rule('نطاق التاريخ غير صحيح.');

  const closings = await prisma.dailyCashClosing.findMany({
    where: { businessDate: { gte: from, lte: to } },
    include: { transfer: true },
    orderBy: { businessDate: 'asc' },
  });

  const days = [];
  for (const c of closings) {
    const rows = await loadDayMovements(c.businessDate);
    const m = dashboardMovement(toLines(rows));
    days.push({
      inflow: m.inflow,
      outflow: m.outflow,
      variance: c.variance.toString(),
      transferred: c.transfer?.amount.toString() ?? 0,
      isClosed: c.status === 'CLOSED',
    });
  }

  const summary = monthlyReconciliation(days);
  const insuranceBalance = await currentInsuranceCashBalance(to);

  return {
    from: input.from,
    to: input.to,
    totalInflow: summary.totalInflow.toString(),
    totalOutflow: summary.totalOutflow.toString(),
    netMovement: summary.netMovement.toString(),
    totalTransferred: summary.totalTransferred.toString(),
    totalVariance: summary.totalVariance.toString(),
    totalShortage: summary.totalShortage.toString(),
    totalSurplus: summary.totalSurplus.toString(),
    notTransferred: summary.notTransferred.toString(),
    closedDays: summary.closedDays,
    openDays: summary.openDays,
    insuranceBalanceAtEnd: insuranceBalance.toString(),
    rows: closings.map((c, i) => ({
      date: formatDate(c.businessDate),
      status: c.status,
      expectedPhysical: c.expectedPhysical.toString(),
      actualCounted: c.actualCounted.toString(),
      variance: c.variance.toString(),
      transferred: c.transfer?.amount.toString() ?? '0',
      inflow: days[i].inflow.toString(),
      outflow: days[i].outflow.toString(),
    })),
  };
}

export const cashSum = (values: Decimal.Value[]) => add(...values);
export const cashDiff = (a: Decimal.Value, b: Decimal.Value) => sub(a, b);
