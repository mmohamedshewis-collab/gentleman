import { describe, it, expect, vi, beforeEach } from 'vitest';

/** اختبارات خدمة التأجير: الصلاحيات، قواعد العمل، الرفض المبكر، سجل التدقيق. */

const auditSpy = vi.fn();
let currentUser: { id: number; employeeId: number | null; permissions: Set<string> };
let items: Record<number, { id: number; status: string; item_code: string }> = {};
let rentalRow: any = null;
let bookings: any[] = [];
let returnedCount = 0;
const created: Record<string, any[]> = {};

const track = (name: string) => vi.fn(async (args: any) => {
  (created[name] ??= []).push(args?.data ?? args);
  return { id: (created[name].length), ...(args?.data ?? {}) };
});

const tx: any = {
  $queryRaw: vi.fn(async (strings: TemplateStringsArray) => {
    const sql = Array.isArray(strings) ? strings.join('') : String(strings);
    if (sql.includes('product_items')) return Object.values(items);
    if (sql.includes('rentals')) return rentalRow ? [rentalRow] : [];
    return [];
  }),
  $executeRaw: vi.fn(async () => 1),
  itemBooking: { findMany: vi.fn(async () => bookings), create: track('booking'), updateMany: vi.fn(async () => ({ count: 1 })) },
  rental: {
    findFirst: vi.fn(async () => null),
    create: vi.fn(async ({ data }: any) => { (created.rental ??= []).push(data); return { id: 1, ...data }; }),
    update: vi.fn(async ({ data }: any) => ({ id: 1, ...data })),
  },
  rentalItem: {
    create: track('rentalItem'),
    findMany: vi.fn(async () => [{ id: 1, itemId: 1, netPrice: '450' }]),
    count: vi.fn(async () => returnedCount),
    updateMany: vi.fn(async () => ({ count: 1 })),
  },
  productItem: { update: track('itemUpdate') },
  itemStatusHistory: { create: track('history') },
  inventoryTransaction: { create: track('inventory') },
  payment: {
    create: vi.fn(async ({ data }: any) => { (created.payment ??= []).push(data); return { id: (created.payment.length), ...data }; }),
    count: vi.fn(async () => 0),
    updateMany: vi.fn(async () => ({ count: 1 })),
  },
  insuranceTransaction: { create: track('insurance'), findFirst: vi.fn(async () => null) },
  employee: { findUnique: vi.fn(async () => ({ rentalCommissionPct: { toString: () => '2' } })) },
};

vi.mock('@/lib/db', () => ({
  prisma: {
    $transaction: (fn: any) => fn(tx),
  customer: { findUnique: vi.fn(async ({ where }: any) => (where.id === 99 ? null : { id: where.id, isActive: where.id !== 50, fullName: 'أحمد محمد' })) },
  },
}));

vi.mock('@/lib/audit', () => ({ writeAudit: (...a: any[]) => auditSpy(...a), redact: (x: any) => x }));

vi.mock('@/lib/settings', () => ({
  getNumberSetting: async (k: string) => {
    const { Decimal } = await import('decimal.js');
    if (k === 'rental.default_days') return new Decimal(1);
    if (k === 'discount.staff_max_percent') return new Decimal(10);
    return new Decimal(0);
  },
  getBoolSetting: async () => false,
}));

vi.mock('@/lib/auth/rbac', async (importOriginal) => {
  const actual = await importOriginal<typeof import('@/lib/auth/rbac')>();
  return {
    ...actual,
    requirePermission: async (perm: string) => {
      if (!currentUser.permissions.has(perm)) {
        const { Errors } = await import('@/lib/errors');
        throw Errors.forbidden(perm);
      }
      return currentUser as never;
    },
  };
});

const base = { customerId: 1, paymentMethodId: 1 };
const asStaff = () => { currentUser = { id: 9, employeeId: 3, permissions: new Set(['rentals.create', 'rentals.view', 'payments.create']) }; };
const asAdmin = () => { currentUser = { id: 1, employeeId: 1, permissions: new Set(['rentals.create', 'rentals.view', 'rentals.void', 'payments.create', 'discount.override']) }; };

beforeEach(() => {
  auditSpy.mockClear();
  for (const k of Object.keys(created)) delete created[k];
  items = { 1: { id: 1, status: 'AVAILABLE', item_code: 'SUIT-0001' } };
  bookings = []; returnedCount = 0;
  rentalRow = { id: 1, status: 'ACTIVE', rental_no: 'R-2026-000001', insurance_amount: '1000', customer_id: 1, total_due: '450', paid_amount: '300' };
  asStaff();
});

describe('إنشاء عقد تأجير', () => {
  it('ينشئ العقد والسطر والحجز ويحدّث الحالة ويسجّل التدقيق', async () => {
    const { createRental } = await import('@/services/rental.service');
    const r = await createRental({
      ...base, items: [{ itemId: 1, unitRentalPrice: 500, discount: 50, insurancePerItem: 1000 }],
      paidAmount: 300,
    } as never);

    expect(r.totalDue).toBe('450');
    expect(r.remainingAmount).toBe('150');
    expect(r.insuranceAmount).toBe('1000');
    expect(created.rentalItem).toHaveLength(1);
    expect(created.booking).toHaveLength(1);
    expect(created.itemUpdate[0].status).toBe('RENTED');
    expect(created.history).toHaveLength(1);
    expect(created.inventory).toHaveLength(1);
    expect(auditSpy.mock.calls[0][0]).toMatchObject({ action: 'rental.create', entityType: 'Rental' });
  });

  it('★ يفصل دفعة الإيجار عن دفعة التأمين', async () => {
    const { createRental } = await import('@/services/rental.service');
    await createRental({
      ...base, items: [{ itemId: 1, unitRentalPrice: 500, insurancePerItem: 1000 }], paidAmount: 500,
    } as never);

    const rentalPay = created.payment.filter((p: any) => !p.isInsurance);
    const insurancePay = created.payment.filter((p: any) => p.isInsurance);
    expect(rentalPay).toHaveLength(1);
    expect(rentalPay[0]).toMatchObject({ purpose: 'RENTAL', amount: '500' });
    expect(insurancePay).toHaveLength(1);
    expect(insurancePay[0]).toMatchObject({ purpose: 'INSURANCE_COLLECT', amount: '1000' });
    // العقد نفسه يُنشأ بمدفوع صفر — Trigger القاعدة هو من يزامنه من الدفعات
    expect(created.rental[0]).toMatchObject({ paidAmount: '0', totalDue: '500' });
  });

  it('★ التأمين لا يدخل إجمالي العقد', async () => {
    const { createRental } = await import('@/services/rental.service');
    await createRental({
      ...base, items: [{ itemId: 1, unitRentalPrice: 500, insurancePerItem: 9000 }], paidAmount: 0,
    } as never);
    expect(created.rental[0].totalDue).toBe('500');
    expect(created.rental[0].insuranceAmount).toBe('9000');
  });

  it('يرفض تأجير قطعة غير متاحة بعد القفل', async () => {
    items[1].status = 'RENTED';
    const { createRental } = await import('@/services/rental.service');
    await expect(createRental({ ...base, items: [{ itemId: 1, unitRentalPrice: 500 }] } as never))
      .rejects.toMatchObject({ code: 'BUSINESS_RULE' });
    expect(created.rental).toBeUndefined();
  });

  it('يرفض التعارض مع حجز قائم', async () => {
    bookings = [{ itemId: 1, startDate: new Date('2026-10-10'), endDate: new Date('2026-10-12'), sourceType: 'RESERVATION' }];
    const { createRental } = await import('@/services/rental.service');
    await expect(createRental({ ...base, items: [{ itemId: 1, unitRentalPrice: 500 }] } as never))
      .rejects.toMatchObject({ code: 'CONFLICT' });
    expect(created.rental).toBeUndefined();
  });

  it('يرفض خصمًا فوق حد الموظف بلا صلاحية', async () => {
    const { createRental } = await import('@/services/rental.service');
    await expect(createRental({
      ...base, items: [{ itemId: 1, unitRentalPrice: 1000, discount: 500 }],
    } as never)).rejects.toMatchObject({ code: 'PERM_DENIED', details: { permission: 'discount.override' } });
  });

  it('المدير يستطيع تجاوز حد الخصم', async () => {
    asAdmin();
    const { createRental } = await import('@/services/rental.service');
    const r = await createRental({
      ...base, items: [{ itemId: 1, unitRentalPrice: 1000, discount: 500 }],
    } as never);
    expect(r.totalDue).toBe('500');
  });

  it('يرفض الإنشاء بلا صلاحية', async () => {
    currentUser = { id: 7, employeeId: null, permissions: new Set(['rentals.view']) };
    const { createRental } = await import('@/services/rental.service');
    await expect(createRental({ ...base, items: [{ itemId: 1, unitRentalPrice: 500 }] } as never))
      .rejects.toMatchObject({ code: 'PERM_DENIED' });
  });

  it('يرفض عميلًا معطّلًا أو غير موجود', async () => {
    const { createRental } = await import('@/services/rental.service');
    await expect(createRental({ ...base, customerId: 99, items: [{ itemId: 1, unitRentalPrice: 500 }] } as never))
      .rejects.toMatchObject({ code: 'NOT_FOUND' });
    await expect(createRental({ ...base, customerId: 50, items: [{ itemId: 1, unitRentalPrice: 500 }] } as never))
      .rejects.toMatchObject({ code: 'BUSINESS_RULE' });
  });

  it('يرفض تحصيل مبلغ بلا طريقة دفع', async () => {
    const { createRental } = await import('@/services/rental.service');
    await expect(createRental({
      customerId: 1, items: [{ itemId: 1, unitRentalPrice: 500 }], paidAmount: 200,
    } as never)).rejects.toMatchObject({ code: 'BUSINESS_RULE' });
  });

  it('يرفض تاريخ إرجاع يسبق تاريخ التأجير', async () => {
    const { createRental } = await import('@/services/rental.service');
    await expect(createRental({
      ...base, rentalDate: '2026-08-10', expectedReturnDate: '2026-08-05',
      items: [{ itemId: 1, unitRentalPrice: 500 }],
    } as never)).rejects.toMatchObject({ code: 'BUSINESS_RULE' });
  });

  it('الرفض المبكر لا يلمس قاعدة البيانات إطلاقًا', async () => {
    const { createRental } = await import('@/services/rental.service');
    await expect(createRental({
      ...base, items: [{ itemId: 1, unitRentalPrice: 500, discount: 900 }],
    } as never)).rejects.toThrow();
    expect(created.rental).toBeUndefined();
    expect(created.payment).toBeUndefined();
    expect(auditSpy).not.toHaveBeenCalled();
  });
});

describe('إلغاء العقد', () => {
  it('يرفض الإلغاء بلا صلاحية مدير', async () => {
    const { voidRental } = await import('@/services/rental.service');
    await expect(voidRental({ rentalId: 1, reason: 'العميل اعتذر' }))
      .rejects.toMatchObject({ code: 'PERM_DENIED', details: { permission: 'rentals.void' } });
  });

  it('يعيد القطع ويحرّر الحجز ويلغي الدفعات ويرد التأمين ويسجّل', async () => {
    asAdmin();
    const { voidRental } = await import('@/services/rental.service');
    const r = await voidRental({ rentalId: 1, reason: 'العميل اعتذر' });

    expect(r.status).toBe('VOIDED');
    expect(tx.itemBooking.updateMany).toHaveBeenCalled();
    expect(tx.payment.updateMany).toHaveBeenCalledWith(
      expect.objectContaining({ data: expect.objectContaining({ isVoided: true }) }),
    );
    expect(created.insurance[0]).toMatchObject({ type: 'REFUNDED', amount: '1000' });
    expect(auditSpy.mock.calls[0][0]).toMatchObject({
      action: 'rental.void', reason: 'العميل اعتذر', after: { status: 'VOIDED' },
    });
  });

  it('يرفض إلغاء عقد أُرجعت منه قطعة', async () => {
    asAdmin(); returnedCount = 1;
    const { voidRental } = await import('@/services/rental.service');
    await expect(voidRental({ rentalId: 1, reason: 'محاولة' }))
      .rejects.toMatchObject({ code: 'BUSINESS_RULE' });
  });

  it('يرفض إلغاء عقد ملغى أو مغلق', async () => {
    asAdmin();
    const { voidRental } = await import('@/services/rental.service');
    for (const st of ['VOIDED', 'CLOSED']) {
      rentalRow = { ...rentalRow, status: st };
      await expect(voidRental({ rentalId: 1, reason: 'محاولة' }))
        .rejects.toMatchObject({ code: 'BUSINESS_RULE' });
    }
  });

  it('يرفض الإلغاء بلا سبب', async () => {
    const { voidRentalSchema } = await import('@/services/rental.service');
    expect(voidRentalSchema.safeParse({ rentalId: 1 }).success).toBe(false);
    expect(voidRentalSchema.safeParse({ rentalId: 1, reason: '' }).success).toBe(false);
    expect(voidRentalSchema.safeParse({ rentalId: 1, reason: 'اعتذار' }).success).toBe(true);
  });
});

describe('الدفعات', () => {
  it('يرفض دفعة تتجاوز المتبقي', async () => {
    const { addRentalPayment } = await import('@/services/rental.service');
    await expect(addRentalPayment({ rentalId: 1, amount: 500, paymentMethodId: 1 }))
      .rejects.toMatchObject({ code: 'BUSINESS_RULE' });
  });

  it('يقبل دفعة ضمن المتبقي ويسجّلها', async () => {
    const { addRentalPayment } = await import('@/services/rental.service');
    const r = await addRentalPayment({ rentalId: 1, amount: 150, paymentMethodId: 1 });
    expect(r.amount).toBe('150');
    expect(created.payment[0]).toMatchObject({ purpose: 'RENTAL', isInsurance: false });
    expect(auditSpy.mock.calls[0][0]).toMatchObject({ action: 'rental.payment' });
  });

  it('يرفض دفعة على عقد ملغى', async () => {
    const { addRentalPayment } = await import('@/services/rental.service');
    rentalRow = { ...rentalRow, status: 'VOIDED' };
    await expect(addRentalPayment({ rentalId: 1, amount: 100, paymentMethodId: 1 }))
      .rejects.toMatchObject({ code: 'BUSINESS_RULE' });
  });

  it('يقبل دفعة على عقد مغلق عليه مستحق من غرامات الإرجاع', async () => {
    const { addRentalPayment } = await import('@/services/rental.service');
    rentalRow = { ...rentalRow, status: 'CLOSED', total_due: '1000', paid_amount: '500' };
    await expect(addRentalPayment({ rentalId: 1, amount: 500, paymentMethodId: 1 }))
      .resolves.toBeTruthy();
  });
});
