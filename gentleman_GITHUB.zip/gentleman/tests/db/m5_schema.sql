CREATE TYPE "ItemStatus" AS ENUM ('AVAILABLE','RENTED','OVERDUE','RESERVED','SOLD','DAMAGED','LOST','CLEANING','MAINTENANCE','DISPOSED');
CREATE TYPE "RentalStatus" AS ENUM ('ACTIVE','PARTIALLY_RETURNED','CLOSED','VOIDED');
CREATE TYPE "RentalItemStatus" AS ENUM ('OUT','RETURNED','LOST','VOIDED');
CREATE TYPE "SaleStatus" AS ENUM ('COMPLETED','VOIDED');
CREATE TYPE "BookingSource" AS ENUM ('RESERVATION','RENTAL');
CREATE TYPE "PaymentDirection" AS ENUM ('IN','OUT');
CREATE TYPE "PaymentPurpose" AS ENUM ('RENTAL','SALE','LATE_FEE','DAMAGE_FEE','RESERVATION_DEPOSIT','INSURANCE_COLLECT','INSURANCE_REFUND','OTHER');
CREATE TYPE "InsuranceTrxType" AS ENUM ('COLLECTED','REFUNDED','DEDUCTED_DAMAGE','DEDUCTED_LOSS','TRANSFERRED_TO_COMPANY');
CREATE TYPE "InventoryTrxType" AS ENUM ('PURCHASE','RENT_OUT','RETURN_IN','SALE','WRITE_OFF','FOUND','ADJUST');
CREATE TYPE "ItemCondition" AS ENUM ('GOOD','DAMAGED','LOST');
CREATE TYPE "VatStatus" AS ENUM ('NOT_APPLICABLE','STANDARD','ZERO_RATED','EXEMPT');

CREATE TABLE customers (id serial PRIMARY KEY, code text UNIQUE NOT NULL, full_name text NOT NULL,
  phone text UNIQUE, national_id text, notes text, is_walk_in boolean DEFAULT false, is_active boolean DEFAULT true);
CREATE TABLE products (id serial PRIMARY KEY, code text UNIQUE, name_ar text,
  sale_price numeric(12,2) DEFAULT 0, rental_price numeric(12,2) DEFAULT 0, default_cost numeric(12,2) DEFAULT 0);
CREATE TABLE product_items (id serial PRIMARY KEY, item_code text UNIQUE NOT NULL, barcode text UNIQUE NOT NULL,
  product_id int REFERENCES products(id), status "ItemStatus" DEFAULT 'AVAILABLE',
  purchase_cost numeric(12,2) DEFAULT 0, rental_price numeric(12,2), sale_price numeric(12,2),
  rental_count int DEFAULT 0, total_rental_revenue numeric(12,2) DEFAULT 0,
  total_fees_revenue numeric(12,2) DEFAULT 0, total_maintenance_cost numeric(12,2) DEFAULT 0,
  last_rental_date date, last_return_date date, is_active boolean DEFAULT true, disposed_at timestamptz);
CREATE TABLE item_status_history (id serial PRIMARY KEY, item_id int, from_status "ItemStatus",
  to_status "ItemStatus", reason text, ref_type text, ref_id int, user_id int, created_at timestamptz DEFAULT now());
CREATE TABLE inventory_transactions (id serial PRIMARY KEY, item_id int, trx_date date,
  type "InventoryTrxType", ref_type text, ref_id int, note text, created_by int);
CREATE TABLE item_bookings (id serial PRIMARY KEY, item_id int, start_date date, end_date date,
  source_type "BookingSource", source_id int, is_active boolean DEFAULT true, created_by int);
CREATE TABLE reservations (id serial PRIMARY KEY, pickup_date date, return_date date);
CREATE TABLE rentals (id serial PRIMARY KEY, rental_no text UNIQUE NOT NULL, customer_id int REFERENCES customers(id),
  employee_id int, rental_date date, expected_return_date date,
  subtotal numeric(12,2) DEFAULT 0, discount numeric(12,2) DEFAULT 0, net_amount numeric(12,2) DEFAULT 0,
  vat_status "VatStatus" DEFAULT 'NOT_APPLICABLE', vat_rate numeric(5,2), vat_amount numeric(12,2) DEFAULT 0,
  gross_amount numeric(12,2) DEFAULT 0, extra_charges numeric(12,2) DEFAULT 0, total_due numeric(12,2) DEFAULT 0,
  deposit_amount numeric(12,2) DEFAULT 0, paid_amount numeric(12,2) DEFAULT 0, remaining_amount numeric(12,2) DEFAULT 0,
  insurance_amount numeric(12,2) DEFAULT 0, status "RentalStatus" DEFAULT 'ACTIVE',
  void_reason text, voided_by int, voided_at timestamptz, notes text, created_by int);
CREATE TABLE rental_items (id serial PRIMARY KEY, rental_id int REFERENCES rentals(id), item_id int REFERENCES product_items(id),
  unit_rental_price numeric(12,2) DEFAULT 0, discount numeric(12,2) DEFAULT 0, net_price numeric(12,2) DEFAULT 0,
  vat_status "VatStatus" DEFAULT 'NOT_APPLICABLE', vat_rate numeric(5,2), vat_amount numeric(12,2) DEFAULT 0,
  gross_amount numeric(12,2) DEFAULT 0, insurance_per_item numeric(12,2) DEFAULT 0,
  expected_return_date date, status "RentalItemStatus" DEFAULT 'OUT', UNIQUE (rental_id, item_id));
CREATE TABLE returns (id serial PRIMARY KEY, rental_id int, return_date date);
CREATE TABLE return_items (id serial PRIMARY KEY, days_late int DEFAULT 0, late_fee numeric(12,2) DEFAULT 0,
  damage_fee numeric(12,2) DEFAULT 0, loss_fee numeric(12,2) DEFAULT 0, insurance_used numeric(12,2) DEFAULT 0,
  insurance_refunded numeric(12,2) DEFAULT 0, extra_due_from_customer numeric(12,2) DEFAULT 0);
CREATE TABLE sales (id serial PRIMARY KEY, subtotal numeric(12,2) DEFAULT 0, discount numeric(12,2) DEFAULT 0,
  net_amount numeric(12,2) DEFAULT 0, vat_status "VatStatus" DEFAULT 'NOT_APPLICABLE', vat_rate numeric(5,2),
  vat_amount numeric(12,2) DEFAULT 0, gross_amount numeric(12,2) DEFAULT 0, paid_amount numeric(12,2) DEFAULT 0,
  status "SaleStatus" DEFAULT 'COMPLETED');
CREATE TABLE sale_items (id serial PRIMARY KEY, sale_id int REFERENCES sales(id), item_id int REFERENCES product_items(id), unit_price numeric(12,2) DEFAULT 0, discount numeric(12,2) DEFAULT 0, net_price numeric(12,2) DEFAULT 0, gross_amount numeric(12,2) DEFAULT 0, purchase_cost numeric(12,2) DEFAULT 0, pre_sale_status "ItemStatus" DEFAULT 'AVAILABLE', is_damaged_sale boolean DEFAULT false,
  vat_status "VatStatus" DEFAULT 'NOT_APPLICABLE', vat_rate numeric(5,2), vat_amount numeric(12,2) DEFAULT 0);
CREATE TABLE payment_methods (id serial PRIMARY KEY, name_ar text UNIQUE, is_cash boolean DEFAULT true, is_active boolean DEFAULT true);
CREATE TABLE payments (id serial PRIMARY KEY, payment_no text UNIQUE NOT NULL, payment_date date DEFAULT CURRENT_DATE,
  direction "PaymentDirection" DEFAULT 'IN', purpose "PaymentPurpose", is_insurance boolean DEFAULT false,
  customer_id int, rental_id int REFERENCES rentals(id), sale_id int, reservation_id int,
  amount numeric(12,2), payment_method_id int REFERENCES payment_methods(id),
  is_voided boolean DEFAULT false, void_reason text, notes text, created_by int);
CREATE TABLE insurance_transactions (id serial PRIMARY KEY, trx_date date DEFAULT CURRENT_DATE, type "InsuranceTrxType",
  customer_id int, rental_id int, payment_id int, payment_method_id int, amount numeric(12,2),
  balance_after numeric(12,2) DEFAULT 0, reason text, approved_by int, is_voided boolean DEFAULT false, created_by int);
CREATE TABLE expenses (id serial PRIMARY KEY, amount numeric(12,2));
CREATE TABLE audit_logs (id serial PRIMARY KEY, user_id int, action text, entity_type text, entity_id text,
  before_json jsonb, after_json jsonb, reason text, created_at timestamptz DEFAULT now());

CREATE SEQUENCE IF NOT EXISTS rental_no_seq;
CREATE SEQUENCE IF NOT EXISTS payment_no_seq;

INSERT INTO payment_methods (name_ar) VALUES ('نقدي');
INSERT INTO customers (code, full_name, is_walk_in) VALUES ('WALKIN','عميل نقدي', true);
INSERT INTO customers (code, full_name, phone) VALUES ('C-000001','أحمد محمد','01012345678');
INSERT INTO products (code, name_ar, rental_price) VALUES ('P1','بدلة كلاسيك أسود', 500);
INSERT INTO product_items (item_code, barcode, product_id, purchase_cost) VALUES
 ('SUIT-0001','SUIT-0001',1,6000), ('SUIT-0002','SUIT-0002',1,6000),
 ('SUIT-0003','SUIT-0003',1,6000), ('SUIT-0004','SUIT-0004',1,6000),
 ('SUIT-0005','SUIT-0005',1,6000), ('SUIT-0006','SUIT-0006',1,6000);
UPDATE product_items SET status='SOLD'    WHERE item_code='SUIT-0004';
UPDATE product_items SET status='DAMAGED' WHERE item_code='SUIT-0005';
DROP TABLE IF EXISTS return_items;
DROP TABLE IF EXISTS returns;
CREATE TABLE returns (id serial PRIMARY KEY, return_no text UNIQUE NOT NULL, rental_id int REFERENCES rentals(id),
  return_date date, employee_id int, notes text, is_voided boolean DEFAULT false,
  void_reason text, voided_by int, voided_at timestamptz, created_by int);
CREATE TABLE return_items (id serial PRIMARY KEY, return_id int REFERENCES returns(id),
  rental_item_id int REFERENCES rental_items(id), item_id int REFERENCES product_items(id),
  actual_return_date date, days_late int DEFAULT 0, late_fee numeric(12,2) DEFAULT 0,
  condition "ItemCondition" DEFAULT 'GOOD', damage_description text,
  damage_fee numeric(12,2) DEFAULT 0, loss_fee numeric(12,2) DEFAULT 0,
  insurance_used numeric(12,2) DEFAULT 0, insurance_refunded numeric(12,2) DEFAULT 0,
  extra_due_from_customer numeric(12,2) DEFAULT 0);
CREATE SEQUENCE IF NOT EXISTS return_no_seq;
ALTER TABLE sales ADD COLUMN IF NOT EXISTS invoice_no text UNIQUE;
ALTER TABLE sales ADD COLUMN IF NOT EXISTS customer_id int REFERENCES customers(id);
ALTER TABLE sales ADD COLUMN IF NOT EXISTS sale_date date DEFAULT CURRENT_DATE;
ALTER TABLE sales ADD COLUMN IF NOT EXISTS total_cost numeric(12,2) DEFAULT 0;
ALTER TABLE sales ADD COLUMN IF NOT EXISTS void_reason text;
ALTER TABLE sales ADD COLUMN IF NOT EXISTS voided_by int;
ALTER TABLE sales ADD COLUMN IF NOT EXISTS voided_at timestamptz;
ALTER TABLE sales ADD COLUMN IF NOT EXISTS created_by int;
CREATE SEQUENCE IF NOT EXISTS invoice_no_seq;
