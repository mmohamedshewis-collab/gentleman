/**
 * بيانات التأسيس — M0
 * تُشغَّل مرة واحدة: npm run db:seed
 * آمنة للتكرار (idempotent): لا تُنشئ نسخًا مكررة ولا تعيد تعيين قيم مُعدَّلة.
 */
import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';
import { PERMISSIONS, ROLE_DEFS } from '../src/lib/auth/permissions';
import { SETTING_DEFS } from '../src/lib/settings.defs';

const prisma = new PrismaClient();

async function main() {
  console.log('— بدء التأسيس —');

  // 1) الصلاحيات
  for (const p of PERMISSIONS) {
    await prisma.permission.upsert({
      where: { code: p.code },
      update: { nameAr: p.nameAr, module: p.module },
      create: { code: p.code, nameAr: p.nameAr, module: p.module },
    });
  }
  console.log(`الصلاحيات: ${PERMISSIONS.length}`);

  // 2) الأدوار وربط صلاحياتها
  for (const r of ROLE_DEFS) {
    const role = await prisma.role.upsert({
      where: { code: r.code },
      update: { nameAr: r.nameAr },
      create: { code: r.code, nameAr: r.nameAr, isSystem: true },
    });

    const perms = await prisma.permission.findMany({
      where: { code: { in: [...r.permissions] } },
      select: { id: true },
    });

    // إعادة ضبط صلاحيات الأدوار النظامية لتطابق الكتالوج المعتمد
    await prisma.rolePermission.deleteMany({ where: { roleId: role.id } });
    await prisma.rolePermission.createMany({
      data: perms.map((p) => ({ roleId: role.id, permissionId: p.id })),
      skipDuplicates: true,
    });
    console.log(`الدور ${r.nameAr}: ${perms.length} صلاحية`);
  }

  // 3) الإعدادات الافتراضية (لا تُكتب فوق قيمة معدَّلة)
  for (const s of SETTING_DEFS) {
    await prisma.setting.upsert({
      where: { key: s.key },
      update: { nameAr: s.nameAr, group: s.group, dataType: s.dataType },
      create: {
        key: s.key,
        nameAr: s.nameAr,
        group: s.group,
        dataType: s.dataType,
        valueJson: s.value as never,
      },
    });
  }
  console.log(`الإعدادات: ${SETTING_DEFS.length}`);

  // 4) طرق الدفع
  const methods = [
    { nameAr: 'نقدي', isCash: true },
    { nameAr: 'بطاقة', isCash: false },
    { nameAr: 'تحويل بنكي', isCash: false },
    { nameAr: 'محفظة إلكترونية', isCash: false },
  ];
  for (const m of methods) {
    await prisma.paymentMethod.upsert({
      where: { nameAr: m.nameAr },
      update: { isCash: m.isCash },
      create: { nameAr: m.nameAr, isCash: m.isCash },
    });
  }
  console.log(`طرق الدفع: ${methods.length}`);

  // 5) فئات المصروفات
  const expenseCategories = [
    'إيجار', 'كهرباء', 'إنترنت', 'تنظيف', 'صيانة',
    'رواتب', 'عمولات', 'أكياس وشماعات', 'تسويق', 'مصروفات أخرى',
  ];
  for (const nameAr of expenseCategories) {
    await prisma.expenseCategory.upsert({
      where: { nameAr }, update: {}, create: { nameAr },
    });
  }
  console.log(`فئات المصروفات: ${expenseCategories.length}`);

  // 6) العميل النقدي
  await prisma.customer.upsert({
    where: { code: 'WALKIN' },
    update: {},
    create: { code: 'WALKIN', fullName: 'عميل نقدي', isWalkIn: true },
  });
  console.log('العميل النقدي: جاهز');

  // 7) مستخدم المدير
  const adminRole = await prisma.role.findUniqueOrThrow({ where: { code: 'ADMIN' } });
  const username = process.env.SEED_ADMIN_USERNAME || 'admin';
  const password = process.env.SEED_ADMIN_PASSWORD;

  const existing = await prisma.user.findUnique({ where: { username } });
  if (!existing) {
    if (!password) {
      throw new Error(
        'SEED_ADMIN_PASSWORD غير محددة في .env — لن يُنشأ حساب المدير بكلمة مرور افتراضية.',
      );
    }
    await prisma.user.create({
      data: {
        username,
        fullName: 'مدير النظام',
        passwordHash: await bcrypt.hash(password, 12),
        roleId: adminRole.id,
      },
    });
    console.log(`تم إنشاء حساب المدير: ${username}`);
    console.log('⚠️  غيّر كلمة المرور فور أول تسجيل دخول.');
  } else {
    console.log(`حساب المدير موجود مسبقًا: ${username}`);
  }

  console.log('— اكتمل التأسيس —');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
