import { queryAuditLogs } from '@/services/audit.service';
import { formatDateTime } from '@/lib/date';

export const dynamic = 'force-dynamic';

export default async function AuditPage() {
  const { rows, total } = await queryAuditLogs({ page: 1, pageSize: 50 });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="section-title">سجل التدقيق</h1>
        <p className="text-sm text-slate-600 mt-1">
          إجمالي العمليات المسجلة: <span className="num">{total}</span> — لا يمكن حذف أي سطر منه.
        </p>
      </div>

      <div className="card overflow-hidden">
        <div className="card-header">آخر 50 عملية</div>
        <div className="overflow-x-auto">
          <table className="table">
            <thead>
              <tr><th>التاريخ والوقت</th><th>المستخدم</th><th>العملية</th><th>الكيان</th><th>المرجع</th><th>السبب</th></tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.id}>
                  <td className="num">{formatDateTime(r.createdAt)}</td>
                  <td>{r.user?.fullName ?? '—'}</td>
                  <td className="num">{r.action}</td>
                  <td className="num">{r.entityType}</td>
                  <td className="num">{r.entityId ?? '—'}</td>
                  <td>{r.reason ?? '—'}</td>
                </tr>
              ))}
              {rows.length === 0 && (
                <tr><td colSpan={6} className="text-center text-slate-500 py-6">لا توجد سجلات بعد.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
