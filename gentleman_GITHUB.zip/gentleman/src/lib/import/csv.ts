/** تحليل CSV — منطق خالص بلا اعتماد على قاعدة البيانات. */

export const MAX_IMPORT_ROWS = 500;

export interface ParseResult {
  rows: Record<string, string>[];
  error?: string;
}

/** يفصل سطرًا مراعيًا الاقتباس المزدوج. */
function splitLine(line: string): string[] {
  const out: string[] = [];
  let cur = '';
  let inQuotes = false;

  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') {
      if (inQuotes && line[i + 1] === '"') { cur += '"'; i++; }
      else inQuotes = !inQuotes;
    } else if (ch === ',' && !inQuotes) {
      out.push(cur.trim());
      cur = '';
    } else {
      cur += ch;
    }
  }
  out.push(cur.trim());
  return out;
}

/**
 * يحلّل CSV ويتحقق من وجود الأعمدة المطلوبة.
 * يتجاهل الأسطر الفارغة ويزيل علامة BOM.
 */
export function parseCsv(text: string, requiredColumns: string[]): ParseResult {
  const clean = text.replace(/^\uFEFF/, '').trim();
  if (!clean) return { rows: [], error: 'الملف فارغ.' };

  const lines = clean.split(/\r?\n/).filter((l) => l.trim() !== '');
  if (lines.length < 2) return { rows: [], error: 'الملف لا يحتوي على بيانات بعد رؤوس الأعمدة.' };

  const headers = splitLine(lines[0]);
  const missing = requiredColumns.filter((c) => !headers.includes(c));
  if (missing.length > 0) {
    return { rows: [], error: `أعمدة مطلوبة غير موجودة: ${missing.join('، ')}` };
  }

  const rows: Record<string, string>[] = [];
  for (const line of lines.slice(1)) {
    const values = splitLine(line);
    const row: Record<string, string> = {};
    headers.forEach((h, i) => { row[h] = values[i] ?? ''; });
    rows.push(row);
  }

  return { rows };
}

/** قوالب جاهزة تُعرض للمستخدم. */
export const CSV_TEMPLATES = {
  items: 'productId,quantity,codePrefix,purchaseCost,barcode\n1,5,SUIT,6000,\n',
  customers: 'fullName,phone,nationalId,notes\nأحمد محمد,01012345678,,\n',
};
