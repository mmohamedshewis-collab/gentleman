\set ON_ERROR_STOP off
\pset pager off
\t on

-- محاكاة معاملة الإرجاع كما تنفّذها الخدمة
CREATE OR REPLACE FUNCTION do_return(
  p_rental int, p_item_code text, p_condition text,
  p_late_fee numeric, p_damage numeric, p_loss numeric,
  p_return_date date DEFAULT CURRENT_DATE, p_cleaning boolean DEFAULT false,
  p_fail boolean DEFAULT false
) RETURNS int AS $$
DECLARE
  v_ret int; v_ri int; v_item int; v_due date; v_days int;
  v_ins numeric; v_charges numeric; v_used numeric; v_refund numeric; v_extra numeric;
  v_bal numeric; v_new_status text; v_open int;
BEGIN
  PERFORM 1 FROM rentals WHERE id = p_rental FOR UPDATE;
  IF (SELECT status::text FROM rentals WHERE id = p_rental) NOT IN ('ACTIVE','PARTIALLY_RETURNED') THEN
    RAISE EXCEPTION 'لا يمكن الإرجاع لعقد حالته %', (SELECT status FROM rentals WHERE id=p_rental);
  END IF;

  SELECT ri.id, ri.item_id, ri.expected_return_date, ri.insurance_per_item
    INTO v_ri, v_item, v_due, v_ins
    FROM rental_items ri JOIN product_items pi ON pi.id = ri.item_id
   WHERE ri.rental_id = p_rental AND pi.item_code = p_item_code AND ri.status = 'OUT'
   FOR UPDATE OF ri;
  IF v_ri IS NULL THEN RAISE EXCEPTION 'لا يوجد سطر مفتوح لهذه القطعة في العقد'; END IF;

  v_days := GREATEST(0, p_return_date - v_due);
  v_charges := p_late_fee + p_damage + p_loss;
  v_used := LEAST(v_charges, v_ins);
  v_refund := v_ins - v_used;
  v_extra := v_charges - v_used;

  INSERT INTO returns (return_no, rental_id, return_date, created_by)
  VALUES ('RET-' || nextval('return_no_seq'), p_rental, p_return_date, 1) RETURNING id INTO v_ret;

  INSERT INTO return_items (return_id, rental_item_id, item_id, actual_return_date, days_late,
                            late_fee, condition, damage_fee, loss_fee,
                            insurance_used, insurance_refunded, extra_due_from_customer)
  VALUES (v_ret, v_ri, v_item, p_return_date, v_days, p_late_fee, p_condition::"ItemCondition",
          p_damage, p_loss, v_used, v_refund, v_extra);

  v_new_status := CASE p_condition
    WHEN 'GOOD' THEN CASE WHEN p_cleaning THEN 'CLEANING' ELSE 'AVAILABLE' END
    WHEN 'DAMAGED' THEN 'DAMAGED' ELSE 'LOST' END;

  INSERT INTO item_status_history (item_id, from_status, to_status, reason, ref_type, ref_id, user_id)
  VALUES (v_item, (SELECT status FROM product_items WHERE id=v_item), v_new_status::"ItemStatus",
          'إرجاع عقد ' || p_rental, 'Return', v_ret, 1);
  UPDATE product_items SET status = v_new_status::"ItemStatus", last_return_date = p_return_date WHERE id = v_item;
  INSERT INTO inventory_transactions (item_id, trx_date, type, ref_type, ref_id, created_by)
  VALUES (v_item, p_return_date, 'RETURN_IN', 'Return', v_ret, 1);

  UPDATE rental_items SET status = CASE WHEN p_condition='LOST' THEN 'LOST' ELSE 'RETURNED' END::"RentalItemStatus"
   WHERE id = v_ri;
  UPDATE item_bookings SET is_active = false WHERE item_id = v_item AND source_type='RENTAL' AND source_id = p_rental;

  -- الغرامات تُضاف إلى مستحقات العقد (إيراد)، والتأمين لا يمر من هنا إطلاقًا
  UPDATE rentals
     SET extra_charges = extra_charges + v_charges,
         total_due = gross_amount + extra_charges + v_charges,
         remaining_amount = (gross_amount + extra_charges + v_charges) - paid_amount
   WHERE id = p_rental;

  IF v_used > 0 THEN
    SELECT COALESCE((SELECT balance_after FROM insurance_transactions ORDER BY id DESC LIMIT 1),0) INTO v_bal;
    INSERT INTO insurance_transactions (type, rental_id, amount, balance_after, reason, created_by)
    VALUES (CASE WHEN p_condition='LOST' THEN 'DEDUCTED_LOSS' ELSE 'DEDUCTED_DAMAGE' END::"InsuranceTrxType",
            p_rental, v_used, v_bal - v_used, 'استخدام تأمين لسداد غرامات', 1);
  END IF;
  IF v_refund > 0 THEN
    SELECT COALESCE((SELECT balance_after FROM insurance_transactions ORDER BY id DESC LIMIT 1),0) INTO v_bal;
    INSERT INTO insurance_transactions (type, rental_id, amount, balance_after, reason, created_by)
    VALUES ('REFUNDED', p_rental, v_refund, v_bal - v_refund, 'رد تأمين للعميل', 1);
  END IF;

  IF p_fail THEN RAISE EXCEPTION 'فشل متعمّد في منتصف الإرجاع'; END IF;

  SELECT count(*) INTO v_open FROM rental_items WHERE rental_id = p_rental AND status = 'OUT';
  UPDATE rentals SET status = (CASE WHEN v_open = 0 THEN 'CLOSED' ELSE 'PARTIALLY_RETURNED' END)::"RentalStatus"
   WHERE id = p_rental;

  INSERT INTO audit_logs (user_id, action, entity_type, entity_id, after_json)
  VALUES (1, 'return.create', 'Return', v_ret::text,
          jsonb_build_object('days_late', v_days, 'charges', v_charges,
                             'insurance_used', v_used, 'insurance_refunded', v_refund,
                             'extra_due', v_extra));
  RETURN v_ret;
END;
$$ LANGUAGE plpgsql;

-- تهيئة: عقد بقطعتين، تأمين 1000 لكل قطعة، استحقاق أمس
INSERT INTO rentals (rental_no, customer_id, rental_date, expected_return_date,
  subtotal, discount, net_amount, gross_amount, total_due, remaining_amount, insurance_amount, created_by)
VALUES ('R-100', 2, CURRENT_DATE - 3, CURRENT_DATE - 1, 1000, 0, 1000, 1000, 1000, 1000, 2000, 1);
INSERT INTO rental_items (rental_id, item_id, unit_rental_price, net_price, gross_amount, insurance_per_item, expected_return_date)
VALUES (1, 1, 500, 500, 500, 1000, CURRENT_DATE - 1), (1, 2, 500, 500, 500, 1000, CURRENT_DATE - 1);
UPDATE product_items SET status='RENTED' WHERE id IN (1,2);
INSERT INTO item_bookings (item_id, start_date, end_date, source_type, source_id)
VALUES (1, CURRENT_DATE-3, CURRENT_DATE-1, 'RENTAL', 1), (2, CURRENT_DATE-3, CURRENT_DATE-1, 'RENTAL', 1);
INSERT INTO insurance_transactions (type, rental_id, amount, balance_after, created_by)
VALUES ('COLLECTED', 1, 2000, 2000, 1);

\echo '=== R1: إرجاع سليم متأخر يومين — التأمين يُرد كاملًا بعد سداد الغرامة ==='
SELECT 'الإرجاع ' || do_return(1, 'SUIT-0001', 'GOOD', 200, 0, 0, CURRENT_DATE);
SELECT 'أيام التأخير=' || days_late || ' غرامة=' || late_fee || ' | تأمين مستخدم=' || insurance_used
       || ' مردود=' || insurance_refunded || ' | مستحق إضافي=' || extra_due_from_customer
  FROM return_items WHERE return_id = 1;
SELECT 'حالة القطعة=' || status FROM product_items WHERE id=1;
SELECT 'حالة العقد=' || status || ' | إجمالي مستحق=' || total_due || ' متبقي=' || remaining_amount FROM rentals WHERE id=1;
SELECT 'رصيد التأمين=' || balance_after FROM insurance_transactions ORDER BY id DESC LIMIT 1;

\echo ''
\echo '=== R2: إرجاع تالف بقيمة تتجاوز التأمين (تلف 1500 > تأمين 1000) ==='
SELECT 'الإرجاع ' || do_return(1, 'SUIT-0002', 'DAMAGED', 200, 1500, 0, CURRENT_DATE);
SELECT 'غرامات=' || (late_fee+damage_fee) || ' | تأمين مستخدم=' || insurance_used
       || ' مردود=' || insurance_refunded || ' | ★ مستحق إضافي على العميل=' || extra_due_from_customer
  FROM return_items WHERE return_id = 2;
SELECT 'حالة القطعة=' || status FROM product_items WHERE id=2;
SELECT 'حالة العقد=' || status FROM rentals WHERE id=1;
SELECT 'رصيد التأمين=' || balance_after FROM insurance_transactions ORDER BY id DESC LIMIT 1;
