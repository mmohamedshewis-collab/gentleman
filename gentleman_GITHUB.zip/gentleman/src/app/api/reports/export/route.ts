import { NextResponse } from 'next/server';
import { z } from 'zod';
import { fail } from '@/lib/api';
import { requirePermission } from '@/lib/auth/rbac';
import { runReport, reportQuerySchema } from '@/services/report.service';
import { reportToExcel } from '@/lib/reports/excel';
import { reportToPrintableHtml } from '@/lib/reports/pdf';
import { getStringSetting } from '@/lib/settings';

const schema = reportQuerySchema.extend({ format: z.enum(['excel', 'pdf']) });

/**
 * التصدير يستدعي `runReport` نفسه بالفلاتر نفسها،
 * فيخرج الملف مطابقًا للشاشة حرفيًا بلا إعادة حساب.
 */
export async function GET(req: Request) {
  try {
    await requirePermission('reports.export');
    const params = Object.fromEntries(new URL(req.url).searchParams.entries());
    const input = schema.parse(params);

    const { format, ...query } = input;
    const report = await runReport(query);
    const stamp = report.generatedAt.replace(/[:\s]/g, '-');

    if (format === 'excel') {
      const buffer = await reportToExcel(report);
      return new NextResponse(buffer, {
        status: 200,
        headers: {
          'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
          'Content-Disposition': `attachment; filename="${report.key}-${stamp}.xlsx"`,
          'Cache-Control': 'no-store',
        },
      });
    }

    const [name, phone, address] = await Promise.all([
      getStringSetting('shop.name'),
      getStringSetting('shop.phone'),
      getStringSetting('shop.address'),
    ]);
    const html = reportToPrintableHtml(report, { name, phone, address });
    return new NextResponse(html, {
      status: 200,
      headers: { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' },
    });
  } catch (err) {
    return fail(err);
  }
}
