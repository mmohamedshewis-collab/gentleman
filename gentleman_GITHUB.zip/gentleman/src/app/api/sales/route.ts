import { route } from '@/lib/api';
import { listSales, saleQuerySchema, createSale, createSaleSchema } from '@/services/sale.service';

export const GET = route({ schema: saleQuerySchema, handler: ({ input }) => listSales(input) });
export const POST = route({ schema: createSaleSchema, handler: ({ input }) => createSale(input) });
