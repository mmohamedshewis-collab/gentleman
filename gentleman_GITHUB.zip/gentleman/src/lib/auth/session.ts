import { createHash, randomBytes } from 'crypto';
import { cookies, headers } from 'next/headers';
import { prisma } from '@/lib/db';
import { Errors } from '@/lib/errors';
import type { PermissionCode } from './permissions';

export const COOKIE_NAME = process.env.SESSION_COOKIE_NAME || 'gentleman_session';
const TTL_HOURS = Number(process.env.SESSION_TTL_HOURS || 12);

export interface SessionUser {
  id: number;
  username: string;
  fullName: string;
  roleCode: string;
  roleNameAr: string;
  employeeId: number | null;
  permissions: Set<PermissionCode>;
}

const sha256 = (v: string) => createHash('sha256').update(v).digest('hex');

export async function createSession(userId: number) {
  const token = randomBytes(32).toString('hex');
  const expiresAt = new Date(Date.now() + TTL_HOURS * 3600 * 1000);
  const h = headers();
  await prisma.userSession.create({
    data: {
      userId,
      tokenHash: sha256(token),
      expiresAt,
      ipAddress: h.get('x-forwarded-for') ?? undefined,
      userAgent: h.get('user-agent') ?? undefined,
    },
  });
  cookies().set(COOKIE_NAME, token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    path: '/',
    expires: expiresAt,
  });
  return { token, expiresAt };
}

export async function destroySession() {
  const token = cookies().get(COOKIE_NAME)?.value;
  if (token) {
    await prisma.userSession.updateMany({
      where: { tokenHash: sha256(token), revokedAt: null },
      data: { revokedAt: new Date() },
    });
  }
  cookies().delete(COOKIE_NAME);
}

/** يقرأ الجلسة الحالية أو null. لا يرمي خطأ. */
export async function getSession(): Promise<SessionUser | null> {
  const token = cookies().get(COOKIE_NAME)?.value;
  if (!token) return null;

  const session = await prisma.userSession.findUnique({
    where: { tokenHash: sha256(token) },
    include: {
      user: {
        include: {
          role: { include: { permissions: { include: { permission: true } } } },
          employee: { select: { id: true } },
        },
      },
    },
  });

  if (!session || session.revokedAt || session.expiresAt < new Date()) return null;
  if (!session.user.isActive) return null;

  return {
    id: session.user.id,
    username: session.user.username,
    fullName: session.user.fullName,
    roleCode: session.user.role.code,
    roleNameAr: session.user.role.nameAr,
    employeeId: session.user.employee?.id ?? null,
    permissions: new Set(
      session.user.role.permissions.map((rp) => rp.permission.code as PermissionCode),
    ),
  };
}

/** يفرض وجود جلسة صالحة. */
export async function requireSession(): Promise<SessionUser> {
  const s = await getSession();
  if (!s) throw Errors.unauthenticated();
  return s;
}
