import { z } from 'zod';
import { route } from '@/lib/api';
import { listAdvances, createAdvance, createAdvanceSchema } from '@/services/advance.service';

export const GET = route({
  schema: z.object({ employeeId: z.coerce.number().int().optional() }),
  handler: ({ input }) => listAdvances(input.employeeId),
});
export const POST = route({ schema: createAdvanceSchema, handler: ({ input }) => createAdvance(input) });
