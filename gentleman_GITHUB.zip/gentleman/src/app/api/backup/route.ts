import { route } from '@/lib/api';
import { runDataExport } from '@/services/backup.service';

/**
 * تصدير بيانات فقط.
 * ⛔ لا يوجد مسار استعادة في النظام — الاستعادة عبر Neon PITR خارج التطبيق.
 */
export const POST = route({ handler: () => runDataExport() });
