import { z } from 'zod';
import { prisma } from '@/lib/db';
import { Errors } from '@/lib/errors';
import { writeAudit } from '@/lib/audit';
import { requirePermission } from '@/lib/auth/rbac';

// ============================ التصنيفات ============================

export const categorySchema = z.object({
  nameAr: z.string().min(2, 'اسم التصنيف مطلوب'),
  parentId: z.number().int().positive().nullable().optional(),
});

export async function listCategories() {
  await requirePermission('products.view');
  return prisma.category.findMany({
    where: { isActive: true },
    include: { _count: { select: { products: true } } },
    orderBy: { nameAr: 'asc' },
  });
}

export async function createCategory(input: z.infer<typeof categorySchema>) {
  const actor = await requirePermission('products.manage');
  return prisma.$transaction(async (tx) => {
    const row = await tx.category.create({
      data: { nameAr: input.nameAr.trim(), parentId: input.parentId ?? null },
    });
    await writeAudit(
      { userId: actor.id, action: 'category.create', entityType: 'Category', entityId: row.id, after: row },
      tx,
    );
    return row;
  });
}

// ============================ الماركات ============================

export const brandSchema = z.object({ name: z.string().min(1, 'اسم الماركة مطلوب') });

export async function listBrands() {
  await requirePermission('products.view');
  return prisma.brand.findMany({ where: { isActive: true }, orderBy: { name: 'asc' } });
}

export async function createBrand(input: z.infer<typeof brandSchema>) {
  const actor = await requirePermission('products.manage');
  const name = input.name.trim();
  if (await prisma.brand.findUnique({ where: { name } })) {
    throw Errors.conflict('الماركة مسجلة بالفعل.');
  }
  return prisma.$transaction(async (tx) => {
    const row = await tx.brand.create({ data: { name } });
    await writeAudit(
      { userId: actor.id, action: 'brand.create', entityType: 'Brand', entityId: row.id, after: row },
      tx,
    );
    return row;
  });
}

// ============================ المنتجات ============================

const money = z.coerce.number().nonnegative('القيمة لا يمكن أن تكون سالبة');

export const createProductSchema = z.object({
  code: z.string().min(2).max(30).regex(/^[A-Za-z0-9-]+$/, 'الكود بحروف إنجليزية وأرقام فقط'),
  nameAr: z.string().min(2, 'اسم المنتج مطلوب'),
  categoryId: z.number().int().positive().nullable().optional(),
  brandId: z.number().int().positive().nullable().optional(),
  size: z.string().max(20).optional(),
  color: z.string().max(30).optional(),
  rentalPrice: money.default(0),
  salePrice: money.default(0),
  defaultCost: money.default(0),
  description: z.string().max(500).optional(),
  imageKey: z.string().max(300).optional(),
});

export const updateProductSchema = createProductSchema.partial().extend({
  id: z.number().int().positive(),
});

export const productQuerySchema = z.object({
  q: z.string().optional(),
  categoryId: z.coerce.number().int().optional(),
  brandId: z.coerce.number().int().optional(),
});

export async function listProducts(input: z.infer<typeof productQuerySchema> = {}) {
  await requirePermission('products.view');
  return prisma.product.findMany({
    where: {
      isActive: true,
      categoryId: input.categoryId,
      brandId: input.brandId,
      ...(input.q ? { OR: [{ nameAr: { contains: input.q } }, { code: { contains: input.q.toUpperCase() } }] } : {}),
    },
    include: {
      category: { select: { nameAr: true } },
      brand: { select: { name: true } },
      _count: { select: { items: true } },
    },
    orderBy: { nameAr: 'asc' },
  });
}

export async function createProduct(input: z.infer<typeof createProductSchema>) {
  const actor = await requirePermission('products.manage');
  const code = input.code.trim().toUpperCase();
  if (await prisma.product.findUnique({ where: { code } })) {
    throw Errors.conflict('كود المنتج مستخدم بالفعل.');
  }
  return prisma.$transaction(async (tx) => {
    const row = await tx.product.create({
      data: {
        code,
        nameAr: input.nameAr.trim(),
        categoryId: input.categoryId ?? null,
        brandId: input.brandId ?? null,
        size: input.size,
        color: input.color,
        rentalPrice: input.rentalPrice,
        salePrice: input.salePrice,
        defaultCost: input.defaultCost,
        description: input.description,
        imageKey: input.imageKey,
      },
    });
    await writeAudit(
      { userId: actor.id, action: 'product.create', entityType: 'Product', entityId: row.id, after: row },
      tx,
    );
    return row;
  });
}

export async function updateProduct(input: z.infer<typeof updateProductSchema>) {
  const actor = await requirePermission('products.manage');
  const before = await prisma.product.findUnique({ where: { id: input.id } });
  if (!before) throw Errors.notFound('المنتج');

  const { id, code, ...rest } = input;
  const data: Record<string, unknown> = { ...rest };
  if (code) data.code = code.trim().toUpperCase();

  const priceChanged =
    (input.rentalPrice !== undefined && !before.rentalPrice.equals(input.rentalPrice)) ||
    (input.salePrice !== undefined && !before.salePrice.equals(input.salePrice));

  return prisma.$transaction(async (tx) => {
    const after = await tx.product.update({ where: { id }, data });
    await writeAudit(
      {
        userId: actor.id,
        action: priceChanged ? 'product.price_change' : 'product.update',
        entityType: 'Product',
        entityId: id,
        before,
        after,
      },
      tx,
    );
    return after;
  });
}
