import { z } from 'zod';
import { prisma } from '@/lib/db';
import { Errors } from '@/lib/errors';
import { writeAudit } from '@/lib/audit';
import { requirePermission } from '@/lib/auth/rbac';
import { businessToday, toBusinessDate } from '@/lib/date';
import { round2 } from '@/lib/money';
import { assertRepaymentWithinBalance, settleSalary } from '@/lib/cash/cash-movement';

/**
 * سلف الموظفين.
 * ★ السلفة خروج نقدي **مسترد** وليست مصروفًا: لا تؤثر على الربح عند صرفها،
 *   ولا تُسجَّل مصروفًا مرة أخرى عند خصمها من الراتب.
 */

const money = z.coerce.number().positive('المبلغ يجب أن يكون أكبر من صفر');

export const createAdvanceSchema = z.object({
  employeeId: z.number().int().positive('الموظف مطلوب'),
  amount: money,
  paymentMethodId: z.number().int().positive(),
  advanceDate: z.string().optional(),
  notes: z.string().max(500).optional(),
});

export const repayAdvanceSchema = z.object({
  advanceId: z.number().int().positive(),
  amount: money,
  method: z.enum(['SALARY_DEDUCTION', 'CASH']),
  expenseId: z.number().int().positive().optional(),
  repaymentDate: z.string().optional(),
});

export const salarySchema = z.object({
  employeeId: z.number().int().positive(),
  grossSalary: money,
  advanceIds: z.array(z.number().int().positive()).default([]),
  otherDeductions: z.coerce.number().nonnegative().default(0),
  paymentMethodId: z.number().int().positive(),
  expenseDate: z.string().optional(),
  notes: z.string().max(500).optional(),
});

export async function listAdvances(employeeId?: number) {
  await requirePermission('advances.view');
  return prisma.employeeAdvance.findMany({
    where: employeeId ? { employeeId } : undefined,
    include: {
      employee: { select: { code: true, fullName: true } },
      paymentMethod: { select: { nameAr: true, isCash: true } },
      repayments: { orderBy: { id: 'desc' } },
    },
    orderBy: { id: 'desc' },
  });
}

export async function createAdvance(input: z.infer<typeof createAdvanceSchema>) {
  const actor = await requirePermission('advances.create');
  const date = input.advanceDate ? toBusinessDate(input.advanceDate) : businessToday();

  const employee = await prisma.employee.findUnique({ where: { id: input.employeeId } });
  if (!employee) throw Errors.notFound('الموظف');
  if (employee.status !== 'ACTIVE') throw Errors.rule('لا يمكن صرف سلفة لموظف غير نشط.');

  const amount = round2(input.amount);

  return prisma.$transaction(async (tx) => {
    await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext('advance_no'))`;
    const year = date.getUTCFullYear();
    const last = await tx.employeeAdvance.findFirst({
      where: { advanceNo: { startsWith: `ADV-${year}-` } },
      orderBy: { advanceNo: 'desc' },
      select: { advanceNo: true },
    });
    const seq = last ? Number.parseInt(last.advanceNo.slice(9), 10) + 1 : 1;

    const row = await tx.employeeAdvance.create({
      data: {
        advanceNo: `ADV-${year}-${String(Number.isFinite(seq) ? seq : 1).padStart(6, '0')}`,
        employeeId: input.employeeId,
        advanceDate: date,
        amount: amount.toString(),
        repaidAmount: '0',
        balance: amount.toString(),
        status: 'OPEN',
        paymentMethodId: input.paymentMethodId,
        notes: input.notes?.trim() || null,
        createdBy: actor.id,
      },
    });

    await writeAudit(
      {
        userId: actor.id,
        action: 'advance.create',
        entityType: 'EmployeeAdvance',
        entityId: row.id,
        after: {
          advanceNo: row.advanceNo,
          employeeId: input.employeeId,
          amount: amount.toString(),
          // ★ خروج نقدي وليس مصروفًا
          isExpense: false,
          profitImpact: '0',
        },
      },
      tx,
    );

    return { id: row.id, advanceNo: row.advanceNo, amount: amount.toString(), balance: amount.toString() };
  });
}

export async function repayAdvance(input: z.infer<typeof repayAdvanceSchema>) {
  const actor = await requirePermission('advances.repay');
  const date = input.repaymentDate ? toBusinessDate(input.repaymentDate) : businessToday();

  if (input.method === 'SALARY_DEDUCTION' && !input.expenseId) {
    throw Errors.rule('الخصم من الراتب يستلزم ربطه بمصروف الراتب.');
  }

  return prisma.$transaction(async (tx) => {
    const locked = await tx.$queryRaw<{ id: number; amount: string; repaid_amount: string; status: string }[]>`
      SELECT id, amount, repaid_amount, status FROM employee_advances
       WHERE id = ${input.advanceId} FOR UPDATE
    `;
    if (locked.length === 0) throw Errors.notFound('السلفة');
    const adv = locked[0];
    if (adv.status === 'CANCELLED') throw Errors.rule('السلفة ملغاة.');
    if (adv.status === 'SETTLED') throw Errors.rule('السلفة مسدَّدة بالكامل.');

    try {
      assertRepaymentWithinBalance({
        amount: adv.amount,
        repaidAmount: adv.repaid_amount,
        newRepayment: input.amount,
      });
    } catch (e) {
      throw Errors.rule((e as Error).message);
    }

    const row = await tx.employeeAdvanceRepayment.create({
      data: {
        advanceId: input.advanceId,
        repaymentDate: date,
        amount: round2(input.amount).toString(),
        method: input.method,
        expenseId: input.expenseId ?? null,
        createdBy: actor.id,
      },
    });

    const after = await tx.employeeAdvance.findUniqueOrThrow({ where: { id: input.advanceId } });

    await writeAudit(
      {
        userId: actor.id,
        action: 'advance.repay',
        entityType: 'EmployeeAdvance',
        entityId: input.advanceId,
        before: { repaidAmount: adv.repaid_amount },
        after: {
          repaidAmount: after.repaidAmount.toString(),
          balance: after.balance.toString(),
          method: input.method,
          // ★ السداد لا يُنشئ مصروفًا
          isExpense: false,
        },
      },
      tx,
    );

    return {
      id: row.id,
      repaidAmount: after.repaidAmount.toString(),
      balance: after.balance.toString(),
      status: after.status,
    };
  });
}

/**
 * صرف الراتب مع خصم السلف.
 * ★ الحالة الوحيدة في النظام التي يختلف فيها المصروف عن الخروج النقدي:
 *   المصروف = إجمالي الراتب · الخروج النقدي = الصافي بعد الخصم.
 */
export async function paySalary(input: z.infer<typeof salarySchema>) {
  const actor = await requirePermission('expenses.create');
  const date = input.expenseDate ? toBusinessDate(input.expenseDate) : businessToday();

  const employee = await prisma.employee.findUnique({ where: { id: input.employeeId } });
  if (!employee) throw Errors.notFound('الموظف');

  const category = await prisma.expenseCategory.findFirst({
    where: { nameAr: { contains: 'رواتب' }, isActive: true },
  });
  if (!category) throw Errors.rule('فئة «رواتب» غير موجودة في الإعدادات.');

  return prisma.$transaction(async (tx) => {
    // قفل السلف المختارة وحساب الخصم من أرصدتها الفعلية
    let advanceDeduction = round2(0);
    const advances: { id: number; balance: string }[] = [];

    for (const id of input.advanceIds) {
      const locked = await tx.$queryRaw<{ id: number; balance: string; status: string }[]>`
        SELECT id, balance, status FROM employee_advances WHERE id = ${id} FOR UPDATE
      `;
      if (locked.length === 0) throw Errors.notFound('السلفة');
      const a = locked[0];
      if (a.status !== 'OPEN') continue;
      advanceDeduction = advanceDeduction.plus(a.balance);
      advances.push({ id: a.id, balance: a.balance });
    }

    let settlement;
    try {
      settlement = settleSalary({
        grossSalary: input.grossSalary,
        advanceDeduction,
        otherDeductions: input.otherDeductions,
      });
    } catch (e) {
      throw Errors.rule(`تعذّر حساب الراتب: ${(e as Error).message}`);
    }

    await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext('expense_no'))`;
    const year = date.getUTCFullYear();
    const last = await tx.expense.findFirst({
      where: { expenseNo: { startsWith: `EXP-${year}-` } },
      orderBy: { expenseNo: 'desc' },
      select: { expenseNo: true },
    });
    const seq = last ? Number.parseInt(last.expenseNo.slice(9), 10) + 1 : 1;

    const expense = await tx.expense.create({
      data: {
        expenseNo: `EXP-${year}-${String(Number.isFinite(seq) ? seq : 1).padStart(6, '0')}`,
        expenseDate: date,
        categoryId: category.id,
        // ★ المصروف = إجمالي الراتب
        amount: settlement.salaryExpense.toString(),
        // ★ الخروج النقدي = الصافي فقط
        cashPaidAmount: settlement.cashPaidAmount.toString(),
        paymentMethodId: input.paymentMethodId,
        employeeId: input.employeeId,
        description: `راتب ${employee.fullName}` + (input.notes ? ` · ${input.notes}` : ''),
        createdBy: actor.id,
      },
    });

    // تسوية السلف بالخصم — بلا أي مصروف إضافي
    for (const a of advances) {
      await tx.employeeAdvanceRepayment.create({
        data: {
          advanceId: a.id,
          repaymentDate: date,
          amount: a.balance,
          method: 'SALARY_DEDUCTION',
          expenseId: expense.id,
          createdBy: actor.id,
        },
      });
    }

    await writeAudit(
      {
        userId: actor.id,
        action: 'salary.pay',
        entityType: 'Expense',
        entityId: expense.id,
        after: {
          employeeId: input.employeeId,
          grossSalary: settlement.grossSalary.toString(),
          advanceDeduction: settlement.advanceDeduction.toString(),
          otherDeductions: settlement.otherDeductions.toString(),
          netSalary: settlement.netSalary.toString(),
          salaryExpense: settlement.salaryExpense.toString(),
          cashPaidAmount: settlement.cashPaidAmount.toString(),
          settledAdvances: advances.map((a) => a.id),
        },
      },
      tx,
    );

    return {
      expenseId: expense.id,
      expenseNo: expense.expenseNo,
      grossSalary: settlement.grossSalary.toString(),
      advanceDeduction: settlement.advanceDeduction.toString(),
      otherDeductions: settlement.otherDeductions.toString(),
      netSalary: settlement.netSalary.toString(),
      salaryExpense: settlement.salaryExpense.toString(),
      cashPaidAmount: settlement.cashPaidAmount.toString(),
    };
  });
}
