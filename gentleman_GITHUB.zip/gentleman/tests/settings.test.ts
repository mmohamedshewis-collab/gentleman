import { describe, it, expect } from 'vitest';
import { SETTING_DEFS } from '../src/lib/settings.defs';

describe('كتالوج الإعدادات', () => {
  it('★ لا يوجد رصيد افتتاحي لنقدية الشركة — محذوف نهائيًا', () => {
    expect(SETTING_DEFS.find((s) => s.key === 'company.opening_cash')).toBeUndefined();
    expect(SETTING_DEFS.find((s) => s.key === 'company.opening_cash_date')).toBeUndefined();
  });

  it('★ رصيد التأمين الافتتاحي باقٍ — التأمينات تستمر عبر الأيام', () => {
    const s = SETTING_DEFS.find((x) => x.key === 'insurance.opening_balance');
    expect(s).toBeDefined();
    expect(s!.value).toBe(0);
  });

  it('لا توجد مفاتيح مكررة', () => {
    const keys = SETTING_DEFS.map((s) => s.key);
    expect(new Set(keys).size).toBe(keys.length);
  });

  it('الضريبة معطّلة بالكامل عند التشغيل', () => {
    expect(SETTING_DEFS.find((s) => s.key === 'vat.enabled')!.value).toBe(false);
  });

  it('نسبة 14% محفوظة كإعداد للمستقبل فقط وليست مثبتة في الكود', () => {
    expect(SETTING_DEFS.find((s) => s.key === 'vat.rate')!.value).toBe(14);
  });

  it('لا يفترض النظام أي رسوم أو نسب عمولة', () => {
    for (const key of [
      'rental.late_fee_per_item_per_day',
      'commission.rental_percent',
      'commission.sales_percent',
      'discount.staff_max_percent',
      'insurance.opening_balance',
    ]) {
      expect(SETTING_DEFS.find((s) => s.key === key)!.value).toBe(0);
    }
  });

  it('العربون غير مسترد عند إلغاء العميل ومسترد عند إلغاء المحل (Q4)', () => {
    expect(SETTING_DEFS.find((s) => s.key === 'rental.deposit_refundable_on_customer_cancel')!.value).toBe(false);
    expect(SETTING_DEFS.find((s) => s.key === 'rental.deposit_refundable_on_shop_cancel')!.value).toBe(true);
  });

  it('التنظيف اختياري ومعطّل افتراضيًا (Q9)', () => {
    expect(SETTING_DEFS.find((s) => s.key === 'cleaning.enabled')!.value).toBe(false);
  });

  it('مدة ركود التأمين 90 يومًا وقابلة للتعديل (Q13)', () => {
    expect(SETTING_DEFS.find((s) => s.key === 'insurance.dormant_days')!.value).toBe(90);
  });
});
