import { describe, it, expect } from 'vitest';
import { daysLate, toBusinessDate, periodBounds } from '../src/lib/date';

describe('حساب التأخير', () => {
  const d = (s: string) => toBusinessDate(s);

  it('الإرجاع في يوم الاستحقاق = صفر أيام تأخير (E03)', () => {
    expect(daysLate(d('2026-08-10'), d('2026-08-10'))).toBe(0);
  });

  it('الإرجاع قبل الموعد لا ينتج تأخيرًا سالبًا (E04)', () => {
    expect(daysLate(d('2026-08-10'), d('2026-08-08'))).toBe(0);
  });

  it('يحسب الأيام التقويمية الكاملة', () => {
    expect(daysLate(d('2026-08-10'), d('2026-08-12'))).toBe(2);
  });

  it('يعمل عبر حدود الشهر', () => {
    expect(daysLate(d('2026-08-30'), d('2026-09-02'))).toBe(3);
  });
});

describe('حدود فترة التقرير', () => {
  it('يوم واحد يشمل اليوم كاملًا (E12)', () => {
    const { start, end } = periodBounds('2026-08-10', '2026-08-10');
    expect(end.getTime() - start.getTime()).toBe(24 * 3600 * 1000 - 1);
  });

  it('يرفض فترة معكوسة', () => {
    expect(() => periodBounds('2026-08-10', '2026-08-01')).toThrowError('PERIOD_INVALID');
  });
});
