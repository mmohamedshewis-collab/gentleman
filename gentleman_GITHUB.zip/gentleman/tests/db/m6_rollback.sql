\set ON_ERROR_STOP off
\t on
SELECT 'قبل: دفعات=' || (SELECT count(*) FROM payments) || ' تدقيق=' || (SELECT count(*) FROM audit_logs) ||
       ' مدفوع=' || (SELECT paid_amount FROM rentals WHERE rental_no='R-M6-1') ||
       ' متبقٍ=' || (SELECT remaining_amount FROM rentals WHERE rental_no='R-M6-1');
SELECT do_payment((SELECT id FROM rentals WHERE rental_no='R-M6-1'), 100, true);
SELECT 'بعد الفشل: دفعات=' || (SELECT count(*) FROM payments) || ' تدقيق=' || (SELECT count(*) FROM audit_logs) ||
       ' مدفوع=' || (SELECT paid_amount FROM rentals WHERE rental_no='R-M6-1') ||
       ' متبقٍ=' || (SELECT remaining_amount FROM rentals WHERE rental_no='R-M6-1');
