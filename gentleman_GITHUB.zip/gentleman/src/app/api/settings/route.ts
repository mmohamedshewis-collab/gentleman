import { route } from '@/lib/api';
import { readSettings, updateSettings, updateSettingsSchema } from '@/services/settings.service';

export const GET = route({ handler: () => readSettings() });
export const PATCH = route({ schema: updateSettingsSchema, handler: ({ input }) => updateSettings(input) });
