/** آلة حالة فاتورة البيع — منطق خالص. */

export type SaleStatus = 'COMPLETED' | 'VOIDED';

export const SALE_STATUS_LABELS: Record<SaleStatus, string> = {
  COMPLETED: 'مكتملة',
  VOIDED: 'ملغاة',
};

/** الفاتورة تُنشأ مكتملة، ولا تخرج منها إلا بالإلغاء. */
export const SALE_ALLOWED_TRANSITIONS: Record<SaleStatus, SaleStatus[]> = {
  COMPLETED: ['VOIDED'],
  VOIDED: [],
};

export interface VoidCheck {
  allowed: boolean;
  reason?: string;
}

/**
 * شروط إلغاء الفاتورة:
 * 1. غير ملغاة مسبقًا.
 * 2. كل قطعها ما زالت SOLD (لم تُستبعد أو تتغير حالتها بعد البيع).
 */
export function canVoidSale(input: {
  status: SaleStatus;
  itemStatuses: string[];
}): VoidCheck {
  if (input.status === 'VOIDED') {
    return { allowed: false, reason: 'الفاتورة ملغاة بالفعل.' };
  }
  const notSold = input.itemStatuses.filter((s) => s !== 'SOLD');
  if (notSold.length > 0) {
    return {
      allowed: false,
      reason: 'لا يمكن إلغاء الفاتورة لأن حالة إحدى القطع تغيّرت بعد البيع.',
    };
  }
  return { allowed: true };
}

/** الحالات التي يجوز أن تعود إليها القطعة بعد إلغاء البيع. */
export const RESTORABLE_AFTER_VOID = ['AVAILABLE', 'DAMAGED', 'MAINTENANCE'] as const;

export function assertRestorable(preSaleStatus: string): void {
  if (!(RESTORABLE_AFTER_VOID as readonly string[]).includes(preSaleStatus)) {
    throw new Error(`لا يمكن إعادة القطعة إلى حالة "${preSaleStatus}" بعد إلغاء البيع.`);
  }
}
