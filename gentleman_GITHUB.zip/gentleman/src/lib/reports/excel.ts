import ExcelJS from 'exceljs';
import { formatCell, type ReportResult } from './report-types';

/**
 * تصدير Excel — يستهلك `ReportResult` نفسه الذي تعرضه الشاشة.
 * ★ لا يعيد حساب أي رقم ولا يستعلم قاعدة البيانات: نفس الأرقام حرفيًا.
 */
export async function reportToExcel(report: ReportResult): Promise<Buffer> {
  const wb = new ExcelJS.Workbook();
  wb.creator = 'Gentleman';
  wb.created = new Date();

  const ws = wb.addWorksheet(report.title.slice(0, 30), {
    views: [{ rightToLeft: true }],          // ★ اتجاه الورقة من اليمين لليسار
    pageSetup: { orientation: 'landscape', fitToPage: true, fitToWidth: 1 },
  });

  const colCount = report.columns.length;
  let r = 1;

  const merge = (row: number, text: string, bold: boolean, size: number, color?: string) => {
    ws.mergeCells(row, 1, row, colCount);
    const cell = ws.getCell(row, 1);
    cell.value = text;
    cell.alignment = { horizontal: 'center', vertical: 'middle', readingOrder: 'rtl' };
    cell.font = { name: 'Arial', size, bold, color: color ? { argb: color } : undefined };
  };

  // ترويسة التقرير
  merge(r++, 'Gentleman — نظام إدارة تأجير وبيع البدلات', true, 14, 'FF002060');
  merge(r++, report.title, true, 12);
  merge(r++, report.period, false, 10);

  if (report.appliedFilters.length > 0) {
    merge(r++, report.appliedFilters.map((f) => `${f.label}: ${f.value}`).join('   •   '), false, 10);
  }
  merge(r++, `تاريخ الإصدار: ${report.generatedAt}`, false, 9);
  r++;

  // رؤوس الأعمدة
  const headerRow = ws.getRow(r);
  report.columns.forEach((c, i) => {
    const cell = headerRow.getCell(i + 1);
    cell.value = c.label;
    cell.font = { name: 'Arial', bold: true, color: { argb: 'FFFFFFFF' } };
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF002060' } };
    cell.alignment = { horizontal: 'center', vertical: 'middle', readingOrder: 'rtl' };
    cell.border = { bottom: { style: 'thin' } };
  });
  headerRow.height = 22;
  const headerIndex = r;
  r++;

  // الصفوف
  for (const row of report.rows) {
    const xr = ws.getRow(r);
    report.columns.forEach((c, i) => {
      const cell = xr.getCell(i + 1);
      const raw = row[c.key];
      if (c.type === 'money' || c.type === 'number') {
        const n = raw === null || raw === '' || raw === '—' ? null : Number(raw);
        cell.value = n !== null && Number.isFinite(n) ? n : null;
        cell.numFmt = c.type === 'money' ? '#,##0.00' : '#,##0';
        cell.alignment = { horizontal: 'left' };
      } else {
        cell.value = raw === null || raw === '' ? '—' : String(raw);
        cell.alignment = { horizontal: 'right', readingOrder: 'rtl' };
      }
      cell.font = { name: 'Arial', size: 10 };
    });
    r++;
  }

  // الإجماليات
  if (report.totals) {
    const tr = ws.getRow(r);
    report.columns.forEach((c, i) => {
      const cell = tr.getCell(i + 1);
      const raw = report.totals![c.key];
      if (c.type === 'money' || c.type === 'number') {
        const n = raw === null || raw === '' ? null : Number(raw);
        cell.value = n !== null && Number.isFinite(n) ? n : null;
        cell.numFmt = c.type === 'money' ? '#,##0.00' : '#,##0';
        cell.alignment = { horizontal: 'left' };
      } else {
        cell.value = raw === null ? '' : String(raw);
        cell.alignment = { horizontal: 'right', readingOrder: 'rtl' };
      }
      cell.font = { name: 'Arial', size: 10, bold: true };
      cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE8EFF8' } };
      cell.border = { top: { style: 'thin' } };
    });
    r++;
  }

  // الملاحظات المحاسبية
  if (report.notes.length > 0) {
    r++;
    for (const note of report.notes) {
      merge(r, `• ${note}`, false, 9, 'FF666666');
      ws.getCell(r, 1).alignment = { horizontal: 'right', readingOrder: 'rtl' };
      r++;
    }
  }

  // عرض الأعمدة حسب أطول محتوى
  report.columns.forEach((c, i) => {
    const lengths = [c.label.length, ...report.rows.map((row) => formatCell(row[c.key], c.type).length)];
    ws.getColumn(i + 1).width = Math.min(40, Math.max(12, Math.max(...lengths) + 4));
  });

  ws.autoFilter = {
    from: { row: headerIndex, column: 1 },
    to: { row: headerIndex, column: colCount },
  };
  ws.views = [{ rightToLeft: true, state: 'frozen', ySplit: headerIndex }];

  return Buffer.from(await wb.xlsx.writeBuffer());
}
