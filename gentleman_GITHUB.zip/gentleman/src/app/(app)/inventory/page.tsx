import Link from 'next/link';
import { inventorySummary } from '@/services/inventory.service';
import { listItems } from '@/services/item.service';
import { STATUS_LABELS, type ItemStatus } from '@/lib/inventory/item-state';
import StatusBadge from '@/components/StatusBadge';
import ScanPanel from '@/components/ScanPanel';

export const dynamic = 'force-dynamic';

const SUMMARY_ORDER: ItemStatus[] = [
  'AVAILABLE', 'RENTED', 'OVERDUE', 'RESERVED', 'CLEANING',
  'MAINTENANCE', 'DAMAGED', 'LOST', 'SOLD', 'DISPOSED',
];

export default async function InventoryPage({
  searchParams,
}: { searchParams: { status?: string; q?: string } }) {
  const [summary, items] = await Promise.all([
    inventorySummary(),
    listItems({
      status: searchParams.status,
      q: searchParams.q,
      page: 1,
      pageSize: 50,
    }),
  ]);

  return (
    <div className="space-y-6">
      <h1 className="section-title">المخزون</h1>

      <ScanPanel />

      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        <Link href="/inventory" className="card p-4 hover:border-brand-light transition">
          <div className="text-slate-500 text-xs">إجمالي القطع</div>
          <div className="num text-2xl font-bold text-brand">{summary.totalItems}</div>
        </Link>
        {SUMMARY_ORDER.map((s) => (
          <Link
            key={s}
            href={`/inventory?status=${s}`}
            className="card p-4 hover:border-brand-light transition"
          >
            <div className="text-slate-500 text-xs">{STATUS_LABELS[s]}</div>
            <div className="num text-2xl font-bold">{summary.statusCounts[s]}</div>
          </Link>
        ))}
      </div>

      <div className="card overflow-hidden">
        <div className="card-header">القطع حسب المنتج</div>
        <div className="overflow-x-auto">
          <table className="table">
            <thead>
              <tr>
                <th>المنتج</th><th>المقاس</th><th>اللون</th><th>الإجمالي</th>
                <th>متاحة</th><th>مؤجرة</th><th>متأخرة</th><th>مباعة</th>
                <th>تالفة</th><th>مفقودة</th>
              </tr>
            </thead>
            <tbody>
              {summary.products.map((p) => (
                <tr key={p.id}>
                  <td className="font-semibold">{p.nameAr}</td>
                  <td>{p.size ?? '—'}</td>
                  <td>{p.color ?? '—'}</td>
                  <td className="num font-bold">{p.total}</td>
                  <td className="num">{p.counts.AVAILABLE}</td>
                  <td className="num">{p.counts.RENTED}</td>
                  <td className="num">{p.counts.OVERDUE}</td>
                  <td className="num">{p.counts.SOLD}</td>
                  <td className="num">{p.counts.DAMAGED}</td>
                  <td className="num">{p.counts.LOST}</td>
                </tr>
              ))}
              {summary.products.length === 0 && (
                <tr><td colSpan={10} className="text-center text-slate-500 py-6">لا توجد منتجات بعد.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      <div className="card overflow-hidden">
        <div className="card-header">
          القطع {searchParams.status ? `— ${STATUS_LABELS[searchParams.status as ItemStatus]}` : ''}
          {' '}(<span className="num">{items.total}</span>)
        </div>
        <div className="overflow-x-auto">
          <table className="table">
            <thead>
              <tr><th>كود القطعة</th><th>الباركود</th><th>المنتج</th><th>الحالة</th><th>مرات التأجير</th><th></th></tr>
            </thead>
            <tbody>
              {items.rows.map((it) => (
                <tr key={it.id}>
                  <td className="num font-semibold">{it.itemCode}</td>
                  <td className="num text-slate-500">{it.barcode}</td>
                  <td>{it.product.nameAr}</td>
                  <td>
                    <StatusBadge status={(it.displayStatus ?? it.status) as ItemStatus} />
                    {it.isOverdue && (
                      <span className="text-[11px] text-danger num mr-2">
                        متأخرة {it.daysLate} يوم
                      </span>
                    )}
                  </td>
                  <td className="num">{it.rentalCount}</td>
                  <td>
                    <Link href={`/inventory/${it.id}`} className="text-brand-light font-semibold">
                      تفاصيل
                    </Link>
                  </td>
                </tr>
              ))}
              {items.rows.length === 0 && (
                <tr><td colSpan={6} className="text-center text-slate-500 py-6">لا توجد قطع مطابقة.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
