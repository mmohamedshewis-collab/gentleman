import { route } from '@/lib/api';
import { payableEmployees } from '@/services/commission.service';

export const GET = route({ handler: () => payableEmployees() });
