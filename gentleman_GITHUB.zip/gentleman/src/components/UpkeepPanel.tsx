'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

interface Record_ {
  id: number; kind: 'MAINTENANCE' | 'CLEANING'; kindLabel: string;
  startDate: string; endDate: string | null; cost: string;
  description: string | null; expenseNo: string | null;
  rentalNo?: string | null; isOpen: boolean;
}

interface Suggestion {
  rentalId: number; rentalNo: string; rentalDate: string;
  status: string; customer: string;
}

const egp = (v: string) =>
  new Intl.NumberFormat('ar-EG', { numberingSystem: 'latn', minimumFractionDigits: 2 })
    .format(Number(v));

/** سجل الصيانة والتنظيف داخل بطاقة القطعة — بأنماط الواجهة القائمة. */
export default function UpkeepPanel({
  itemId, history, methods, canManage,
}: {
  itemId: number;
  history: { records: Record_[]; maintenanceCost: string; cleaningCost: string; upkeepCost: string };
  methods: { id: number; nameAr: string }[];
  canManage: boolean;
}) {
  const router = useRouter();
  const [kind, setKind] = useState<'MAINTENANCE' | 'CLEANING'>('MAINTENANCE');
  const [cost, setCost] = useState('');
  const [description, setDescription] = useState('');
  const [methodId, setMethodId] = useState(methods[0]?.id ?? 0);
  const [msg, setMsg] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);
  const [busy, setBusy] = useState(false);
  // ★ M13-1: اقتراح العقد — لا يُربط تلقائيًا، والمستخدم يؤكده صراحةً
  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);
  const [rentalId, setRentalId] = useState<number | ''>('');

  async function loadSuggestions() {
    const res = await fetch(`/api/upkeep/suggestions?itemId=${itemId}`);
    const json = await res.json();
    if (json.ok) setSuggestions(json.data.suggestions);
  }

  async function call(url: string, body: Record<string, unknown>) {
    setBusy(true); setMsg(null);
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    const json = await res.json();
    setBusy(false);
    if (!json.ok) { setMsg({ type: 'err', text: json.error?.message ?? 'تعذّر التنفيذ.' }); return; }
    setCost(''); setDescription('');
    router.refresh();
  }

  return (
    <div className="card">
      <div className="card-header">الصيانة والتنظيف</div>

      <div className="p-5 grid grid-cols-3 gap-4 text-sm border-b border-slate-200">
        <div>
          <div className="text-slate-500">تكلفة الصيانة</div>
          <div className="num font-bold">{egp(history.maintenanceCost)}</div>
        </div>
        <div>
          <div className="text-slate-500">تكلفة التنظيف</div>
          <div className="num font-bold">{egp(history.cleaningCost)}</div>
        </div>
        <div>
          <div className="text-slate-500">الإجمالي</div>
          <div className="num font-bold text-brand">{egp(history.upkeepCost)}</div>
        </div>
      </div>

      {canManage && (
        <div className="p-5 grid grid-cols-1 md:grid-cols-5 gap-3 items-end border-b border-slate-200">
          <div>
            <label className="label">النوع</label>
            <select className="input" value={kind}
                    onChange={(e) => {
                      const k = e.target.value as typeof kind;
                      setKind(k);
                      setRentalId('');
                      if (k === 'CLEANING' && suggestions.length === 0) void loadSuggestions();
                    }}>
              <option value="MAINTENANCE">صيانة</option>
              <option value="CLEANING">تنظيف</option>
            </select>
          </div>
          <div>
            <label className="label">التكلفة</label>
            <input className="input num" dir="ltr" inputMode="decimal"
                   value={cost} onChange={(e) => setCost(e.target.value)} />
          </div>
          {Number(cost || 0) > 0 && (
            <div>
              <label className="label">طريقة الدفع</label>
              <select className="input" value={methodId}
                      onChange={(e) => setMethodId(Number(e.target.value))}>
                {methods.map((m) => <option key={m.id} value={m.id}>{m.nameAr}</option>)}
              </select>
            </div>
          )}
          <div>
            <label className="label">الوصف</label>
            <input className="input" value={description}
                   onChange={(e) => setDescription(e.target.value)} />
          </div>
          <button className="btn-primary" disabled={busy}
                  onClick={() => call('/api/upkeep', {
                    itemId, kind, cost: Number(cost || 0),
                    description: description || undefined,
                    paymentMethodId: Number(cost || 0) > 0 ? methodId : undefined,
                    // ★ يُرسل فقط إن أكّده المستخدم
                    rentalId: kind === 'CLEANING' && rentalId !== '' ? rentalId : undefined,
                  })}>
            {busy ? 'جارٍ…' : 'بدء'}
          </button>
        </div>
      )}

      {canManage && kind === 'CLEANING' && (
        <div className="px-5 pb-5 -mt-2">
          <label className="label">العقد المرتبط (اختياري)</label>
          <select className="input" value={rentalId}
                  onChange={(e) => setRentalId(e.target.value === '' ? '' : Number(e.target.value))}>
            <option value="">بلا عقد</option>
            {suggestions.map((s) => (
              <option key={s.rentalId} value={s.rentalId}>
                {s.rentalNo} — {s.customer} ({s.rentalDate})
              </option>
            ))}
          </select>
          <p className="text-xs text-slate-400 mt-1">
            هذه <strong>اقتراحات</strong> من عقود سابقة لهذه القطعة، وليست رابطًا مستنتجًا.
            لا يُحفظ أي عقد ما لم تختره بنفسك.
          </p>
        </div>
      )}

      <div className="overflow-x-auto">
        <table className="table">
          <thead>
            <tr><th>النوع</th><th>البدء</th><th>الإنهاء</th><th>التكلفة</th><th>المصروف</th><th>العقد</th><th>الوصف</th><th></th></tr>
          </thead>
          <tbody>
            {history.records.map((r) => (
              <tr key={`${r.kind}-${r.id}`}>
                <td>{r.kindLabel}</td>
                <td className="num">{r.startDate}</td>
                <td className="num">{r.endDate ?? '—'}</td>
                <td className="num">{egp(r.cost)}</td>
                <td className="num text-xs">{r.expenseNo ?? '—'}</td>
                <td className="num text-xs">{r.rentalNo ?? '—'}</td>
                <td className="text-slate-600">{r.description ?? '—'}</td>
                <td>
                  {r.isOpen && canManage && (
                    <button className="text-brand-light font-semibold text-sm" disabled={busy}
                            onClick={() => call('/api/upkeep/complete', {
                              recordId: r.id, kind: r.kind, toStatus: 'AVAILABLE',
                            })}>
                      إنهاء
                    </button>
                  )}
                </td>
              </tr>
            ))}
            {history.records.length === 0 && (
              <tr><td colSpan={8} className="text-center text-slate-500 py-6">لا توجد عمليات مسجّلة.</td></tr>
            )}
          </tbody>
        </table>
      </div>

      <p className="px-5 py-4 text-xs text-slate-500 border-t border-slate-200">
        تكلفة الصيانة والتنظيف مصروف تشغيلي يخفض الربح، وتُرصد على القطعة لتظهر في ربحية عمرها.
      </p>
    </div>
  );
}
