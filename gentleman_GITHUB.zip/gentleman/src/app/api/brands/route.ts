import { route } from '@/lib/api';
import { listBrands, createBrand, brandSchema } from '@/services/catalog.service';

export const GET = route({ handler: () => listBrands() });
export const POST = route({ schema: brandSchema, handler: ({ input }) => createBrand(input) });
