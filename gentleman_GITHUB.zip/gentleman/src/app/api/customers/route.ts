import { route } from '@/lib/api';
import {
  listCustomers, customerQuerySchema,
  createCustomer, createCustomerSchema,
  updateCustomer, updateCustomerSchema,
} from '@/services/customer.service';

export const GET = route({ schema: customerQuerySchema, handler: ({ input }) => listCustomers(input) });
export const POST = route({ schema: createCustomerSchema, handler: ({ input }) => createCustomer(input) });
export const PATCH = route({ schema: updateCustomerSchema, handler: ({ input }) => updateCustomer(input) });
