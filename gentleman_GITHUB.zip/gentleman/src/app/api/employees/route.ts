import { route } from '@/lib/api';
import {
  listEmployees, createEmployee, createEmployeeSchema,
  updateEmployee, updateEmployeeSchema,
} from '@/services/employee.service';

export const GET = route({ handler: () => listEmployees() });
export const POST = route({ schema: createEmployeeSchema, handler: ({ input }) => createEmployee(input) });
export const PATCH = route({ schema: updateEmployeeSchema, handler: ({ input }) => updateEmployee(input) });
