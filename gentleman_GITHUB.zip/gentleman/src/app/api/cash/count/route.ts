import { route } from '@/lib/api';
import { cashCountPreview, recordCashCount, countSchema, dateQuerySchema } from '@/services/cash.service';

export const GET = route({ schema: dateQuerySchema, handler: ({ input }) => cashCountPreview(input.date) });
export const POST = route({ schema: countSchema, handler: ({ input }) => recordCashCount(input) });
