import { route } from '@/lib/api';
import { listRoles } from '@/services/user.service';

export const GET = route({ handler: () => listRoles() });
