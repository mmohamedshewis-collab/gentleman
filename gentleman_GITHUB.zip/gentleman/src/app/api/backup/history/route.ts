import { route } from '@/lib/api';
import { exportHistory, exportHistorySchema } from '@/services/backup.service';

export const GET = route({ schema: exportHistorySchema, handler: ({ input }) => exportHistory(input) });
