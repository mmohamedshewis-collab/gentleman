import { z } from 'zod';
import { Decimal } from 'decimal.js';
import { prisma } from '@/lib/db';
import { requireSession, type SessionUser } from '@/lib/auth/session';
import { can } from '@/lib/auth/rbac';
import { businessToday, formatDate } from '@/lib/date';
import { round2, add } from '@/lib/money';
import { runReport } from '@/services/report.service';
import { inventorySummary } from '@/services/inventory.service';
import { currentInsuranceCashBalance } from '@/services/cash.service';
import { employeePerformanceReport } from '@/services/employee.service';

/**
 * لوحة التحكم — **مجمِّع فقط**.
 *
 * ★ لا تحسب رقمًا واحدًا بنفسها. كل مؤشر يستدعي دالة معتمدة قائمة
 *   (تقارير M7 · مخزون M1 · نقدية وتأمين M6 · أداء الموظفين M6).
 *   لذلك يستحيل بنيويًا أن يختلف رقم اللوحة عن رقم تقريره.
 *
 * ⛔ قراءة فقط · لا منطق مالي جديد · لا تغيير في قاعدة البيانات.
 */

export const dashboardQuerySchema = z.object({
  from: z.string().optional(),
  to: z.string().optional(),
});

export type DashboardQuery = z.infer<typeof dashboardQuerySchema>;

export interface Kpi {
  key: string;
  label: string;
  value: string;
  /** نوع القيمة للعرض */
  kind: 'money' | 'count';
  /** رابط التقرير المقابل بنفس الفلتر — يربط اللوحة بـ M7 بلا تكرار */
  href: string | null;
  hint?: string;
}

export interface DashboardResult {
  from: string;
  to: string;
  today: string;
  /** مؤشرات اليوم — تتبع تاريخ العمل لا الفلتر */
  todayKpis: Kpi[];
  /** أرصدة لحظية — لا تتأثر بالفلتر إطلاقًا (D4) */
  balanceKpis: Kpi[];
  /** مؤشرات الفترة المختارة */
  periodKpis: Kpi[];
  /** أفضل خمسة موظفين في الفترة */
  employees: {
    fullName: string;
    netRental: string;
    netSales: string;
    commissionTotal: string;
    performanceIndex: string | null;
  }[];
  notes: string[];
}

/** مجموع عمود مالي من صفوف تقرير. */
const sumColumn = (rows: Record<string, unknown>[], key: string): Decimal => {
  if (rows.length === 0) return round2(0);
  return add(...rows.map((r) => {
    const v = r[key];
    const n = v === null || v === undefined || v === '' ? 0 : Number(v);
    return Number.isFinite(n) ? n : 0;
  }));
};

const q = (params: Record<string, string>) =>
  `/reports?${new URLSearchParams(params).toString()}`;

export async function getDashboard(input: DashboardQuery): Promise<DashboardResult> {
  const user: SessionUser = await requireSession();

  const todayStr = formatDate(businessToday());
  const from = input.from ?? `${todayStr.slice(0, 8)}01`;
  const to = input.to ?? todayStr;

  const canOperational = can(user, 'reports.operational.view');
  const canFinancial = can(user, 'reports.financial.view');
  const canInventory = can(user, 'items.view');
  const canCommissions = can(user, 'commissions.view');

  const todayKpis: Kpi[] = [];
  const balanceKpis: Kpi[] = [];
  const periodKpis: Kpi[] = [];
  const notes: string[] = [];

  // ===================== مؤشرات اليوم =====================
  // تتبع تاريخ العمل بتوقيت مصر، لا الفلتر المختار.
  if (canOperational) {
    const [rentals, sales] = await Promise.all([
      runReport({ key: 'daily-rentals', from: todayStr, to: todayStr }),
      runReport({ key: 'daily-sales', from: todayStr, to: todayStr }),
    ]);

    todayKpis.push({
      key: 'today-rentals',
      label: 'تأجيرات اليوم',
      value: String(rentals.rows.length),
      kind: 'count',
      href: q({ key: 'daily-rentals', from: todayStr, to: todayStr }),
    });
    todayKpis.push({
      key: 'today-sales',
      label: 'مبيعات اليوم',
      value: String(sales.rows.length),
      kind: 'count',
      href: q({ key: 'daily-sales', from: todayStr, to: todayStr }),
    });
  }

  if (canFinancial) {
    const revenue = await runReport({ key: 'revenue', from: todayStr, to: todayStr });
    todayKpis.push({
      key: 'today-revenue',
      label: 'إيراد اليوم',
      value: sumColumn(revenue.rows, 'amount').toString(),
      kind: 'money',
      href: q({ key: 'revenue', from: todayStr, to: todayStr }),
      // D2: الإيراد ليس النقدية — تنبيه صريح بجوار البطاقتين
      hint: 'الإيراد المستحق اليوم — يختلف عن النقدية المحصَّلة',
    });
    notes.push('الإيراد يختلف عن حركة النقدية: البيع بالفيزا إيراد بلا نقدية، وتحصيل المتأخرات نقدية بلا إيراد.');
  }

  // ملاحظة: صافي حركة النقدية اليوم يعرضه المكوّن القائم `CashMovementBox` (M6)
  // ولا يُكرَّر هنا كمؤشر — مصدر واحد لكل رقم.

  // ===================== أرصدة لحظية (D4) =====================
  // لا تتأثر بالفلتر لأنها أرصدة نقطة زمنية لا مجاميع فترة.
  if (canFinancial) {
    const outstanding = await runReport({ key: 'outstanding' });
    balanceKpis.push({
      key: 'outstanding',
      label: 'مستحقات على العملاء',
      value: sumColumn(outstanding.rows, 'remaining').toString(),
      kind: 'money',
      href: q({ key: 'outstanding' }),
      hint: 'رصيد لحظي — لا يتأثر بالفترة المختارة',
    });

    const insurance = await currentInsuranceCashBalance(businessToday());
    balanceKpis.push({
      key: 'insurance-balance',
      label: 'رصيد التأمينات (أموال عملاء)',
      value: insurance.toString(),
      kind: 'money',
      href: q({ key: 'insurance-balance', from, to }),
      hint: 'ليست إيرادًا ولا مال المحل — التزام تجاه العملاء',
    });
    notes.push('التأمينات أموال عملاء محتفَظ بها، وليست إيرادًا ولا جزءًا من نقدية المحل.');
  }

  if (canOperational) {
    const overdue = await runReport({ key: 'overdue-items' });
    balanceKpis.push({
      key: 'overdue',
      label: 'تأجيرات متأخرة',
      value: String(overdue.rows.length),
      kind: 'count',
      href: q({ key: 'overdue-items' }),
      hint: 'رصيد لحظي',
    });
  }

  if (canInventory) {
    const inv = await inventorySummary();
    balanceKpis.push({
      key: 'available-items',
      label: 'قطع متاحة',
      value: String(inv.statusCounts.AVAILABLE ?? 0),
      kind: 'count',
      href: canOperational ? q({ key: 'available-items' }) : null,
      hint: 'رصيد لحظي',
    });
    balanceKpis.push({
      key: 'rented-items',
      label: 'قطع مؤجرة',
      value: String((inv.statusCounts.RENTED ?? 0) + (inv.statusCounts.OVERDUE ?? 0)),
      kind: 'count',
      href: canOperational ? q({ key: 'rented-items' }) : null,
      hint: 'رصيد لحظي',
    });
  }

  // ===================== مؤشرات الفترة =====================
  if (canFinancial) {
    const [revenue, expenses, profit] = await Promise.all([
      runReport({ key: 'revenue', from, to }),
      runReport({ key: 'expenses', from, to }),
      runReport({ key: 'net-profit', from, to }),
    ]);

    periodKpis.push({
      key: 'period-revenue',
      label: 'إيراد الفترة',
      value: sumColumn(revenue.rows, 'amount').toString(),
      kind: 'money',
      href: q({ key: 'revenue', from, to }),
    });
    periodKpis.push({
      key: 'period-expenses',
      label: 'مصروفات الفترة',
      value: sumColumn(expenses.rows, 'amount').toString(),
      kind: 'money',
      href: q({ key: 'expenses', from, to }),
    });

    // D3: الربح تقديري — نأخذ السطر الأخير من تقرير الأرباح نفسه
    const profitRow = profit.rows[profit.rows.length - 1];
    periodKpis.push({
      key: 'period-profit',
      label: 'صافي الربح التقديري',
      value: profitRow ? String(profitRow.amount) : '0',
      kind: 'money',
      href: q({ key: 'net-profit', from, to }),
      hint: 'تقديري: تكلفة القطعة تُحمَّل عند بيعها — راجع ربحية القطعة عبر عمرها',
    });
    notes.push('صافي الربح تقديري لأن تكلفة شراء القطعة تُحمَّل عند بيعها لا موزّعة على عمرها.');
  }

  // ===================== أداء الموظفين =====================
  let employees: DashboardResult['employees'] = [];
  if (canCommissions) {
    const report = await employeePerformanceReport({ from, to });
    employees = report.rows
      .slice()
      .sort((a, b) => Number(b.netRental) + Number(b.netSales) - (Number(a.netRental) + Number(a.netSales)))
      .slice(0, 5)
      .map((r) => ({
        fullName: r.fullName,
        netRental: r.netRental,
        netSales: r.netSales,
        commissionTotal: r.commissionTotal,
        performanceIndex: r.performanceIndex,
      }));
    notes.push('أرقام عمولة الموظفين تحليلية ولا تدخل الربح — العمولة تؤثر عليه عبر مصروف صرفها فقط.');
  }

  return { from, to, today: todayStr, todayKpis, balanceKpis, periodKpis, employees, notes };
}
