import { route } from '@/lib/api';
import { queryAuditLogs, auditQuerySchema } from '@/services/audit.service';

export const GET = route({ schema: auditQuerySchema, handler: ({ input }) => queryAuditLogs(input) });
