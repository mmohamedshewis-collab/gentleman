import { notFound } from 'next/navigation';
import { getSale } from '@/services/sale.service';
import { getSession } from '@/lib/auth/session';
import { getStringSetting } from '@/lib/settings';
import { formatEGP } from '@/lib/money';
import { formatDate, formatDateTime } from '@/lib/date';
import PrintButton from '@/components/PrintButton';
import VoidSaleForm from '@/components/VoidSaleForm';

export const dynamic = 'force-dynamic';

export default async function InvoicePage({ params }: { params: { id: string } }) {
  const id = Number(params.id);
  if (!Number.isFinite(id)) notFound();

  const sale = await getSale(id);
  const session = await getSession();
  const canVoid = (session?.permissions.has('sales.void') ?? false) && sale.status === 'COMPLETED';
  const canSeeProfit = session?.permissions.has('reports.financial.view') ?? false;

  const shopName = await getStringSetting('shop.name');
  const shopPhone = await getStringSetting('shop.phone');
  const shopAddress = await getStringSetting('shop.address');

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between print:hidden">
        <h1 className="section-title">فاتورة بيع</h1>
        <PrintButton />
      </div>

      {sale.status === 'VOIDED' && (
        <div className="rounded-lg bg-red-50 border border-red-200 p-4 text-danger font-bold">
          فاتورة ملغاة — {sale.voidReason}
        </div>
      )}

      <div className="card print:shadow-none print:border-0">
        <div className="p-6 border-b border-slate-200 text-center">
          <h2 className="text-2xl font-bold text-brand">{shopName || 'Gentleman'}</h2>
          {shopAddress && <p className="text-sm text-slate-600 mt-1">{shopAddress}</p>}
          {shopPhone && <p className="text-sm text-slate-600 num">{shopPhone}</p>}
        </div>

        <div className="p-6 grid grid-cols-2 gap-4 text-sm border-b border-slate-200">
          <div><span className="text-slate-500">رقم الفاتورة: </span><span className="num font-semibold">{sale.invoiceNo}</span></div>
          <div><span className="text-slate-500">التاريخ: </span><span className="num">{formatDate(sale.saleDate)}</span></div>
          <div><span className="text-slate-500">العميل: </span><span className="font-semibold">{sale.customer.isWalkIn ? 'عميل نقدي' : sale.customer.fullName}</span></div>
          <div><span className="text-slate-500">الموظف: </span>{sale.employee?.fullName ?? '—'}</div>
        </div>

        <table className="table">
          <thead>
            <tr><th>القطعة</th><th>الوصف</th><th>السعر</th><th>الخصم</th><th>الصافي</th></tr>
          </thead>
          <tbody>
            {sale.items.map((li) => (
              <tr key={li.id}>
                <td className="num">{li.item.itemCode}</td>
                <td>
                  {li.item.product.nameAr}
                  {li.item.product.size && ` · مقاس ${li.item.product.size}`}
                  {li.isDamagedSale && <span className="badge bg-amber-100 text-warn mr-2">بيع قطعة تالفة</span>}
                </td>
                <td className="num">{formatEGP(li.unitPrice.toString())}</td>
                <td className="num">{formatEGP(li.discount.toString())}</td>
                <td className="num font-semibold">{formatEGP(li.netPrice.toString())}</td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className="p-6 space-y-2 text-sm border-t border-slate-200">
          <div className="flex justify-between"><span>الإجمالي قبل الخصم</span><span className="num">{formatEGP(sale.subtotal.toString())}</span></div>
          <div className="flex justify-between"><span>الخصم</span><span className="num">{formatEGP(sale.discount.toString())}</span></div>
          <div className="flex justify-between font-bold text-base border-t border-slate-200 pt-2">
            <span>صافي البيع</span><span className="num">{formatEGP(sale.netAmount.toString())}</span>
          </div>
          {sale.vatStatus !== 'NOT_APPLICABLE' && (
            <div className="flex justify-between"><span>ضريبة القيمة المضافة</span><span className="num">{formatEGP(sale.vatAmount.toString())}</span></div>
          )}
          <div className="flex justify-between"><span>المدفوع</span><span className="num">{formatEGP(sale.paidAmount.toString())}</span></div>
          <div className="flex justify-between font-semibold text-ok"><span>المتبقي</span><span className="num">{formatEGP(sale.remaining)}</span></div>
          <div className="text-xs text-slate-500 pt-2">
            طريقة الدفع: {sale.payments.map((p) => p.paymentMethod.nameAr).join('، ') || '—'}
          </div>
        </div>
      </div>

      {canSeeProfit && (
        <div className="card print:hidden">
          <div className="card-header">تحليل الربحية (لا يظهر في الفاتورة)</div>
          <div className="p-5 grid grid-cols-3 gap-4 text-sm">
            <div><div className="text-slate-500">صافي البيع</div><div className="num font-bold">{formatEGP(sale.netAmount.toString())}</div></div>
            <div><div className="text-slate-500">تكلفة شراء القطع</div><div className="num font-bold">{formatEGP(sale.totalCost.toString())}</div></div>
            <div>
              <div className="text-slate-500">مجمل الربح</div>
              <div className={`num font-bold ${Number(sale.grossProfit) < 0 ? 'text-danger' : 'text-ok'}`}>
                {formatEGP(sale.grossProfit)}
              </div>
            </div>
          </div>
          <p className="px-5 pb-5 text-xs text-slate-500">
            تكلفة الشراء تُستخدم لتحليل الربحية فقط. ربحية القطعة الحقيقية تظهر في بطاقة القطعة
            شاملةً إيرادات تأجيرها عبر عمرها.
          </p>
        </div>
      )}

      {canVoid && <VoidSaleForm saleId={sale.id} invoiceNo={sale.invoiceNo} />}

      <p className="text-xs text-slate-400 print:hidden num">
        أُنشئت في {formatDateTime(sale.createdAt)}
      </p>
    </div>
  );
}
