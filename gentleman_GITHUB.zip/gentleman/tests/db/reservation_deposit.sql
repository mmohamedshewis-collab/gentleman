\set ON_ERROR_STOP off
\pset pager off
\t on
DELETE FROM payments WHERE payment_no LIKE 'DEP-%';
DELETE FROM item_bookings WHERE source_id = 9001;

\echo '=== تهيئة: حجز بعربون 300 ثم عقد بـ1,500 ==='
INSERT INTO reservations (reservation_no, customer_id, event_date, pickup_date, return_date, deposit_amount, created_by)
VALUES ('RES-DEP-1', 2, CURRENT_DATE+12, CURRENT_DATE+10, CURRENT_DATE+12, 300, 1)
ON CONFLICT (reservation_no) DO NOTHING;

INSERT INTO payments (payment_no, purpose, reservation_id, customer_id, amount, payment_method_id, created_by)
SELECT 'DEP-1', 'RESERVATION_DEPOSIT', id, 2, 300, 1, 1 FROM reservations WHERE reservation_no='RES-DEP-1';

INSERT INTO rentals (rental_no, customer_id, rental_date, expected_return_date, subtotal, discount,
  net_amount, gross_amount, total_due, remaining_amount, created_by)
VALUES ('R-DEP-1', 2, CURRENT_DATE, CURRENT_DATE+2, 1500, 0, 1500, 1500, 1500, 1500, 1)
ON CONFLICT (rental_no) DO NOTHING;

SELECT '  قبل التخصيص: مستحق=' || total_due || ' مدفوع=' || paid_amount || ' متبقٍ=' || remaining_amount
  FROM rentals WHERE rental_no='R-DEP-1';

\echo ''
\echo '=== ★ التخصيص: ربط الدفعة القائمة بالعقد (لا دفعة جديدة) ==='
UPDATE payments SET rental_id = (SELECT id FROM rentals WHERE rental_no='R-DEP-1')
 WHERE payment_no='DEP-1' AND rental_id IS NULL;

SELECT '  بعد التخصيص: مستحق=' || total_due || ' مدفوع=' || paid_amount || ' متبقٍ=' || remaining_amount
  FROM rentals WHERE rental_no='R-DEP-1';

\echo ''
\echo '=== ★ عدد الدفعات: يجب أن تبقى واحدة ==='
SELECT '  دفعات مرتبطة بالعقد = ' || count(*) FROM payments WHERE rental_id=(SELECT id FROM rentals WHERE rental_no='R-DEP-1');
SELECT '  الدفعة ما زالت مربوطة بالحجز = ' || (reservation_id IS NOT NULL) FROM payments WHERE payment_no='DEP-1';
SELECT '  المبلغ والتاريخ لم يتغيّرا: ' || amount || ' | ' || payment_date FROM payments WHERE payment_no='DEP-1';

\echo ''
\echo '=== ★ منع التخصيص مرتين: شرط rental_id IS NULL ==='
UPDATE payments SET rental_id = 99999 WHERE payment_no='DEP-1' AND rental_id IS NULL;
SELECT '  العقد المرتبط لم يتغيّر = ' || (rental_id = (SELECT id FROM rentals WHERE rental_no='R-DEP-1')) FROM payments WHERE payment_no='DEP-1';

\echo ''
\echo '=== ★ منع السداد الزائد: تخصيص عربون يتجاوز العقد ==='
INSERT INTO rentals (rental_no, customer_id, rental_date, expected_return_date, subtotal, discount,
  net_amount, gross_amount, total_due, remaining_amount, created_by)
VALUES ('R-DEP-2', 2, CURRENT_DATE, CURRENT_DATE+2, 200, 0, 200, 200, 200, 200, 1)
ON CONFLICT (rental_no) DO NOTHING;
INSERT INTO payments (payment_no, purpose, reservation_id, customer_id, amount, payment_method_id, created_by)
SELECT 'DEP-2', 'RESERVATION_DEPOSIT', id, 2, 500, 1, 1 FROM reservations WHERE reservation_no='RES-DEP-1';
UPDATE payments SET rental_id = (SELECT id FROM rentals WHERE rental_no='R-DEP-2') WHERE payment_no='DEP-2';
