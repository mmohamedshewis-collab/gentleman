import { monthlyTreasuryReconciliation } from '@/services/cash.service';
import { formatEGP } from '@/lib/money';
import { businessToday, formatDate } from '@/lib/date';

export const dynamic = 'force-dynamic';

export default async function ReconcilePage({
  searchParams,
}: { searchParams: { from?: string; to?: string } }) {
  const today = formatDate(businessToday());
  const from = searchParams.from ?? `${today.slice(0, 8)}01`;
  const to = searchParams.to ?? today;

  const r = await monthlyTreasuryReconciliation({ from, to });

  return (
    <div className="space-y-6">
      <h1 className="section-title">مطابقة الخزينة الشهرية</h1>

      <div className="card">
        <div className="card-header">من {from} إلى {to}</div>
        <form className="p-4 flex gap-3 items-end border-b border-slate-200" action="/cash/reconcile">
          <div><label className="label">من</label><input className="input num" type="date" name="from" defaultValue={from} /></div>
          <div><label className="label">إلى</label><input className="input num" type="date" name="to" defaultValue={to} /></div>
          <button className="btn-primary">عرض</button>
        </form>

        <div className="p-5 grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
          <div><div className="text-slate-500">المقبوضات النقدية</div><div className="num font-bold text-ok">{formatEGP(r.totalInflow)}</div></div>
          <div><div className="text-slate-500">المدفوعات النقدية</div><div className="num font-bold text-danger">{formatEGP(r.totalOutflow)}</div></div>
          <div><div className="text-slate-500">صافي حركة الشركة</div><div className="num font-bold">{formatEGP(r.netMovement)}</div></div>
          <div><div className="text-slate-500">المرحَّل للخزينة</div><div className="num font-bold text-brand">{formatEGP(r.totalTransferred)}</div></div>
          <div><div className="text-slate-500">إجمالي العجز</div><div className="num font-bold text-danger">{formatEGP(r.totalShortage)}</div></div>
          <div><div className="text-slate-500">إجمالي الزيادة</div><div className="num font-bold text-warn">{formatEGP(r.totalSurplus)}</div></div>
          <div><div className="text-slate-500">مبالغ غير مرحَّلة</div><div className="num font-bold">{formatEGP(r.notTransferred)}</div></div>
          <div><div className="text-slate-500">رصيد التأمينات آخر الفترة</div><div className="num font-bold text-brand-light">{formatEGP(r.insuranceBalanceAtEnd)}</div></div>
          <div><div className="text-slate-500">أيام مغلقة</div><div className="num font-bold">{r.closedDays}</div></div>
          <div><div className="text-slate-500">أيام غير مغلقة</div><div className="num font-bold">{r.openDays}</div></div>
        </div>
      </div>

      <div className="card overflow-hidden">
        <div className="card-header">تفصيل الأيام</div>
        <div className="overflow-x-auto">
          <table className="table">
            <thead>
              <tr><th>التاريخ</th><th>المقبوض</th><th>المدفوع</th><th>المتوقع</th><th>الفعلي</th><th>الفرق</th><th>المرحَّل</th><th>الحالة</th></tr>
            </thead>
            <tbody>
              {r.rows.map((d) => (
                <tr key={d.date}>
                  <td className="num">{d.date}</td>
                  <td className="num">{formatEGP(d.inflow)}</td>
                  <td className="num">{formatEGP(d.outflow)}</td>
                  <td className="num">{formatEGP(d.expectedPhysical)}</td>
                  <td className="num">{formatEGP(d.actualCounted)}</td>
                  <td className={`num font-semibold ${Number(d.variance) < 0 ? 'text-danger' : Number(d.variance) > 0 ? 'text-warn' : ''}`}>
                    {formatEGP(d.variance)}
                  </td>
                  <td className="num">{formatEGP(d.transferred)}</td>
                  <td>
                    <span className={`badge ${d.status === 'CLOSED' ? 'bg-slate-100 text-slate-500' : 'bg-green-100 text-ok'}`}>
                      {d.status === 'CLOSED' ? 'مغلق' : 'مفتوح'}
                    </span>
                  </td>
                </tr>
              ))}
              {r.rows.length === 0 && (
                <tr><td colSpan={8} className="text-center text-slate-500 py-8">لا توجد أيام مجرودة في هذه الفترة.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
