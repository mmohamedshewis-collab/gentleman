\set ON_ERROR_STOP off
\pset pager off
\t on

\echo '=== C1: الفرق محسوب — إدخال فرق خاطئ يُرفض ==='
INSERT INTO daily_cash_closings (business_date, expected_company_position, expected_insurance_cash,
  expected_physical, actual_counted, variance)
VALUES (CURRENT_DATE - 5, 200, 1000, 1200, 1150, 0);

\echo '=== C1ب: الفرق الصحيح يُقبل ==='
INSERT INTO daily_cash_closings (business_date, expected_company_position, expected_insurance_cash,
  expected_physical, actual_counted, variance, counted_by, counted_at)
VALUES (CURRENT_DATE - 5, 200, 1000, 1200, 1150, -50, 1, now());
SELECT 'اليوم: متوقع=' || expected_physical || ' فعلي=' || actual_counted || ' فرق=' || variance
  FROM daily_cash_closings WHERE business_date = CURRENT_DATE - 5;

\echo ''
\echo '=== C1ج: المتوقع لا يساوي مجموع مكوناته (يُرفض) ==='
INSERT INTO daily_cash_closings (business_date, expected_company_position, expected_insurance_cash,
  expected_physical, actual_counted, variance)
VALUES (CURRENT_DATE - 4, 200, 1000, 9999, 9999, 0);

\echo ''
\echo '=== C4: الترحيل قبل إغلاق اليوم (يُرفض) ==='
INSERT INTO cash_transfers (transfer_no, closing_id, transfer_date, amount)
SELECT 'TR-1', id, CURRENT_DATE, 150 FROM daily_cash_closings WHERE business_date = CURRENT_DATE - 5;

\echo '=== إغلاق اليوم ==='
UPDATE daily_cash_closings SET status='CLOSED', closed_by=1, closed_at=now()
 WHERE business_date = CURRENT_DATE - 5;

\echo '=== C4ب: الترحيل الجزئي (يُرفض) — المطلوب 150 ==='
INSERT INTO cash_transfers (transfer_no, closing_id, transfer_date, amount)
SELECT 'TR-2', id, CURRENT_DATE, 100 FROM daily_cash_closings WHERE business_date = CURRENT_DATE - 5;

\echo '=== C4ج: ترحيل يشمل التأمين (يُرفض) ==='
INSERT INTO cash_transfers (transfer_no, closing_id, transfer_date, amount)
SELECT 'TR-3', id, CURRENT_DATE, 1150 FROM daily_cash_closings WHERE business_date = CURRENT_DATE - 5;

\echo '=== C4د: الترحيل الكامل 1150-1000=150 (يُقبل) ==='
INSERT INTO cash_transfers (transfer_no, closing_id, transfer_date, amount, transferred_by)
SELECT 'TR-4', id, CURRENT_DATE, 150, 1 FROM daily_cash_closings WHERE business_date = CURRENT_DATE - 5;
SELECT 'رُحِّل: ' || amount || ' | والفرق ما زال ' ||
  (SELECT variance FROM daily_cash_closings WHERE business_date = CURRENT_DATE - 5)
  FROM cash_transfers WHERE transfer_no='TR-4';

\echo ''
\echo '=== C2: إعادة فتح يوم مغلق (يُرفض) ==='
UPDATE daily_cash_closings SET status='OPEN' WHERE business_date = CURRENT_DATE - 5;

\echo '=== C2ب: تعديل جرد يوم مغلق (يُرفض) ==='
UPDATE daily_cash_closings SET actual_counted=9999, variance=8799 WHERE business_date = CURRENT_DATE - 5;

\echo ''
\echo '=== C3: تسجيل مصروف بتاريخ يوم مغلق (يُرفض) ==='
INSERT INTO expenses (expense_no, expense_date, category_id, amount, payment_method_id, created_by)
VALUES ('EXP-CLOSED', CURRENT_DATE - 5, 1, 100, 1, 1);

\echo '=== C3ب: تسجيل دفعة بتاريخ يوم مغلق (يُرفض) ==='
INSERT INTO payments (payment_no, payment_date, purpose, customer_id, amount, payment_method_id, created_by)
VALUES ('PAY-CLOSED', CURRENT_DATE - 5, 'OTHER', 2, 100, 1, 1);

\echo '=== C3ج: تسجيل بتاريخ يوم مفتوح (يُقبل) ==='
INSERT INTO expenses (expense_no, expense_date, category_id, amount, payment_method_id, created_by)
VALUES ('EXP-OPEN', CURRENT_DATE, 1, 100, 1, 1);
SELECT 'سُجِّل: ' || expense_no FROM expenses WHERE expense_no='EXP-OPEN';

\echo ''
\echo '=== C8: حذف يوم أو ترحيل (يُرفض) ==='
DELETE FROM daily_cash_closings WHERE business_date = CURRENT_DATE - 5;
DELETE FROM cash_transfers WHERE transfer_no='TR-4';
