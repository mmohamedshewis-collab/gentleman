import { describe, it, expect } from 'vitest';
import { readFileSync } from 'node:fs';
import {
  MOVEMENT_RULES, dashboardMovement, companyCashPosition,
  insuranceCashBalance, countCash, movementLabel, type CashMovementType,
} from '../src/lib/cash/cash-movement';
import {
  auditClassification, profitToCashBridge, unexplainedDifference,
  assertCommissionParity, revenueOf, expenseOf,
  REVENUE_MOVEMENTS, EXPENSE_MOVEMENTS,
  CASH_OUT_NOT_EXPENSE, CASH_IN_NOT_REVENUE,
} from '../src/lib/finance/reconciliation';

const s = (v: { toString(): string }) => v.toString();

// ==================== D-1: تحويل التأمين الراكد ====================

describe('★ D-1 — تحويل التأمين الراكد', () => {
  const r = MOVEMENT_RULES.INSURANCE_TRANSFERRED;

  it('لا يُصنَّف تحصيل تأجير', () => {
    expect(movementLabel('INSURANCE_TRANSFERRED')).toBe('تحويل تأمين راكد للمحل');
    expect(movementLabel('INSURANCE_TRANSFERRED')).not.toBe(movementLabel('RENTAL_COLLECTION'));
  });

  it('★ ليس مصروفًا', () => {
    expect(r.isExpense).toBe(false);
  });

  it('★ لا حركة نقد مادية — المال في الدرج أصلًا', () => {
    expect(r.direction).toBe('NONE');
    expect(r.inDashboardMovement).toBe(false);
    expect(s(dashboardMovement([{ type: 'INSURANCE_TRANSFERRED', amount: 500 }]).net)).toBe('0');
  });

  it('★ يرفع مركز نقدية الشركة ويخفض رصيد التأمين', () => {
    expect(s(companyCashPosition([{ type: 'INSURANCE_TRANSFERRED', amount: 500 }]))).toBe('500');
    expect(r.affectsInsuranceBalance).toBe(true);
  });

  it('★ إيراد بقرار Q13 المعتمد — وتقرير M7 يحتسبه كذلك', () => {
    expect(r.isRevenue).toBe(true);
    const report = readFileSync('src/services/report.service.ts', 'utf8');
    expect(report).toContain('TRANSFERRED_TO_COMPANY');
  });

  it('★ الجرد يتطابق بعد التحويل — لا فرق وهمي', () => {
    // تأمين 1,000 في الدرج · تحويل 1,000 راكد للمحل · الدرج لم يتغيّر
    const position = companyCashPosition([{ type: 'INSURANCE_TRANSFERRED', amount: 1000 }]);
    const balance = insuranceCashBalance({
      openingBalance: 0, collected: 1000, refunded: 0, retained: 0, forfeited: 1000,
    });
    const count = countCash({
      companyPosition: position, insuranceBalance: balance, actualCounted: 1000,
    });
    expect(s(position)).toBe('1000');
    expect(s(balance)).toBe('0');
    expect(s(count.expectedPhysical)).toBe('1000');
    expect(s(count.variance)).toBe('0');   // ★ كان +1000 قبل الإصلاح
  });

  it('★ الخدمة تدرجه في حركة اليوم', () => {
    const src = readFileSync('src/services/cash.service.ts', 'utf8');
    expect(src).toContain('TRANSFERRED_TO_COMPANY');
    expect(src).toContain('INSURANCE_TRANSFERRED');
  });

  it('★ يبقى متتبَّعًا في دفتر التأمين — لا دفتر ثانٍ', () => {
    const src = readFileSync('src/services/finance.service.ts', 'utf8');
    expect(src).toContain("hashtext('insurance_ledger')");
    expect(src).toContain('balanceAfter');
    expect(src).toContain('approvedBy: actor.id');
  });
});

// ==================== D-2: غرض OTHER ====================

describe('★ D-2 — غرض OTHER لا يُصنَّف تحصيل تأجير', () => {
  it('نوعان صريحان حسب الاتجاه', () => {
    expect(MOVEMENT_RULES.OTHER_IN.direction).toBe('IN');
    expect(MOVEMENT_RULES.OTHER_OUT.direction).toBe('OUT');
  });

  it('★ ليس إيرادًا ولا مصروفًا', () => {
    for (const t of ['OTHER_IN', 'OTHER_OUT'] as const) {
      expect(MOVEMENT_RULES[t].isRevenue).toBe(false);
      expect(MOVEMENT_RULES[t].isExpense).toBe(false);
    }
  });

  it('★ تسميته ليست «تحصيل تأجير»', () => {
    expect(movementLabel('OTHER_IN')).toBe('مقبوضات أخرى');
    expect(movementLabel('OTHER_OUT')).toBe('مدفوعات أخرى');
    expect(movementLabel('OTHER_IN')).not.toBe(movementLabel('RENTAL_COLLECTION'));
  });

  it('★ الخدمة تصنّف حسب الاتجاه لا بفرع افتراضي', () => {
    const src = readFileSync('src/services/cash.service.ts', 'utf8');
    expect(src).toContain("p.purpose === 'RENTAL'");
    expect(src).toContain("p.direction === 'OUT' ? 'OTHER_OUT' : 'OTHER_IN'");
  });

  it('يدخل حركة النقدية بالاتجاه الصحيح', () => {
    const m = dashboardMovement([
      { type: 'OTHER_IN', amount: 100 },
      { type: 'OTHER_OUT', amount: 40 },
    ]);
    expect(s(m.inflow)).toBe('100');
    expect(s(m.outflow)).toBe('40');
    expect(s(m.net)).toBe('60');
  });

  it('★ لا يدخل الإيراد ولا المصروف', () => {
    const lines = [{ type: 'OTHER_IN' as const, amount: 100 }, { type: 'OTHER_OUT' as const, amount: 40 }];
    expect(s(revenueOf(lines))).toBe('0');
    expect(s(expenseOf(lines))).toBe('0');
  });
});

// ==================== D-3: صحة التسميات ====================

describe('★ D-3 — كل حركة تحمل تسميتها الحقيقية', () => {
  const expected: [CashMovementType, string][] = [
    ['RENTAL_COLLECTION', 'تحصيل تأجير'],
    ['SALE_COLLECTION', 'تحصيل مبيعات'],
    ['RESERVATION_DEPOSIT', 'عربون حجز'],
    ['INSURANCE_TRANSFERRED', 'تحويل تأمين راكد للمحل'],
    ['OTHER_IN', 'مقبوضات أخرى'],
    ['OTHER_OUT', 'مدفوعات أخرى'],
    ['EXPENSE_PAYMENT', 'مصروف نقدي'],
    ['SALARY_PAYMENT', 'صرف راتب'],
    ['COMMISSION_PAYMENT', 'صرف عمولة'],
    ['EMPLOYEE_ADVANCE', 'سلفة موظف'],
    ['CUSTOMER_REFUND', 'رد مبلغ لعميل'],
  ];

  it('★ كل نوع بتسميته الصحيحة', () => {
    for (const [type, label] of expected) {
      expect(movementLabel(type), type).toBe(label);
    }
  });

  it('★ لا تسمية مكررة بين نوعين', () => {
    const labels = (Object.keys(MOVEMENT_RULES) as CashMovementType[]).map(movementLabel);
    expect(new Set(labels).size).toBe(labels.length);
  });

  it('★ الاتجاه في الكشف مشتق من قاعدة النوع لا من قائمة يدوية', () => {
    const src = readFileSync('src/services/cash.service.ts', 'utf8');
    expect(src).toContain("MOVEMENT_RULES[r.type].direction === 'IN'");
  });
});

// ==================== حارس المطابقة ====================

describe('★ حارس المطابقة — تدقيق التصنيف', () => {
  it('★ جدول التصنيف كله سليم — صفر مخالفة', () => {
    const issues = auditClassification();
    expect(issues, issues.map((i) => `${i.type}: ${i.problem}`).join(' | ')).toEqual([]);
  });

  it('★ كل نوع مصنَّف في مجموعة واحدة بالضبط', () => {
    const all = Object.keys(MOVEMENT_RULES) as CashMovementType[];
    for (const t of all) {
      const inRevenue = REVENUE_MOVEMENTS.includes(t);
      const inExpense = EXPENSE_MOVEMENTS.includes(t);
      expect(inRevenue && inExpense, `${t} إيراد ومصروف معًا`).toBe(false);
    }
  });

  it('★ خمس عمليات تخرج نقدًا وليست مصروفًا', () => {
    for (const t of CASH_OUT_NOT_EXPENSE) {
      expect(MOVEMENT_RULES[t].isExpense, t).toBe(false);
      expect(MOVEMENT_RULES[t].isRevenue, t).toBe(false);
    }
  });

  it('★ أربع عمليات تدخل نقدًا وليست إيرادًا', () => {
    for (const t of CASH_IN_NOT_REVENUE) {
      expect(MOVEMENT_RULES[t].isRevenue, t).toBe(false);
    }
  });

  it('★ العربون ورده لا يمسان الربح', () => {
    expect(MOVEMENT_RULES.RESERVATION_DEPOSIT.isRevenue).toBe(false);
    expect(MOVEMENT_RULES.RESERVATION_DEPOSIT.isExpense).toBe(false);
    expect(MOVEMENT_RULES.CUSTOMER_REFUND.isRevenue).toBe(false);
    expect(MOVEMENT_RULES.CUSTOMER_REFUND.isExpense).toBe(false);
  });

  it('★ الراتب والسلفة والشراء والترحيل: الأول مصروف والبقية لا', () => {
    expect(MOVEMENT_RULES.SALARY_PAYMENT.isExpense).toBe(true);
    for (const t of ['EMPLOYEE_ADVANCE', 'PRODUCT_PURCHASE', 'TREASURY_TRANSFER'] as const) {
      expect(MOVEMENT_RULES[t].isExpense, t).toBe(false);
    }
  });
});

describe('★ حارس المطابقة — جسر الربح إلى النقدية', () => {
  const zero = {
    priorPeriodCogs: 0, writeOffs: 0, itemPurchasesPaid: 0,
    receivablesIncrease: 0, accruedUnpaidIncrease: 0, collectedOnVoided: 0,
    advancesPaid: 0, advanceRepayments: 0, advancesSettledByDeduction: 0,
    reservationDepositsHeld: 0, insuranceRecognizedNoCash: 0,
  };

  it('بلا فروق: النقدية = الربح', () => {
    const b = profitToCashBridge({ profit: 1000, ...zero });
    expect(s(b.expectedCashMovement)).toBe('1000');
    expect(s(unexplainedDifference(b, 1000))).toBe('0');
  });

  it('★ السيناريو المرجعي المعتمد يُطابق إلى الصفر', () => {
    // ربح (9,004) · تكلفة قطعة اشتُريت سابقًا 6,000 · مستحقات 450
    const b = profitToCashBridge({
      profit: -9004, ...zero, priorPeriodCogs: 6000, receivablesIncrease: 450,
    });
    expect(s(b.expectedCashMovement)).toBe('-3454');
    expect(s(unexplainedDifference(b, -3454))).toBe('0');
  });

  it('★ عربون حجز محتفظ به يُفسَّر ولا يبقى فرقًا', () => {
    const b = profitToCashBridge({ profit: 0, ...zero, reservationDepositsHeld: 300 });
    expect(s(b.expectedCashMovement)).toBe('300');
    expect(s(unexplainedDifference(b, 300))).toBe('0');
  });

  it('★ تحويل تأمين راكد: إيراد بلا نقد — يُفسَّر ببنده', () => {
    // إيراد 500 بلا تحصيل ⟹ الربح +500 والنقدية 0
    const b = profitToCashBridge({ profit: 500, ...zero, insuranceRecognizedNoCash: 500 });
    expect(s(b.expectedCashMovement)).toBe('0');
    expect(s(unexplainedDifference(b, 0))).toBe('0');
  });

  it('★ الراتب مع خصم السلفة يُفسَّر', () => {
    // مصروف 6,000 وخروج نقدي 5,500
    const b = profitToCashBridge({ profit: -6000, ...zero, advancesSettledByDeduction: 500 });
    expect(s(b.expectedCashMovement)).toBe('-5500');
    expect(s(unexplainedDifference(b, -5500))).toBe('0');
  });

  it('★ سلفة نقدية: خروج بلا مصروف', () => {
    const b = profitToCashBridge({ profit: 0, ...zero, advancesPaid: 500 });
    expect(s(b.expectedCashMovement)).toBe('-500');
  });

  it('★ شراء قطعة نقدًا: خروج بلا مصروف', () => {
    const b = profitToCashBridge({ profit: 0, ...zero, itemPurchasesPaid: 6000 });
    expect(s(b.expectedCashMovement)).toBe('-6000');
  });

  it('★ يكشف المبلغ غير المفسَّر', () => {
    const b = profitToCashBridge({ profit: 1000, ...zero });
    // النقدية الفعلية 946 بلا بند يفسّر الـ54
    expect(s(unexplainedDifference(b, 946))).toBe('-54');
  });

  it('كل بند في الجسر له تسمية', () => {
    const b = profitToCashBridge({ profit: 0, ...zero });
    expect(b.adjustments).toHaveLength(11);
    for (const a of b.adjustments) expect(a.label.length).toBeGreaterThan(3);
  });
});

describe('★ حارس المطابقة — تكافؤ العمولة', () => {
  it('مصروف العمولات = العمولات المصروفة', () => {
    const r = assertCommissionParity({ commissionExpenseTotal: 54, commissionPaidTotal: 54 });
    expect(r.ok).toBe(true);
  });

  it('★ يكشف فرقًا بين المصروف والمصروف فعلًا', () => {
    const r = assertCommissionParity({ commissionExpenseTotal: 54, commissionPaidTotal: 40 });
    expect(r.ok).toBe(false);
    expect(s(r.difference)).toBe('14');
    expect(r.message).toContain('فرق غير مفسَّر');
  });
});

// ==================== لا مسار تصنيف ثانٍ ====================

describe('★ لا مسار تصنيف مالي ثانٍ', () => {
  it('التصنيف معرَّف في ملف واحد فقط', () => {
    const cash = readFileSync('src/lib/cash/cash-movement.ts', 'utf8');
    expect(cash).toContain('MOVEMENT_RULES');
    for (const f of ['src/services/cash.service.ts', 'src/services/report.service.ts',
                     'src/services/dashboard.service.ts']) {
      const src = readFileSync(f, 'utf8');
      expect(src, f).not.toContain('isRevenue:');
      expect(src, f).not.toContain('isExpense:');
    }
  });

  it('لوحة التحكم والتقارير من المصدر نفسه', () => {
    const dash = readFileSync('src/services/dashboard.service.ts', 'utf8');
    expect(dash).toContain("from '@/services/report.service'");
    expect(dash).not.toContain('prisma.rental.');
    expect(dash).not.toContain('prisma.sale.');
  });

  it('حساب الربح في موضع واحد', () => {
    const report = readFileSync('src/services/report.service.ts', 'utf8');
    const occurrences = (report.match(/صافي الربح التقديري/g) ?? []).length;
    expect(occurrences).toBeGreaterThan(0);
    const dash = readFileSync('src/services/dashboard.service.ts', 'utf8');
    expect(dash).toContain("key: 'net-profit'");
  });
});
