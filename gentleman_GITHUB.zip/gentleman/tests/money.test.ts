import { describe, it, expect } from 'vitest';
import { add, sub, mul, pct, round2, computeDocumentTotals, VAT_DISABLED } from '../src/lib/money';

describe('حساب المبالغ', () => {
  it('لا يقع في خطأ الفاصلة العائمة', () => {
    expect(add(0.1, 0.2).toString()).toBe('0.3');
    expect(add(1.005, 0).toString()).toBe('1.01');
  });

  it('يقرّب لمنزلتين نصف لأعلى', () => {
    expect(round2(2.345).toString()).toBe('2.35');
    expect(round2(2.344).toString()).toBe('2.34');
  });

  it('يحسب النسبة المئوية بدقة', () => {
    expect(pct(750, 14).toString()).toBe('105');
    expect(pct(333.33, 5).toString()).toBe('16.67');
  });

  it('يطرح ويضرب بدقة', () => {
    expect(sub(800, 50).toString()).toBe('750');
    expect(mul(3, 249.99).toString()).toBe('749.97');
  });
});

describe('الوضع الحالي: المحل غير خاضع للضريبة (VAT_ENABLED = false)', () => {
  it('لا تُحتسب ضريبة ولا تُحصَّل من العميل', () => {
    const r = computeDocumentTotals({ subtotal: 800, discount: 50, vat: VAT_DISABLED });
    expect(r.netAmount.toString()).toBe('750');
    expect(r.vatStatus).toBe('NOT_APPLICABLE');
    expect(r.vatRate).toBeNull();
    expect(r.vatAmount.toString()).toBe('0');
    expect(r.grossAmount.toString()).toBe('750');
  });

  it('النسبة المخزَّنة 14% لا تُطبَّق إطلاقًا ما دامت الضريبة معطّلة', () => {
    const r = computeDocumentTotals({ subtotal: 1000, discount: 0, vat: { enabled: false, rate: 14 } });
    expect(r.vatAmount.toString()).toBe('0');
    expect(r.grossAmount.toString()).toBe('1000');
  });

  it('غياب سياق الضريبة يعني التعطيل — لا افتراض ضمني', () => {
    const r = computeDocumentTotals({ subtotal: 500, discount: 0 });
    expect(r.vatStatus).toBe('NOT_APPLICABLE');
    expect(r.vatAmount.toString()).toBe('0');
  });
});

describe('الوضع المستقبلي: Subtotal → Discount → Net → VAT 14% → Grand Total', () => {
  const VAT_ON = { enabled: true, rate: 14 };

  it('تُحسب الضريبة على الصافي بعد الخصم', () => {
    const r = computeDocumentTotals({ subtotal: 1000, discount: 200, vat: VAT_ON });
    expect(r.netAmount.toString()).toBe('800');
    expect(r.vatStatus).toBe('STANDARD');
    expect(r.vatRate!.toString()).toBe('14');
    expect(r.vatAmount.toString()).toBe('112');
    expect(r.grossAmount.toString()).toBe('912');
  });

  it('النسبة ليست مثبتة في الكود — تغييرها من الإعدادات يغيّر النتيجة', () => {
    const r = computeDocumentTotals({ subtotal: 1000, discount: 0, vat: { enabled: true, rate: 5 } });
    expect(r.vatAmount.toString()).toBe('50');
  });

  it('السطر المعفى أو صفري النسبة لا يحمل ضريبة رغم التفعيل', () => {
    const r = computeDocumentTotals({ subtotal: 1000, discount: 0, vat: VAT_ON, lineVatStatus: 'EXEMPT' });
    expect(r.vatStatus).toBe('EXEMPT');
    expect(r.vatAmount.toString()).toBe('0');
    expect(r.grossAmount.toString()).toBe('1000');
  });

  it('يرفض نسبة خارج النطاق', () => {
    expect(() => computeDocumentTotals({ subtotal: 100, discount: 0, vat: { enabled: true, rate: 150 } }))
      .toThrowError('VAT_RATE_OUT_OF_RANGE');
  });

  it('يرفض خصمًا أكبر من الإجمالي', () => {
    expect(() => computeDocumentTotals({ subtotal: 100, discount: 150 }))
      .toThrowError('DISCOUNT_EXCEEDS_SUBTOTAL');
  });
});
