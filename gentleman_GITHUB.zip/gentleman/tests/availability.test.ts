import { describe, it, expect } from 'vitest';
import { overlaps } from '../src/lib/availability';

const p = (a: string, b: string) => ({ start: new Date(a), end: new Date(b) });

describe('نواة التوفر — تعارض الفترات', () => {
  it('تداخل جزئي = تعارض', () => {
    expect(overlaps(p('2026-09-01', '2026-09-05'), p('2026-09-04', '2026-09-08'))).toBe(true);
  });
  it('احتواء كامل = تعارض', () => {
    expect(overlaps(p('2026-09-01', '2026-09-10'), p('2026-09-03', '2026-09-04'))).toBe(true);
  });
  it('نفس يوم النهاية والبداية = تعارض (القطعة لا تكون في مكانين)', () => {
    expect(overlaps(p('2026-09-01', '2026-09-05'), p('2026-09-05', '2026-09-07'))).toBe(true);
  });
  it('فترتان منفصلتان = لا تعارض', () => {
    expect(overlaps(p('2026-09-01', '2026-09-05'), p('2026-09-06', '2026-09-09'))).toBe(false);
  });
  it('حجز مستقبلي يمنع تأجيرًا يتقاطع معه رغم أن حالة القطعة الآن "متاحة"', () => {
    const futureReservation = p('2026-10-10', '2026-10-12');
    const walkInRental = p('2026-10-09', '2026-10-11');
    expect(overlaps(futureReservation, walkInRental)).toBe(true);
  });
});
