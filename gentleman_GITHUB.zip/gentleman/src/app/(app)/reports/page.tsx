import { runReport, reportCatalog, type ReportKey } from '@/services/report.service';
import { getSession } from '@/lib/auth/session';
import { businessToday, formatDate } from '@/lib/date';
import { formatCell } from '@/lib/reports/report-types';
import ReportToolbar from '@/components/ReportToolbar';

export const dynamic = 'force-dynamic';

export default async function ReportsPage({
  searchParams,
}: {
  searchParams: { key?: string; from?: string; to?: string };
}) {
  const session = await getSession();
  const canFinancial = session?.permissions.has('reports.financial.view') ?? false;
  const canExport = session?.permissions.has('reports.export') ?? false;

  const catalog = reportCatalog().filter((r) => canFinancial || !r.isFinancial);
  const key = (searchParams.key as ReportKey) ?? catalog[0]?.key;

  const today = formatDate(businessToday());
  const from = searchParams.from ?? `${today.slice(0, 8)}01`;
  const to = searchParams.to ?? today;

  const report = key ? await runReport({ key, from, to }) : null;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="section-title">التقارير</h1>
        <p className="text-sm text-slate-600 mt-1">
          التقارير المتاحة لك: <span className="num">{catalog.length}</span>
        </p>
      </div>

      <ReportToolbar
        catalog={catalog}
        current={key}
        from={from}
        to={to}
        canExport={canExport}
      />

      {report && (
        <div className="card overflow-hidden">
          <div className="card-header">
            {report.title} — <span className="num">{report.period}</span>
          </div>

          {report.appliedFilters.length > 0 && (
            <div className="px-5 py-3 border-b border-slate-200 text-sm text-slate-600">
              {report.appliedFilters.map((f) => `${f.label}: ${f.value}`).join('  •  ')}
            </div>
          )}

          <div className="overflow-x-auto">
            <table className="table">
              <thead>
                <tr>{report.columns.map((c) => <th key={c.key}>{c.label}</th>)}</tr>
              </thead>
              <tbody>
                {report.rows.map((row, i) => (
                  <tr key={i}>
                    {report.columns.map((c) => (
                      <td
                        key={c.key}
                        className={c.type === 'money' || c.type === 'number' ? 'num' : ''}
                      >
                        {formatCell(row[c.key], c.type)}
                      </td>
                    ))}
                  </tr>
                ))}
                {report.rows.length === 0 && (
                  <tr>
                    <td colSpan={report.columns.length} className="text-center text-slate-500 py-8">
                      لا توجد بيانات في هذه الفترة.
                    </td>
                  </tr>
                )}
              </tbody>
              {report.totals && (
                <tfoot>
                  <tr className="font-bold bg-brand-soft">
                    {report.columns.map((c) => (
                      <td
                        key={c.key}
                        className={c.type === 'money' || c.type === 'number' ? 'num' : ''}
                      >
                        {report.totals![c.key] === null
                          ? ''
                          : formatCell(report.totals![c.key], c.type)}
                      </td>
                    ))}
                  </tr>
                </tfoot>
              )}
            </table>
          </div>

          {report.notes.length > 0 && (
            <div className="px-5 py-4 border-t border-slate-200 text-xs text-slate-500 space-y-1">
              {report.notes.map((n) => <p key={n}>• {n}</p>)}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
