import { Errors } from '@/lib/errors';
import { requireSession, type SessionUser } from './session';
import { hasPermission, hasAnyPermission, type PermissionCode } from './permissions';

export const can = (user: SessionUser, permission: PermissionCode): boolean =>
  hasPermission(user.permissions, permission);

export const canAny = (user: SessionUser, permissions: PermissionCode[]): boolean =>
  hasAnyPermission(user.permissions, permissions);

/**
 * البوابة الوحيدة لتنفيذ أي عملية محمية.
 * كل مسار API وكل دالة خدمة تمر من هنا — إخفاء الزر في الواجهة ليس حماية.
 */
export async function requirePermission(
  permission: PermissionCode,
): Promise<SessionUser> {
  const user = await requireSession();
  if (!can(user, permission)) throw Errors.forbidden(permission);
  return user;
}

export async function requireAnyPermission(
  permissions: PermissionCode[],
): Promise<SessionUser> {
  const user = await requireSession();
  if (!canAny(user, permissions)) throw Errors.forbidden(permissions.join('|'));
  return user;
}
