BEGIN;
SELECT pg_sleep(0.1);
INSERT INTO daily_cash_closings (business_date, expected_company_position, expected_insurance_cash,
  expected_physical, actual_counted, variance, counted_by, counted_at)
VALUES (CURRENT_DATE - 1, 100, 0, 100, 100, 0, 1, now());
COMMIT;
