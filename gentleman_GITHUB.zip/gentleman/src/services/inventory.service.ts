import { z } from 'zod';
import { prisma } from '@/lib/db';
import { requirePermission } from '@/lib/auth/rbac';
import { STATUS_LABELS, type ItemStatus } from '@/lib/inventory/item-state';
import { periodBounds } from '@/lib/date';
import { overdueItemRefs, overdueMap } from '@/lib/inventory/overdue';

/** ملخص المخزون: عدد القطع في كل حالة، إجمالاً وحسب المنتج. */
export async function inventorySummary() {
  await requirePermission('items.view');

  const [byStatus, byProduct, totals, overdueRefs] = await Promise.all([
    prisma.productItem.groupBy({ by: ['status'], _count: { _all: true } }),
    prisma.product.findMany({
      where: { isActive: true },
      select: {
        id: true, code: true, nameAr: true, size: true, color: true,
        rentalPrice: true, salePrice: true,
        items: { select: { id: true, status: true } },
      },
      orderBy: { nameAr: 'asc' },
    }),
    prisma.productItem.aggregate({ _count: { _all: true } }),
    // ★ التأخير مشتق من مصدر الحقيقة الواحد — لا يُخزَّن على القطعة
    overdueItemRefs(prisma),
  ]);

  const overdue = overdueMap(overdueRefs);

  const statusCounts = Object.fromEntries(
    (Object.keys(STATUS_LABELS) as ItemStatus[]).map((s) => [s, 0]),
  ) as Record<ItemStatus, number>;
  for (const row of byStatus) statusCounts[row.status as ItemStatus] = row._count._all;

  // العرض فقط: القطعة المؤجرة المستحقة تُعرض «متأخرة».
  // حالتها المخزَّنة تبقى RENTED — آلة الحالة لم تتغيّر.
  const overdueCount = overdueRefs.length;
  if (overdueCount > 0) {
    statusCounts.RENTED = Math.max(0, statusCounts.RENTED - overdueCount);
    statusCounts.OVERDUE = statusCounts.OVERDUE + overdueCount;
  }

  const products = byProduct.map((p) => {
    const counts = Object.fromEntries(
      (Object.keys(STATUS_LABELS) as ItemStatus[]).map((s) => [s, 0]),
    ) as Record<ItemStatus, number>;
    for (const it of p.items) {
      const displayed: ItemStatus =
        it.status === 'RENTED' && overdue.has(it.id) ? 'OVERDUE' : (it.status as ItemStatus);
      counts[displayed] += 1;
    }
    return {
      id: p.id, code: p.code, nameAr: p.nameAr, size: p.size, color: p.color,
      rentalPrice: p.rentalPrice, salePrice: p.salePrice,
      total: p.items.length,
      counts,
    };
  });

  return { statusCounts, totalItems: totals._count._all, products, overdueCount };
}

export const inventoryTrxQuerySchema = z.object({
  from: z.string().optional(),
  to: z.string().optional(),
  itemId: z.coerce.number().int().optional(),
  type: z.string().optional(),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(10).max(200).default(50),
});

export async function listInventoryTransactions(input: z.infer<typeof inventoryTrxQuerySchema>) {
  await requirePermission('items.view');
  const where: Record<string, unknown> = {};
  if (input.itemId) where.itemId = input.itemId;
  if (input.type) where.type = input.type;
  if (input.from && input.to) {
    const { start, end } = periodBounds(input.from, input.to);
    where.createdAt = { gte: start, lte: end };
  }

  const [rows, total] = await Promise.all([
    prisma.inventoryTransaction.findMany({
      where,
      include: { item: { select: { itemCode: true, product: { select: { nameAr: true } } } } },
      orderBy: { createdAt: 'desc' },
      skip: (input.page - 1) * input.pageSize,
      take: input.pageSize,
    }),
    prisma.inventoryTransaction.count({ where }),
  ]);
  return { rows, total, page: input.page, pageSize: input.pageSize };
}

/** بيانات طباعة ملصقات الباركود. */
export const labelQuerySchema = z.object({
  ids: z.string().optional(),
  productId: z.coerce.number().int().optional(),
});

export async function itemsForLabels(input: z.infer<typeof labelQuerySchema>) {
  await requirePermission('items.manage');
  const where: Record<string, unknown> = {};
  if (input.ids) {
    where.id = { in: input.ids.split(',').map(Number).filter(Boolean) };
  } else if (input.productId) {
    where.productId = input.productId;
  } else {
    return [];
  }
  return prisma.productItem.findMany({
    where,
    select: {
      id: true, itemCode: true, barcode: true,
      product: { select: { nameAr: true, size: true, color: true } },
    },
    orderBy: { itemCode: 'asc' },
  });
}
