import { describe, it, expect } from 'vitest';
import {
  buildItemCode, parseSequence, validateBarcode, generateCodes, normalizePrefix,
} from '../src/lib/inventory/codes';

describe('أكواد القطع', () => {
  it('يبني الكود بأربع خانات', () => {
    expect(buildItemCode('SUIT', 1)).toBe('SUIT-0001');
    expect(buildItemCode('SUIT', 123)).toBe('SUIT-0123');
  });
  it('ينظّف البادئة من الرموز والمسافات', () => {
    expect(normalizePrefix(' su it-#1 ')).toBe('SUIT1');
  });
  it('يقرأ الرقم التسلسلي', () => {
    expect(parseSequence('SUIT-0042')).toBe(42);
    expect(parseSequence('SUIT')).toBeNull();
  });
  it('يولّد أكوادًا متتالية', () => {
    expect(generateCodes('SUIT', 5, 3)).toEqual(['SUIT-0005', 'SUIT-0006', 'SUIT-0007']);
  });
  it('يرفض عددًا خارج النطاق', () => {
    expect(() => generateCodes('SUIT', 1, 0)).toThrowError('COUNT_OUT_OF_RANGE');
    expect(() => generateCodes('SUIT', 1, 500)).toThrowError('COUNT_OUT_OF_RANGE');
  });
});

describe('الباركود', () => {
  it('يقبل الأكواد الصحيحة', () => {
    expect(validateBarcode('SUIT-0001')).toBeNull();
    expect(validateBarcode('6221031492015')).toBeNull();
  });
  it('يرفض المسافات والعربية والأقصر من أربعة', () => {
    expect(validateBarcode('SUIT 001')).not.toBeNull();
    expect(validateBarcode('بدلة1')).not.toBeNull();
    expect(validateBarcode('AB')).not.toBeNull();
  });
});
