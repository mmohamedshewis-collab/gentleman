'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function ItemStatusForm({
  itemId, currentLabel, targets,
}: {
  itemId: number;
  currentLabel: string;
  targets: { value: string; label: string }[];
}) {
  const router = useRouter();
  const [toStatus, setToStatus] = useState(targets[0]?.value ?? '');
  const [reason, setReason] = useState('');
  const [msg, setMsg] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit() {
    setBusy(true); setMsg(null);
    const res = await fetch('/api/items/status', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ itemId, toStatus, reason }),
    });
    const json = await res.json();
    setBusy(false);
    if (!json.ok) { setMsg({ type: 'err', text: json.error?.message ?? 'تعذّر تغيير الحالة.' }); return; }
    setMsg({ type: 'ok', text: `تم تغيير الحالة إلى "${json.data.label}".` });
    setReason('');
    router.refresh();
  }

  return (
    <div className="card">
      <div className="card-header">تغيير حالة القطعة</div>
      <div className="p-5 grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
        <div>
          <label className="label">الحالة الحالية</label>
          <input className="input bg-slate-50" value={currentLabel} disabled />
        </div>
        <div>
          <label className="label">الحالة الجديدة</label>
          <select className="input" value={toStatus} onChange={(e) => setToStatus(e.target.value)}>
            {targets.map((t) => <option key={t.value} value={t.value}>{t.label}</option>)}
          </select>
        </div>
        <div>
          <label className="label">السبب (إلزامي)</label>
          <input
            className="input" value={reason} placeholder="مثال: تلف في السحّاب"
            onChange={(e) => setReason(e.target.value)}
          />
        </div>
      </div>
      <div className="px-5 pb-5 flex items-center gap-4">
        <button className="btn-primary" onClick={submit} disabled={busy || reason.trim().length < 3}>
          {busy ? 'جارٍ الحفظ…' : 'تأكيد التغيير'}
        </button>
        {msg && (
          <span className={`text-sm font-semibold ${msg.type === 'ok' ? 'text-ok' : 'text-danger'}`}>
            {msg.text}
          </span>
        )}
        <span className="text-xs text-slate-400">
          حالات التأجير والبيع والحجز تُسجَّل من عملياتها ولا تُضبط يدويًا.
        </span>
      </div>
    </div>
  );
}
