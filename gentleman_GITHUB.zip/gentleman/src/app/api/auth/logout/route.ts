import { route } from '@/lib/api';
import { logout } from '@/services/auth.service';
import { getSession } from '@/lib/auth/session';

export const POST = route({
  handler: async () => {
    const s = await getSession();
    return logout(s?.id ?? null);
  },
});
