'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

/**
 * البحث السريع بالجوال: يكتب الموظف الرقم، فإما يظهر العميل فورًا
 * أو يُنشئه باسم واحد فقط بضغطة واحدة. لا خطوات زائدة.
 */
export default function CustomerLookup() {
  const router = useRouter();
  const [phone, setPhone] = useState('');
  const [state, setState] = useState<'idle' | 'searching' | 'found' | 'new'>('idle');
  const [found, setFound] = useState<{ id: number; fullName: string; phoneDisplay: string; code: string } | null>(null);
  const [fullName, setFullName] = useState('');
  const [msg, setMsg] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  async function search() {
    setBusy(true); setMsg(null); setFound(null); setState('searching');
    const res = await fetch(`/api/customers/lookup?phone=${encodeURIComponent(phone)}`);
    const json = await res.json();
    setBusy(false);
    if (!json.ok) { setState('idle'); setMsg({ type: 'err', text: json.error?.message ?? 'تعذّر البحث.' }); return; }
    if (json.data.found) { setFound(json.data.customer); setState('found'); }
    else { setState('new'); setFullName(''); }
  }

  async function create() {
    setBusy(true); setMsg(null);
    const res = await fetch('/api/customers', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ fullName, phone }),
    });
    const json = await res.json();
    setBusy(false);
    if (!json.ok) { setMsg({ type: 'err', text: json.error?.message ?? 'تعذّر الحفظ.' }); return; }
    setFound(json.data); setState('found');
    setMsg({ type: 'ok', text: 'تم إنشاء العميل.' });
    router.refresh();
  }

  return (
    <div className="card">
      <div className="card-header">بحث سريع عن عميل</div>
      <div className="p-5 space-y-4">
        <div className="flex gap-3 items-end">
          <div className="flex-1">
            <label className="label">رقم الجوال</label>
            <input
              className="input num" dir="ltr" inputMode="tel" autoFocus
              placeholder="01012345678"
              value={phone}
              onChange={(e) => { setPhone(e.target.value); setState('idle'); }}
              onKeyDown={(e) => e.key === 'Enter' && search()}
            />
          </div>
          <button className="btn-primary" onClick={search} disabled={busy || !phone}>
            {busy && state === 'searching' ? 'جارٍ البحث…' : 'بحث'}
          </button>
        </div>

        {state === 'found' && found && (
          <div className="rounded-lg bg-brand-soft border border-brand-light/30 p-4 flex items-center justify-between">
            <div>
              <div className="font-bold text-brand">{found.fullName}</div>
              <div className="text-sm text-slate-600 num">{found.phoneDisplay} · {found.code}</div>
            </div>
            <a className="btn-secondary" href={`/customers/${found.id}`}>فتح البطاقة</a>
          </div>
        )}

        {state === 'new' && (
          <div className="rounded-lg bg-amber-50 border border-amber-200 p-4 space-y-3">
            <p className="text-sm font-semibold text-warn">
              لا يوجد عميل بهذا الرقم — أدخل الاسم لإنشائه فورًا.
            </p>
            <div className="flex gap-3 items-end">
              <div className="flex-1">
                <label className="label">اسم العميل</label>
                <input
                  className="input" autoFocus value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && fullName.length > 1 && create()}
                />
              </div>
              <button className="btn-primary" onClick={create} disabled={busy || fullName.trim().length < 2}>
                حفظ
              </button>
            </div>
          </div>
        )}

        {msg && (
          <p className={`text-sm font-semibold ${msg.type === 'ok' ? 'text-ok' : 'text-danger'}`}>
            {msg.text}
          </p>
        )}
      </div>
    </div>
  );
}
