-- Q-1: قفل الحساب بعد محاولات دخول فاشلة
-- عمودان على جدول users القائم — لا جدول جديد ولا Trigger ولا صلاحية.
-- آمن لإعادة التشغيل (idempotent) وبلا أثر على أي بيانات قائمة.

ALTER TABLE users ADD COLUMN IF NOT EXISTS failed_attempts integer NOT NULL DEFAULT 0;
ALTER TABLE users ADD COLUMN IF NOT EXISTS locked_until timestamptz;

-- العدّاد لا يكون سالبًا
ALTER TABLE users DROP CONSTRAINT IF EXISTS ck_user_failed_attempts;
ALTER TABLE users
  ADD CONSTRAINT ck_user_failed_attempts CHECK (failed_attempts >= 0);
