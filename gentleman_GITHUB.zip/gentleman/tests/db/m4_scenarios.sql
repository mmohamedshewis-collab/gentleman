\set ON_ERROR_STOP off
\pset pager off
\t on

\echo '=== R1: إرجاع سليم في الموعد — التأمين يُرد كاملًا ولا إيراد ==='
SELECT 'العقد ' || do_rental(ARRAY['SUIT-0001'], 2, 500, 0, 500, 0, 1000, CURRENT_DATE, CURRENT_DATE+1);
SELECT 'الإرجاع ' || do_return(last_rental(), 'SUIT-0001', 'GOOD', 0, CURRENT_DATE+1);
SELECT 'الغرامات=' || (late_fee+damage_fee+loss_fee) || ' مستخدم=' || insurance_used ||
       ' مردود=' || insurance_refunded || ' مستحق=' || extra_due_from_customer
  FROM return_items WHERE return_id = last_return();
SELECT 'حالة القطعة=' || status FROM product_items WHERE item_code='SUIT-0001';
SELECT 'حالة العقد=' || status FROM rentals WHERE id = last_rental();

\echo ''
\echo '=== R2: إرجاع متأخر يومين — غرامة 200 تُستقطع من التأمين ==='
SELECT 'العقد ' || do_rental(ARRAY['SUIT-0002'], 2, 500, 0, 500, 0, 1000, CURRENT_DATE-3, CURRENT_DATE-2);
SELECT 'الإرجاع ' || do_return(last_rental(), 'SUIT-0002', 'GOOD', 0, CURRENT_DATE);
SELECT 'أيام التأخير=' || days_late || ' غرامة=' || late_fee || ' مستخدم=' || insurance_used ||
       ' مردود=' || insurance_refunded FROM return_items WHERE return_id = last_return();

\echo ''
\echo '=== R3: ★ تلف 250 وتأمين 1000 — الإيراد 250 وليس 500 ==='
SELECT 'العقد ' || do_rental(ARRAY['SUIT-0003'], 2, 500, 0, 500, 0, 1000, CURRENT_DATE, CURRENT_DATE+1);
SELECT 'الإرجاع ' || do_return(last_rental(), 'SUIT-0003', 'DAMAGED', 250, CURRENT_DATE);
SELECT 'إيراد معترف به=' || (late_fee+damage_fee+loss_fee) ||
       ' | تأمين مستخدم (سداد لا إيراد)=' || insurance_used || ' | مردود=' || insurance_refunded
  FROM return_items WHERE return_id = last_return();
SELECT 'حالة القطعة=' || status FROM product_items WHERE item_code='SUIT-0003';

\echo ''
\echo '=== R4: تلف 1500 يتجاوز التأمين — 500 مديونية تُضاف للعقد ==='
SELECT 'العقد ' || do_rental(ARRAY['SUIT-0006'], 2, 500, 0, 500, 0, 1000, CURRENT_DATE, CURRENT_DATE+1);
SELECT 'قبل: المستحق=' || total_due || ' المتبقي=' || remaining_amount FROM rentals WHERE id=last_rental();
SELECT 'الإرجاع ' || do_return(last_rental(), 'SUIT-0006', 'DAMAGED', 1500, CURRENT_DATE);
SELECT 'مستخدم=' || insurance_used || ' مردود=' || insurance_refunded || ' مستحق إضافي=' || extra_due_from_customer
  FROM return_items WHERE return_id = last_return();
SELECT 'بعد: المستحق=' || total_due || ' المتبقي=' || remaining_amount || ' غرامات=' || extra_charges
  FROM rentals WHERE id=last_rental();

\echo ''
\echo '=== R5: الإرجاع المزدوج لنفس القطعة (يجب أن يُرفض) ==='
SELECT do_return(last_rental(), 'SUIT-0006', 'GOOD', 0, CURRENT_DATE);

\echo ''
\echo '=== R6: خرق معادلة التسوية مباشرة في القاعدة (يجب أن يُرفض) ==='
INSERT INTO return_items (return_id, rental_item_id, item_id, actual_return_date, late_fee,
                          condition, insurance_used, insurance_refunded, extra_due_from_customer)
VALUES (last_return(), 999, 1, CURRENT_DATE, 200, 'GOOD', 200, 800, 100);

\echo ''
\echo '=== R7: تالفة بلا قيمة تلف (يجب أن تُرفض) ==='
INSERT INTO return_items (return_id, rental_item_id, item_id, actual_return_date,
                          condition, damage_fee, insurance_used, insurance_refunded, extra_due_from_customer)
VALUES (last_return(), 998, 1, CURRENT_DATE, 'DAMAGED', 0, 0, 0, 0);

\echo ''
\echo '=== R8: تلف مع حالة مفقودة (يجب أن يُرفض) ==='
INSERT INTO return_items (return_id, rental_item_id, item_id, actual_return_date,
                          condition, damage_fee, loss_fee, insurance_used, insurance_refunded, extra_due_from_customer)
VALUES (last_return(), 997, 1, CURRENT_DATE, 'LOST', 100, 500, 0, 0, 600);

\echo ''
\echo '=== R9: إرجاع جزئي لعقد بقطعتين ==='
SELECT 'العقد ' || do_rental(ARRAY['SUIT-0007','SUIT-0008'], 2, 500, 0, 1000, 0, 2000, CURRENT_DATE, CURRENT_DATE+1);
SELECT 'الإرجاع ' || do_return(last_rental(), 'SUIT-0007', 'GOOD', 0, CURRENT_DATE);
SELECT 'حالة العقد بعد قطعة واحدة=' || status FROM rentals WHERE id=last_rental();
SELECT 'الإرجاع ' || do_return(last_rental(), 'SUIT-0008', 'GOOD', 0, CURRENT_DATE);
SELECT 'حالة العقد بعد الباقي=' || status FROM rentals WHERE id=last_rental();

\echo ''
\echo '=== R10: إرجاع على عقد مغلق (يجب أن يُرفض) ==='
SELECT do_return(last_rental(), 'SUIT-0007', 'GOOD', 0, CURRENT_DATE);

\echo ''
\echo '=== R11: إرجاع بفقد ==='
SELECT 'العقد ' || do_rental(ARRAY['SUIT-0009'], 2, 500, 0, 500, 0, 1000, CURRENT_DATE, CURRENT_DATE+1);
SELECT 'الإرجاع ' || do_return(last_rental(), 'SUIT-0009', 'LOST', 6000, CURRENT_DATE);
SELECT 'حالة القطعة=' || status FROM product_items WHERE item_code='SUIT-0009';
SELECT 'مستخدم=' || insurance_used || ' مستحق إضافي=' || extra_due_from_customer
  FROM return_items WHERE return_id=last_return();
SELECT 'حركة المخزون=' || type FROM inventory_transactions ORDER BY id DESC LIMIT 1;

\echo ''
\echo '=== R12: سقف الغرامة ==='
SELECT 'العقد ' || do_rental(ARRAY['SUIT-0010'], 2, 500, 0, 500, 0, 3000, CURRENT_DATE-20, CURRENT_DATE-19);
SELECT 'الإرجاع ' || do_return(last_rental(), 'SUIT-0010', 'GOOD', 0, CURRENT_DATE, 100, 500);
SELECT 'أيام التأخير=' || days_late || ' الغرامة بعد السقف=' || late_fee FROM return_items WHERE return_id=last_return();

\echo ''
\echo '=== R13: إرجاع مبكر — لا غرامة ولا استرداد ==='
SELECT 'العقد ' || do_rental(ARRAY['SUIT-0011'], 2, 500, 0, 500, 0, 1000, CURRENT_DATE, CURRENT_DATE+10);
SELECT 'الإرجاع ' || do_return(last_rental(), 'SUIT-0011', 'GOOD', 0, CURRENT_DATE);
SELECT 'أيام التأخير=' || days_late || ' غرامة=' || late_fee || ' مردود=' || insurance_refunded
  FROM return_items WHERE return_id=last_return();
