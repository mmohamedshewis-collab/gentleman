import { Decimal } from 'decimal.js';
import { round2, add, sub } from '@/lib/money';

/**
 * منطق النقدية — دوال خالصة بلا اعتماد على قاعدة البيانات.
 *
 * ثلاثة مبادئ حاكمة:
 *  1. لا رصيد افتتاحي يومي. مركز الشركة رقم **مشتق** من الحركات منذ آخر ترحيل.
 *  2. النقد فقط: أي طريقة دفع غير نقدية لا تمس نقدية المحل.
 *  3. التأمين **رصيد** لا حركة يومية، ولا يُصفَّر عند الإغلاق.
 */

/** أنواع الحركات النقدية — مربوطة بنوع العملية الحقيقي، لا وحدة عامة. */
export type CashMovementType =
  // داخل
  | 'RENTAL_COLLECTION'
  | 'SALE_COLLECTION'
  | 'LATE_FEE_COLLECTION'
  | 'ADVANCE_REPAYMENT'
  | 'RESERVATION_DEPOSIT'
  | 'OTHER_IN'
  | 'OTHER_OUT'
  // خارج
  | 'EXPENSE_PAYMENT'
  | 'SALARY_PAYMENT'
  | 'COMMISSION_PAYMENT'
  | 'EMPLOYEE_ADVANCE'
  | 'CUSTOMER_REFUND'
  | 'PRODUCT_PURCHASE'
  | 'INSURANCE_REFUND'
  | 'TREASURY_TRANSFER'
  // بلا حركة نقدية مادية
  | 'INSURANCE_COLLECTION'
  | 'INSURANCE_RETAINED'
  | 'INSURANCE_TRANSFERRED';

export interface MovementRule {
  labelAr: string;
  /** يؤثر على مركز نقدية الشركة */
  affectsCompanyCash: boolean;
  /** يؤثر على رصيد نقدية التأمين بالمحل */
  affectsInsuranceBalance: boolean;
  /** يظهر في «صافي حركة النقدية اليوم» على لوحة التحكم */
  inDashboardMovement: boolean;
  isRevenue: boolean;
  isExpense: boolean;
  direction: 'IN' | 'OUT' | 'NONE';
}

/**
 * جدول التصنيف — مصدر الحقيقة الوحيد.
 * ليس كل دخول نقدي إيرادًا، وليس كل خروج نقدي مصروفًا.
 */
export const MOVEMENT_RULES: Record<CashMovementType, MovementRule> = {
  RENTAL_COLLECTION:    { labelAr: 'تحصيل تأجير',            affectsCompanyCash: true,  affectsInsuranceBalance: false, inDashboardMovement: true,  isRevenue: true,  isExpense: false, direction: 'IN' },
  SALE_COLLECTION:      { labelAr: 'تحصيل مبيعات',           affectsCompanyCash: true,  affectsInsuranceBalance: false, inDashboardMovement: true,  isRevenue: true,  isExpense: false, direction: 'IN' },
  LATE_FEE_COLLECTION:  { labelAr: 'تحصيل غرامات',           affectsCompanyCash: true,  affectsInsuranceBalance: false, inDashboardMovement: true,  isRevenue: true,  isExpense: false, direction: 'IN' },
  ADVANCE_REPAYMENT:    { labelAr: 'سداد سلفة نقدًا',        affectsCompanyCash: true,  affectsInsuranceBalance: false, inDashboardMovement: true,  isRevenue: false, isExpense: false, direction: 'IN' },

  EXPENSE_PAYMENT:      { labelAr: 'مصروف نقدي',             affectsCompanyCash: true,  affectsInsuranceBalance: false, inDashboardMovement: true,  isRevenue: false, isExpense: true,  direction: 'OUT' },
  SALARY_PAYMENT:       { labelAr: 'صرف راتب',               affectsCompanyCash: true,  affectsInsuranceBalance: false, inDashboardMovement: true,  isRevenue: false, isExpense: true,  direction: 'OUT' },
  COMMISSION_PAYMENT:   { labelAr: 'صرف عمولة',              affectsCompanyCash: true,  affectsInsuranceBalance: false, inDashboardMovement: true,  isRevenue: false, isExpense: true,  direction: 'OUT' },
  EMPLOYEE_ADVANCE:     { labelAr: 'سلفة موظف',              affectsCompanyCash: true,  affectsInsuranceBalance: false, inDashboardMovement: true,  isRevenue: false, isExpense: false, direction: 'OUT' },
  // ★ عربون الحجز: دخول نقدي وليس إيرادًا — الحجز وعد لا عملية.
  //   الإيراد يُعترف به عند التحويل إلى تأجير داخل العقد.
  RESERVATION_DEPOSIT:  { labelAr: 'عربون حجز',                affectsCompanyCash: true,  affectsInsuranceBalance: false, inDashboardMovement: true,  isRevenue: false, isExpense: false, direction: 'IN'  },

  CUSTOMER_REFUND:      { labelAr: 'رد مبلغ لعميل',          affectsCompanyCash: true,  affectsInsuranceBalance: false, inDashboardMovement: true,  isRevenue: false, isExpense: false, direction: 'OUT' },
  PRODUCT_PURCHASE:     { labelAr: 'شراء قطع نقدًا',         affectsCompanyCash: true,  affectsInsuranceBalance: false, inDashboardMovement: true,  isRevenue: false, isExpense: false, direction: 'OUT' },

  // يخرج من الدرج لكنه مال العميل: يخفض رصيد التأمين لا مركز الشركة
  INSURANCE_REFUND:     { labelAr: 'رد تأمين لعميل',         affectsCompanyCash: false, affectsInsuranceBalance: true,  inDashboardMovement: false, isRevenue: false, isExpense: false, direction: 'OUT' },
  // يدخل الدرج لكنه مال العميل
  INSURANCE_COLLECTION: { labelAr: 'تحصيل تأمين',            affectsCompanyCash: false, affectsInsuranceBalance: true,  inDashboardMovement: false, isRevenue: false, isExpense: false, direction: 'IN' },
  // ★ لا يتحرك نقد ماديًا — تنتقل الملكية فقط من العميل إلى المحل
  INSURANCE_RETAINED:   { labelAr: 'تأمين مُستبقى للمحل',    affectsCompanyCash: true,  affectsInsuranceBalance: true,  inDashboardMovement: false, isRevenue: true,  isExpense: false, direction: 'NONE' },
  // ★ Q13: تأمين راكد لم يُطالَب به — نفس آلية الاستبقاء تمامًا.
  //   المال في الدرج أصلًا، فلا حركة نقد مادية. إيراد بقرار Q13 المعتمد،
  //   وتقرير الإيرادات في M7 يحتسبه كذلك بالفعل.
  INSURANCE_TRANSFERRED:{ labelAr: 'تحويل تأمين راكد للمحل', affectsCompanyCash: true,  affectsInsuranceBalance: true,  inDashboardMovement: false, isRevenue: true,  isExpense: false, direction: 'NONE' },

  // حركات أخرى: نقدية بلا إيراد وبلا مصروف — لا تُصنَّف تحصيل تأجير
  OTHER_IN:             { labelAr: 'مقبوضات أخرى',           affectsCompanyCash: true,  affectsInsuranceBalance: false, inDashboardMovement: true,  isRevenue: false, isExpense: false, direction: 'IN'  },
  OTHER_OUT:            { labelAr: 'مدفوعات أخرى',           affectsCompanyCash: true,  affectsInsuranceBalance: false, inDashboardMovement: true,  isRevenue: false, isExpense: false, direction: 'OUT' },

  TREASURY_TRANSFER:    { labelAr: 'ترحيل إلى الخزينة',      affectsCompanyCash: true,  affectsInsuranceBalance: false, inDashboardMovement: false, isRevenue: false, isExpense: false, direction: 'OUT' },
};

export const isRevenueMovement = (t: CashMovementType) => MOVEMENT_RULES[t].isRevenue;
export const isExpenseMovement = (t: CashMovementType) => MOVEMENT_RULES[t].isExpense;
export const movementLabel = (t: CashMovementType) => MOVEMENT_RULES[t].labelAr;

// ======================= الحركة اليومية =======================

export interface CashLine {
  type: CashMovementType;
  amount: Decimal.Value;
}

/**
 * صافي حركة النقدية اليوم (صندوق لوحة التحكم).
 * يشمل فقط ما أثّر فعليًا على نقدية الشركة ويُعرض في اللوحة.
 * ⛔ لا يشمل: رصيد أمس · التأمين · الفيزا · التحويل البنكي · الترحيل.
 */
export function dashboardMovement(lines: CashLine[]) {
  let inflow = new Decimal(0);
  let outflow = new Decimal(0);

  for (const l of lines) {
    const rule = MOVEMENT_RULES[l.type];
    if (!rule.inDashboardMovement) continue;
    const amt = round2(l.amount);
    if (amt.lt(0)) throw new Error('CASH_AMOUNT_NEGATIVE');
    if (rule.direction === 'IN') inflow = inflow.plus(amt);
    else if (rule.direction === 'OUT') outflow = outflow.plus(amt);
  }

  return {
    inflow: round2(inflow),
    outflow: round2(outflow),
    net: sub(inflow, outflow),
  };
}

/**
 * مركز نقدية الشركة — رقم **مشتق** من الحركات منذ آخر ترحيل.
 * ⛔ ليس رصيدًا افتتاحيًا ولا يُدخله مستخدم.
 * يشمل التأمين المُستبقى لأنه يزيد مال الشركة داخل الدرج بلا تحصيل جديد.
 */
export function companyCashPosition(linesSinceLastTransfer: CashLine[]): Decimal {
  let position = new Decimal(0);

  for (const l of linesSinceLastTransfer) {
    const rule = MOVEMENT_RULES[l.type];
    if (!rule.affectsCompanyCash) continue;
    const amt = round2(l.amount);
    if (amt.lt(0)) throw new Error('CASH_AMOUNT_NEGATIVE');

    if (rule.direction === 'NONE') {
      // ★ لا حركة نقد مادية، لكن ملكية المبلغ انتقلت من العميل إلى المحل
      //   (التأمين المُستبقى والتأمين الراكد المحوَّل).
      //   مشتق من قاعدة النوع لا باسم محدد — حتى لا يُنسى أي نوع جديد.
      position = position.plus(amt);
    } else if (rule.direction === 'IN') {
      position = position.plus(amt);
    } else if (rule.direction === 'OUT') {
      position = position.minus(amt);
    }
  }
  return round2(position);
}

/**
 * رصيد نقدية التأمين بالمحل — رصيد متراكم لا حركة يومية.
 * ⛔ لا يُصفَّر عند إغلاق اليوم ولا يُرحَّل إلى الخزينة.
 */
export function insuranceCashBalance(input: {
  openingBalance: Decimal.Value;
  collected: Decimal.Value;
  refunded: Decimal.Value;
  retained: Decimal.Value;
  forfeited?: Decimal.Value;
}): Decimal {
  const balance = round2(input.openingBalance)
    .plus(round2(input.collected))
    .minus(round2(input.refunded))
    .minus(round2(input.retained))
    .minus(round2(input.forfeited ?? 0));

  if (balance.lt(0)) throw new Error('INSURANCE_BALANCE_NEGATIVE');
  return round2(balance);
}

// ======================= الجرد المادي =======================

export interface CashCountResult {
  companyPosition: Decimal;
  insuranceBalance: Decimal;
  expectedPhysical: Decimal;
  actualCounted: Decimal;
  variance: Decimal;
  status: 'MATCHED' | 'SHORTAGE' | 'SURPLUS';
}

/**
 * النقدية المتوقعة فعليًا = مركز الشركة + رصيد نقدية التأمين.
 * ⛔ ليست «حركة الشركة اليوم + حركة التأمين اليوم» — التأمين رصيد لا حركة.
 */
export function countCash(input: {
  companyPosition: Decimal.Value;
  insuranceBalance: Decimal.Value;
  actualCounted: Decimal.Value;
}): CashCountResult {
  const companyPosition = round2(input.companyPosition);
  const insuranceBalance = round2(input.insuranceBalance);
  const actualCounted = round2(input.actualCounted);

  if (insuranceBalance.lt(0)) throw new Error('INSURANCE_BALANCE_NEGATIVE');
  if (actualCounted.lt(0)) throw new Error('ACTUAL_CASH_NEGATIVE');

  const expectedPhysical = add(companyPosition, insuranceBalance);
  const variance = sub(actualCounted, expectedPhysical);

  return {
    companyPosition,
    insuranceBalance,
    expectedPhysical,
    actualCounted,
    variance,
    status: variance.isZero() ? 'MATCHED' : variance.lt(0) ? 'SHORTAGE' : 'SURPLUS',
  };
}

export const varianceLabel = (v: Decimal.Value): string => {
  const d = round2(v);
  return d.isZero() ? 'مطابق' : d.lt(0) ? 'عجز' : 'زيادة';
};

// ======================= الترحيل =======================

/**
 * الترحيل الكامل إلزامي: يُرحَّل كل كاش الشركة، ولا يُرحَّل جنيه من التأمين.
 * بعده لا ينتقل أي رصيد نقدي للشركة إلى اليوم التالي.
 */
export function requiredTransferAmount(input: {
  actualCounted: Decimal.Value;
  insuranceBalance: Decimal.Value;
}): Decimal {
  const amount = sub(input.actualCounted, input.insuranceBalance);
  if (amount.lt(0)) throw new Error('TRANSFER_BELOW_INSURANCE');
  return amount;
}

/** يرفض أي ترحيل جزئي أو زائد. */
export function assertFullTransfer(input: {
  amount: Decimal.Value;
  actualCounted: Decimal.Value;
  insuranceBalance: Decimal.Value;
}): void {
  const required = requiredTransferAmount(input);
  const amount = round2(input.amount);
  if (!amount.equals(required)) {
    throw new Error(
      `الترحيل الكامل إلزامي: المطلوب ترحيل ${required.toString()} والمدخل ${amount.toString()}.`,
    );
  }
}

// ======================= السلف =======================

export interface AdvanceState {
  amount: Decimal;
  repaidAmount: Decimal;
  balance: Decimal;
  status: 'OPEN' | 'SETTLED';
}

/** رصيد السلفة محسوب لا مُدخَل، ولا يُسدَّد أكثر من الرصيد. */
export function advanceState(input: {
  amount: Decimal.Value;
  repaidAmount: Decimal.Value;
}): AdvanceState {
  const amount = round2(input.amount);
  const repaidAmount = round2(input.repaidAmount);

  if (amount.lte(0)) throw new Error('ADVANCE_AMOUNT_INVALID');
  if (repaidAmount.lt(0)) throw new Error('ADVANCE_REPAID_NEGATIVE');
  if (repaidAmount.gt(amount)) throw new Error('ADVANCE_REPAID_EXCEEDS_AMOUNT');

  const balance = sub(amount, repaidAmount);
  return {
    amount,
    repaidAmount,
    balance,
    status: balance.isZero() ? 'SETTLED' : 'OPEN',
  };
}

export function assertRepaymentWithinBalance(input: {
  amount: Decimal.Value;
  repaidAmount: Decimal.Value;
  newRepayment: Decimal.Value;
}): void {
  const state = advanceState(input);
  const repayment = round2(input.newRepayment);
  if (repayment.lte(0)) throw new Error('REPAYMENT_AMOUNT_INVALID');
  if (repayment.gt(state.balance)) {
    throw new Error(
      `السداد يتجاوز رصيد السلفة: الرصيد ${state.balance.toString()} والمدخل ${repayment.toString()}.`,
    );
  }
}

// ======================= الراتب مع خصم السلفة =======================

export interface SalarySettlement {
  grossSalary: Decimal;
  advanceDeduction: Decimal;
  otherDeductions: Decimal;
  netSalary: Decimal;
  /** ★ المصروف يساوي الإجمالي، والخروج النقدي يساوي الصافي */
  salaryExpense: Decimal;
  cashPaidAmount: Decimal;
}

/**
 * الراتب مع خصم السلفة — الحالة الوحيدة في النظام التي يختلف فيها
 * المصروف عن الخروج النقدي. السلفة لا تُسجَّل مصروفًا مرة أخرى.
 */
export function settleSalary(input: {
  grossSalary: Decimal.Value;
  advanceDeduction?: Decimal.Value;
  otherDeductions?: Decimal.Value;
}): SalarySettlement {
  const grossSalary = round2(input.grossSalary);
  const advanceDeduction = round2(input.advanceDeduction ?? 0);
  const otherDeductions = round2(input.otherDeductions ?? 0);

  if (grossSalary.lte(0)) throw new Error('SALARY_AMOUNT_INVALID');
  if (advanceDeduction.lt(0) || otherDeductions.lt(0)) throw new Error('DEDUCTION_NEGATIVE');

  const totalDeductions = add(advanceDeduction, otherDeductions);
  if (totalDeductions.gt(grossSalary)) throw new Error('DEDUCTIONS_EXCEED_SALARY');

  const netSalary = sub(grossSalary, totalDeductions);

  return {
    grossSalary,
    advanceDeduction,
    otherDeductions,
    netSalary,
    salaryExpense: grossSalary,   // الربح ينخفض بالإجمالي
    cashPaidAmount: netSalary,    // الدرج ينخفض بالصافي فقط
  };
}

// ======================= المطابقة الشهرية =======================

export function monthlyReconciliation(days: Array<{
  inflow: Decimal.Value;
  outflow: Decimal.Value;
  variance: Decimal.Value;
  transferred: Decimal.Value;
  isClosed: boolean;
}>) {
  let inflow = new Decimal(0);
  let outflow = new Decimal(0);
  let shortage = new Decimal(0);
  let surplus = new Decimal(0);
  let transferred = new Decimal(0);
  let closedDays = 0;
  let openDays = 0;

  for (const d of days) {
    inflow = inflow.plus(round2(d.inflow));
    outflow = outflow.plus(round2(d.outflow));
    transferred = transferred.plus(round2(d.transferred));
    const v = round2(d.variance);
    if (v.lt(0)) shortage = shortage.plus(v.abs());
    else if (v.gt(0)) surplus = surplus.plus(v);
    if (d.isClosed) closedDays++;
    else openDays++;
  }

  const netMovement = sub(inflow, outflow);
  return {
    totalInflow: round2(inflow),
    totalOutflow: round2(outflow),
    netMovement,
    totalTransferred: round2(transferred),
    totalVariance: sub(surplus, shortage),
    totalShortage: round2(shortage),
    totalSurplus: round2(surplus),
    /** ما لم يُرحَّل بعد — أيام مفتوحة أو ترحيل ناقص */
    notTransferred: sub(netMovement, transferred),
    closedDays,
    openDays,
  };
}

export const sumAmounts = (values: Decimal.Value[]): Decimal => add(...values);
