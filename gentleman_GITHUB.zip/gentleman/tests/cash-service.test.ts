import { describe, it, expect, vi, beforeEach } from 'vitest';

/** اختبارات خدمات النقدية والسلف: الصلاحيات · القواعد · التدقيق. */

const auditSpy = vi.fn();
let currentUser: { id: number; employeeId: number | null; permissions: Set<string> };
let closingRow: Record<string, unknown> | null;
let transferRow: Record<string, unknown> | null;
let advanceRow: Record<string, string | number> | null;
let employeeRow: Record<string, unknown> | null;
const created: Record<string, unknown[]> = {};

const record = (k: string) => (a: { data: Record<string, unknown> }) => {
  (created[k] ??= []).push(a.data);
  return { id: created[k].length, ...a.data };
};

const tx = {
  $queryRaw: vi.fn(async (strings: TemplateStringsArray) => {
    const q = strings.join(' ');
    if (q.includes('daily_cash_closings')) return closingRow ? [closingRow] : [];
    if (q.includes('employee_advances')) return advanceRow ? [advanceRow] : [];
    return [];
  }),
  $executeRaw: vi.fn(async () => 1),
  dailyCashClosing: {
    findUnique: vi.fn(async () => closingRow),
    create: vi.fn(record('closing')),
    update: vi.fn(async (a: any) => ({ ...closingRow, ...a.data, id: 1,
      variance: { toString: () => '-50' }, actualCounted: { toString: () => '1150' },
      expectedInsuranceCash: { toString: () => '1000' } })),
  },
  cashTransfer: {
    findUnique: vi.fn(async () => transferRow),
    findFirst: vi.fn(async () => null),
    create: vi.fn(record('transfer')),
  },
  employeeAdvance: {
    findFirst: vi.fn(async () => null),
    create: vi.fn(record('advance')),
    findUniqueOrThrow: vi.fn(async () => ({
      repaidAmount: { toString: () => '200' },
      balance: { toString: () => '300' },
      status: 'OPEN',
    })),
  },
  employeeAdvanceRepayment: { create: vi.fn(record('repayment')) },
  expense: { findFirst: vi.fn(async () => null), create: vi.fn(record('expense')) },
  expenseCategory: { findFirst: vi.fn(async () => ({ id: 3, nameAr: 'رواتب' })) },
};

vi.mock('@/lib/db', () => ({
  prisma: {
    $transaction: (fn: any) => fn(tx),
    dailyCashClosing: { findUnique: vi.fn(async () => closingRow), findMany: vi.fn(async () => []) },
    employee: { findUnique: vi.fn(async () => employeeRow) },
    employeeAdvance: { findMany: vi.fn(async () => []) },
    expenseCategory: { findFirst: vi.fn(async () => ({ id: 3, nameAr: 'رواتب' })) },
    payment: { findMany: vi.fn(async () => []) },
    expense: { findMany: vi.fn(async () => []) },
    insuranceTransaction: { findMany: vi.fn(async () => []) },
    employeeAdvanceRepayment: { findMany: vi.fn(async () => []) },
    productItem: { findMany: vi.fn(async () => []) },
    cashTransfer: { findFirst: vi.fn(async () => null), findMany: vi.fn(async () => []) },
    user: { findMany: vi.fn(async () => []) },
  },
}));

vi.mock('@/lib/audit', () => ({ writeAudit: (...a: any[]) => auditSpy(...a), redact: (x: any) => x }));

vi.mock('@/lib/settings', () => ({
  getNumberSetting: async () => (await import('decimal.js')).Decimal ? new (await import('decimal.js')).Decimal(0) : 0,
  getBoolSetting: async () => false,
  getStringSetting: async () => '',
}));

vi.mock('@/lib/auth/rbac', async (importOriginal) => {
  const actual = await importOriginal<typeof import('@/lib/auth/rbac')>();
  return {
    ...actual,
    requirePermission: async (perm: string) => {
      if (!currentUser.permissions.has(perm)) {
        const { Errors } = await import('@/lib/errors');
        throw Errors.forbidden(perm);
      }
      return currentUser as never;
    },
  };
});

const asStaff = () => {
  currentUser = { id: 9, employeeId: 3, permissions: new Set(['cash.movement.view', 'cash.count']) };
};
const asAdmin = () => {
  currentUser = {
    id: 1, employeeId: 1,
    permissions: new Set([
      'cash.movement.view', 'cash.count', 'cash.close', 'cash.transfer',
      'cash.reconcile.view', 'advances.view', 'advances.create', 'advances.repay',
      'expenses.create',
    ]),
  };
};

beforeEach(() => {
  auditSpy.mockClear();
  for (const k of Object.keys(created)) delete created[k];
  for (const m of Object.values(tx)) {
    if (typeof m === 'object' && m !== null) {
      for (const f of Object.values(m)) if (typeof f === 'function' && 'mockClear' in f) (f as any).mockClear();
    } else if (typeof m === 'function' && 'mockClear' in m) (m as any).mockClear();
  }
  closingRow = null;
  transferRow = null;
  advanceRow = { id: 1, amount: '500', repaid_amount: '200', status: 'OPEN' };
  employeeRow = { id: 1, fullName: 'محمد علي', status: 'ACTIVE' };
  asAdmin();
});

describe('صلاحيات النقدية', () => {
  it('عرض الحركة يحتاج cash.movement.view', async () => {
    currentUser = { id: 5, employeeId: null, permissions: new Set() };
    const { todayCashMovement } = await import('@/services/cash.service');
    await expect(todayCashMovement()).rejects.toMatchObject({ code: 'PERM_DENIED' });
  });

  it('الموظف يجرد ولا يغلق ولا يرحّل', async () => {
    asStaff();
    const { closeDay, recordTransfer } = await import('@/services/cash.service');
    await expect(closeDay({})).rejects.toMatchObject({
      code: 'PERM_DENIED', details: { permission: 'cash.close' },
    });
    await expect(recordTransfer({ amount: 100 })).rejects.toMatchObject({
      code: 'PERM_DENIED', details: { permission: 'cash.transfer' },
    });
  });
});

describe('إغلاق اليوم', () => {
  it('يُرفض بلا جرد', async () => {
    closingRow = null;
    const { closeDay } = await import('@/services/cash.service');
    await expect(closeDay({})).rejects.toMatchObject({ code: 'BUSINESS_RULE' });
    expect(auditSpy).not.toHaveBeenCalled();
  });

  it('يُرفض إذا كان اليوم مغلقًا بالفعل', async () => {
    closingRow = { id: 1, status: 'CLOSED', counted_at: new Date() };
    const { closeDay } = await import('@/services/cash.service');
    await expect(closeDay({})).rejects.toMatchObject({ code: 'BUSINESS_RULE' });
  });

  it('ينجح بعد الجرد ويسجّل التدقيق ويعيد المبلغ الواجب ترحيله', async () => {
    closingRow = { id: 1, status: 'OPEN', counted_at: new Date() };
    const { closeDay } = await import('@/services/cash.service');
    const r = await closeDay({});
    expect(r.status).toBe('CLOSED');
    // الواجب ترحيله = الفعلي 1150 − التأمين 1000
    expect(r.requiredTransfer).toBe('150');
    expect(auditSpy.mock.calls[0][0]).toMatchObject({
      action: 'cash.close', entityType: 'DailyCashClosing',
      before: { status: 'OPEN' }, after: { status: 'CLOSED' },
    });
  });
});

describe('الترحيل', () => {
  const closed = {
    id: 1, status: 'CLOSED',
    actualCounted: { toString: () => '1150' },
    expectedInsuranceCash: { toString: () => '1000' },
    variance: { toString: () => '-50' },
  };

  it('يُرفض قبل الإغلاق', async () => {
    closingRow = { ...closed, status: 'OPEN' };
    const { recordTransfer } = await import('@/services/cash.service');
    await expect(recordTransfer({ amount: 150 })).rejects.toMatchObject({ code: 'BUSINESS_RULE' });
  });

  it('يرفض الترحيل الجزئي', async () => {
    closingRow = closed;
    const { recordTransfer } = await import('@/services/cash.service');
    await expect(recordTransfer({ amount: 100 }))
      .rejects.toMatchObject({ code: 'BUSINESS_RULE' });
  });

  it('يرفض ترحيلًا يشمل التأمين', async () => {
    closingRow = closed;
    const { recordTransfer } = await import('@/services/cash.service');
    await expect(recordTransfer({ amount: 1150 }))
      .rejects.toMatchObject({ code: 'BUSINESS_RULE' });
  });

  it('★ الترحيل الكامل ينجح ولا يمس الفرق', async () => {
    closingRow = closed;
    const { recordTransfer } = await import('@/services/cash.service');
    const r = await recordTransfer({ amount: 150 });
    expect(r.amount).toBe('150');
    expect(r.variance).toBe('-50');   // الفرق لم يتغير
    expect(auditSpy.mock.calls[0][0]).toMatchObject({
      action: 'cash.transfer',
      after: { varianceUnchanged: '-50' },
    });
  });

  it('يرفض ترحيل اليوم مرتين', async () => {
    closingRow = closed;
    transferRow = { id: 1 };
    const { recordTransfer } = await import('@/services/cash.service');
    await expect(recordTransfer({ amount: 150 })).rejects.toMatchObject({ code: 'CONFLICT' });
  });
});

describe('سلف الموظفين', () => {
  it('السلفة خروج نقدي وليست مصروفًا', async () => {
    const { createAdvance } = await import('@/services/advance.service');
    const r = await createAdvance({ employeeId: 1, amount: 500, paymentMethodId: 1 });
    expect(r.amount).toBe('500');
    expect(r.balance).toBe('500');
    expect(created.expense).toBeUndefined();      // ★ لا مصروف
    expect(auditSpy.mock.calls[0][0]).toMatchObject({
      action: 'advance.create',
      after: { isExpense: false, profitImpact: '0' },
    });
  });

  it('تُرفض لموظف غير نشط', async () => {
    employeeRow = { id: 1, fullName: 'x', status: 'INACTIVE' };
    const { createAdvance } = await import('@/services/advance.service');
    await expect(createAdvance({ employeeId: 1, amount: 500, paymentMethodId: 1 }))
      .rejects.toMatchObject({ code: 'BUSINESS_RULE' });
  });

  it('تحتاج صلاحية advances.create', async () => {
    asStaff();
    const { createAdvance } = await import('@/services/advance.service');
    await expect(createAdvance({ employeeId: 1, amount: 500, paymentMethodId: 1 }))
      .rejects.toMatchObject({ code: 'PERM_DENIED', details: { permission: 'advances.create' } });
  });

  it('السداد لا يتجاوز الرصيد', async () => {
    const { repayAdvance } = await import('@/services/advance.service');
    // الرصيد 300 (500 − 200)
    await expect(repayAdvance({ advanceId: 1, amount: 400, method: 'CASH' }))
      .rejects.toMatchObject({ code: 'BUSINESS_RULE' });
  });

  it('السداد داخل الرصيد ينجح ولا يُنشئ مصروفًا', async () => {
    const { repayAdvance } = await import('@/services/advance.service');
    const r = await repayAdvance({ advanceId: 1, amount: 200, method: 'CASH' });
    expect(r.balance).toBe('300');
    expect(created.expense).toBeUndefined();
    expect(auditSpy.mock.calls[0][0]).toMatchObject({
      action: 'advance.repay', after: { isExpense: false },
    });
  });

  it('الخصم من الراتب يستلزم مصروفًا مرتبطًا', async () => {
    const { repayAdvance } = await import('@/services/advance.service');
    await expect(repayAdvance({ advanceId: 1, amount: 100, method: 'SALARY_DEDUCTION' }))
      .rejects.toMatchObject({ code: 'BUSINESS_RULE' });
  });

  it('السلفة المسدَّدة بالكامل لا تُسدَّد مجددًا', async () => {
    advanceRow = { id: 1, amount: '500', repaid_amount: '500', status: 'SETTLED' };
    const { repayAdvance } = await import('@/services/advance.service');
    await expect(repayAdvance({ advanceId: 1, amount: 10, method: 'CASH' }))
      .rejects.toMatchObject({ code: 'BUSINESS_RULE' });
  });
});

describe('الراتب مع خصم السلفة', () => {
  it('★ المصروف 6,000 والخروج النقدي 5,500', async () => {
    advanceRow = { id: 1, balance: '500', status: 'OPEN' };
    const { paySalary } = await import('@/services/advance.service');
    const r = await paySalary({
      employeeId: 1, grossSalary: 6000, advanceIds: [1],
      otherDeductions: 0, paymentMethodId: 1,
    });

    expect(r.grossSalary).toBe('6000');
    expect(r.salaryExpense).toBe('6000');
    expect(r.cashPaidAmount).toBe('5500');
    expect(r.advanceDeduction).toBe('500');

    // سجل المصروف يحمل الرقمين منفصلين
    expect(created.expense[0]).toMatchObject({ amount: '6000', cashPaidAmount: '5500' });
    // تسوية السلفة بلا مصروف إضافي
    expect(created.repayment).toHaveLength(1);
    expect(created.repayment[0]).toMatchObject({ method: 'SALARY_DEDUCTION', amount: '500' });
    expect(created.expense).toHaveLength(1);      // ★ مصروف واحد فقط
  });

  it('بلا سلف: المصروف = الخروج النقدي', async () => {
    const { paySalary } = await import('@/services/advance.service');
    const r = await paySalary({
      employeeId: 1, grossSalary: 6000, advanceIds: [],
      otherDeductions: 0, paymentMethodId: 1,
    });
    expect(r.salaryExpense).toBe(r.cashPaidAmount);
    expect(created.repayment).toBeUndefined();
  });

  it('يسجّل تفاصيل الراتب في التدقيق', async () => {
    advanceRow = { id: 1, balance: '500', status: 'OPEN' };
    const { paySalary } = await import('@/services/advance.service');
    await paySalary({
      employeeId: 1, grossSalary: 6000, advanceIds: [1],
      otherDeductions: 0, paymentMethodId: 1,
    });
    expect(auditSpy.mock.calls[0][0]).toMatchObject({
      action: 'salary.pay',
      after: {
        grossSalary: '6000', advanceDeduction: '500',
        netSalary: '5500', salaryExpense: '6000', cashPaidAmount: '5500',
      },
    });
  });

  it('يرفض خصومات تتجاوز الراتب', async () => {
    advanceRow = { id: 1, balance: '5000', status: 'OPEN' };
    const { paySalary } = await import('@/services/advance.service');
    await expect(paySalary({
      employeeId: 1, grossSalary: 1000, advanceIds: [1],
      otherDeductions: 0, paymentMethodId: 1,
    })).rejects.toMatchObject({ code: 'BUSINESS_RULE' });
  });
});
