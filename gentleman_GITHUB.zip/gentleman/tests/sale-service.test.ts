import { describe, it, expect, vi, beforeEach } from 'vitest';

/**
 * اختبارات طبقة خدمة البيع.
 * قاعدة البيانات محاكاة، والهدف: الصلاحيات، خطوات المعاملة، الرفض،
 * محتوى سجل التدقيق، وأثر الإلغاء الكامل.
 */

const auditSpy = vi.fn();
let currentUser: { id: number; employeeId: number | null; permissions: Set<string> };
let items: Record<number, { id: number; item_code: string; status: string; purchase_cost: string }>;
let saleRow: { id: number; invoice_no: string; status: string; net_amount: string; total_cost: string } | null;
let saleItemRows: { id: number; itemId: number; preSaleStatus: string; lateFee?: number }[];
let settings: Record<string, unknown>;

const created: Record<string, unknown[]> = {};
const record = (k: string) => (a: { data: Record<string, unknown> }) => {
  (created[k] ??= []).push(a.data);
  return { id: (created[k].length), ...a.data };
};

const tx = {
  $queryRaw: vi.fn(async (strings: TemplateStringsArray) => {
    const q = strings.join(' ');
    if (q.includes('FROM product_items')) return Object.values(items);
    if (q.includes('FROM sales')) return saleRow ? [saleRow] : [];
    return [];
  }),
  $executeRaw: vi.fn(async () => 1),
  employee: { findUnique: vi.fn(async () => ({ salesCommissionPct: { toString: () => '3' } })) },
  customer: { findUnique: vi.fn(async () => ({ id: 1, isActive: true })) },
  sale: {
    findFirst: vi.fn(async () => null),
    create: vi.fn(async (a: any) => ({ id: 77, ...a.data })),
    update: vi.fn(async (a: any) => ({ id: 77, invoiceNo: 'INV-2026-000001', status: a.data.status })),
  },
  saleItem: {
    create: vi.fn(record('saleItem')),
    findMany: vi.fn(async () => saleItemRows),
  },
  productItem: {
    update: vi.fn(record('itemUpdate')),
    findMany: vi.fn(async () => saleItemRows.map((s) => ({ id: s.itemId, status: items[s.itemId]?.status ?? 'SOLD' }))),
  },
  itemStatusHistory: { create: vi.fn(record('history')) },
  inventoryTransaction: { create: vi.fn(record('inventory')) },
  itemBooking: { updateMany: vi.fn(async () => ({ count: 0 })) },
  payment: {
    findFirst: vi.fn(async () => null),
    create: vi.fn(record('payment')),
    updateMany: vi.fn(async () => ({ count: 1 })),
  },
};

vi.mock('@/lib/db', () => ({
  prisma: {
    $transaction: (fn: any) => fn(tx),
    productItem: { findFirst: vi.fn(async () => null) },
  },
}));

vi.mock('@/lib/audit', () => ({ writeAudit: (...a: any[]) => auditSpy(...a), redact: (x: any) => x }));

vi.mock('@/lib/settings', () => ({
  getBoolSetting: async (k: string) => Boolean(settings[k]),
  getNumberSetting: async (k: string) => {
    const { Decimal } = await import('decimal.js');
    return new Decimal((settings[k] as number) ?? 0);
  },
  getStringSetting: async (k: string) => String(settings[k] ?? ''),
}));

vi.mock('@/lib/auth/rbac', async (importOriginal) => {
  const actual = await importOriginal<typeof import('@/lib/auth/rbac')>();
  return {
    ...actual,
    requirePermission: async (perm: string) => {
      if (!currentUser.permissions.has(perm)) {
        const { Errors } = await import('@/lib/errors');
        throw Errors.forbidden(perm);
      }
      return currentUser as never;
    },
  };
});

const asStaff = () => { currentUser = { id: 9, employeeId: 3, permissions: new Set(['sales.view', 'sales.create']) }; };
const asAdmin = () => {
  currentUser = {
    id: 1, employeeId: 1,
    permissions: new Set(['sales.view', 'sales.create', 'sales.void', 'discount.override']),
  };
};

beforeEach(() => {
  auditSpy.mockClear();
  for (const k of Object.keys(created)) delete created[k];
  for (const m of Object.values(tx)) {
    if (typeof m === 'object' && m !== null) {
      for (const f of Object.values(m)) if (typeof f === 'function' && 'mockClear' in f) (f as any).mockClear();
    } else if (typeof m === 'function' && 'mockClear' in m) (m as any).mockClear();
  }
  items = {
    1: { id: 1, item_code: 'SUIT-0001', status: 'AVAILABLE', purchase_cost: '6000' },
    2: { id: 2, item_code: 'SUIT-0002', status: 'RENTED', purchase_cost: '6000' },
    3: { id: 3, item_code: 'SUIT-0003', status: 'SOLD', purchase_cost: '6000' },
    4: { id: 4, item_code: 'SUIT-0004', status: 'DAMAGED', purchase_cost: '6000' },
    5: { id: 5, item_code: 'SUIT-0005', status: 'OVERDUE', purchase_cost: '6000' },
  };
  saleRow = { id: 77, invoice_no: 'INV-2026-000001', status: 'COMPLETED', net_amount: '1300', total_cost: '6000' };
  saleItemRows = [{ id: 1, itemId: 1, preSaleStatus: 'AVAILABLE' }];
  settings = { 'vat.enabled': false, 'vat.rate': 14, 'discount.staff_max_percent': 10 };
  asAdmin();
});

const sell = async (itemIds: number[], unitPrice = 1500, discount = 0, paid?: number) => {
  const { createSale } = await import('@/services/sale.service');
  items = Object.fromEntries(itemIds.map((id) => [id, items[id]])) as typeof items;
  const total = itemIds.length * (unitPrice - discount);
  return createSale({
    items: itemIds.map((itemId) => ({ itemId, unitPrice, discount })),
    paidAmount: paid ?? total,
    paymentMethodId: 1,
  });
};

describe('بيع قطعة متاحة', () => {
  it('ينشئ الفاتورة والسطر ويحوّل القطعة إلى مباعة ويسجّل الدفعة والتدقيق', async () => {
    const r = await sell([1], 1500, 200);

    expect(r.netAmount).toBe('1300');
    expect(r.paidAmount).toBe('1300');
    expect(r.remaining).toBe('0');
    expect(r.totalCost).toBe('6000');
    expect(r.grossProfit).toBe('-4700');

    // السطر يحفظ التكلفة وحالة ما قبل البيع
    expect(created.saleItem[0]).toMatchObject({
      itemId: 1, netPrice: '1300', purchaseCost: '6000', preSaleStatus: 'AVAILABLE', isDamagedSale: false,
    });
    // القطعة صارت مباعة
    expect(created.itemUpdate[0]).toMatchObject({ status: 'SOLD' });
    // سجل الحالة وحركة المخزون
    expect(created.history[0]).toMatchObject({ fromStatus: 'AVAILABLE', toStatus: 'SOLD' });
    expect(created.inventory[0]).toMatchObject({ type: 'SALE' });
    // دفعة واحدة بقيمة الفاتورة، غير تأمينية
    expect(created.payment[0]).toMatchObject({ purpose: 'SALE', isInsurance: false, amount: '1300' });
    // التدقيق
    expect(auditSpy.mock.calls[0][0]).toMatchObject({
      action: 'sale.create', entityType: 'Sale',
      after: { netAmount: '1300', totalCost: '6000', grossProfit: '-4700' },
    });
  });

  it('يعطّل أي ارتباط زمني للقطعة المباعة', async () => {
    await sell([1]);
    expect(tx.itemBooking.updateMany).toHaveBeenCalledWith(
      expect.objectContaining({ data: { isActive: false } }),
    );
  });
});

describe('منع بيع القطع غير المؤهلة', () => {
  it('لا تُباع قطعة مؤجرة', async () => {
    await expect(sell([2])).rejects.toMatchObject({ code: 'BUSINESS_RULE' });
    expect(created.saleItem).toBeUndefined();
  });
  it('لا تُباع قطعة متأخرة', async () => {
    await expect(sell([5])).rejects.toMatchObject({ code: 'BUSINESS_RULE' });
  });
  it('لا تُباع قطعة مباعة', async () => {
    await expect(sell([3])).rejects.toMatchObject({ code: 'BUSINESS_RULE' });
  });
  it('القطعة التالفة تُباع وتُوسم بيع تالف', async () => {
    const r = await sell([4], 500, 0);
    expect(r.netAmount).toBe('500');
    expect(created.saleItem[0]).toMatchObject({ preSaleStatus: 'DAMAGED', isDamagedSale: true });
  });
});

describe('البيع نقدي بالكامل', () => {
  it('يرفض السداد الجزئي', async () => {
    await expect(sell([1], 1000, 0, 600)).rejects.toMatchObject({ code: 'BUSINESS_RULE' });
  });
  it('يرفض السداد الزائد', async () => {
    await expect(sell([1], 1000, 0, 1200)).rejects.toMatchObject({ code: 'BUSINESS_RULE' });
  });
  it('يرفض خصمًا أكبر من السعر', async () => {
    await expect(sell([1], 500, 900, 0)).rejects.toMatchObject({ code: 'BUSINESS_RULE' });
  });
});

describe('الصلاحيات', () => {
  it('البيع يحتاج sales.create', async () => {
    currentUser = { id: 5, employeeId: null, permissions: new Set(['sales.view']) };
    await expect(sell([1])).rejects.toMatchObject({ code: 'PERM_DENIED' });
  });

  it('خصم فوق حد الموظف يحتاج discount.override', async () => {
    asStaff();
    await expect(sell([1], 1000, 300)).rejects.toMatchObject({
      code: 'PERM_DENIED', details: { permission: 'discount.override' },
    });
  });

  it('خصم داخل الحد يمر للموظف', async () => {
    asStaff();
    const r = await sell([1], 1000, 100);
    expect(r.netAmount).toBe('900');
  });

  it('الإلغاء يحتاج sales.void', async () => {
    asStaff();
    const { voidSale } = await import('@/services/sale.service');
    await expect(voidSale({ saleId: 77, reason: 'خطأ في الفاتورة' }))
      .rejects.toMatchObject({ code: 'PERM_DENIED', details: { permission: 'sales.void' } });
  });
});

describe('إلغاء الفاتورة', () => {
  it('يعيد القطعة إلى حالتها قبل البيع ويلغي الدفعات ويسجّل التدقيق', async () => {
    items[1].status = 'SOLD';
    const { voidSale } = await import('@/services/sale.service');
    const r = await voidSale({ saleId: 77, reason: 'العميل أعاد القطعة فورًا' });

    expect(r.status).toBe('VOIDED');
    expect(r.restoredItems).toEqual([{ itemId: 1, restoredTo: 'AVAILABLE' }]);
    expect(created.itemUpdate[0]).toMatchObject({ status: 'AVAILABLE', disposedAt: null });
    expect(created.history[0]).toMatchObject({ fromStatus: 'SOLD', toStatus: 'AVAILABLE' });
    expect(created.inventory[0]).toMatchObject({ type: 'ADJUST' });
    expect(tx.payment.updateMany).toHaveBeenCalledWith(
      expect.objectContaining({ data: expect.objectContaining({ isVoided: true }) }),
    );
    expect(auditSpy.mock.calls[0][0]).toMatchObject({
      action: 'sale.void',
      before: { status: 'COMPLETED', netAmount: '1300', totalCost: '6000' },
      after: { status: 'VOIDED', netAmount: '0', totalCost: '0' },
      reason: 'العميل أعاد القطعة فورًا',
    });
  });

  it('القطعة التالفة تعود تالفة لا متاحة', async () => {
    items[4].status = 'SOLD';
    saleItemRows = [{ id: 1, itemId: 4, preSaleStatus: 'DAMAGED' }];
    const { voidSale } = await import('@/services/sale.service');
    const r = await voidSale({ saleId: 77, reason: 'إلغاء' });
    expect(r.restoredItems).toEqual([{ itemId: 4, restoredTo: 'DAMAGED' }]);
    expect(created.itemUpdate[0]).toMatchObject({ status: 'DAMAGED' });
  });

  it('★ لا يستخدم أي عَلَم جلسة — الإذن مبني على حالة البيانات', async () => {
    items[1].status = 'SOLD';
    const { voidSale } = await import('@/services/sale.service');
    await voidSale({ saleId: 77, reason: 'إلغاء' });
    const calls = tx.$executeRaw.mock.calls.map((c) => (c[0] as TemplateStringsArray).join(' '));
    expect(calls.some((q) => q.includes('void_sale') || q.includes('set_config'))).toBe(false);
  });

  it('★ تُلغى الفاتورة قبل استعادة القطع — وهو شرط سماح قاعدة البيانات', async () => {
    items[1].status = 'SOLD';
    const order: string[] = [];
    tx.sale.update.mockImplementationOnce(async (a: any) => { order.push('sale'); return { id: 77, invoiceNo: 'INV-2026-000001', status: a.data.status }; });
    tx.productItem.update.mockImplementationOnce(async (a: any) => { order.push('item'); return a.data; });
    const { voidSale } = await import('@/services/sale.service');
    await voidSale({ saleId: 77, reason: 'إلغاء' });
    expect(order).toEqual(['sale', 'item']);
  });

  it('★ محاولة موظف بلا صلاحية الوصول إلى SOLD → AVAILABLE تفشل', async () => {
    items[1].status = 'SOLD';
    currentUser = { id: 9, employeeId: 3, permissions: new Set(['sales.view', 'sales.create', 'items.manage']) };
    const { voidSale } = await import('@/services/sale.service');
    await expect(voidSale({ saleId: 77, reason: 'محاولة تجاوز' }))
      .rejects.toMatchObject({ code: 'PERM_DENIED', details: { permission: 'sales.void' } });
    expect(tx.sale.update).not.toHaveBeenCalled();
    expect(tx.productItem.update).not.toHaveBeenCalled();
  });

  it('★ تغيير حالة قطعة مباعة عبر شاشة المخزون مرفوض من آلة الحالة', async () => {
    const { canTransition } = await import('@/lib/inventory/item-state');
    expect(canTransition('SOLD', 'AVAILABLE', { manual: true }).allowed).toBe(false);
    expect(canTransition('SOLD', 'AVAILABLE').allowed).toBe(false);
  });

  it('يرفض إلغاء فاتورة ملغاة', async () => {
    saleRow!.status = 'VOIDED';
    const { voidSale } = await import('@/services/sale.service');
    await expect(voidSale({ saleId: 77, reason: 'محاولة ثانية' }))
      .rejects.toMatchObject({ code: 'BUSINESS_RULE' });
    expect(auditSpy).not.toHaveBeenCalled();
  });

  it('يرفض الإلغاء إذا تغيّرت حالة القطعة بعد البيع', async () => {
    items[1].status = 'DISPOSED';
    const { voidSale } = await import('@/services/sale.service');
    await expect(voidSale({ saleId: 77, reason: 'إلغاء' }))
      .rejects.toMatchObject({ code: 'BUSINESS_RULE' });
  });

  it('يرفض إلغاء فاتورة غير موجودة قبل أي كتابة', async () => {
    saleRow = null;
    const { voidSale } = await import('@/services/sale.service');
    await expect(voidSale({ saleId: 999, reason: 'غير موجودة' }))
      .rejects.toMatchObject({ code: 'NOT_FOUND' });
    expect(auditSpy).not.toHaveBeenCalled();
  });

  it('سبب الإلغاء إلزامي', async () => {
    const { voidSaleSchema } = await import('@/services/sale.service');
    expect(voidSaleSchema.safeParse({ saleId: 1 }).success).toBe(false);
    expect(voidSaleSchema.safeParse({ saleId: 1, reason: '' }).success).toBe(false);
    expect(voidSaleSchema.safeParse({ saleId: 1, reason: 'خطأ' }).success).toBe(true);
  });
});

describe('العميل', () => {
  it('يُربط بالعميل النقدي عند عدم تحديد عميل', async () => {
    await sell([1]);
    expect(tx.customer.findUnique).toHaveBeenCalledWith(
      expect.objectContaining({ where: { code: 'WALKIN' } }),
    );
  });
});

describe('★ مراجعة أمنية: لا يمكن تجاوز آلة الحالة عبر مسار الإلغاء', () => {
  it('موظف بلا صلاحية الإلغاء يُرفض قبل أي كتابة أو تغيير حالة', async () => {
    asStaff();
    items[1].status = 'SOLD';
    const { voidSale } = await import('@/services/sale.service');
    await expect(voidSale({ saleId: 77, reason: 'محاولة استغلال' }))
      .rejects.toMatchObject({ code: 'PERM_DENIED', details: { permission: 'sales.void' } });

    // لا تغيير حالة، ولا سجل حالة، ولا تدقيق، ولا لمس للدفعات
    expect(created.itemUpdate).toBeUndefined();
    expect(created.history).toBeUndefined();
    expect(auditSpy).not.toHaveBeenCalled();
    expect(tx.payment.updateMany).not.toHaveBeenCalled();
  });

  it('لا يوجد أي مسار في الخدمة يضبط عَلَم جلسة لتجاوز آلة الحالة', async () => {
    items[1].status = 'SOLD';
    const { voidSale } = await import('@/services/sale.service');
    await voidSale({ saleId: 77, reason: 'إلغاء سليم' });

    const rawCalls = tx.$executeRaw.mock.calls
      .map((c) => (c[0] as TemplateStringsArray).join(' '))
      .join(' | ');
    expect(rawCalls).not.toContain('set_config');
    expect(rawCalls).not.toContain('void_sale');
  });

  it('الإلغاء يبدأ بالتحقق من الوجود والحالة قبل أي تعديل على القطع', async () => {
    saleRow = null;
    const { voidSale } = await import('@/services/sale.service');
    await expect(voidSale({ saleId: 999, reason: 'فاتورة غير موجودة' }))
      .rejects.toMatchObject({ code: 'NOT_FOUND' });
    expect(created.itemUpdate).toBeUndefined();
  });

  it('تغيير حالة قطعة مباعة يدويًا من شاشة المخزون مرفوض', async () => {
    const { canTransition } = await import('@/lib/inventory/item-state');
    for (const to of ['AVAILABLE', 'DAMAGED', 'MAINTENANCE', 'RENTED'] as const) {
      expect(canTransition('SOLD', to, { manual: true }).allowed).toBe(false);
    }
  });
});
