import { listReservations } from '@/services/reservation.service';
import { listPaymentMethods } from '@/services/finance.service';
import { getSession } from '@/lib/auth/session';
import { formatEGP } from '@/lib/money';
import ReservationForm from '@/components/ReservationForm';
import ReservationActions from '@/components/ReservationActions';

export const dynamic = 'force-dynamic';

export default async function ReservationsPage() {
  const session = await getSession();
  const canCreate = session?.permissions.has('reservations.create') ?? false;
  const canCancel = session?.permissions.has('reservations.cancel') ?? false;
  const canConvert = session?.permissions.has('reservations.convert') ?? false;

  const [rows, methods] = await Promise.all([
    listReservations({}),
    canCreate ? listPaymentMethods() : Promise.resolve([]),
  ]);

  const active = rows.filter((r) => r.status === 'PENDING' || r.status === 'CONFIRMED');

  return (
    <div className="space-y-6">
      <div>
        <h1 className="section-title">الحجوزات</h1>
        <p className="text-sm text-slate-600 mt-1">
          الحجوزات القائمة: <span className="num">{active.length}</span> من إجمالي{' '}
          <span className="num">{rows.length}</span>
        </p>
      </div>

      {canCreate && (
        <ReservationForm methods={methods.map((m) => ({ id: m.id, nameAr: m.nameAr }))} />
      )}

      <div className="card overflow-hidden">
        <div className="card-header">قائمة الحجوزات</div>
        <div className="overflow-x-auto">
          <table className="table">
            <thead>
              <tr>
                <th>رقم الحجز</th><th>العميل</th><th>المناسبة</th>
                <th>الاستلام</th><th>الإرجاع</th><th>القطع</th>
                <th>العربون</th><th>الحالة</th><th></th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.id} className={r.status === 'CANCELLED' ? 'opacity-50' : ''}>
                  <td className="num">{r.reservationNo}</td>
                  <td>
                    {r.customer}
                    {r.phone && <span className="block text-xs text-slate-500 num">{r.phone}</span>}
                  </td>
                  <td className="num">{r.eventDate}</td>
                  <td className="num">{r.pickupDate}</td>
                  <td className="num">{r.returnDate}</td>
                  <td className="text-xs">
                    {r.items.map((i) => i.itemCode).filter(Boolean).join('، ') || '—'}
                  </td>
                  <td className="num">
                    {formatEGP(r.depositCollected)}
                    {Number(r.depositRefunded) > 0 && (
                      <span className="block text-xs text-danger">
                        رُدَّ {formatEGP(r.depositRefunded)}
                      </span>
                    )}
                  </td>
                  <td>
                    <span className={`badge ${
                      r.status === 'CANCELLED' ? 'bg-red-100 text-danger'
                      : r.status === 'CONVERTED' ? 'bg-slate-100 text-slate-500'
                      : r.isMissed ? 'bg-amber-100 text-warn'
                      : 'bg-green-100 text-ok'}`}>
                      {r.displayLabel}
                    </span>
                    {r.convertedRentalNo && (
                      <span className="block text-xs text-slate-500 num mt-1">
                        {r.convertedRentalNo}
                      </span>
                    )}
                  </td>
                  <td>
                    {(r.status === 'PENDING' || r.status === 'CONFIRMED') && (
                      <ReservationActions
                        reservationId={r.id}
                        reservationNo={r.reservationNo}
                        canCancel={canCancel}
                        canConvert={canConvert}
                        methods={methods.map((m) => ({ id: m.id, nameAr: m.nameAr }))}
                      />
                    )}
                  </td>
                </tr>
              ))}
              {rows.length === 0 && (
                <tr><td colSpan={9} className="text-center text-slate-500 py-8">لا توجد حجوزات.</td></tr>
              )}
            </tbody>
          </table>
        </div>
        <p className="px-5 py-4 text-xs text-slate-500 border-t border-slate-200">
          الحجز لا يُنشئ إيرادًا — العربون دخول نقدي فقط، والإيراد يُعترف به عند التحويل إلى تأجير.
          حالة «فائت» مشتقة للعرض ولا تُخزَّن.
        </p>
      </div>
    </div>
  );
}
