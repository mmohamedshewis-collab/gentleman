import { z } from 'zod';
import { Decimal } from 'decimal.js';
import { prisma } from '@/lib/db';
import { Errors } from '@/lib/errors';
import { writeAudit } from '@/lib/audit';
import { requirePermission } from '@/lib/auth/rbac';
import { toBusinessDate, businessToday, periodBounds } from '@/lib/date';
import { round2, add, sub } from '@/lib/money';
import {
  earnedForPeriod, periodVariance, computePayout, assertPayable,
  periodMonthOf, previousMonths, monthBounds,
  type EarningOperation,
} from '@/lib/hr/commission';

/**
 * صرف عمولة الموظف.
 *
 * ★ الطبقات الخمس:
 *   Performance — تحليلي، لا يُخزَّن ولا يدخل الربح
 *   Earned      — دالة على العملية بنسبة مجمَّدة، وصفر إن كانت ملغاة
 *   Paid        — صف في `commissions` يُنشأ عند الصرف فقط
 *   Expense     — صف واحد في `expenses` تصنيف «عمولات» مربوط بسجل الصرف
 *   Cash Outflow— هو نفسه سجل المصروف لا سجل ثانٍ
 *
 * ⛔ لا يوجد Commission Payable.
 */

const monthSchema = z.string().regex(/^\d{4}-\d{2}$/, 'الفترة بصيغة YYYY-MM');

export const commissionQuerySchema = z.object({
  employeeId: z.coerce.number().int().positive().optional(),
  periodMonth: monthSchema.optional(),
});

export const payCommissionSchema = z.object({
  employeeId: z.number().int().positive('يجب اختيار الموظف'),
  periodMonth: monthSchema,
  paymentMethodId: z.number().int().positive(),
  expenseDate: z.string().optional(),
  notes: z.string().max(500).optional(),
});

// ============ جمع عمليات الموظف في فترة ============

async function operationsFor(employeeId: number, from: string, to: string): Promise<EarningOperation[]> {
  const { start, end } = periodBounds(from, to);

  const [rentals, sales] = await Promise.all([
    prisma.rental.findMany({
      where: { employeeId, createdAt: { gte: start, lte: end } },
      select: { netAmount: true, commissionRatePct: true, status: true },
    }),
    prisma.sale.findMany({
      where: { employeeId, createdAt: { gte: start, lte: end } },
      select: { netAmount: true, commissionRatePct: true, status: true },
    }),
  ]);

  return [
    ...rentals.map((r) => ({
      kind: 'RENTAL' as const,
      netAmount: r.netAmount.toString(),
      ratePct: r.commissionRatePct?.toString() ?? null,
      isVoided: r.status === 'VOIDED',        // ★ الملغى خارج الوعاء
    })),
    ...sales.map((s) => ({
      kind: 'SALE' as const,
      netAmount: s.netAmount.toString(),
      ratePct: s.commissionRatePct?.toString() ?? null,
      isVoided: s.status !== 'COMPLETED',
    })),
  ];
}

/** العمولة المستحقة عن شهر — تُحسب لحظيًا وتعكس الحقيقة الآن. */
export async function earnedForMonth(employeeId: number, periodMonth: string) {
  const { from, to } = monthBounds(periodMonth);
  return earnedForPeriod(await operationsFor(employeeId, from, to));
}

/**
 * المصروف فعلًا عن شهر — سجل مجمَّد لا يُعدَّل.
 * `wasPaid = false` تعني أن الفترة لم تُصرف أصلًا، وهي **ليست فرقًا**:
 * الفرق يقيس تغيّر المستحق **بعد** الصرف فقط. لولا هذا التمييز لأُضيفت
 * كل فترة غير مصروفة إلى كل صرف تالٍ، فتُصرف مرارًا بلا نهاية.
 */
async function paidForMonth(
  employeeId: number,
  periodMonth: string,
): Promise<{ amount: Decimal; wasPaid: boolean }> {
  const row = await prisma.commission.findUnique({
    where: { employeeId_periodMonth: { employeeId, periodMonth } },
    select: { commissionAmount: true, status: true },
  });
  if (!row || row.status !== 'PAID') return { amount: round2(0), wasPaid: false };
  return { amount: round2(row.commissionAmount.toString()), wasPaid: true };
}

// ============ كشف العمولة للموظف ============

/**
 * يفصل صراحةً بين الطبقات الأربع حتى لا يختلط التحليلي بالمصروف.
 */
export async function commissionStatement(input: z.infer<typeof commissionQuerySchema>) {
  await requirePermission('commissions.view');

  const periodMonth = input.periodMonth ?? periodMonthOf(businessToday());
  const employees = await prisma.employee.findMany({
    where: input.employeeId ? { id: input.employeeId } : { status: 'ACTIVE' },
    orderBy: { code: 'asc' },
  });

  const rows = [];
  for (const emp of employees) {
    const earned = await earnedForMonth(emp.id, periodMonth);
    const paidNow = await paidForMonth(emp.id, periodMonth);
    const paid = paidNow.amount;

    // فروق الفترات الست السابقة — **المصروفة فقط**
    const priors = [];
    for (const m of previousMonths(periodMonth, 6)) {
      const p = await paidForMonth(emp.id, m);
      if (!p.wasPaid) continue;              // فترة لم تُصرف ليست فرقًا
      const e = await earnedForMonth(emp.id, m);
      const v = periodVariance({ periodMonth: m, earned: e.total, paid: p.amount });
      if (!v.variance.isZero()) priors.push(v);
    }

    const payout = computePayout({
      currentEarned: earned.total,
      priorVariances: priors.map((p) => p.variance),
    });

    const record = await prisma.commission.findUnique({
      where: { employeeId_periodMonth: { employeeId: emp.id, periodMonth } },
      include: { paidExpense: { select: { id: true, expenseNo: true, amount: true } } },
    });

    rows.push({
      employeeId: emp.id,
      code: emp.code,
      fullName: emp.fullName,
      periodMonth,
      // 1) تحليلي — لا يدخل الربح
      performance: {
        rentalBase: earned.rentalBase.toString(),
        salesBase: earned.salesBase.toString(),
        base: earned.base.toString(),
      },
      // 2) المستحق الآن
      earned: {
        rental: earned.rentalCommission.toString(),
        sales: earned.salesCommission.toString(),
        total: earned.total.toString(),
      },
      // 3) المصروف فعلًا
      paid: paid.toString(),
      // الفروق السابقة
      priorVariances: priors.map((p) => ({
        periodMonth: p.periodMonth,
        earned: p.earned.toString(),
        paid: p.paid.toString(),
        variance: p.variance.toString(),
      })),
      priorVarianceTotal: payout.priorVariance.toString(),
      payable: payout.payable.toString(),
      carryForward: payout.carryForward.toString(),
      // 4) المصروف المرتبط — الطريق الوحيد للربح والنقدية
      expense: record?.paidExpense
        ? {
            id: record.paidExpense.id,
            expenseNo: record.paidExpense.expenseNo,
            amount: record.paidExpense.amount.toString(),
          }
        : null,
      status: record?.status ?? 'NOT_PAID',
      isPaid: record?.status === 'PAID',
    });
  }

  return {
    periodMonth,
    rows,
    totals: {
      earned: add(...rows.map((r) => r.earned.total)).toString(),
      paid: add(...rows.map((r) => r.paid)).toString(),
      payable: add(...rows.map((r) => r.payable)).toString(),
    },
    note:
      'الأرقام التحليلية والمستحقة لا تدخل قائمة الأرباح. ' +
      'العمولة تؤثر على الربح والنقدية عبر سجل المصروف عند الصرف فقط.',
  };
}

// ============ صرف العمولة ============

/**
 * الصرف: سجل عمولة واحد + مصروف واحد مربوط به = تدفق نقدي واحد.
 * منع الازدواج بأربع طبقات: قفل استشاري · فحص سجل قائم ·
 * فريد (employee, month) · فريد paid_expense_id.
 */
export async function payCommission(input: z.infer<typeof payCommissionSchema>) {
  const actor = await requirePermission('commissions.pay');
  const expenseDate = input.expenseDate ? toBusinessDate(input.expenseDate) : businessToday();

  const employee = await prisma.employee.findUnique({ where: { id: input.employeeId } });
  if (!employee) throw Errors.notFound('الموظف');

  const category = await prisma.expenseCategory.findFirst({
    where: { nameAr: { contains: 'عمولات' }, isActive: true },
  });
  if (!category) throw Errors.rule('فئة «عمولات» غير موجودة في الإعدادات.');

  // الحساب قبل المعاملة — قراءة فقط
  const earned = await earnedForMonth(input.employeeId, input.periodMonth);
  const priors: Decimal[] = [];
  for (const m of previousMonths(input.periodMonth, 6)) {
    const p = await paidForMonth(input.employeeId, m);
    if (!p.wasPaid) continue;                // فترة لم تُصرف ليست فرقًا
    const e = await earnedForMonth(input.employeeId, m);
    const v = periodVariance({ periodMonth: m, earned: e.total, paid: p.amount });
    if (!v.variance.isZero()) priors.push(v.variance);
  }
  const payout = computePayout({ currentEarned: earned.total, priorVariances: priors });

  try {
    assertPayable(payout.payable);
  } catch (e) {
    throw Errors.rule((e as Error).message);
  }

  return prisma.$transaction(async (tx) => {
    // قفل استشاري على (الموظف، الشهر) يمنع سباق جلستين
    await tx.$executeRaw`
      SELECT pg_advisory_xact_lock(hashtext(${`commission:${input.employeeId}:${input.periodMonth}`}))
    `;

    const existing = await tx.commission.findUnique({
      where: {
        employeeId_periodMonth: {
          employeeId: input.employeeId,
          periodMonth: input.periodMonth,
        },
      },
    });
    if (existing && existing.status === 'PAID') {
      throw Errors.conflict(
        `عمولة ${employee.fullName} عن ${input.periodMonth} مصروفة بالفعل.`,
      );
    }

    // 1) المصروف — الطريق الوحيد للربح والنقدية
    await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext('expense_no'))`;
    const year = expenseDate.getUTCFullYear();
    const last = await tx.expense.findFirst({
      where: { expenseNo: { startsWith: `EXP-${year}-` } },
      orderBy: { expenseNo: 'desc' },
      select: { expenseNo: true },
    });
    const seq = last ? Number.parseInt(last.expenseNo.slice(9), 10) + 1 : 1;

    const expense = await tx.expense.create({
      data: {
        expenseNo: `EXP-${year}-${String(Number.isFinite(seq) ? seq : 1).padStart(6, '0')}`,
        expenseDate,
        categoryId: category.id,
        amount: payout.payable.toString(),
        // الخروج النقدي = المصروف نفسه (لا خصم سلفة هنا)
        cashPaidAmount: payout.payable.toString(),
        paymentMethodId: input.paymentMethodId,
        employeeId: input.employeeId,
        description:
          `صرف عمولة ${employee.fullName} عن ${input.periodMonth}` +
          (input.notes ? ` · ${input.notes}` : ''),
        createdBy: actor.id,
      },
    });

    // 2) سجل الصرف مربوط بالمصروف
    const data = {
      rentalBase: earned.rentalBase.toString(),
      salesBase: earned.salesBase.toString(),
      rentalRatePct: employee.rentalCommissionPct.toString(),
      salesRatePct: employee.salesCommissionPct.toString(),
      commissionAmount: payout.payable.toString(),
      status: 'PAID' as const,
      paidExpenseId: expense.id,
    };

    const record = existing
      ? await tx.commission.update({ where: { id: existing.id }, data })
      : await tx.commission.create({
          data: {
            employeeId: input.employeeId,
            periodMonth: input.periodMonth,
            ...data,
          },
        });

    await writeAudit(
      {
        userId: actor.id,
        action: 'commission.pay',
        entityType: 'Commission',
        entityId: record.id,
        after: {
          employeeId: input.employeeId,
          periodMonth: input.periodMonth,
          currentEarned: payout.currentEarned.toString(),
          priorVariance: payout.priorVariance.toString(),
          paidAmount: payout.payable.toString(),
          carryForward: payout.carryForward.toString(),
          expenseId: expense.id,
          expenseNo: expense.expenseNo,
        },
      },
      tx,
    );

    return {
      commissionId: record.id,
      employeeId: input.employeeId,
      employeeName: employee.fullName,
      periodMonth: input.periodMonth,
      currentEarned: payout.currentEarned.toString(),
      priorVariance: payout.priorVariance.toString(),
      paidAmount: payout.payable.toString(),
      carryForward: payout.carryForward.toString(),
      expenseId: expense.id,
      expenseNo: expense.expenseNo,
    };
  });
}

/** قائمة الموظفين لاختيارهم في شاشات الصرف (عمولة · راتب · سلفة). */
export async function payableEmployees() {
  await requirePermission('employees.view');
  const employees = await prisma.employee.findMany({
    where: { status: 'ACTIVE' },
    select: {
      id: true, code: true, fullName: true, jobTitle: true,
      monthlySalary: true, rentalCommissionPct: true, salesCommissionPct: true,
    },
    orderBy: { code: 'asc' },
  });

  return employees.map((e) => ({
    id: e.id,
    code: e.code,
    fullName: e.fullName,
    jobTitle: e.jobTitle,
    monthlySalary: e.monthlySalary.toString(),
    rentalCommissionPct: e.rentalCommissionPct.toString(),
    salesCommissionPct: e.salesCommissionPct.toString(),
  }));
}

export const commissionSum = (v: Decimal.Value[]) => add(...v);
export const commissionDiff = (a: Decimal.Value, b: Decimal.Value) => sub(a, b);
