import { describe, it, expect } from 'vitest';
import {
  allocatedSalary, computeCommission, computePerformance,
  remainingAfterPayment, PayrollError,
} from '../src/lib/payroll/commission';

const s = (v: { toString(): string }) => v.toString();

describe('تخصيص الراتب للفترة', () => {
  it('شهر كامل = الراتب كاملًا', () => {
    expect(s(allocatedSalary(6000, 30, 30))).toBe('6000');
  });
  it('نصف شهر = نصف الراتب', () => {
    expect(s(allocatedSalary(6000, 15, 30))).toBe('3000');
  });
  it('خمسة أيام من 31 يومًا', () => {
    expect(s(allocatedSalary(6200, 5, 31))).toBe('1000');
  });
  it('يرفض المدخلات غير الصالحة', () => {
    expect(() => allocatedSalary(-1, 10, 30)).toThrowError(PayrollError);
    expect(() => allocatedSalary(6000, -1, 30)).toThrowError(PayrollError);
    expect(() => allocatedSalary(6000, 10, 0)).toThrowError(PayrollError);
  });
});

describe('العمولة', () => {
  const r = computeCommission({
    netRentalSales: 10000, netProductSales: 5000,
    rentalRatePct: 2, salesRatePct: 3,
  });
  it('نسبتان مستقلتان للتأجير والبيع', () => {
    expect(s(r.rentalCommission)).toBe('200');
    expect(s(r.salesCommission)).toBe('150');
    expect(s(r.commissionAmount)).toBe('350');
  });
  it('مبيعات الموظف = تأجير + بيع', () => {
    expect(s(r.employeeSales)).toBe('15000');
  });
  it('★ الغرامات والتأمين خارج الوعاء تمامًا', () => {
    // نفس الأرقام مع غرامات وتأمين ضخمين لا تتغير النتيجة لأنها لا تُمرَّر أصلًا
    const same = computeCommission({
      netRentalSales: 10000, netProductSales: 5000, rentalRatePct: 2, salesRatePct: 3,
    });
    expect(s(same.commissionAmount)).toBe('350');
  });
  it('يرفض النسب خارج النطاق والقيم السالبة', () => {
    expect(() => computeCommission({ netRentalSales: 1, netProductSales: 1, rentalRatePct: 101, salesRatePct: 0 })).toThrowError(PayrollError);
    expect(() => computeCommission({ netRentalSales: -1, netProductSales: 0, rentalRatePct: 1, salesRatePct: 1 })).toThrowError(PayrollError);
  });
});

describe('مؤشر أداء الموظف', () => {
  it('المبيعات ÷ (الراتب + العمولة)', () => {
    const p = computePerformance({ employeeSales: 15000, allocatedSalary: 6000, accruedCommission: 350 });
    expect(s(p.employeeCost)).toBe('6350');
    expect(s(p.performance!)).toBe('2.36');
  });
  it('لا قسمة على صفر — يُعرض "غير محسوب"', () => {
    const p = computePerformance({ employeeSales: 15000, allocatedSalary: 0, accruedCommission: 0 });
    expect(p.performance).toBeNull();
    expect(p.label).toBe('غير محسوب');
  });
  it('موظف بلا مبيعات مؤشره صفر لا خطأ', () => {
    const p = computePerformance({ employeeSales: 0, allocatedSalary: 6000, accruedCommission: 0 });
    expect(s(p.performance!)).toBe('0');
  });
});

describe('المتبقي بعد الدفعة', () => {
  it('يحسب المتبقي بدقة', () => {
    expect(s(remainingAfterPayment(1000, 300, 200))).toBe('500');
  });
  it('السداد الكامل يجعل المتبقي صفرًا', () => {
    expect(s(remainingAfterPayment(1000, 300, 700))).toBe('0');
  });
  it('يرفض الدفعة التي تتجاوز المتبقي', () => {
    expect(() => remainingAfterPayment(1000, 300, 800)).toThrowError(PayrollError);
  });
  it('يرفض الدفعة الصفرية أو السالبة', () => {
    expect(() => remainingAfterPayment(1000, 0, 0)).toThrowError(PayrollError);
    expect(() => remainingAfterPayment(1000, 0, -5)).toThrowError(PayrollError);
  });
});
