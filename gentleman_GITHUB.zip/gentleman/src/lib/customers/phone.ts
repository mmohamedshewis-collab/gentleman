/**
 * أرقام الجوال المصرية — منطق خالص.
 * رقم الجوال هو مفتاح البحث الأساسي عن العميل، فلا بد أن يُخزَّن بصيغة واحدة
 * مهما أدخله الموظف: بمسافات، بشرطات، بمفتاح الدولة، أو بأرقام عربية.
 */

const ARABIC_DIGITS = '٠١٢٣٤٥٦٧٨٩';

/** تحويل الأرقام العربية إلى لاتينية وإزالة كل ما ليس رقمًا. */
function toLatinDigits(raw: string): string {
  let out = '';
  for (const ch of raw) {
    const ai = ARABIC_DIGITS.indexOf(ch);
    if (ai >= 0) out += String(ai);
    else if (ch >= '0' && ch <= '9') out += ch;
  }
  return out;
}

/** شبكات المحمول المصرية. */
const VALID_PREFIXES = ['010', '011', '012', '015'];

export interface PhoneResult {
  ok: boolean;
  phone?: string;   // الصيغة المخزَّنة: 01XXXXXXXXX
  error?: string;
}

/**
 * توحيد رقم الجوال إلى 11 رقمًا يبدأ بـ 01.
 * يقبل: 01012345678 · +201012345678 · 00201012345678 · 0020 10 1234 5678 · ٠١٠١٢٣٤٥٦٧٨
 */
export function normalizePhone(raw: string): PhoneResult {
  if (!raw || !raw.trim()) return { ok: false, error: 'رقم الجوال مطلوب.' };

  let d = toLatinDigits(raw);

  if (d.startsWith('0020')) d = '0' + d.slice(4);
  else if (d.startsWith('20') && d.length === 12) d = '0' + d.slice(2);
  else if (d.length === 10 && d.startsWith('1')) d = '0' + d;

  if (d.length !== 11) {
    return { ok: false, error: 'رقم الجوال يجب أن يتكون من 11 رقمًا (مثال: 01012345678).' };
  }
  if (!VALID_PREFIXES.includes(d.slice(0, 3))) {
    return { ok: false, error: 'رقم الجوال يجب أن يبدأ بـ 010 أو 011 أو 012 أو 015.' };
  }
  return { ok: true, phone: d };
}

/** عرض مقروء: 0101 234 5678 */
export function formatPhone(phone: string): string {
  if (phone.length !== 11) return phone;
  return `${phone.slice(0, 4)} ${phone.slice(4, 7)} ${phone.slice(7)}`;
}

/** الرقم القومي المصري: 14 رقمًا. اختياري، لكن إن أُدخل فليكن صحيحًا. */
export function normalizeNationalId(raw?: string | null): PhoneResult {
  if (!raw || !raw.trim()) return { ok: true, phone: undefined };
  const d = toLatinDigits(raw);
  if (d.length !== 14) {
    return { ok: false, error: 'الرقم القومي يجب أن يتكون من 14 رقمًا.' };
  }
  return { ok: true, phone: d };
}

/** كود العميل: C-000001 */
export const buildCustomerCode = (sequence: number): string =>
  `C-${String(sequence).padStart(6, '0')}`;
