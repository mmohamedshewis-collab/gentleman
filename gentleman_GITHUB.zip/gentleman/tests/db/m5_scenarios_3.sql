\set ON_ERROR_STOP off
\t on
\echo '=== S18 (بعد الإصلاح): إعادة بيع القطعة بعد إلغاء فاتورتها ==='
SELECT 'الفاتورة الجديدة ' || do_sale(ARRAY['SUIT-0001'], 2, 1200, 0);
SELECT 'حالة القطعة=' || status FROM product_items WHERE item_code='SUIT-0001';
\echo ''
\echo '=== S20: محاولة بيع نفس القطعة في فاتورة سارية أخرى (يجب أن تُرفض) ==='
INSERT INTO sale_items (sale_id, item_id, unit_price, discount, net_price, gross_amount, purchase_cost, pre_sale_status)
VALUES (2, 1, 100, 0, 100, 100, 6000, 'AVAILABLE');
