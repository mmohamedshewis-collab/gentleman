import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        brand: {
          DEFAULT: '#002060',
          dark: '#001845',
          light: '#0070C0',
          soft: '#E8EFF8',
        },
        ok: '#127C4A',
        warn: '#B45309',
        danger: '#B42318',
      },
      fontFamily: { sans: ['var(--font-app)', 'Tahoma', 'sans-serif'] },
      boxShadow: { card: '0 1px 2px rgba(16,24,40,.06), 0 1px 3px rgba(16,24,40,.10)' },
    },
  },
  plugins: [],
};
export default config;
