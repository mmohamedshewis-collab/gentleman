import { Decimal } from 'decimal.js';
import { round2, add, sub } from '@/lib/money';
import { computeDocumentTotals, VAT_DISABLED, type VatContext, type VatStatus } from '@/lib/money';

export class SalePricingError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'SalePricingError';
  }
}

export interface SaleLineInput {
  itemId: number;
  unitPrice: Decimal.Value;
  discount?: Decimal.Value;
  /** تكلفة شراء القطعة — تُجمَّد وقت البيع لتحليل الربحية. */
  purchaseCost: Decimal.Value;
  preSaleStatus: string;
}

export interface SaleLineResult {
  itemId: number;
  unitPrice: Decimal;
  discount: Decimal;
  netPrice: Decimal;
  vatStatus: VatStatus;
  vatRate: Decimal | null;
  vatAmount: Decimal;
  grossAmount: Decimal;
  purchaseCost: Decimal;
  preSaleStatus: string;
  isDamagedSale: boolean;
}

export function computeSaleLine(input: SaleLineInput, vat: VatContext = VAT_DISABLED): SaleLineResult {
  const unitPrice = round2(input.unitPrice);
  const discount = round2(input.discount ?? 0);
  const purchaseCost = round2(input.purchaseCost);

  if (unitPrice.lt(0)) throw new SalePricingError('سعر البيع لا يمكن أن يكون سالبًا.');
  if (discount.lt(0)) throw new SalePricingError('الخصم لا يمكن أن يكون سالبًا.');
  if (discount.gt(unitPrice)) throw new SalePricingError('الخصم لا يمكن أن يتجاوز سعر البيع.');
  if (purchaseCost.lt(0)) throw new SalePricingError('تكلفة الشراء لا يمكن أن تكون سالبة.');

  const t = computeDocumentTotals({ subtotal: unitPrice, discount, vat });

  return {
    itemId: input.itemId,
    unitPrice,
    discount,
    netPrice: t.netAmount,
    vatStatus: t.vatStatus,
    vatRate: t.vatRate,
    vatAmount: t.vatAmount,
    grossAmount: t.grossAmount,
    purchaseCost,
    preSaleStatus: input.preSaleStatus,
    isDamagedSale: input.preSaleStatus === 'DAMAGED',
  };
}

export interface SaleTotals {
  lines: SaleLineResult[];
  subtotal: Decimal;
  discount: Decimal;
  netAmount: Decimal;
  vatStatus: VatStatus;
  vatRate: Decimal | null;
  vatAmount: Decimal;
  grossAmount: Decimal;
  totalCost: Decimal;
  grossProfit: Decimal;
}

export function computeSaleTotals(
  inputs: SaleLineInput[],
  vat: VatContext = VAT_DISABLED,
): SaleTotals {
  if (inputs.length === 0) throw new SalePricingError('الفاتورة يجب أن تحتوي على قطعة واحدة على الأقل.');

  const ids = inputs.map((i) => i.itemId);
  if (new Set(ids).size !== ids.length) {
    throw new SalePricingError('لا يمكن تكرار نفس القطعة داخل الفاتورة.');
  }

  const lines = inputs.map((i) => computeSaleLine(i, vat));

  const subtotal = add(...lines.map((l) => l.unitPrice));
  const discount = add(...lines.map((l) => l.discount));
  const netAmount = add(...lines.map((l) => l.netPrice));
  const vatAmount = add(...lines.map((l) => l.vatAmount));
  const grossAmount = add(netAmount, vatAmount);
  const totalCost = add(...lines.map((l) => l.purchaseCost));

  return {
    lines,
    subtotal,
    discount,
    netAmount,
    vatStatus: lines[0].vatStatus,
    vatRate: lines[0].vatRate,
    vatAmount,
    grossAmount,
    totalCost,
    // ★ مجمل الربح = الإيراد − التكلفة. قد يكون سالبًا، ولا علاقة له بالنقدية.
    grossProfit: sub(netAmount, totalCost),
  };
}

/** البيع نقدي بالكامل: المدفوع يساوي الإجمالي تمامًا. */
export function assertFullPayment(grossAmount: Decimal.Value, paid: Decimal.Value): void {
  const g = round2(grossAmount);
  const p = round2(paid);
  if (!g.equals(p)) {
    throw new SalePricingError(
      `البيع نقدي بالكامل: المطلوب ${g.toString()} والمدفوع ${p.toString()}. لا يُسمح بمتبقٍ.`,
    );
  }
}

export const remainingAfterSale = (grossAmount: Decimal.Value, paid: Decimal.Value): Decimal =>
  sub(grossAmount, paid);

/** INV-2026-000001 */
export const buildInvoiceNo = (year: number, seq: number): string =>
  `INV-${year}-${String(seq).padStart(6, '0')}`;

export function exceedsDiscountLimit(
  unitPrice: Decimal.Value,
  discount: Decimal.Value,
  maxPercent: Decimal.Value,
): boolean {
  const price = round2(unitPrice);
  if (price.lte(0)) return round2(discount).gt(0);
  const pct = round2(discount).times(100).dividedBy(price);
  return pct.gt(round2(maxPercent));
}
