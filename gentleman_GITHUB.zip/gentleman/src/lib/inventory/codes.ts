/** أكواد القطع والباركود — منطق خالص. */

const MAX_BATCH = 200;

/** تنظيف البادئة: حروف إنجليزية وأرقام فقط بحالة كبيرة. */
export function normalizePrefix(raw: string): string {
  const clean = raw.trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
  if (!clean) throw new Error('PREFIX_REQUIRED');
  return clean;
}

/** SUIT-0001 */
export function buildItemCode(prefix: string, sequence: number, pad = 4): string {
  if (!Number.isInteger(sequence) || sequence < 1) throw new Error('SEQUENCE_INVALID');
  return `${normalizePrefix(prefix)}-${String(sequence).padStart(pad, '0')}`;
}

/** استخراج الرقم التسلسلي من كود قطعة، أو null إن لم يكن بالصيغة المتوقعة. */
export function parseSequence(itemCode: string): number | null {
  const m = /^[A-Z0-9]+-(\d+)$/.exec(itemCode.trim().toUpperCase());
  if (!m) return null;
  const n = Number.parseInt(m[1], 10);
  return Number.isFinite(n) ? n : null;
}

/** توليد دفعة أكواد متتالية بدءًا من رقم معيّن. */
export function generateCodes(prefix: string, startSequence: number, count: number): string[] {
  if (!Number.isInteger(count) || count < 1 || count > MAX_BATCH) {
    throw new Error('COUNT_OUT_OF_RANGE');
  }
  return Array.from({ length: count }, (_, i) => buildItemCode(prefix, startSequence + i));
}

export const defaultBarcode = (itemCode: string): string => itemCode;

/** القارئ يعمل كلوحة مفاتيح: بلا مسافات ولا حروف عربية ولا رموز. */
const BARCODE_PATTERN = /^[A-Z0-9][A-Z0-9-]{2,30}$/;

export function normalizeBarcode(raw: string): string {
  return raw.trim().toUpperCase();
}

/** يُرجع رسالة الخطأ بالعربية، أو null إذا كان الباركود صالحًا. */
export function validateBarcode(raw: string): string | null {
  const code = normalizeBarcode(raw);
  if (!code) return 'الباركود مطلوب.';
  if (/\s/.test(code)) return 'الباركود لا يحتوي على مسافات.';
  if (!BARCODE_PATTERN.test(code)) {
    return 'الباركود غير صالح: حروف إنجليزية وأرقام وشرطة فقط، من 3 إلى 31 خانة.';
  }
  return null;
}
