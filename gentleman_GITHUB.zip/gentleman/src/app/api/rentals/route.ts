import { route } from '@/lib/api';
import {
  listRentals, rentalQuerySchema, createRental, createRentalSchema,
} from '@/services/rental.service';

export const GET = route({ schema: rentalQuerySchema, handler: ({ input }) => listRentals(input) });
export const POST = route({ schema: createRentalSchema, handler: ({ input }) => createRental(input) });
