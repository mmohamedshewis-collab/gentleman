import { route } from '@/lib/api';
import { employeePerformanceReport, performanceQuerySchema } from '@/services/employee.service';

export const GET = route({
  schema: performanceQuerySchema,
  handler: ({ input }) => employeePerformanceReport(input),
});
