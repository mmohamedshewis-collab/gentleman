import { describe, it, expect, vi, beforeEach } from 'vitest';

/** اختبارات طبقة خدمة الإرجاع: الصلاحيات، الرفض، التدقيق، الإلغاء. */

const auditSpy = vi.fn();
let currentUser: { id: number; employeeId: number | null; permissions: Set<string> };

let rentalRow: { id: number; status: string; rental_no: string; extra_charges: string };
let lineRows: { id: number; item_id: number; status: string; rental_id: number; insurance_per_item: string; expected_return_date: Date }[];
let returnRow: { id: number; rental_id: number; is_voided: boolean; return_no: string };
let returnItemRows: any[];
let lineStatuses: string[];

const created = { returns: [] as any[], returnItems: [] as any[], insurance: [] as any[], history: [] as any[], inventory: [] as any[] };
const updates = { rentalItems: [] as any[], productItems: [] as any[], rentals: [] as any[], bookings: [] as any[], returns: [] as any[] };
const rawSql: string[] = [];

const tx = {
  $queryRaw: vi.fn(async (strings: TemplateStringsArray) => {
    const q = strings.join(' ');
    if (q.includes('FROM rentals')) return [rentalRow];
    if (q.includes('FROM rental_items')) return lineRows;
    if (q.includes('FROM returns')) return [returnRow];
    return [];
  }),
  $executeRaw: vi.fn(async (strings: TemplateStringsArray) => { rawSql.push(strings.join(' ')); return 1; }),
  return: {
    create: vi.fn(async ({ data }: any) => { const r = { id: 500, ...data }; created.returns.push(r); return r; }),
    findFirst: vi.fn(async () => null),
    update: vi.fn(async (a: any) => { updates.returns.push(a); return { id: 500 }; }),
  },
  returnItem: {
    create: vi.fn(async ({ data }: any) => { created.returnItems.push(data); return { id: 1, ...data }; }),
    findMany: vi.fn(async () => returnItemRows),
  },
  rentalItem: {
    update: vi.fn(async (a: any) => { updates.rentalItems.push(a); return {}; }),
    findMany: vi.fn(async () => lineStatuses.map((status) => ({ status }))),
  },
  productItem: { update: vi.fn(async (a: any) => { updates.productItems.push(a); return {}; }) },
  itemStatusHistory: { create: vi.fn(async ({ data }: any) => { created.history.push(data); return {}; }) },
  inventoryTransaction: { create: vi.fn(async ({ data }: any) => { created.inventory.push(data); return {}; }) },
  itemBooking: { updateMany: vi.fn(async (a: any) => { updates.bookings.push(a); return {}; }) },
  rental: { update: vi.fn(async (a: any) => { updates.rentals.push(a); return {}; }) },
  insuranceTransaction: {
    create: vi.fn(async ({ data }: any) => { created.insurance.push(data); return {}; }),
    findFirst: vi.fn(async () => ({ balanceAfter: '1000' })),
  },
};

vi.mock('@/lib/db', () => ({ prisma: { $transaction: (fn: any) => fn(tx) } }));
vi.mock('@/lib/audit', () => ({ writeAudit: (...a: any[]) => auditSpy(...a), redact: (x: any) => x }));
vi.mock('@/lib/settings', () => ({
  getNumberSetting: async (k: string) => {
    const { Decimal } = await import('decimal.js');
    if (k === 'rental.late_fee_per_item_per_day') return new Decimal(100);
    return new Decimal(0);
  },
  getBoolSetting: async () => false,
}));
vi.mock('@/lib/auth/rbac', async (importOriginal) => {
  const actual = await importOriginal<typeof import('@/lib/auth/rbac')>();
  return {
    ...actual,
    requirePermission: async (perm: string) => {
      if (!currentUser.permissions.has(perm)) {
        const { Errors } = await import('@/lib/errors');
        throw Errors.forbidden(perm);
      }
      return currentUser as never;
    },
  };
});

const D = (s: string) => new Date(`${s}T00:00:00.000Z`);
const asStaff = () => { currentUser = { id: 9, employeeId: 3, permissions: new Set(['returns.create', 'rentals.view']) }; };
const asAdmin = () => { currentUser = { id: 1, employeeId: 1, permissions: new Set(['returns.create', 'returns.void', 'returns.waive_fee', 'rentals.view']) }; };

beforeEach(() => {
  vi.useFakeTimers();
  vi.setSystemTime(new Date('2026-08-12T09:00:00Z'));
  auditSpy.mockClear();
  for (const k of Object.keys(created)) (created as any)[k].length = 0;
  for (const k of Object.keys(updates)) (updates as any)[k].length = 0;
  rawSql.length = 0;
  rentalRow = { id: 1, status: 'ACTIVE', rental_no: 'R-2026-0001', extra_charges: '0' };
  lineRows = [{ id: 10, item_id: 100, status: 'OUT', rental_id: 1, insurance_per_item: '1000', expected_return_date: D('2026-08-10') }];
  lineStatuses = ['RETURNED'];
  returnRow = { id: 500, rental_id: 1, is_voided: false, return_no: 'RT-2026-0001' };
  returnItemRows = [];
  asStaff();
});

describe('صلاحيات الإرجاع', () => {
  it('من لا يملك returns.create يُرفض', async () => {
    currentUser = { id: 5, employeeId: null, permissions: new Set(['rentals.view']) };
    const { createReturn } = await import('@/services/return.service');
    await expect(createReturn({ rentalId: 1, lines: [{ rentalItemId: 10, condition: 'GOOD' }] }))
      .rejects.toMatchObject({ code: 'PERM_DENIED' });
  });

  it('تعديل غرامة التأخير يحتاج صلاحية returns.waive_fee', async () => {
    const { createReturn } = await import('@/services/return.service');
    await expect(createReturn({
      rentalId: 1,
      lines: [{ rentalItemId: 10, condition: 'GOOD', lateFeeOverride: 0, overrideReason: 'عميل دائم' }],
    })).rejects.toMatchObject({ code: 'PERM_DENIED', details: { permission: 'returns.waive_fee' } });
  });

  it('المدير يستطيع الإعفاء لكن بسبب إلزامي', async () => {
    asAdmin();
    const { createReturn } = await import('@/services/return.service');
    await expect(createReturn({
      rentalId: 1, lines: [{ rentalItemId: 10, condition: 'GOOD', lateFeeOverride: 0 }],
    })).rejects.toMatchObject({ code: 'BUSINESS_RULE' });
  });

  it('لا يمكن رفع الغرامة فوق المحسوبة', async () => {
    asAdmin();
    const { createReturn } = await import('@/services/return.service');
    await expect(createReturn({
      rentalId: 1,
      lines: [{ rentalItemId: 10, condition: 'GOOD', lateFeeOverride: 5000, overrideReason: 'محاولة' }],
    })).rejects.toMatchObject({ code: 'BUSINESS_RULE' });
  });

  it('إلغاء الإرجاع يحتاج صلاحية مدير', async () => {
    const { voidReturn } = await import('@/services/return.service');
    await expect(voidReturn({ returnId: 500, reason: 'خطأ في التسجيل' }))
      .rejects.toMatchObject({ code: 'PERM_DENIED', details: { permission: 'returns.void' } });
  });
});

describe('رفض الحالات غير الصحيحة', () => {
  it('عقد ملغى لا يقبل إرجاعًا', async () => {
    rentalRow.status = 'VOIDED';
    const { createReturn } = await import('@/services/return.service');
    await expect(createReturn({ rentalId: 1, lines: [{ rentalItemId: 10, condition: 'GOOD' }] }))
      .rejects.toMatchObject({ code: 'BUSINESS_RULE' });
  });

  it('عقد مغلق لا يقبل إرجاعًا', async () => {
    rentalRow.status = 'CLOSED';
    const { createReturn } = await import('@/services/return.service');
    await expect(createReturn({ rentalId: 1, lines: [{ rentalItemId: 10, condition: 'GOOD' }] }))
      .rejects.toMatchObject({ code: 'BUSINESS_RULE' });
  });

  it('قطعة مُرجَعة بالفعل تُرفض', async () => {
    lineRows[0].status = 'RETURNED';
    const { createReturn } = await import('@/services/return.service');
    await expect(createReturn({ rentalId: 1, lines: [{ rentalItemId: 10, condition: 'GOOD' }] }))
      .rejects.toMatchObject({ code: 'CONFLICT' });
  });

  it('قطعة من عقد آخر تُرفض', async () => {
    lineRows[0].rental_id = 99;
    const { createReturn } = await import('@/services/return.service');
    await expect(createReturn({ rentalId: 1, lines: [{ rentalItemId: 10, condition: 'GOOD' }] }))
      .rejects.toMatchObject({ code: 'BUSINESS_RULE' });
  });

  it('تكرار نفس القطعة في الطلب يُرفض', async () => {
    const { createReturn } = await import('@/services/return.service');
    await expect(createReturn({
      rentalId: 1,
      lines: [{ rentalItemId: 10, condition: 'GOOD' }, { rentalItemId: 10, condition: 'GOOD' }],
    })).rejects.toMatchObject({ code: 'BUSINESS_RULE' });
  });

  it('تالفة بلا قيمة تلف تُرفض', async () => {
    const { createReturn } = await import('@/services/return.service');
    await expect(createReturn({ rentalId: 1, lines: [{ rentalItemId: 10, condition: 'DAMAGED' }] }))
      .rejects.toMatchObject({ code: 'BUSINESS_RULE' });
  });

  it('العملية المرفوضة لا تترك أي أثر', async () => {
    rentalRow.status = 'CLOSED';
    const { createReturn } = await import('@/services/return.service');
    await expect(createReturn({ rentalId: 1, lines: [{ rentalItemId: 10, condition: 'GOOD' }] })).rejects.toThrow();
    expect(created.returns).toHaveLength(0);
    expect(created.returnItems).toHaveLength(0);
    expect(created.insurance).toHaveLength(0);
    expect(auditSpy).not.toHaveBeenCalled();
  });
});

describe('إرجاع سليم متأخر — الفصل بين المفاهيم', () => {
  it('يحسب التأخير ويستقطع من التأمين ويرد الباقي', async () => {
    const { createReturn } = await import('@/services/return.service');
    const r = await createReturn({ rentalId: 1, lines: [{ rentalItemId: 10, condition: 'GOOD' }] });

    // يومان تأخير × 100
    expect(created.returnItems[0]).toMatchObject({ daysLate: 2, lateFee: '200' });
    expect(r.totalCharges).toBe('200');
    expect(r.insuranceUsed).toBe('200');
    expect(r.insuranceRefunded).toBe('800');
    expect(r.extraDueFromCustomer).toBe('0');
    expect(r.rentalStatus).toBe('CLOSED');
  });

  it('يسجّل حركتَي تأمين منفصلتين: استقطاع ورد', async () => {
    const { createReturn } = await import('@/services/return.service');
    await createReturn({ rentalId: 1, lines: [{ rentalItemId: 10, condition: 'GOOD' }] });
    expect(created.insurance.map((i) => i.type)).toEqual(['DEDUCTED_DAMAGE', 'REFUNDED']);
    expect(created.insurance[0]).toMatchObject({ amount: '200', balanceAfter: '800' });
    expect(created.insurance[1]).toMatchObject({ amount: '800', balanceAfter: '0' });
  });

  it('القطعة تعود متاحة والحجز الزمني يُعطَّل', async () => {
    const { createReturn } = await import('@/services/return.service');
    await createReturn({ rentalId: 1, lines: [{ rentalItemId: 10, condition: 'GOOD' }] });
    expect(updates.productItems[0].data.status).toBe('AVAILABLE');
    expect(updates.rentalItems[0].data.status).toBe('RETURNED');
    expect(updates.bookings[0].data).toMatchObject({ isActive: false });
  });
});

describe('إرجاع تالف يتجاوز التأمين', () => {
  it('يستهلك التأمين ويحوّل الفرق إلى مديونية على العقد', async () => {
    const { createReturn } = await import('@/services/return.service');
    const r = await createReturn({
      rentalId: 1,
      lines: [{ rentalItemId: 10, condition: 'DAMAGED', damageFee: 1500, damageDescription: 'حرق' }],
    });
    // 200 تأخير + 1500 تلف = 1700 غرامات، التأمين 1000
    expect(r.totalCharges).toBe('1700');
    expect(r.insuranceUsed).toBe('1000');
    expect(r.insuranceRefunded).toBe('0');
    expect(r.extraDueFromCustomer).toBe('700');
    expect(updates.productItems[0].data.status).toBe('DAMAGED');
    // المستحق الإضافي يُضاف إلى العقد
    expect(rawSql.some((q) => q.includes('extra_charges'))).toBe(true);
  });

  it('لا يسجّل حركة رد تأمين عندما لا يتبقى شيء', async () => {
    const { createReturn } = await import('@/services/return.service');
    await createReturn({ rentalId: 1, lines: [{ rentalItemId: 10, condition: 'DAMAGED', damageFee: 1500 }] });
    expect(created.insurance.map((i) => i.type)).toEqual(['DEDUCTED_DAMAGE']);
  });
});

describe('إرجاع بفقد', () => {
  it('القطعة تصبح مفقودة وحركة المخزون إعدام', async () => {
    const { createReturn } = await import('@/services/return.service');
    const r = await createReturn({
      rentalId: 1, lines: [{ rentalItemId: 10, condition: 'LOST', lossFee: 6000 }],
    });
    expect(updates.productItems[0].data.status).toBe('LOST');
    expect(updates.rentalItems[0].data.status).toBe('LOST');
    expect(created.inventory[0].type).toBe('WRITE_OFF');
    expect(r.extraDueFromCustomer).toBe('5200'); // 200 تأخير + 6000 فقد − 1000 تأمين
  });
});

describe('الإرجاع الجزئي', () => {
  it('العقد يبقى مُرجَعًا جزئيًا ما دام فيه قطعة خارجة', async () => {
    lineStatuses = ['RETURNED', 'OUT'];
    const { createReturn } = await import('@/services/return.service');
    const r = await createReturn({ rentalId: 1, lines: [{ rentalItemId: 10, condition: 'GOOD' }] });
    expect(r.rentalStatus).toBe('PARTIALLY_RETURNED');
    expect(updates.rentals[0].data.status).toBe('PARTIALLY_RETURNED');
  });
});

describe('سجل التدقيق', () => {
  it('يسجّل الإرجاع بكل أرقامه المنفصلة', async () => {
    const { createReturn } = await import('@/services/return.service');
    await createReturn({ rentalId: 1, lines: [{ rentalItemId: 10, condition: 'DAMAGED', damageFee: 250 }] });
    expect(auditSpy).toHaveBeenCalledOnce();
    expect(auditSpy.mock.calls[0][0]).toMatchObject({
      userId: 9,
      action: 'return.create',
      entityType: 'Return',
      after: {
        totalCharges: '450', insuranceUsed: '450',
        insuranceRefunded: '550', extraDue: '0', rentalStatus: 'CLOSED',
      },
    });
  });
});

describe('إلغاء الإرجاع', () => {
  beforeEach(() => {
    asAdmin();
    returnItemRows = [{
      id: 1, returnId: 500, rentalItemId: 10, itemId: 100,
      lateFee: '200', damageFee: '250', lossFee: '0',
      insuranceUsed: '450', insuranceRefunded: '550', extraDueFromCustomer: '0',
    }];
    lineStatuses = ['OUT'];
  });

  it('يعيد القطعة والسطر إلى حالة التأجير ويعيد تفعيل الحجز', async () => {
    const { voidReturn } = await import('@/services/return.service');
    const r = await voidReturn({ returnId: 500, reason: 'تسجيل خاطئ' });
    expect(updates.rentalItems[0].data.status).toBe('OUT');
    expect(updates.productItems[0].data.status).toBe('RENTED');
    expect(updates.bookings[0].data).toMatchObject({ isActive: true });
    expect(r.rentalStatus).toBe('ACTIVE');
  });

  it('يعكس حركة التأمين بالكامل', async () => {
    const { voidReturn } = await import('@/services/return.service');
    await voidReturn({ returnId: 500, reason: 'تسجيل خاطئ' });
    expect(created.insurance).toHaveLength(1);
    expect(created.insurance[0]).toMatchObject({ type: 'COLLECTED', amount: '1000', balanceAfter: '2000' });
  });

  it('لا يحذف الإرجاع بل يعلّمه ملغى', async () => {
    const { voidReturn } = await import('@/services/return.service');
    await voidReturn({ returnId: 500, reason: 'تسجيل خاطئ' });
    expect(updates.returns[0].data).toMatchObject({ isVoided: true, voidReason: 'تسجيل خاطئ', voidedBy: 1 });
  });

  it('يرفض إلغاء إرجاع ملغى بالفعل', async () => {
    returnRow.is_voided = true;
    const { voidReturn } = await import('@/services/return.service');
    await expect(voidReturn({ returnId: 500, reason: 'مرة ثانية' }))
      .rejects.toMatchObject({ code: 'BUSINESS_RULE' });
  });

  it('يسجّل الإلغاء في سجل التدقيق بالسبب', async () => {
    const { voidReturn } = await import('@/services/return.service');
    await voidReturn({ returnId: 500, reason: 'تسجيل خاطئ' });
    expect(auditSpy.mock.calls[0][0]).toMatchObject({
      action: 'return.void', entityType: 'Return', reason: 'تسجيل خاطئ',
    });
  });
});
