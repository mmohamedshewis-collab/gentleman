#!/usr/bin/env node
/**
 * تشغيل التهيئة الأولية مرة واحدة فقط أثناء بناء Vercel.
 *
 * ★ آمن للتكرار: يتخطّى نفسه إن كانت البيانات موجودة، فلا يفسد
 *   بيانات إنتاج قائمة عند كل نشر.
 * ⛔ لا يعدّل أي منطق أعمال — يستدعي prisma/seed.ts القائم كما هو.
 */

import { spawnSync } from 'node:child_process';
import pg from 'pg';

const { Client } = pg;
const DATABASE_URL = process.env.DATABASE_URL;

if (!DATABASE_URL) {
  console.error('❌ DATABASE_URL غير مضبوط.');
  process.exit(1);
}

const client = new Client({
  connectionString: DATABASE_URL,
  ssl: DATABASE_URL.includes('sslmode=require') ? { rejectUnauthorized: false } : undefined,
});

try {
  await client.connect();

  // هل سبق أن هُيِّئت القاعدة؟ وجود دور واحد يكفي كدليل.
  const { rows } = await client.query(
    `SELECT EXISTS (
       SELECT 1 FROM information_schema.tables
        WHERE table_schema='public' AND table_name='roles'
     ) AS has_table`,
  );

  if (!rows[0].has_table) {
    console.log('▶ جدول الأدوار غير موجود — تخطّي التهيئة.');
    process.exit(0);
  }

  const { rows: counts } = await client.query('SELECT count(*)::int AS n FROM roles');
  await client.end();

  if (counts[0].n > 0) {
    console.log('▶ القاعدة مهيّأة بالفعل — تخطّي التهيئة (آمن للتكرار).');
    process.exit(0);
  }

  if (!process.env.SEED_ADMIN_PASSWORD) {
    console.error(
      '❌ SEED_ADMIN_PASSWORD غير مضبوط — لن يُنشأ حساب المدير.\n' +
      '   أضفه في Vercel ← Settings ← Environment Variables ثم أعد النشر.',
    );
    process.exit(1);
  }

  console.log('▶ تشغيل التهيئة الأولية…');
  const r = spawnSync('npx', ['tsx', 'prisma/seed.ts'], { stdio: 'inherit' });
  if (r.status !== 0) {
    console.error('❌ فشلت التهيئة الأولية.');
    process.exit(1);
  }
  console.log('✅ التهيئة الأولية نجحت.');
} catch (err) {
  console.error('❌ خطأ في التهيئة:', err instanceof Error ? err.message : err);
  await client.end().catch(() => {});
  process.exit(1);
}
