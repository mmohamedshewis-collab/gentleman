\set ON_ERROR_STOP off
\pset pager off
\t on

-- محاكاة معاملة البيع بنفس ترتيب خطوات SaleService.createSale
CREATE OR REPLACE FUNCTION do_sale(
  p_item_codes text[], p_customer int, p_price numeric, p_discount numeric,
  p_paid numeric DEFAULT NULL, p_fail boolean DEFAULT false
) RETURNS int AS $$
DECLARE
  v_sale int; v_item int; v_status text; v_code text; v_cost numeric;
  v_sub numeric := 0; v_disc numeric := 0; v_net numeric := 0; v_cost_total numeric := 0;
  v_paid numeric;
BEGIN
  -- 1) قفل القطع وفحص الحالة
  FOREACH v_code IN ARRAY p_item_codes LOOP
    SELECT id, status::text, purchase_cost INTO v_item, v_status, v_cost
      FROM product_items WHERE item_code = v_code FOR UPDATE;
    IF v_item IS NULL THEN RAISE EXCEPTION 'القطعة % غير موجودة', v_code; END IF;
    IF v_status NOT IN ('AVAILABLE','DAMAGED','MAINTENANCE') THEN
      RAISE EXCEPTION 'لا يمكن بيع القطعة % لأن حالتها %', v_code, v_status;
    END IF;
    v_sub := v_sub + p_price;
    v_disc := v_disc + p_discount;
    v_net := v_net + (p_price - p_discount);
    v_cost_total := v_cost_total + v_cost;
  END LOOP;

  v_paid := COALESCE(p_paid, v_net);
  IF v_paid <> v_net THEN
    RAISE EXCEPTION 'البيع نقدي بالكامل: المطلوب % والمدفوع %', v_net, v_paid;
  END IF;

  -- 2) الفاتورة بإجماليات مكتملة
  INSERT INTO sales (invoice_no, customer_id, sale_date, subtotal, discount, net_amount,
                     gross_amount, paid_amount, total_cost, status, created_by)
  VALUES ('INV-' || nextval('invoice_no_seq'), p_customer, CURRENT_DATE,
          v_sub, v_disc, v_net, v_net, v_paid, v_cost_total, 'COMPLETED', 1)
  RETURNING id INTO v_sale;

  -- 3) السطور + حالة القطعة + سجل الحالة + حركة المخزون
  FOREACH v_code IN ARRAY p_item_codes LOOP
    SELECT id, status::text, purchase_cost INTO v_item, v_status, v_cost
      FROM product_items WHERE item_code = v_code;

    INSERT INTO sale_items (sale_id, item_id, unit_price, discount, net_price, gross_amount,
                            purchase_cost, pre_sale_status, is_damaged_sale)
    VALUES (v_sale, v_item, p_price, p_discount, p_price - p_discount, p_price - p_discount,
            v_cost, v_status::"ItemStatus", v_status = 'DAMAGED');

    INSERT INTO item_status_history (item_id, from_status, to_status, reason, ref_type, ref_id, user_id)
    VALUES (v_item, v_status::"ItemStatus", 'SOLD', 'فاتورة بيع ' || v_sale, 'Sale', v_sale, 1);

    UPDATE product_items SET status = 'SOLD', disposed_at = now() WHERE id = v_item;

    INSERT INTO inventory_transactions (item_id, trx_date, type, ref_type, ref_id, created_by)
    VALUES (v_item, CURRENT_DATE, 'SALE', 'Sale', v_sale, 1);

    UPDATE item_bookings SET is_active = false WHERE item_id = v_item AND is_active;
  END LOOP;

  IF p_fail THEN RAISE EXCEPTION 'فشل متعمّد في منتصف البيع'; END IF;

  -- 4) الدفعة
  INSERT INTO payments (payment_no, purpose, sale_id, customer_id, amount, payment_method_id, created_by)
  VALUES ('PAY-S' || nextval('payment_no_seq'), 'SALE', v_sale, p_customer, v_paid, 1, 1);

  INSERT INTO audit_logs (user_id, action, entity_type, entity_id, after_json)
  VALUES (1, 'sale.create', 'Sale', v_sale::text,
          jsonb_build_object('net', v_net, 'cost', v_cost_total, 'gross_profit', v_net - v_cost_total));
  RETURN v_sale;
END;
$$ LANGUAGE plpgsql;

-- تهيئة القطع
UPDATE product_items SET status='AVAILABLE', purchase_cost=6000 WHERE item_code IN ('SUIT-0001','SUIT-0002','SUIT-0003','SUIT-0006');
UPDATE product_items SET status='DAMAGED', purchase_cost=6000 WHERE item_code='SUIT-0005';

\echo '=== S1: بيع قطعة متاحة بخصم ==='
SELECT 'الفاتورة ' || do_sale(ARRAY['SUIT-0001'], 2, 1500, 200);
SELECT 'إجمالي=' || subtotal || ' خصم=' || discount || ' | ★ صافي البيع (Revenue)=' || net_amount
       || ' | ★ محصَّل نقدًا=' || paid_amount || ' | متبقٍ=' || (gross_amount - paid_amount)
       || ' | ★ تكلفة=' || total_cost || ' | ★ مجمل الربح=' || (net_amount - total_cost)
  FROM sales WHERE id=1;
SELECT 'حالة القطعة=' || status || ' | حالة ما قبل البيع المحفوظة=' ||
       (SELECT pre_sale_status FROM sale_items WHERE sale_id=1)
  FROM product_items WHERE item_code='SUIT-0001';
SELECT 'الدفعة: مبلغ=' || amount || ' غرض=' || purpose || ' تأمين=' || is_insurance FROM payments WHERE sale_id=1;

\echo ''
\echo '=== S2: محاولة بيع قطعة مباعة (يجب أن تُرفض) ==='
SELECT do_sale(ARRAY['SUIT-0001'], 2, 1000, 0);

\echo ''
\echo '=== S3: محاولة بيع قطعة مؤجرة (يجب أن تُرفض) ==='
UPDATE product_items SET status='RENTED' WHERE item_code='SUIT-0002';
SELECT do_sale(ARRAY['SUIT-0002'], 2, 1000, 0);

\echo ''
\echo '=== S4: محاولة بيع قطعة متأخرة (يجب أن تُرفض) ==='
UPDATE product_items SET status='OVERDUE' WHERE item_code='SUIT-0002';
SELECT do_sale(ARRAY['SUIT-0002'], 2, 1000, 0);

\echo ''
\echo '=== S5: بيع قطعة تالفة (يجب أن ينجح) ==='
SELECT 'الفاتورة ' || do_sale(ARRAY['SUIT-0005'], 2, 800, 0);
SELECT 'بيع تالف=' || is_damaged_sale || ' | حالة ما قبل البيع=' || pre_sale_status
  FROM sale_items WHERE sale_id = 2;

\echo ''
\echo '=== S6: سداد جزئي (يجب أن يُرفض) ==='
SELECT do_sale(ARRAY['SUIT-0003'], 2, 1000, 0, 600);

\echo ''
\echo '=== S7: خصم أكبر من السعر (يجب أن يُرفض) ==='
INSERT INTO sale_items (sale_id, item_id, unit_price, discount, net_price, gross_amount, purchase_cost, pre_sale_status)
VALUES (1, 6, 500, 900, -400, -400, 6000, 'AVAILABLE');

\echo ''
\echo '=== S8: حالة ما قبل البيع غير قابلة للبيع (يجب أن تُرفض) ==='
INSERT INTO sale_items (sale_id, item_id, unit_price, discount, net_price, gross_amount, purchase_cost, pre_sale_status)
VALUES (1, 6, 500, 0, 500, 500, 6000, 'RENTED');
