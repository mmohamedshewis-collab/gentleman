#!/usr/bin/env node
/**
 * تهيئة قاعدة البيانات أثناء بناء Vercel — بديل psql.
 *
 * ★ لماذا؟ صورة بناء Vercel لا تحتوي psql، فسكربتات `db:constraints`
 *   و`db:verify` تفشل هناك. هذا السكربت ينفّذ الملفين نفسيهما عبر Node.
 *
 * ⛔ لا يغيّر أي منطق تطبيق أو أعمال — ينفّذ SQL القائم كما هو.
 * ⛔ يفشل بصوت عالٍ: أي خطأ يوقف البناء ولا يمر بصمت.
 *
 * الاستخدام: node scripts/db-bootstrap.mjs
 */

import { readFileSync } from 'node:fs';
import pg from 'pg';

const { Client } = pg;

const DATABASE_URL = process.env.DATABASE_URL;
if (!DATABASE_URL) {
  console.error('❌ DATABASE_URL غير مضبوط — لا يمكن تهيئة قاعدة البيانات.');
  process.exit(1);
}

const FILES = [
  { path: 'prisma/sql/01_constraints.sql', label: 'قيود الحماية المالية' },
  { path: 'prisma/sql/verify_production.sql', label: 'التحقق من سلامة النشر' },
];

const client = new Client({
  connectionString: DATABASE_URL,
  // Neon يتطلب TLS
  ssl: DATABASE_URL.includes('sslmode=require') ? { rejectUnauthorized: false } : undefined,
});

try {
  await client.connect();
  console.log('▶ الاتصال بقاعدة البيانات: ✅');

  for (const { path, label } of FILES) {
    const sql = readFileSync(path, 'utf8');
    // ★ pg ينفّذ عدة عبارات في استعلام واحد، فتبقى كتل $$ ... $$ سليمة
    //   ولا نحتاج تقسيمًا يدويًا يكسر دوال plpgsql.
    await client.query(sql);
    console.log(`▶ ${label}: ✅`);
  }

  // تأكيد نهائي مقروء من القاعدة نفسها
  const { rows } = await client.query(`
    SELECT
      (SELECT count(*) FROM pg_constraint
        WHERE contype IN ('c','x') AND conname ~ '^(ck|ex)_')      AS checks,
      (SELECT count(*) FROM pg_constraint WHERE contype='f')        AS fks,
      (SELECT count(*) FROM pg_trigger WHERE NOT tgisinternal)      AS triggers,
      (SELECT count(*) FROM information_schema.tables
        WHERE table_schema='public' AND table_type='BASE TABLE')    AS tables
  `);
  const r = rows[0];
  console.log(
    `▶ النتيجة: جداول=${r.tables} · قيود=${r.checks} · مفاتيح=${r.fks} · Triggers=${r.triggers}`,
  );

  if (Number(r.checks) < 47 || Number(r.triggers) < 44) {
    throw new Error(
      `الحماية المالية ناقصة: قيود=${r.checks} (المطلوب 47) · Triggers=${r.triggers} (المطلوب 44)`,
    );
  }

  console.log('✅ تهيئة قاعدة البيانات نجحت — كل عناصر الحماية المالية موجودة.');
} catch (err) {
  // لا نطبع رابط الاتصال ولا أي سر
  console.error('❌ فشلت تهيئة قاعدة البيانات:', err instanceof Error ? err.message : err);
  process.exitCode = 1;
} finally {
  await client.end().catch(() => {});
}
