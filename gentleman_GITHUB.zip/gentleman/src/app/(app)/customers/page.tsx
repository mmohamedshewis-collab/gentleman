import Link from 'next/link';
import { listCustomers } from '@/services/customer.service';
import { getSession } from '@/lib/auth/session';
import CustomerLookup from '@/components/CustomerLookup';

export const dynamic = 'force-dynamic';

export default async function CustomersPage({
  searchParams,
}: { searchParams: { q?: string } }) {
  const session = await getSession();
  const canCreate = session?.permissions.has('customers.create') ?? false;
  const { rows, total } = await listCustomers({
    q: searchParams.q,
    includeInactive: false,
    page: 1,
    pageSize: 50,
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="section-title">العملاء</h1>
        <p className="text-sm text-slate-600 mt-1">
          إجمالي العملاء المفعّلين: <span className="num">{total}</span>
        </p>
      </div>

      {canCreate && <CustomerLookup />}

      <div className="card overflow-hidden">
        <div className="card-header">قائمة العملاء</div>
        <form className="p-4 border-b border-slate-200" action="/customers">
          <input
            name="q" className="input max-w-md"
            placeholder="ابحث بالاسم أو رقم الجوال أو كود العميل"
            defaultValue={searchParams.q ?? ''}
          />
        </form>
        <div className="overflow-x-auto">
          <table className="table">
            <thead>
              <tr><th>الكود</th><th>الاسم</th><th>رقم الجوال</th><th>ملاحظات</th><th></th></tr>
            </thead>
            <tbody>
              {rows.map((c) => (
                <tr key={c.id}>
                  <td className="num">{c.code}</td>
                  <td className="font-semibold">
                    {c.fullName}
                    {c.isWalkIn && <span className="badge bg-slate-100 text-slate-500 mr-2">نقدي</span>}
                  </td>
                  <td className="num">{c.phoneDisplay ?? '—'}</td>
                  <td className="text-slate-600">{c.notes ?? '—'}</td>
                  <td>
                    <Link className="text-brand-light font-semibold" href={`/customers/${c.id}`}>
                      فتح
                    </Link>
                  </td>
                </tr>
              ))}
              {rows.length === 0 && (
                <tr><td colSpan={5} className="text-center text-slate-500 py-8">لا يوجد عملاء مطابقون.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
