\set ON_ERROR_STOP off
\t on
\echo '=== C3 (بعد الإصلاح): مصروف بتاريخ يوم مغلق ==='
INSERT INTO expenses (expense_no, expense_date, category_id, amount, payment_method_id, created_by)
VALUES ('EXP-C2', CURRENT_DATE - 5, 1, 100, 1, 1);
\echo '=== C3ب: دفعة بتاريخ يوم مغلق ==='
INSERT INTO payments (payment_no, payment_date, purpose, customer_id, amount, payment_method_id, created_by)
VALUES ('PAY-C2', CURRENT_DATE - 5, 'OTHER', 2, 100, 1, 1);
\echo '=== C3ج: حركة تأمين بتاريخ يوم مغلق ==='
INSERT INTO insurance_transactions (trx_date, type, amount, balance_after, created_by)
VALUES (CURRENT_DATE - 5, 'COLLECTED', 100, 100, 1);
\echo '=== C3د: سلفة بتاريخ يوم مغلق ==='
INSERT INTO employee_advances (advance_no, employee_id, advance_date, amount, balance, payment_method_id)
VALUES ('ADV-C2', 1, CURRENT_DATE - 5, 500, 500, 1);
\echo '=== C3هـ: تسجيل بتاريخ يوم مفتوح (يُقبل) ==='
INSERT INTO expenses (expense_no, expense_date, category_id, amount, payment_method_id, created_by)
VALUES ('EXP-OK2', CURRENT_DATE, 1, 100, 1, 1);
SELECT 'سُجِّل: ' || expense_no FROM expenses WHERE expense_no='EXP-OK2';
