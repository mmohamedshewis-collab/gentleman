import { describe, it, expect, vi, beforeEach } from 'vitest';
import { readFileSync } from 'node:fs';

/**
 * اختبارات لوحة التحكم.
 * ★ الأهم: اختبار التطابق — رقم كل مؤشر = رقم تقريره في M7 بالضبط.
 */

let currentUser: { id: number; employeeId: number | null; permissions: Set<string> };

// بيانات ثابتة تمر عبر تقارير M7 الحقيقية (لا أرقام مصطنعة في اللوحة)
const dec = (v: string) => ({ toString: () => v });
const D = new Date('2026-08-10T00:00:00Z');

const RENTALS = [{
  rentalNo: 'R-2026-000001',
  rentalDate: D, expectedReturnDate: D, createdAt: D,
  netAmount: dec('750'), extraCharges: dec('0'),
  paidAmount: dec('300'), remainingAmount: dec('450'), insuranceAmount: dec('1000'),
  totalDue: dec('750'),
  status: 'ACTIVE',
  customer: { isWalkIn: false, fullName: 'أحمد محمد', phone: '01012345678' },
  employee: { fullName: 'محمد علي' },
  items: [{
    id: 1, status: 'OUT', netPrice: dec('750'),
    item: { itemCode: 'SUIT-0001', productId: 1, product: { nameAr: 'بدلة كلاسيك', code: 'P1' } },
  }],
}];

const SALES = [{
  invoiceNo: 'INV-2026-000001',
  saleDate: D, createdAt: D,
  subtotal: dec('1500'), discount: dec('200'),
  netAmount: dec('1300'), totalCost: dec('6000'),
  status: 'COMPLETED',
  customer: { isWalkIn: true, fullName: 'عميل نقدي' },
  employee: { fullName: 'محمد علي' },
  items: [{ isDamagedSale: false, netPrice: dec('1300') }],
}];

vi.mock('@/lib/db', () => {
  const empty = {
    findMany: async () => [],
    aggregate: async () => ({ _sum: {}, _count: { _all: 0 } }),
    findUnique: async () => null,
    groupBy: async () => [],
    count: async () => 0,
  };
  return {
    prisma: {
      ...Object.fromEntries(
        ['expense', 'payment', 'returnItem', 'insuranceTransaction', 'product',
         'productItem', 'rentalItem', 'saleItem', 'customer', 'employee',
         'paymentMethod', 'expenseCategory', 'commission',
         'employeeAdvance', 'employeeAdvanceRepayment', 'cashTransfer',
         'dailyCashClosing', 'user'].map((k) => [k, empty]),
      ),
      rental: {
        ...empty,
        findMany: async () => RENTALS,
        aggregate: async () => ({ _sum: { netAmount: { toString: () => '750' } }, _count: { _all: 1 } }),
      },
      sale: {
        ...empty,
        findMany: async () => SALES,
        aggregate: async () => ({ _sum: { totalCost: { toString: () => '6000' } }, _count: { _all: 1 } }),
      },
    },
  };
});

vi.mock('@/lib/auth/session', () => ({
  requireSession: async () => currentUser,
}));

vi.mock('@/lib/auth/rbac', async (importOriginal) => {
  const actual = await importOriginal<typeof import('@/lib/auth/rbac')>();
  return {
    ...actual,
    requirePermission: async (perm: string) => {
      if (!currentUser.permissions.has(perm)) {
        const { Errors } = await import('@/lib/errors');
        throw Errors.forbidden(perm);
      }
      return currentUser as never;
    },
  };
});

vi.mock('@/lib/settings', () => ({
  getNumberSetting: async () => new (require('decimal.js').Decimal)(0),
  getBoolSetting: async () => false,
  getStringSetting: async () => '',
}));

const asAdmin = () => {
  currentUser = {
    id: 1, employeeId: 1, fullName: 'مدير', roleNameAr: 'المدير',
    permissions: new Set([
      'reports.operational.view', 'reports.financial.view',
      'items.view', 'commissions.view', 'cash.movement.view', 'employees.view',
    ]),
  } as never;
};

const asStaff = () => {
  currentUser = {
    id: 9, employeeId: 3, fullName: 'موظف', roleNameAr: 'موظف الفرع',
    permissions: new Set(['reports.operational.view', 'items.view', 'cash.movement.view']),
  } as never;
};

beforeEach(() => { asAdmin(); });

const allKpis = (d: Awaited<ReturnType<typeof import('@/services/dashboard.service')['getDashboard']>>) =>
  [...d.todayKpis, ...d.balanceKpis, ...d.periodKpis];

const kpi = (d: Parameters<typeof allKpis>[0], key: string) =>
  allKpis(d).find((k) => k.key === key);

// ============================ التطابق ============================

describe('★ التطابق — رقم اللوحة = رقم التقرير', () => {
  it('إيراد الفترة يطابق تقرير الإيرادات', async () => {
    const { getDashboard } = await import('@/services/dashboard.service');
    const { runReport } = await import('@/services/report.service');

    const d = await getDashboard({ from: '2026-08-01', to: '2026-08-31' });
    const report = await runReport({ key: 'revenue', from: '2026-08-01', to: '2026-08-31' });

    const reportTotal = report.totals!.amount;
    expect(kpi(d, 'period-revenue')!.value).toBe(String(reportTotal));
  });

  it('مصروفات الفترة تطابق تقرير المصروفات', async () => {
    const { getDashboard } = await import('@/services/dashboard.service');
    const { runReport } = await import('@/services/report.service');

    const d = await getDashboard({ from: '2026-08-01', to: '2026-08-31' });
    const report = await runReport({ key: 'expenses', from: '2026-08-01', to: '2026-08-31' });

    const expected = report.totals ? String(report.totals.amount) : '0';
    expect(kpi(d, 'period-expenses')!.value).toBe(expected);
  });

  it('★ صافي الربح يطابق السطر الأخير من تقرير الأرباح حرفيًا', async () => {
    const { getDashboard } = await import('@/services/dashboard.service');
    const { runReport } = await import('@/services/report.service');

    const d = await getDashboard({ from: '2026-08-01', to: '2026-08-31' });
    const report = await runReport({ key: 'net-profit', from: '2026-08-01', to: '2026-08-31' });

    const last = report.rows[report.rows.length - 1];
    expect(last.line).toBe('صافي الربح التقديري');
    expect(kpi(d, 'period-profit')!.value).toBe(String(last.amount));
  });

  it('عدد التأجيرات والمبيعات يطابق صفوف تقاريرها', async () => {
    const { getDashboard } = await import('@/services/dashboard.service');
    const { runReport } = await import('@/services/report.service');

    const d = await getDashboard({});
    const [r, s] = await Promise.all([
      runReport({ key: 'daily-rentals', from: d.today, to: d.today }),
      runReport({ key: 'daily-sales', from: d.today, to: d.today }),
    ]);
    expect(kpi(d, 'today-rentals')!.value).toBe(String(r.rows.length));
    expect(kpi(d, 'today-sales')!.value).toBe(String(s.rows.length));
  });

  it('المتأخرات تطابق تقرير القطع المتأخرة', async () => {
    const { getDashboard } = await import('@/services/dashboard.service');
    const { runReport } = await import('@/services/report.service');
    const d = await getDashboard({});
    const report = await runReport({ key: 'overdue-items' });
    expect(kpi(d, 'overdue')!.value).toBe(String(report.rows.length));
  });
});

// ============================ D4 ============================

describe('D4 — الأرصدة لا تتأثر بالفلتر', () => {
  it('★ تغيير الفترة لا يغيّر الأرصدة', async () => {
    const { getDashboard } = await import('@/services/dashboard.service');
    const a = await getDashboard({ from: '2020-01-01', to: '2020-01-31' });
    const b = await getDashboard({ from: '2026-08-01', to: '2026-08-31' });
    expect(a.balanceKpis.map((k) => k.value)).toEqual(b.balanceKpis.map((k) => k.value));
  });

  it('★ مؤشرات اليوم تتبع تاريخ العمل لا الفلتر', async () => {
    const { getDashboard } = await import('@/services/dashboard.service');
    const a = await getDashboard({ from: '2020-01-01', to: '2020-01-31' });
    const b = await getDashboard({ from: '2026-08-01', to: '2026-08-31' });
    expect(a.today).toBe(b.today);
    expect(a.todayKpis.map((k) => k.value)).toEqual(b.todayKpis.map((k) => k.value));
  });

  it('كل رصيد موسوم بأنه لحظي', async () => {
    const { getDashboard } = await import('@/services/dashboard.service');
    const d = await getDashboard({});
    for (const k of d.balanceKpis) {
      expect(k.hint ?? '').toMatch(/لحظي|التزام تجاه العملاء/);
    }
  });
});

// ============================ D2 و D3 ============================

describe('D2 — الإيراد والنقدية مؤشران منفصلان', () => {
  it('★ الإيراد مؤشر مستقل، والنقدية يعرضها المكوّن القائم بلا تكرار', async () => {
    const { getDashboard } = await import('@/services/dashboard.service');
    const d = await getDashboard({});
    expect(kpi(d, 'today-revenue')!.label).toBe('إيراد اليوم');
    // النقدية ليست مؤشرًا مكررًا — مصدرها CashMovementBox القائم
    expect(kpi(d, 'today-cash')).toBeUndefined();

    const page = readFileSync('src/app/(app)/page.tsx', 'utf8');
    expect(page).toContain('CashMovementBox');
    const box = readFileSync('src/components/CashMovementBox.tsx', 'utf8');
    expect(box).toContain('صافي حركة النقدية اليوم');
  });

  it('يوضّح الفرق بينهما نصًّا', async () => {
    const { getDashboard } = await import('@/services/dashboard.service');
    const d = await getDashboard({});
    expect(d.notes.some((n) => n.includes('الإيراد يختلف عن حركة النقدية'))).toBe(true);
  });
});

describe('D3 — الربح موسوم تقديريًا', () => {
  it('عنوان البطاقة وتنبيهها', async () => {
    const { getDashboard } = await import('@/services/dashboard.service');
    const d = await getDashboard({});
    const p = kpi(d, 'period-profit')!;
    expect(p.label).toBe('صافي الربح التقديري');
    expect(p.hint).toContain('ربحية القطعة');
  });
});

// ============================ الصلاحيات ============================

describe('صلاحيات اللوحة', () => {
  it('★ موظف الفرع لا يرى أي مؤشر مالي', async () => {
    asStaff();
    const { getDashboard } = await import('@/services/dashboard.service');
    const d = await getDashboard({});
    for (const key of ['today-revenue', 'outstanding', 'insurance-balance',
                       'period-revenue', 'period-expenses', 'period-profit']) {
      expect(kpi(d, key), `${key} يجب ألا يظهر للموظف`).toBeUndefined();
    }
    expect(d.periodKpis).toHaveLength(0);
  });

  it('موظف الفرع يرى المؤشرات التشغيلية وحركة النقدية', async () => {
    asStaff();
    const { getDashboard } = await import('@/services/dashboard.service');
    const d = await getDashboard({});
    expect(kpi(d, 'today-rentals')).toBeDefined();
    expect(kpi(d, 'available-items')).toBeDefined();
  });

  it('★ الموظف لا يرى أداء زملائه', async () => {
    asStaff();
    const { getDashboard } = await import('@/services/dashboard.service');
    expect((await getDashboard({})).employees).toHaveLength(0);
  });

  it('المدير يرى كل المؤشرات', async () => {
    const { getDashboard } = await import('@/services/dashboard.service');
    const d = await getDashboard({});
    for (const key of ['today-revenue', 'outstanding', 'insurance-balance',
                       'period-revenue', 'period-expenses', 'period-profit']) {
      expect(kpi(d, key), key).toBeDefined();
    }
  });

  it('★ المؤشر غير المسموح لا يُحسب أصلًا فلا يُستدل عليه', async () => {
    asStaff();
    const { getDashboard } = await import('@/services/dashboard.service');
    const d = await getDashboard({});
    // لا مفتاح مالي في أي مجموعة
    const keys = allKpis(d).map((k) => k.key);
    expect(keys.some((k) => k.includes('revenue') || k.includes('profit'))).toBe(false);
  });
});

// ============================ D6 والبنية ============================

describe('D6 — مجمِّع فقط بلا منطق جديد', () => {
  const src = readFileSync('src/services/dashboard.service.ts', 'utf8');

  it('★ لا استعلام مباشر لقاعدة البيانات للمؤشرات', () => {
    expect(src).not.toContain('prisma.rental.');
    expect(src).not.toContain('prisma.sale.');
    expect(src).not.toContain('prisma.expense.');
  });

  it('★ قراءة فقط — صفر عملية كتابة', () => {
    for (const op of ['.create(', '.update(', '.delete(', '.upsert(',
                      'updateMany', 'deleteMany', '$executeRaw', '$transaction']) {
      expect(src).not.toContain(op);
    }
  });

  it('★ يعيد استخدام دوال M1 و M6 و M7 المعتمدة', () => {
    expect(src).toContain("from '@/services/report.service'");
    expect(src).toContain("from '@/services/inventory.service'");
    expect(src).toContain("from '@/services/cash.service'");
    expect(src).toContain("from '@/services/employee.service'");
  });

  it('كل مؤشر يشير إلى تقريره المقابل', async () => {
    const { getDashboard } = await import('@/services/dashboard.service');
    const d = await getDashboard({});
    const linked = allKpis(d).filter((k) => k.href !== null);
    expect(linked.length).toBeGreaterThan(0);
    for (const k of linked) expect(k.href).toMatch(/^\/(reports|cash)/);
  });

  it('لا بطاقات تطويرية في الصفحة (D1)', () => {
    const page = readFileSync('src/app/(app)/page.tsx', 'utf8');
    expect(page).not.toContain('M0_DONE');
    expect(page).not.toContain('تُبنى في المرحلة M8');
  });
});
