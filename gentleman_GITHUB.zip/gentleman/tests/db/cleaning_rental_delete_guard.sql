\set ON_ERROR_STOP off
\t on
UPDATE cleaning_records SET rental_id = (SELECT id FROM rentals WHERE rental_no='R-M13-1') WHERE id=1;
SELECT '  ✅ رُبط سجل التنظيف 1 بالعقد ' || (SELECT rental_no FROM rentals WHERE id=(SELECT rental_id FROM cleaning_records WHERE id=1));
\echo '--- محاولة حذف العقد المرتبط (يجب أن تُرفض) ---'
DELETE FROM rentals WHERE rental_no='R-M13-1';
\echo '--- تأكيد بقاء العقد والرابط ---'
SELECT '  العقد ما زال موجودًا: ' || count(*) FROM rentals WHERE rental_no='R-M13-1';
SELECT '  الرابط سليم: ' || (rental_id IS NOT NULL) FROM cleaning_records WHERE id=1;
\echo '--- السجل الثاني ما زال NULL (لا ملء رجعي) ---'
SELECT '  سجل 2: rental_id=' || COALESCE(rental_id::text,'NULL') FROM cleaning_records WHERE id=2;
