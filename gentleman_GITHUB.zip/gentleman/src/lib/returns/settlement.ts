import { Decimal } from 'decimal.js';
import { round2, add, sub } from '@/lib/money';
import { daysLate as calcDaysLate } from '@/lib/date';

/**
 * منطق تسوية الإرجاع — خالص وقابل للاختبار بلا قاعدة بيانات.
 *
 * القاعدة الحاسمة التي تمنع ازدواج الإيراد:
 *   الإيراد يُسجَّل مرة واحدة عند فرض الغرامة، لا عند تحصيلها.
 *   استخدام التأمين لسداد الغرامة حركة سداد وليس إيرادًا جديدًا.
 */

export class SettlementError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'SettlementError';
  }
}

export type ItemCondition = 'GOOD' | 'DAMAGED' | 'LOST';

export interface LateFeeInput {
  expectedReturnDate: Date;
  actualReturnDate: Date;
  feePerItemPerDay: Decimal.Value;
  capPerItem?: Decimal.Value; // 0 أو غير محدد = بلا سقف
}

export interface LateFeeResult {
  daysLate: number;
  rawFee: Decimal;
  cappedFee: Decimal;
  wasCapped: boolean;
}

/** غرامة التأخير: لكل قطعة في اليوم، مع سقف اختياري. */
export function computeLateFee(input: LateFeeInput): LateFeeResult {
  const fee = round2(input.feePerItemPerDay);
  if (fee.lt(0)) throw new SettlementError('رسوم التأخير لا يمكن أن تكون سالبة.');

  const days = calcDaysLate(input.expectedReturnDate, input.actualReturnDate);
  const rawFee = round2(fee.times(days));

  const cap = round2(input.capPerItem ?? 0);
  if (cap.lt(0)) throw new SettlementError('سقف الغرامة لا يمكن أن يكون سالبًا.');

  const capped = cap.gt(0) && rawFee.gt(cap) ? cap : rawFee;
  return { daysLate: days, rawFee, cappedFee: capped, wasCapped: capped.lt(rawFee) };
}

export interface SettlementInput {
  condition: ItemCondition;
  lateFee: Decimal.Value;
  damageFee?: Decimal.Value;
  lossFee?: Decimal.Value;
  /** التأمين المحصَّل لهذه القطعة تحديدًا. */
  insuranceAvailable: Decimal.Value;
}

export interface SettlementResult {
  /** ★ إيراد — يُسجَّل مرة واحدة */
  lateFee: Decimal;
  damageFee: Decimal;
  lossFee: Decimal;
  totalCharges: Decimal;
  /** ★ سداد — ليس إيرادًا */
  insuranceUsed: Decimal;
  /** ★ خروج من التزام — ليس إيرادًا */
  insuranceRefunded: Decimal;
  /** ★ مديونية على العميل — ليست إيرادًا */
  extraDueFromCustomer: Decimal;
}

/**
 * توزيع التأمين على الغرامات.
 * التأمين يُستخدم أولًا لسداد الغرامات، والباقي يُرد، والعجز يصبح مديونية.
 */
export function computeSettlement(input: SettlementInput): SettlementResult {
  const lateFee = round2(input.lateFee);
  const damageFee = round2(input.damageFee ?? 0);
  const lossFee = round2(input.lossFee ?? 0);
  const insurance = round2(input.insuranceAvailable);

  for (const [label, v] of [
    ['غرامة التأخير', lateFee], ['قيمة التلف', damageFee],
    ['تعويض الفقد', lossFee], ['التأمين', insurance],
  ] as const) {
    if (v.lt(0)) throw new SettlementError(`${label} لا يمكن أن يكون سالبًا.`);
  }

  // اتساق الحالة مع المبالغ
  if (input.condition === 'DAMAGED' && damageFee.lte(0)) {
    throw new SettlementError('يجب إدخال قيمة التلف عند تسجيل القطعة تالفة.');
  }
  if (input.condition === 'LOST' && lossFee.lte(0)) {
    throw new SettlementError('يجب إدخال قيمة تعويض الفقد عند تسجيل القطعة مفقودة.');
  }
  if (input.condition === 'GOOD' && (damageFee.gt(0) || lossFee.gt(0))) {
    throw new SettlementError('لا يجوز تسجيل تلف أو فقد على قطعة مُرجَعة سليمة.');
  }
  if (input.condition !== 'DAMAGED' && damageFee.gt(0)) {
    throw new SettlementError('قيمة التلف تُسجَّل فقط مع حالة "تالفة".');
  }
  if (input.condition !== 'LOST' && lossFee.gt(0)) {
    throw new SettlementError('تعويض الفقد يُسجَّل فقط مع حالة "مفقودة".');
  }

  const totalCharges = add(lateFee, damageFee, lossFee);

  // التأمين يسدّد الغرامات بحد أقصى ما هو متاح
  const insuranceUsed = totalCharges.lte(insurance) ? totalCharges : insurance;
  const insuranceRefunded = sub(insurance, insuranceUsed);
  const extraDueFromCustomer = sub(totalCharges, insuranceUsed);

  return {
    lateFee, damageFee, lossFee, totalCharges,
    insuranceUsed, insuranceRefunded, extraDueFromCustomer,
  };
}

/** ثوابت التسوية — تُفحص بعد كل حساب ولا يجوز خرقها إطلاقًا. */
export function assertSettlementInvariants(
  r: SettlementResult,
  insuranceAvailable: Decimal.Value,
): void {
  const insurance = round2(insuranceAvailable);

  if (!add(r.insuranceUsed, r.insuranceRefunded).equals(insurance)) {
    throw new SettlementError(
      `اختلال في التأمين: المستخدم ${r.insuranceUsed} + المردود ${r.insuranceRefunded} ≠ المتاح ${insurance}`,
    );
  }
  if (!add(r.insuranceUsed, r.extraDueFromCustomer).equals(r.totalCharges)) {
    throw new SettlementError(
      `اختلال في التسوية: المستخدم ${r.insuranceUsed} + المستحق ${r.extraDueFromCustomer} ≠ الغرامات ${r.totalCharges}`,
    );
  }
  if (!add(r.lateFee, r.damageFee, r.lossFee).equals(r.totalCharges)) {
    throw new SettlementError('اختلال في مجموع الغرامات.');
  }
  for (const v of [r.insuranceUsed, r.insuranceRefunded, r.extraDueFromCustomer]) {
    if (v.lt(0)) throw new SettlementError('نتيجة تسوية سالبة — غير مقبولة.');
  }
}

/**
 * ★ الإيراد المعترف به من هذا الإرجاع.
 * لا يشمل التأمين المستخدم إطلاقًا — وإلا لتضاعف الإيراد.
 */
export const recognizedRevenue = (r: SettlementResult): Decimal =>
  add(r.lateFee, r.damageFee, r.lossFee);

/** حالة القطعة بعد الإرجاع. */
export function itemStatusAfterReturn(
  condition: ItemCondition,
  cleaningEnabled: boolean,
): 'AVAILABLE' | 'CLEANING' | 'DAMAGED' | 'LOST' {
  if (condition === 'LOST') return 'LOST';
  if (condition === 'DAMAGED') return 'DAMAGED';
  return cleaningEnabled ? 'CLEANING' : 'AVAILABLE';
}

/** حالة سطر العقد بعد الإرجاع. */
export const rentalItemStatusAfterReturn = (c: ItemCondition): 'RETURNED' | 'LOST' =>
  c === 'LOST' ? 'LOST' : 'RETURNED';

/** اشتقاق حالة العقد من حالات سطوره — لا تُكتب يدويًا أبدًا. */
export function deriveRentalStatus(
  lineStatuses: Array<'OUT' | 'RETURNED' | 'LOST' | 'VOIDED'>,
): 'ACTIVE' | 'PARTIALLY_RETURNED' | 'CLOSED' {
  const active = lineStatuses.filter((s) => s !== 'VOIDED');
  const out = active.filter((s) => s === 'OUT').length;
  if (out === active.length) return 'ACTIVE';
  if (out === 0) return 'CLOSED';
  return 'PARTIALLY_RETURNED';
}
