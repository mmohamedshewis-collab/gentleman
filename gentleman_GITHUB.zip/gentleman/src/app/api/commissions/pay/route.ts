import { route } from '@/lib/api';
import { payCommission, payCommissionSchema } from '@/services/commission.service';

export const POST = route({ schema: payCommissionSchema, handler: ({ input }) => payCommission(input) });
