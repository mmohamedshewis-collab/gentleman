import { exportHistory } from '@/services/backup.service';
import { getSession } from '@/lib/auth/session';
import OperationsPanel from '@/components/OperationsPanel';

export const dynamic = 'force-dynamic';

export default async function OperationsPage() {
  const session = await getSession();
  const canExport = session?.permissions.has('backup.run') ?? false;
  const canImportItems = session?.permissions.has('items.manage') ?? false;
  const canImportCustomers = session?.permissions.has('customers.create') ?? false;

  const history = canExport ? await exportHistory({ limit: 20 }) : null;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="section-title">التشغيل والبيانات</h1>
        <p className="text-sm text-slate-600 mt-1">
          تصدير البيانات للأرشيف واستيراد البيانات الافتتاحية.
        </p>
      </div>

      <OperationsPanel
        canExport={canExport}
        canImportItems={canImportItems}
        canImportCustomers={canImportCustomers}
        history={history}
      />
    </div>
  );
}
