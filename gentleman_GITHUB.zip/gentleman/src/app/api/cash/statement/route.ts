import { route } from '@/lib/api';
import { dayCashStatement, dateQuerySchema } from '@/services/cash.service';

export const GET = route({ schema: dateQuerySchema, handler: ({ input }) => dayCashStatement(input.date) });
