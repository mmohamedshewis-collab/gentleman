import { z } from 'zod';
import { prisma } from '@/lib/db';
import { Errors } from '@/lib/errors';
import { writeAudit } from '@/lib/audit';
import { requirePermission, can } from '@/lib/auth/rbac';
import { businessToday, toBusinessDate } from '@/lib/date';
import { add, round2 } from '@/lib/money';
import { getNumberSetting, getBoolSetting } from '@/lib/settings';
import {
  computeLateFee, computeSettlement, assertSettlementInvariants, recognizedRevenue,
  itemStatusAfterReturn, rentalItemStatusAfterReturn, deriveRentalStatus,
  SettlementError, type ItemCondition,
} from '@/lib/returns/settlement';

const money = z.coerce.number().min(0).max(9999999);

export const returnLineSchema = z.object({
  rentalItemId: z.number().int().positive(),
  condition: z.enum(['GOOD', 'DAMAGED', 'LOST']),
  damageFee: money.optional(),
  lossFee: money.optional(),
  damageDescription: z.string().max(500).optional(),
  /** إعفاء أو تخفيض غرامة التأخير — يتطلب صلاحية وسببًا */
  lateFeeOverride: money.optional(),
  overrideReason: z.string().max(300).optional(),
});

export const createReturnSchema = z.object({
  rentalId: z.number().int().positive(),
  returnDate: z.string().optional(),
  lines: z.array(returnLineSchema).min(1, 'يجب اختيار قطعة واحدة على الأقل'),
  notes: z.string().max(500).optional(),
});

export const voidReturnSchema = z.object({
  returnId: z.number().int().positive(),
  reason: z.string().trim().min(3, 'سبب الإلغاء مطلوب').max(300),
});

export const scanForReturnSchema = z.object({ barcode: z.string().min(1) });

/**
 * مسح باركود للإرجاع: يجد العقد النشط للقطعة ويعرض ما يحتاجه الموظف فورًا،
 * مع غرامة التأخير محسوبة مسبقًا.
 */
export async function scanForReturn(barcode: string) {
  await requirePermission('returns.create');
  const code = barcode.trim().toUpperCase();

  const line = await prisma.rentalItem.findFirst({
    where: {
      status: 'OUT',
      rental: { status: { in: ['ACTIVE', 'PARTIALLY_RETURNED'] } },
      item: { OR: [{ barcode: code }, { itemCode: code }] },
    },
    include: {
      item: { include: { product: { select: { nameAr: true, size: true, color: true } } } },
      rental: { include: { customer: { select: { id: true, fullName: true, phone: true } } } },
    },
  });

  if (!line) {
    throw Errors.notFound(`عقد تأجير نشط للقطعة "${code}"`);
  }

  const feePerDay = await getNumberSetting('rental.late_fee_per_item_per_day');
  const cap = await getNumberSetting('rental.late_fee_cap_per_item');
  const today = businessToday();

  const late = computeLateFee({
    expectedReturnDate: line.expectedReturnDate,
    actualReturnDate: today,
    feePerItemPerDay: feePerDay,
    capPerItem: cap,
  });

  return {
    rentalItemId: line.id,
    rentalId: line.rentalId,
    rentalNo: line.rental.rentalNo,
    customer: line.rental.customer,
    itemCode: line.item.itemCode,
    barcode: line.item.barcode,
    productName: line.item.product.nameAr,
    size: line.item.product.size,
    color: line.item.product.color,
    expectedReturnDate: line.expectedReturnDate,
    daysLate: late.daysLate,
    lateFee: late.cappedFee.toString(),
    lateFeeWasCapped: late.wasCapped,
    insuranceAvailable: line.insurancePerItem.toString(),
  };
}

/**
 * تسجيل الإرجاع — معاملة واحدة ذرّية.
 *
 * الفصل الصارم بين المفاهيم:
 *   الغرامات (تأخير/تلف/فقد) = إيراد يُسجَّل مرة واحدة هنا.
 *   التأمين المستخدم         = سداد، وليس إيرادًا.
 *   التأمين المردود          = خروج من التزام، وليس إيرادًا.
 *   المستحق الإضافي          = مديونية تُضاف إلى العقد.
 */
export async function createReturn(input: z.infer<typeof createReturnSchema>) {
  const actor = await requirePermission('returns.create');

  const returnDate = input.returnDate ? toBusinessDate(input.returnDate) : businessToday();
  const feePerDay = await getNumberSetting('rental.late_fee_per_item_per_day');
  const cap = await getNumberSetting('rental.late_fee_cap_per_item');
  const cleaningEnabled = await getBoolSetting('cleaning.enabled');

  // لا تكرار لنفس السطر داخل الطلب
  const ids = input.lines.map((l) => l.rentalItemId);
  if (new Set(ids).size !== ids.length) {
    throw Errors.rule('لا يمكن إرجاع نفس القطعة مرتين في العملية الواحدة.');
  }

  return prisma.$transaction(async (tx) => {
    // 1) قفل العقد
    const lockedRental = await tx.$queryRaw<{ id: number; status: string; rental_no: string; extra_charges: string }[]>`
      SELECT id, status::text AS status, rental_no, extra_charges::text AS extra_charges
        FROM rentals WHERE id = ${input.rentalId} FOR UPDATE
    `;
    if (lockedRental.length === 0) throw Errors.notFound('عقد التأجير');
    const rental = lockedRental[0];

    if (rental.status === 'VOIDED') throw Errors.rule('العقد ملغى ولا يقبل إرجاعًا.');
    if (rental.status === 'CLOSED') throw Errors.rule('العقد مغلق — كل قطعه أُرجعت بالفعل.');

    // 2) قفل السطور بترتيب ثابت (يمنع الجمود بين جلستين)
    const sortedIds = [...ids].sort((a, b) => a - b);
    const lockedLines = await tx.$queryRaw<
      { id: number; item_id: number; status: string; rental_id: number; insurance_per_item: string; expected_return_date: Date }[]
    >`
      SELECT id, item_id, status::text AS status, rental_id,
             insurance_per_item::text AS insurance_per_item, expected_return_date
        FROM rental_items WHERE id = ANY(${sortedIds}::int[]) ORDER BY id FOR UPDATE
    `;

    if (lockedLines.length !== ids.length) throw Errors.notFound('أحد سطور العقد');

    for (const l of lockedLines) {
      if (l.rental_id !== input.rentalId) {
        throw Errors.rule('إحدى القطع لا تنتمي إلى هذا العقد.');
      }
      if (l.status !== 'OUT') {
        const label = l.status === 'RETURNED' ? 'مُرجَعة بالفعل' : l.status === 'LOST' ? 'مسجَّلة كمفقودة' : 'ملغاة';
        throw Errors.conflict(`القطعة ${label} ولا يمكن إرجاعها مرة أخرى.`);
      }
      if (returnDate < l.expected_return_date && false) {
        // مسموح: الإرجاع المبكر
      }
    }

    // 3) رقم الإرجاع (قفل استشاري يمنع تكرار الرقم بين جلستين)
    await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext('return_no'))`;
    const year = returnDate.getUTCFullYear();
    const lastReturn = await tx.return.findFirst({
      where: { returnNo: { startsWith: `RT-${year}-` } },
      orderBy: { returnNo: 'desc' },
      select: { returnNo: true },
    });
    const seq = lastReturn ? Number.parseInt(lastReturn.returnNo.slice(8), 10) + 1 : 1;
    const returnNo = `RT-${year}-${String(Number.isFinite(seq) ? seq : 1).padStart(4, '0')}`;

    // 4) رأس الإرجاع
    const ret = await tx.return.create({
      data: {
        returnNo,
        rentalId: input.rentalId,
        returnDate,
        employeeId: actor.employeeId ?? null,
        notes: input.notes?.trim() || null,
        createdBy: actor.id,
      },
    });

    const byId = new Map(lockedLines.map((l) => [l.id, l]));
    let totalExtraDue = round2(0);
    let totalCharges = round2(0);
    let totalInsuranceUsed = round2(0);
    let totalInsuranceRefunded = round2(0);

    for (const lineInput of input.lines) {
      const line = byId.get(lineInput.rentalItemId)!;

      // 5) غرامة التأخير — يحسبها النظام لا الموظف
      const late = computeLateFee({
        expectedReturnDate: line.expected_return_date,
        actualReturnDate: returnDate,
        feePerItemPerDay: feePerDay,
        capPerItem: cap,
      });

      let lateFee = late.cappedFee;
      if (lineInput.lateFeeOverride !== undefined) {
        if (!can(actor, 'returns.waive_fee')) throw Errors.forbidden('returns.waive_fee');
        if (!lineInput.overrideReason?.trim()) {
          throw Errors.rule('يجب كتابة سبب عند تعديل غرامة التأخير.');
        }
        if (round2(lineInput.lateFeeOverride).gt(late.cappedFee)) {
          throw Errors.rule('لا يمكن رفع غرامة التأخير فوق القيمة المحسوبة.');
        }
        lateFee = round2(lineInput.lateFeeOverride);
      }

      // 6) تسوية التأمين
      let settlement;
      try {
        settlement = computeSettlement({
          condition: lineInput.condition as ItemCondition,
          lateFee,
          damageFee: lineInput.damageFee,
          lossFee: lineInput.lossFee,
          insuranceAvailable: line.insurance_per_item,
        });
        assertSettlementInvariants(settlement, line.insurance_per_item);
      } catch (e) {
        if (e instanceof SettlementError) throw Errors.rule(e.message);
        throw e;
      }

      // 7) سطر الإرجاع
      await tx.returnItem.create({
        data: {
          returnId: ret.id,
          rentalItemId: line.id,
          itemId: line.item_id,
          actualReturnDate: returnDate,
          daysLate: late.daysLate,
          lateFee: settlement.lateFee.toString(),
          condition: lineInput.condition,
          damageDescription: lineInput.damageDescription?.trim() || null,
          damageFee: settlement.damageFee.toString(),
          lossFee: settlement.lossFee.toString(),
          insuranceUsed: settlement.insuranceUsed.toString(),
          insuranceRefunded: settlement.insuranceRefunded.toString(),
          extraDueFromCustomer: settlement.extraDueFromCustomer.toString(),
        },
      });

      // 8) حالة سطر العقد
      const newLineStatus = rentalItemStatusAfterReturn(lineInput.condition as ItemCondition);
      await tx.rentalItem.update({ where: { id: line.id }, data: { status: newLineStatus } });

      // 9) حالة القطعة
      const newItemStatus = itemStatusAfterReturn(lineInput.condition as ItemCondition, cleaningEnabled);
      await tx.productItem.update({
        where: { id: line.item_id },
        data: {
          status: newItemStatus,
          lastReturnDate: returnDate,
          totalFeesRevenue: { increment: recognizedRevenue(settlement).toString() },
        },
      });

      await tx.itemStatusHistory.create({
        data: {
          itemId: line.item_id,
          fromStatus: 'RENTED',
          toStatus: newItemStatus,
          reason: `إرجاع ${returnNo} — الحالة: ${lineInput.condition}`,
          refType: 'Return',
          refId: ret.id,
          userId: actor.id,
        },
      });

      await tx.inventoryTransaction.create({
        data: {
          itemId: line.item_id,
          trxDate: returnDate,
          type: lineInput.condition === 'LOST' ? 'WRITE_OFF' : 'RETURN_IN',
          refType: 'Return',
          refId: ret.id,
          note: `إرجاع ${returnNo}`,
          createdBy: actor.id,
        },
      });

      // 10) تعطيل الحجز الزمني للقطعة
      await tx.itemBooking.updateMany({
        where: { itemId: line.item_id, sourceType: 'RENTAL', sourceId: input.rentalId, isActive: true },
        data: { isActive: false },
      });

      totalCharges = add(totalCharges, settlement.totalCharges);
      totalExtraDue = add(totalExtraDue, settlement.extraDueFromCustomer);
      totalInsuranceUsed = add(totalInsuranceUsed, settlement.insuranceUsed);
      totalInsuranceRefunded = add(totalInsuranceRefunded, settlement.insuranceRefunded);
    }

    // 11) حركات التأمين — سجل مستقل برصيد جارٍ
    if (totalInsuranceUsed.gt(0) || totalInsuranceRefunded.gt(0)) {
      await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext('insurance_ledger'))`;
      const last = await tx.insuranceTransaction.findFirst({
        orderBy: { id: 'desc' },
        select: { balanceAfter: true },
      });
      let balance = round2(last?.balanceAfter?.toString() ?? 0);

      if (totalInsuranceUsed.gt(0)) {
        balance = round2(balance.minus(totalInsuranceUsed));
        await tx.insuranceTransaction.create({
          data: {
            trxDate: returnDate,
            type: 'DEDUCTED_DAMAGE',
            rentalId: input.rentalId,
            amount: totalInsuranceUsed.toString(),
            balanceAfter: balance.toString(),
            reason: `استقطاع من التأمين لسداد غرامات الإرجاع ${returnNo}`,
            createdBy: actor.id,
          },
        });
      }
      if (totalInsuranceRefunded.gt(0)) {
        balance = round2(balance.minus(totalInsuranceRefunded));
        await tx.insuranceTransaction.create({
          data: {
            trxDate: returnDate,
            type: 'REFUNDED',
            rentalId: input.rentalId,
            amount: totalInsuranceRefunded.toString(),
            balanceAfter: balance.toString(),
            reason: `رد تأمين للعميل عند الإرجاع ${returnNo}`,
            createdBy: actor.id,
          },
        });
      }
    }

    // 12) المستحق الإضافي يُضاف إلى العقد — والمتبقي يتحدّث تلقائيًا بـ Trigger
    if (totalExtraDue.gt(0)) {
      const current = round2(rental.extra_charges);
      const newExtra = add(current, totalExtraDue);
      await tx.$executeRaw`
        UPDATE rentals
           SET extra_charges = ${newExtra.toString()}::numeric,
               total_due = gross_amount + ${newExtra.toString()}::numeric,
               remaining_amount = (gross_amount + ${newExtra.toString()}::numeric) - paid_amount
         WHERE id = ${input.rentalId}
      `;
    }

    // 13) حالة العقد تُشتق من سطوره ولا تُكتب يدويًا
    const allLines = await tx.rentalItem.findMany({
      where: { rentalId: input.rentalId },
      select: { status: true },
    });
    const derived = deriveRentalStatus(allLines.map((l) => l.status as never));
    await tx.rental.update({ where: { id: input.rentalId }, data: { status: derived } });

    // 14) سجل التدقيق
    await writeAudit(
      {
        userId: actor.id,
        action: 'return.create',
        entityType: 'Return',
        entityId: ret.id,
        after: {
          returnNo,
          rentalNo: rental.rental_no,
          itemsCount: input.lines.length,
          totalCharges: totalCharges.toString(),
          insuranceUsed: totalInsuranceUsed.toString(),
          insuranceRefunded: totalInsuranceRefunded.toString(),
          extraDue: totalExtraDue.toString(),
          rentalStatus: derived,
        },
      },
      tx,
    );

    return {
      id: ret.id,
      returnNo,
      rentalStatus: derived,
      totalCharges: totalCharges.toString(),
      insuranceUsed: totalInsuranceUsed.toString(),
      insuranceRefunded: totalInsuranceRefunded.toString(),
      extraDueFromCustomer: totalExtraDue.toString(),
    };
  });
}

/**
 * إلغاء الإرجاع — لا حذف، بل عكس كامل لكل الآثار.
 */
export async function voidReturn(input: z.infer<typeof voidReturnSchema>) {
  const actor = await requirePermission('returns.void');

  return prisma.$transaction(async (tx) => {
    const locked = await tx.$queryRaw<
      { id: number; rental_id: number; is_voided: boolean; return_no: string }[]
    >`
      SELECT id, rental_id, is_voided, return_no FROM returns WHERE id = ${input.returnId} FOR UPDATE
    `;
    if (locked.length === 0) throw Errors.notFound('عملية الإرجاع');
    const ret = locked[0];
    if (ret.is_voided) throw Errors.rule('عملية الإرجاع ملغاة بالفعل.');

    const items = await tx.returnItem.findMany({ where: { returnId: ret.id } });

    let totalExtraDue = round2(0);
    let totalInsuranceUsed = round2(0);
    let totalInsuranceRefunded = round2(0);

    for (const it of items) {
      // إعادة سطر العقد والقطعة إلى حالة التأجير
      await tx.rentalItem.update({ where: { id: it.rentalItemId }, data: { status: 'OUT' } });

      await tx.productItem.update({
        where: { id: it.itemId },
        data: {
          status: 'RENTED',
          totalFeesRevenue: {
            decrement: add(it.lateFee.toString(), it.damageFee.toString(), it.lossFee.toString()).toString(),
          },
        },
      });

      await tx.itemStatusHistory.create({
        data: {
          itemId: it.itemId,
          fromStatus: 'RENTED',
          toStatus: 'RENTED',
          reason: `إلغاء إرجاع ${ret.return_no}: ${input.reason}`,
          refType: 'Return',
          refId: ret.id,
          userId: actor.id,
        },
      });

      await tx.itemBooking.updateMany({
        where: { itemId: it.itemId, sourceType: 'RENTAL', sourceId: ret.rental_id },
        data: { isActive: true },
      });

      totalExtraDue = add(totalExtraDue, it.extraDueFromCustomer.toString());
      totalInsuranceUsed = add(totalInsuranceUsed, it.insuranceUsed.toString());
      totalInsuranceRefunded = add(totalInsuranceRefunded, it.insuranceRefunded.toString());
    }

    // عكس حركات التأمين
    if (totalInsuranceUsed.gt(0) || totalInsuranceRefunded.gt(0)) {
      await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext('insurance_ledger'))`;
      const last = await tx.insuranceTransaction.findFirst({
        orderBy: { id: 'desc' },
        select: { balanceAfter: true },
      });
      let balance = round2(last?.balanceAfter?.toString() ?? 0);
      const restored = add(totalInsuranceUsed, totalInsuranceRefunded);
      balance = add(balance, restored);

      await tx.insuranceTransaction.create({
        data: {
          trxDate: businessToday(),
          type: 'COLLECTED',
          rentalId: ret.rental_id,
          amount: restored.toString(),
          balanceAfter: balance.toString(),
          reason: `عكس تسوية تأمين بسبب إلغاء الإرجاع ${ret.return_no}: ${input.reason}`,
          createdBy: actor.id,
        },
      });
    }

    // خصم المستحق الإضافي من العقد
    if (totalExtraDue.gt(0)) {
      await tx.$executeRaw`
        UPDATE rentals
           SET extra_charges = GREATEST(extra_charges - ${totalExtraDue.toString()}::numeric, 0),
               total_due = gross_amount + GREATEST(extra_charges - ${totalExtraDue.toString()}::numeric, 0),
               remaining_amount = (gross_amount + GREATEST(extra_charges - ${totalExtraDue.toString()}::numeric, 0)) - paid_amount
         WHERE id = ${ret.rental_id}
      `;
    }

    await tx.return.update({
      where: { id: ret.id },
      data: {
        isVoided: true,
        voidReason: input.reason,
        voidedBy: actor.id,
        voidedAt: new Date(),
      },
    });

    // إعادة اشتقاق حالة العقد
    const allLines = await tx.rentalItem.findMany({
      where: { rentalId: ret.rental_id },
      select: { status: true },
    });
    const derived = deriveRentalStatus(allLines.map((l) => l.status as never));
    await tx.$executeRaw`
      UPDATE rentals SET status = ${derived}::"RentalStatus" WHERE id = ${ret.rental_id}
    `;

    await writeAudit(
      {
        userId: actor.id,
        action: 'return.void',
        entityType: 'Return',
        entityId: ret.id,
        before: { isVoided: false },
        after: { isVoided: true, rentalStatus: derived },
        reason: input.reason,
      },
      tx,
    );

    return { id: ret.id, returnNo: ret.return_no, rentalStatus: derived };
  });
}

export const returnQuerySchema = z.object({
  rentalId: z.coerce.number().int().optional(),
  from: z.string().optional(),
  to: z.string().optional(),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(10).max(200).default(50),
});

export async function listReturns(input: z.infer<typeof returnQuerySchema>) {
  await requirePermission('rentals.view');
  const where: Record<string, unknown> = {};
  if (input.rentalId) where.rentalId = input.rentalId;
  if (input.from && input.to) {
    where.returnDate = { gte: toBusinessDate(input.from), lte: toBusinessDate(input.to) };
  }

  const [rows, total] = await Promise.all([
    prisma.return.findMany({
      where,
      include: {
        rental: { include: { customer: { select: { fullName: true } } } },
        items: { include: { item: { select: { itemCode: true } } } },
      },
      orderBy: { id: 'desc' },
      skip: (input.page - 1) * input.pageSize,
      take: input.pageSize,
    }),
    prisma.return.count({ where }),
  ]);
  return { rows, total, page: input.page, pageSize: input.pageSize };
}
