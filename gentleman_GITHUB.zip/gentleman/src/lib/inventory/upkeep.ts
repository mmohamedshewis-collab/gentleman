import { Decimal } from 'decimal.js';
import { round2, add, sub } from '@/lib/money';
import type { ItemStatus } from '@/lib/inventory/item-state';

/**
 * الصيانة والتنظيف — منطق خالص.
 *
 * ★ منطق النوعين متطابق (سجل + تكلفة + انتقال حالة)، فبُنيا معًا بلا تكرار.
 * ★ التكلفة **مصروف تشغيلي عادي** يمر بالمسار المالي المعتمد، وتُرصد على القطعة
 *   لتظهر في ربحية عمرها. لا رسملة ولا إهلاك (Q1 المعتمد).
 */

export type UpkeepKind = 'MAINTENANCE' | 'CLEANING';

export const UPKEEP_LABELS: Record<UpkeepKind, string> = {
  MAINTENANCE: 'صيانة',
  CLEANING: 'تنظيف',
};

/** الحالة التي تنتقل إليها القطعة عند بدء العملية. */
export const UPKEEP_STATUS: Record<UpkeepKind, ItemStatus> = {
  MAINTENANCE: 'MAINTENANCE',
  CLEANING: 'CLEANING',
};

/** تصنيف المصروف المقابل — يجب أن يكون موجودًا في الإعدادات. */
export const UPKEEP_EXPENSE_CATEGORY: Record<UpkeepKind, string> = {
  MAINTENANCE: 'صيانة',
  CLEANING: 'تنظيف',
};

export class UpkeepError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'UpkeepError';
  }
}

/** التكلفة لا تكون سالبة، والصفر مقبول (تنظيف داخلي بلا تكلفة). */
export function assertCost(cost: Decimal.Value): Decimal {
  const c = round2(cost);
  if (c.lt(0)) throw new UpkeepError('التكلفة لا يمكن أن تكون سالبة.');
  return c;
}

/** تاريخ الإنهاء لا يسبق تاريخ البدء. */
export function assertDates(startDate: Date, endDate?: Date | null): void {
  if (endDate && endDate < startDate) {
    throw new UpkeepError('تاريخ الإنهاء لا يمكن أن يسبق تاريخ البدء.');
  }
}

/**
 * ★ التكلفة تُنشئ مصروفًا فقط إذا كانت موجبة.
 *   تكلفة صفرية = عملية داخلية بلا خروج نقدي ولا مصروف.
 */
export const requiresExpense = (cost: Decimal.Value): boolean => round2(cost).gt(0);

export interface LifetimeProfitInput {
  rentalRevenue: Decimal.Value;
  feesRevenue: Decimal.Value;
  saleRevenue: Decimal.Value;
  purchaseCost: Decimal.Value;
  maintenanceCost: Decimal.Value;
  cleaningCost: Decimal.Value;
}

export interface LifetimeProfit {
  totalRevenue: Decimal;
  upkeepCost: Decimal;
  totalCost: Decimal;
  profit: Decimal;
}

/**
 * ربحية القطعة عبر عمرها — نفس تعريف M7 حرفيًا.
 *
 * ⛔ لم يتغيّر تعريف الإيراد ولا تكلفة الشراء. التصحيح الوحيد أن تكلفتَي
 *   الصيانة والتنظيف صارتا رقمين حقيقيين بدل صفر دائم.
 */
export function lifetimeProfit(input: LifetimeProfitInput): LifetimeProfit {
  const totalRevenue = add(input.rentalRevenue, input.feesRevenue, input.saleRevenue);
  const upkeepCost = add(input.maintenanceCost, input.cleaningCost);
  const totalCost = add(input.purchaseCost, upkeepCost);
  return {
    totalRevenue,
    upkeepCost,
    totalCost,
    profit: sub(totalRevenue, totalCost),
  };
}

/** مجموع تكاليف مجموعة سجلات. */
export const sumCosts = (records: { cost: Decimal.Value }[]): Decimal =>
  records.length ? add(...records.map((r) => r.cost)) : new Decimal(0);
