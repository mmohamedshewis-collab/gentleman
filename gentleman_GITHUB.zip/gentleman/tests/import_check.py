import os, re, sys
root='src'
files=[]
for d,_,fs in os.walk(root):
    for f in fs:
        if f.endswith(('.ts','.tsx')): files.append(os.path.join(d,f))

def resolve(spec, frm):
    if spec.startswith('@/'): base=os.path.join('src', spec[2:])
    elif spec.startswith('.'): base=os.path.normpath(os.path.join(os.path.dirname(frm), spec))
    else: return None
    for cand in (base+'.ts', base+'.tsx', os.path.join(base,'index.ts'), os.path.join(base,'index.tsx')):
        if os.path.exists(cand): return cand
    return False

def exports_of(path):
    src=open(path).read()
    names=set(re.findall(r'export\s+(?:async\s+)?(?:function|const|let|class|type|interface|enum)\s+(\w+)', src))
    for block in re.findall(r'export\s*\{([^}]*)\}', src):
        for part in block.split(','):
            part=part.strip()
            if not part: continue
            names.add(part.split(' as ')[-1].strip())
    if re.search(r'export\s+default', src): names.add('default')
    return names

errors=[]
imports=0
for f in files:
    src=open(f).read()
    for m in re.finditer(r'import\s+(type\s+)?(.+?)\s+from\s+[\'"]([^\'"]+)[\'"]', src, re.S):
        spec=m.group(3); clause=m.group(2)
        target=resolve(spec,f)
        if target is None: continue
        imports+=1
        if target is False:
            errors.append(f'{f}: الوحدة غير موجودة -> {spec}'); continue
        exp=exports_of(target)
        named=re.search(r'\{([^}]*)\}', clause)
        if named:
            for part in named.group(1).split(','):
                part=part.strip().replace('type ','')
                if not part: continue
                name=part.split(' as ')[0].strip()
                if name and name not in exp:
                    errors.append(f'{f}: يستورد "{name}" غير المُصدَّر من {target}')
print(f'ملفات مفحوصة: {len(files)} | استيرادات داخلية: {imports}')
if errors:
    print('\nمشاكل:'); [print(' -',e) for e in errors]; sys.exit(1)
print('\n✓ كل الاستيرادات الداخلية سليمة ولا يوجد استيراد لعنصر غير مُصدَّر.')
