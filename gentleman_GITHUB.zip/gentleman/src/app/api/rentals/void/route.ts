import { route } from '@/lib/api';
import { voidRental, voidRentalSchema } from '@/services/rental.service';

export const POST = route({ schema: voidRentalSchema, handler: ({ input }) => voidRental(input) });
