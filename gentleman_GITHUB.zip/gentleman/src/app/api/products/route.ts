import { route } from '@/lib/api';
import {
  listProducts, productQuerySchema,
  createProduct, createProductSchema,
  updateProduct, updateProductSchema,
} from '@/services/catalog.service';

export const GET = route({ schema: productQuerySchema, handler: ({ input }) => listProducts(input) });
export const POST = route({ schema: createProductSchema, handler: ({ input }) => createProduct(input) });
export const PATCH = route({ schema: updateProductSchema, handler: ({ input }) => updateProduct(input) });
