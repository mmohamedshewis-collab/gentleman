import Link from 'next/link';
import { todayCashMovement } from '@/services/cash.service';
import { formatEGP } from '@/lib/money';

/**
 * صندوق «صافي حركة النقدية اليوم».
 * حركة الشركة وحدها: بلا رصيد افتتاحي وبلا تأمين وبلا فيزا أو تحويل بنكي.
 */
export default async function CashMovementBox() {
  const m = await todayCashMovement();
  const net = Number(m.net);

  return (
    <Link href="/cash" className="block">
      <div className="card hover:shadow-md transition">
        <div className="card-header">صافي حركة النقدية اليوم</div>
        <div className="p-5 grid grid-cols-3 gap-4 text-center">
          <div>
            <div className="text-slate-500 text-sm">المقبوضات النقدية</div>
            <div className="num font-bold text-ok text-lg">{formatEGP(m.inflow)}</div>
          </div>
          <div>
            <div className="text-slate-500 text-sm">المدفوعات النقدية</div>
            <div className="num font-bold text-danger text-lg">{formatEGP(m.outflow)}</div>
          </div>
          <div>
            <div className="text-slate-500 text-sm">صافي الحركة</div>
            <div className={`num font-bold text-lg ${net < 0 ? 'text-danger' : 'text-brand'}`}>
              {formatEGP(m.net)}
            </div>
          </div>
        </div>
        <p className="px-5 pb-4 text-xs text-slate-400 text-center">
          حركة اليوم فقط · اضغط لعرض كشف الحركات
        </p>
      </div>
    </Link>
  );
}
