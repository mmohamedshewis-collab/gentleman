import { route } from '@/lib/api';
import { listInventoryTransactions, inventoryTrxQuerySchema } from '@/services/inventory.service';

export const GET = route({
  schema: inventoryTrxQuerySchema,
  handler: ({ input }) => listInventoryTransactions(input),
});
