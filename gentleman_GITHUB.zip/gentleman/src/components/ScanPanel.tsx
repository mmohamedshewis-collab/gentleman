'use client';

import { useState } from 'react';
import Link from 'next/link';
import BarcodeScanner from './BarcodeScanner';

interface ScanResult {
  id: number; itemCode: string; barcode: string; productName: string;
  category: string | null; brand: string | null; size: string | null; color: string | null;
  status: string; statusLabel: string;
  rentalPrice: string; salePrice: string; rentalCount: number;
  lastRentalDate: string | null; lastReturnDate: string | null;
  canBeRented: boolean; canBeSold: boolean;
}

export default function ScanPanel() {
  const [result, setResult] = useState<ScanResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function scan(code: string) {
    setBusy(true); setError(null); setResult(null);
    try {
      const res = await fetch(`/api/items/scan?barcode=${encodeURIComponent(code)}`);
      const json = await res.json();
      if (!json.ok) { setError(json.error?.message ?? 'تعذّر العثور على القطعة.'); return; }
      setResult(json.data);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="card">
      <div className="card-header">مسح الباركود</div>
      <div className="p-5 space-y-4">
        <BarcodeScanner onScan={scan} />

        {busy && <p className="text-sm text-slate-500">جارٍ البحث…</p>}

        {error && (
          <p className="text-danger text-sm font-semibold bg-red-50 rounded-lg px-3 py-2">{error}</p>
        )}

        {result && (
          <div className="rounded-xl border border-slate-200 p-4">
            <div className="flex items-start justify-between gap-4 mb-3">
              <div>
                <div className="text-lg font-bold text-brand">{result.productName}</div>
                <div className="num text-sm text-slate-500">{result.itemCode}</div>
              </div>
              <span className="badge bg-brand-soft text-brand">{result.statusLabel}</span>
            </div>

            <dl className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
              <div><dt className="text-slate-500">المقاس</dt><dd className="font-semibold">{result.size ?? '—'}</dd></div>
              <div><dt className="text-slate-500">اللون</dt><dd className="font-semibold">{result.color ?? '—'}</dd></div>
              <div><dt className="text-slate-500">الماركة</dt><dd className="font-semibold">{result.brand ?? '—'}</dd></div>
              <div><dt className="text-slate-500">التصنيف</dt><dd className="font-semibold">{result.category ?? '—'}</dd></div>
              <div><dt className="text-slate-500">سعر التأجير</dt><dd className="font-semibold num">{result.rentalPrice}</dd></div>
              <div><dt className="text-slate-500">سعر البيع</dt><dd className="font-semibold num">{result.salePrice}</dd></div>
              <div><dt className="text-slate-500">مرات التأجير</dt><dd className="font-semibold num">{result.rentalCount}</dd></div>
              <div>
                <dt className="text-slate-500">الجاهزية</dt>
                <dd className="font-semibold">
                  {result.canBeRented ? 'قابلة للتأجير' : 'غير قابلة للتأجير'}
                </dd>
              </div>
            </dl>

            <Link href={`/inventory/${result.id}`} className="btn-secondary mt-4 inline-flex">
              فتح بطاقة القطعة
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}
