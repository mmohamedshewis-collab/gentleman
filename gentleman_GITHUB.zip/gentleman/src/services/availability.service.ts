import { prisma } from '@/lib/db';
import { toBusinessDate } from '@/lib/date';
import { Errors } from '@/lib/errors';
import { overlaps, BLOCKING_STATUSES, type Period } from '@/lib/availability';

export { overlaps };
export type { Period };

/**
 * نواة التوفر (Availability Core) — M0/M1.
 * التوفر ليس "حالة القطعة الآن" بل "هل القطعة مرتبطة بفترة متعارضة؟".
 * جدول item_bookings هو المصدر الوحيد للحقيقة، ويكتب فيه كل من التأجير والحجز،
 * ويحرسه قيد EXCLUDE في PostgreSQL فيمنع أي تداخل حتى مع الطلبات المتزامنة.
 */

export function toPeriod(startISO: string, endISO: string): Period {
  const start = toBusinessDate(startISO);
  const end = toBusinessDate(endISO);
  if (end < start) throw Errors.rule('تاريخ النهاية يجب ألا يسبق تاريخ البداية.');
  return { start, end };
}

export async function isItemAvailable(
  itemId: number,
  period: Period,
  opts: { ignoreBookingId?: number } = {},
): Promise<{ available: boolean; reason?: string }> {
  const item = await prisma.productItem.findUnique({
    where: { id: itemId },
    select: { id: true, status: true, isActive: true },
  });
  if (!item) throw Errors.notFound('القطعة');
  if (!item.isActive) return { available: false, reason: 'القطعة غير مفعّلة.' };
  if ((BLOCKING_STATUSES as readonly string[]).includes(item.status)) {
    return { available: false, reason: `حالة القطعة الحالية (${item.status}) تمنع أي ارتباط.` };
  }

  const conflict = await prisma.itemBooking.findFirst({
    where: {
      itemId,
      isActive: true,
      id: opts.ignoreBookingId ? { not: opts.ignoreBookingId } : undefined,
      startDate: { lte: period.end },
      endDate: { gte: period.start },
    },
    select: { id: true, startDate: true, endDate: true, sourceType: true, sourceId: true },
  });

  if (conflict) {
    return {
      available: false,
      reason:
        `القطعة مرتبطة بالفعل في الفترة من ${conflict.startDate.toISOString().slice(0, 10)} ` +
        `إلى ${conflict.endDate.toISOString().slice(0, 10)} (${conflict.sourceType} رقم ${conflict.sourceId}).`,
    };
  }
  return { available: true };
}

/** القطع المتاحة فعليًا لمنتج معيّن خلال فترة مستقبلية. */
export async function availableItemsForProduct(productId: number, period: Period) {
  return prisma.productItem.findMany({
    where: {
      productId,
      isActive: true,
      status: { notIn: [...BLOCKING_STATUSES] },
      bookings: {
        none: {
          isActive: true,
          startDate: { lte: period.end },
          endDate: { gte: period.start },
        },
      },
    },
    select: { id: true, itemCode: true, barcode: true, status: true },
  });
}
