-- M13-1: ربط سجل التنظيف بعقد التأجير
--
-- حقل اختياري واحد بمفتاح أجنبي. لا جدول جديد ولا Trigger ولا صلاحية.
-- ⛔ لا ملء رجعي إطلاقًا: السجلات التاريخية تبقى NULL لأن لا دليل قاطع
--    على عقدها، وNULL هو التمثيل الصادق لـ«غير معروف».
-- ON DELETE RESTRICT: حذف عقد مرتبط بتنظيف مرفوض — لا يتيم ولا فقد لمعلومة مالية.

ALTER TABLE cleaning_records ADD COLUMN IF NOT EXISTS rental_id integer;

ALTER TABLE cleaning_records DROP CONSTRAINT IF EXISTS cleaning_records_rental_id_fkey;
ALTER TABLE cleaning_records
  ADD CONSTRAINT cleaning_records_rental_id_fkey
  FOREIGN KEY (rental_id) REFERENCES rentals(id)
  ON DELETE RESTRICT;
