import { route } from '@/lib/api';
import { recordTransfer, transferSchema } from '@/services/cash.service';

export const POST = route({ schema: transferSchema, handler: ({ input }) => recordTransfer(input) });
