import { route } from '@/lib/api';
import {
  listExpenses, expenseQuerySchema, createExpense, expenseSchema,
} from '@/services/finance.service';

export const GET = route({ schema: expenseQuerySchema, handler: ({ input }) => listExpenses(input) });
export const POST = route({ schema: expenseSchema, handler: ({ input }) => createExpense(input) });
