import { Decimal } from 'decimal.js';
import { add, sub, round2, pct, computeDocumentTotals, VAT_DISABLED, type VatContext } from '@/lib/money';

/**
 * حسابات عقد التأجير.
 * التأمين خارج كل معادلات العقد — لا يدخل الإجمالي ولا المدفوع ولا المتبقي.
 */

export interface RentalLineInput {
  itemId: number;
  unitRentalPrice: Decimal.Value;
  discount?: Decimal.Value;
  insurancePerItem?: Decimal.Value;
}

export interface RentalLineTotals {
  itemId: number;
  unitRentalPrice: Decimal;
  discount: Decimal;
  netPrice: Decimal;
  insurancePerItem: Decimal;
}

export class PricingError extends Error {}

export function computeLine(line: RentalLineInput): RentalLineTotals {
  const price = round2(line.unitRentalPrice);
  const discount = round2(line.discount ?? 0);
  const insurance = round2(line.insurancePerItem ?? 0);

  if (price.lt(0)) throw new PricingError('سعر التأجير لا يمكن أن يكون سالبًا.');
  if (discount.lt(0)) throw new PricingError('الخصم لا يمكن أن يكون سالبًا.');
  if (insurance.lt(0)) throw new PricingError('التأمين لا يمكن أن يكون سالبًا.');
  if (discount.gt(price)) throw new PricingError('الخصم لا يمكن أن يتجاوز سعر التأجير.');

  return {
    itemId: line.itemId,
    unitRentalPrice: price,
    discount,
    netPrice: sub(price, discount),
    insurancePerItem: insurance,
  };
}

export interface RentalTotals {
  lines: RentalLineTotals[];
  subtotal: Decimal;
  discount: Decimal;
  netAmount: Decimal;
  vatAmount: Decimal;
  grossAmount: Decimal;
  totalDue: Decimal;
  insuranceAmount: Decimal;
  paidAmount: Decimal;
  remainingAmount: Decimal;
  discountPercent: Decimal;
}

export function computeRentalTotals(input: {
  lines: RentalLineInput[];
  paidAmount?: Decimal.Value;
  vat?: VatContext | null;
}): RentalTotals {
  if (!input.lines.length) throw new PricingError('يجب اختيار قطعة واحدة على الأقل.');

  const ids = input.lines.map((l) => l.itemId);
  if (new Set(ids).size !== ids.length) {
    throw new PricingError('لا يمكن إضافة نفس القطعة أكثر من مرة في العقد.');
  }

  const lines = input.lines.map(computeLine);

  const subtotal = add(...lines.map((l) => l.unitRentalPrice));
  const discount = add(...lines.map((l) => l.discount));
  const insuranceAmount = add(...lines.map((l) => l.insurancePerItem));

  const doc = computeDocumentTotals({
    subtotal,
    discount,
    vat: input.vat ?? VAT_DISABLED,
  });

  // لا رسوم إضافية عند الإنشاء — تُضاف عند الإرجاع (تأخير/تلف)
  const totalDue = doc.grossAmount;
  const paidAmount = round2(input.paidAmount ?? 0);

  if (paidAmount.lt(0)) throw new PricingError('المبلغ المدفوع لا يمكن أن يكون سالبًا.');
  if (paidAmount.gt(totalDue)) {
    throw new PricingError('المبلغ المدفوع لا يمكن أن يتجاوز إجمالي العقد.');
  }

  return {
    lines,
    subtotal: doc.subtotal,
    discount: doc.discount,
    netAmount: doc.netAmount,
    vatAmount: doc.vatAmount,
    grossAmount: doc.grossAmount,
    totalDue,
    insuranceAmount,
    paidAmount,
    remainingAmount: sub(totalDue, paidAmount),
    discountPercent: subtotal.isZero() ? round2(0) : round2(discount.dividedBy(subtotal).times(100)),
  };
}

/** هل يتجاوز الخصم حد الموظف؟ */
export function exceedsDiscountLimit(discountPercent: Decimal.Value, maxPercent: Decimal.Value): boolean {
  return new Decimal(discountPercent).gt(new Decimal(maxPercent));
}

/** رقم العقد: R-2026-000001 */
export const buildRentalNo = (year: number, sequence: number): string =>
  `R-${year}-${String(sequence).padStart(6, '0')}`;

export { pct };
