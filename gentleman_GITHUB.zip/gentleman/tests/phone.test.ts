import { describe, it, expect } from 'vitest';
import { normalizePhone, formatPhone, normalizeNationalId, buildCustomerCode } from '../src/lib/customers/phone';

describe('توحيد رقم الجوال', () => {
  it('يقبل الصيغة المحلية', () => {
    expect(normalizePhone('01012345678').phone).toBe('01012345678');
  });
  it('يقبل مفتاح الدولة بكل صوره', () => {
    for (const v of ['+201012345678', '00201012345678', '201012345678', '+20 101 234 5678']) {
      expect(normalizePhone(v).phone).toBe('01012345678');
    }
  });
  it('يتجاهل المسافات والشرطات والأقواس', () => {
    expect(normalizePhone(' 010-1234 5678 ').phone).toBe('01012345678');
  });
  it('يحوّل الأرقام العربية إلى لاتينية', () => {
    expect(normalizePhone('٠١٠١٢٣٤٥٦٧٨').phone).toBe('01012345678');
  });
  it('يقبل الرقم بدون الصفر الأول', () => {
    expect(normalizePhone('1012345678').phone).toBe('01012345678');
  });
  it('يرفض الطول الخاطئ', () => {
    expect(normalizePhone('0101234').ok).toBe(false);
    expect(normalizePhone('010123456789').ok).toBe(false);
  });
  it('يرفض شبكة غير مصرية', () => {
    const r = normalizePhone('01312345678');
    expect(r.ok).toBe(false);
    expect(r.error).toContain('010');
  });
  it('يرفض الفارغ', () => {
    expect(normalizePhone('').ok).toBe(false);
    expect(normalizePhone('   ').ok).toBe(false);
  });
  it('نفس الرقم بصيغ مختلفة يعطي نفس المفتاح — لا تكرار للعميل', () => {
    const forms = ['01012345678', '+201012345678', '0020 101 234 5678', '١٠١٢٣٤٥٦٧٨'];
    const keys = new Set(forms.map((f) => normalizePhone(f).phone));
    expect(keys.size).toBe(1);
  });
});

describe('عرض الرقم', () => {
  it('يعرضه مقروءًا', () => {
    expect(formatPhone('01012345678')).toBe('0101 234 5678');
  });
});

describe('الرقم القومي', () => {
  it('اختياري — الفراغ مقبول', () => {
    expect(normalizeNationalId('').ok).toBe(true);
    expect(normalizeNationalId(null).ok).toBe(true);
  });
  it('يقبل 14 رقمًا ويرفض غير ذلك', () => {
    expect(normalizeNationalId('29001011234567').phone).toBe('29001011234567');
    expect(normalizeNationalId('123').ok).toBe(false);
  });
});

describe('كود العميل', () => {
  it('يبني الكود بست خانات', () => {
    expect(buildCustomerCode(1)).toBe('C-000001');
    expect(buildCustomerCode(1234)).toBe('C-001234');
  });
});
