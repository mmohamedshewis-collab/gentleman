import { route } from '@/lib/api';
import { suggestRentalsForItem, upkeepQuerySchema } from '@/services/upkeep.service';

/** اقتراحات العقود لربط التنظيف — قراءة فقط، لا تربط شيئًا. */
export const GET = route({
  schema: upkeepQuerySchema,
  handler: ({ input }) => suggestRentalsForItem(input),
});
