import { z } from 'zod';
import { prisma } from '@/lib/db';
import { Errors } from '@/lib/errors';
import { writeAudit } from '@/lib/audit';
import { requirePermission } from '@/lib/auth/rbac';
import { businessToday, toBusinessDate, formatDate } from '@/lib/date';
import { round2 } from '@/lib/money';
import { canTransition, STATUS_LABELS, type ItemStatus } from '@/lib/inventory/item-state';
import {
  UPKEEP_LABELS, UPKEEP_STATUS, UPKEEP_EXPENSE_CATEGORY,
  assertCost, assertDates, requiresExpense, sumCosts,
  UpkeepError, type UpkeepKind,
} from '@/lib/inventory/upkeep';

/**
 * الصيانة والتنظيف — خدمة واحدة لنوعين متطابقي المنطق.
 *
 * ★ يعيد استخدام: آلة الحالة (M1) · سجل حالة القطعة · المصروفات (M6) · التدقيق.
 * ★ التكلفة مصروف تشغيلي عادي — لا نموذج محاسبي جديد ولا رسملة ولا إهلاك.
 * ★ يصحّح تقرير ربحية القطعة: التكلفة صارت رقمًا حقيقيًا بدل صفر دائم.
 */

const money = z.coerce.number().nonnegative('التكلفة لا يمكن أن تكون سالبة');

export const startUpkeepSchema = z.object({
  itemId: z.number().int().positive(),
  kind: z.enum(['MAINTENANCE', 'CLEANING']),
  cost: money.default(0),
  description: z.string().max(500).optional(),
  /** العقد أو الإرجاع الذي استدعى التنظيف — للتتبّع */
  refType: z.string().max(30).optional(),
  refId: z.number().int().positive().optional(),
  /**
   * عقد التأجير المرتبط بالتنظيف — اختياري وبيانات وصفية بحتة.
   * يجب أن يؤكده المستخدم صراحةً؛ لا يُستنتج ولا يُملأ تلقائيًا.
   */
  rentalId: z.number().int().positive().optional(),
  paymentMethodId: z.number().int().positive().optional(),
  startDate: z.string().optional(),
});

export const completeUpkeepSchema = z.object({
  recordId: z.number().int().positive(),
  kind: z.enum(['MAINTENANCE', 'CLEANING']),
  /** الحالة التي تعود إليها القطعة */
  toStatus: z.enum(['AVAILABLE', 'DAMAGED', 'DISPOSED']),
  endDate: z.string().optional(),
});

export const upkeepQuerySchema = z.object({
  itemId: z.coerce.number().int().positive(),
});

// ============================ العرض ============================

/** سجل الصيانة والتنظيف لقطعة — يظهر في بطاقتها. */
export async function itemUpkeepHistory(input: z.infer<typeof upkeepQuerySchema>) {
  await requirePermission('items.view');

  const [maintenance, cleaning] = await Promise.all([
    prisma.maintenanceRecord.findMany({
      where: { itemId: input.itemId },
      include: { expense: { select: { expenseNo: true, amount: true } } },
      orderBy: { id: 'desc' },
    }),
    prisma.cleaningRecord.findMany({
      where: { itemId: input.itemId },
      include: {
        expense: { select: { expenseNo: true, amount: true } },
        rental: { select: { rentalNo: true } },
      },
      orderBy: { id: 'desc' },
    }),
  ]);

  const maintenanceCost = sumCosts(maintenance.map((m) => ({ cost: m.cost.toString() })));
  const cleaningCost = sumCosts(cleaning.map((c) => ({ cost: c.cost.toString() })));

  return {
    itemId: input.itemId,
    maintenanceCost: maintenanceCost.toString(),
    cleaningCost: cleaningCost.toString(),
    upkeepCost: maintenanceCost.plus(cleaningCost).toString(),
    records: [
      ...maintenance.map((m) => ({
        id: m.id,
        kind: 'MAINTENANCE' as UpkeepKind,
        kindLabel: UPKEEP_LABELS.MAINTENANCE,
        startDate: formatDate(m.startDate),
        endDate: m.endDate ? formatDate(m.endDate) : null,
        cost: m.cost.toString(),
        description: m.description,
        expenseNo: m.expense?.expenseNo ?? null,
        isOpen: m.endDate === null,
      })),
      ...cleaning.map((c) => ({
        id: c.id,
        kind: 'CLEANING' as UpkeepKind,
        kindLabel: UPKEEP_LABELS.CLEANING,
        startDate: formatDate(c.sentDate),
        endDate: c.receivedDate ? formatDate(c.receivedDate) : null,
        cost: c.cost.toString(),
        description: null,
        expenseNo: c.expense?.expenseNo ?? null,
        rentalNo: c.rental?.rentalNo ?? null,
        isOpen: c.receivedDate === null,
      })),
    ].sort((a, b) => b.startDate.localeCompare(a.startDate)),
  };
}

/**
 * عقود سابقة أُعيدت فيها هذه القطعة — **اقتراح للمستخدم لا رابط مستنتج**.
 * لا تكتب شيئًا ولا تربط شيئًا؛ المستخدم وحده يؤكد العقد.
 */
export async function suggestRentalsForItem(input: z.infer<typeof upkeepQuerySchema>) {
  await requirePermission('items.view');

  const lines = await prisma.rentalItem.findMany({
    where: { itemId: input.itemId, rental: { status: { not: 'VOIDED' } } },
    include: {
      rental: {
        select: {
          id: true, rentalNo: true, rentalDate: true, expectedReturnDate: true,
          status: true, customer: { select: { fullName: true } },
        },
      },
    },
    orderBy: { rentalId: 'desc' },
    take: 5,
  });

  return {
    itemId: input.itemId,
    // ★ اقتراحات مرتبة من الأحدث — العقد الأول هو آخر ما أُعيدت فيه القطعة
    suggestions: lines.map((l) => ({
      rentalId: l.rental.id,
      rentalNo: l.rental.rentalNo,
      rentalDate: formatDate(l.rental.rentalDate),
      expectedReturnDate: formatDate(l.rental.expectedReturnDate),
      status: l.rental.status,
      customer: l.rental.customer.fullName,
    })),
    note: 'هذه اقتراحات للاختيار — لا يُربط أي عقد تلقائيًا، ويجب تأكيد المستخدم.',
  };
}

// ============================ البدء ============================

/**
 * بدء صيانة أو تنظيف: ينقل القطعة للحالة المناسبة، ينشئ السجل بتكلفته،
 * وينشئ مصروفًا مرتبطًا **إن كانت التكلفة موجبة**.
 */
export async function startUpkeep(input: z.infer<typeof startUpkeepSchema>) {
  const actor = await requirePermission('items.manage');

  const startDate = input.startDate ? toBusinessDate(input.startDate) : businessToday();
  let cost;
  try {
    cost = assertCost(input.cost);
  } catch (e) {
    throw Errors.rule((e as UpkeepError).message);
  }

  if (requiresExpense(cost) && !input.paymentMethodId) {
    throw Errors.rule('يجب تحديد طريقة الدفع لتسجيل تكلفة العملية.');
  }

  const targetStatus = UPKEEP_STATUS[input.kind];

  // ★ M13-1: التحقق من العقد قبل أي كتابة.
  //   لا يكفي وجود العقد — يجب أن يحوي **هذه القطعة** عبر rental_items،
  //   وإلا نُسبت تكلفة تنظيف لعقد لا علاقة له بها.
  if (input.rentalId !== undefined) {
    if (input.kind !== 'CLEANING') {
      throw Errors.rule('ربط العقد متاح للتنظيف فقط.');
    }
    const line = await prisma.rentalItem.findFirst({
      where: { rentalId: input.rentalId, itemId: input.itemId },
      select: { id: true },
    });
    if (!line) {
      const rental = await prisma.rental.findUnique({
        where: { id: input.rentalId },
        select: { rentalNo: true },
      });
      throw Errors.rule(
        rental
          ? `العقد ${rental.rentalNo} لا يحتوي هذه القطعة.`
          : 'عقد التأجير غير موجود.',
      );
    }
  }

  return prisma.$transaction(async (tx) => {
    // 1) قفل القطعة وفحص الانتقال عبر آلة الحالة القائمة
    const locked = await tx.$queryRaw<{ id: number; item_code: string; status: ItemStatus }[]>`
      SELECT id, item_code, status FROM product_items WHERE id = ${input.itemId} FOR UPDATE
    `;
    if (locked.length === 0) throw Errors.notFound('القطعة');
    const item = locked[0];

    if (item.status === targetStatus) {
      throw Errors.conflict(`القطعة بالفعل في حالة "${STATUS_LABELS[targetStatus]}".`);
    }

    const check = canTransition(item.status, targetStatus, { manual: true });
    if (!check.allowed) {
      throw Errors.rule(
        check.reason ??
        `لا يمكن نقل القطعة ${item.item_code} من "${STATUS_LABELS[item.status]}" إلى "${STATUS_LABELS[targetStatus]}".`,
      );
    }

    // 2) المصروف — مسار M6 المعتمد، بلا نموذج محاسبي جديد
    let expenseId: number | null = null;
    if (requiresExpense(cost)) {
      const categoryName = UPKEEP_EXPENSE_CATEGORY[input.kind];
      const category = await tx.expenseCategory.findFirst({
        where: { nameAr: { contains: categoryName }, isActive: true },
      });
      if (!category) {
        throw Errors.rule(`فئة المصروف «${categoryName}» غير موجودة في الإعدادات.`);
      }

      await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext('expense_no'))`;
      const year = startDate.getUTCFullYear();
      const last = await tx.expense.findFirst({
        where: { expenseNo: { startsWith: `EXP-${year}-` } },
        orderBy: { expenseNo: 'desc' },
        select: { expenseNo: true },
      });
      const seq = last ? Number.parseInt(last.expenseNo.slice(9), 10) + 1 : 1;

      const expense = await tx.expense.create({
        data: {
          expenseNo: `EXP-${year}-${String(Number.isFinite(seq) ? seq : 1).padStart(6, '0')}`,
          expenseDate: startDate,
          categoryId: category.id,
          amount: cost.toString(),
          cashPaidAmount: cost.toString(),
          paymentMethodId: input.paymentMethodId!,
          description:
            `${UPKEEP_LABELS[input.kind]} القطعة ${item.item_code}` +
            (input.description ? ` · ${input.description}` : '') +
            (input.refType && input.refId ? ` · ${input.refType} #${input.refId}` : ''),
          createdBy: actor.id,
        },
      });
      expenseId = expense.id;
    }

    // 3) السجل — مربوط بالقطعة وبالمصروف
    const record = input.kind === 'MAINTENANCE'
      ? await tx.maintenanceRecord.create({
          data: {
            itemId: input.itemId,
            startDate,
            cost: cost.toString(),
            description: input.description?.trim() || null,
            expenseId,
            createdBy: actor.id,
          },
        })
      : await tx.cleaningRecord.create({
          data: {
            itemId: input.itemId,
            // ★ بيانات وصفية — لا أثر مالي
            rentalId: input.rentalId ?? null,
            sentDate: startDate,
            cost: cost.toString(),
            expenseId,
            createdBy: actor.id,
          },
        });

    // 4) سجل حالة القطعة — التتبّع من تاريخ القطعة
    await tx.itemStatusHistory.create({
      data: {
        itemId: input.itemId,
        fromStatus: item.status,
        toStatus: targetStatus,
        reason:
          `بدء ${UPKEEP_LABELS[input.kind]}` +
          (cost.gt(0) ? ` بتكلفة ${cost.toString()}` : ' بلا تكلفة') +
          (input.description ? ` · ${input.description}` : ''),
        refType: input.kind === 'MAINTENANCE' ? 'MaintenanceRecord' : 'CleaningRecord',
        refId: record.id,
        userId: actor.id,
      },
    });

    await tx.productItem.update({
      where: { id: input.itemId },
      data: {
        status: targetStatus,
        // الحقل المجمَّع للعرض السريع — التقرير يحسب من السجلات نفسها
        ...(input.kind === 'MAINTENANCE'
          ? { totalMaintenanceCost: { increment: cost.toString() } }
          : {}),
      },
    });

    await writeAudit(
      {
        userId: actor.id,
        action: 'upkeep.start',
        entityType: input.kind === 'MAINTENANCE' ? 'MaintenanceRecord' : 'CleaningRecord',
        entityId: record.id,
        after: {
          itemId: input.itemId,
          itemCode: item.item_code,
          kind: input.kind,
          cost: cost.toString(),
          expenseId,
          fromStatus: item.status,
          toStatus: targetStatus,
          rentalId: input.rentalId ?? null,
          // ★ تكلفة تشغيلية لا إيرادًا · وربط العقد وصفي بلا أثر مالي
          revenueImpact: '0',
        },
      },
      tx,
    );

    return {
      recordId: record.id,
      kind: input.kind,
      itemCode: item.item_code,
      cost: cost.toString(),
      expenseId,
      status: targetStatus,
    };
  });
}

// ============================ الإنهاء ============================

/** إنهاء الصيانة أو التنظيف وإعادة القطعة إلى الخدمة. */
export async function completeUpkeep(input: z.infer<typeof completeUpkeepSchema>) {
  const actor = await requirePermission('items.manage');
  const endDate = input.endDate ? toBusinessDate(input.endDate) : businessToday();

  return prisma.$transaction(async (tx) => {
    const record = input.kind === 'MAINTENANCE'
      ? await tx.maintenanceRecord.findUnique({ where: { id: input.recordId } })
      : await tx.cleaningRecord.findUnique({ where: { id: input.recordId } });
    if (!record) throw Errors.notFound('السجل');

    const startDate = 'startDate' in record ? record.startDate : record.sentDate;
    const existingEnd = 'endDate' in record ? record.endDate : record.receivedDate;
    if (existingEnd) throw Errors.rule('العملية منتهية بالفعل.');

    try {
      assertDates(startDate, endDate);
    } catch (e) {
      throw Errors.rule((e as UpkeepError).message);
    }

    const locked = await tx.$queryRaw<{ id: number; item_code: string; status: ItemStatus }[]>`
      SELECT id, item_code, status FROM product_items WHERE id = ${record.itemId} FOR UPDATE
    `;
    if (locked.length === 0) throw Errors.notFound('القطعة');
    const item = locked[0];

    const check = canTransition(item.status, input.toStatus, { manual: true });
    if (!check.allowed) {
      throw Errors.rule(
        check.reason ??
        `لا يمكن نقل القطعة من "${STATUS_LABELS[item.status]}" إلى "${STATUS_LABELS[input.toStatus]}".`,
      );
    }

    if (input.kind === 'MAINTENANCE') {
      await tx.maintenanceRecord.update({ where: { id: record.id }, data: { endDate } });
    } else {
      await tx.cleaningRecord.update({ where: { id: record.id }, data: { receivedDate: endDate } });
    }

    await tx.itemStatusHistory.create({
      data: {
        itemId: record.itemId,
        fromStatus: item.status,
        toStatus: input.toStatus,
        reason: `إنهاء ${UPKEEP_LABELS[input.kind]}`,
        refType: input.kind === 'MAINTENANCE' ? 'MaintenanceRecord' : 'CleaningRecord',
        refId: record.id,
        userId: actor.id,
      },
    });

    await tx.productItem.update({
      where: { id: record.itemId },
      data: { status: input.toStatus },
    });

    await writeAudit(
      {
        userId: actor.id,
        action: 'upkeep.complete',
        entityType: input.kind === 'MAINTENANCE' ? 'MaintenanceRecord' : 'CleaningRecord',
        entityId: record.id,
        before: { status: item.status },
        after: { status: input.toStatus, endDate: formatDate(endDate) },
      },
      tx,
    );

    return {
      recordId: record.id,
      itemCode: item.item_code,
      status: input.toStatus,
      cost: round2(record.cost.toString()).toString(),
    };
  });
}
