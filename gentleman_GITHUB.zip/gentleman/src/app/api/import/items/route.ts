import { route } from '@/lib/api';
import { importItems, importSchema } from '@/services/import.service';

export const POST = route({ schema: importSchema, handler: ({ input }) => importItems(input) });
