import { describe, it, expect } from 'vitest';
import {
  MOVEMENT_RULES, dashboardMovement, companyCashPosition, insuranceCashBalance,
  countCash, varianceLabel, requiredTransferAmount, assertFullTransfer,
  advanceState, assertRepaymentWithinBalance, settleSalary, monthlyReconciliation,
  type CashLine,
} from '../src/lib/cash/cash-movement';

const s = (v: { toString(): string }) => v.toString();

describe('تصنيف الحركات — ليس كل دخول إيرادًا ولا كل خروج مصروفًا', () => {
  it('التحصيلات إيراد ونقدية', () => {
    for (const t of ['RENTAL_COLLECTION', 'SALE_COLLECTION', 'LATE_FEE_COLLECTION'] as const) {
      expect(MOVEMENT_RULES[t].isRevenue).toBe(true);
      expect(MOVEMENT_RULES[t].affectsCompanyCash).toBe(true);
    }
  });

  it('خمس عمليات تخرج نقدًا وليست مصروفًا', () => {
    for (const t of ['EMPLOYEE_ADVANCE', 'CUSTOMER_REFUND', 'PRODUCT_PURCHASE',
                     'INSURANCE_REFUND', 'TREASURY_TRANSFER'] as const) {
      expect(MOVEMENT_RULES[t].isExpense).toBe(false);
      expect(MOVEMENT_RULES[t].isRevenue).toBe(false);
      expect(MOVEMENT_RULES[t].direction).toBe('OUT');
    }
  });

  it('المصروف والراتب والعمولة مصروفات', () => {
    for (const t of ['EXPENSE_PAYMENT', 'SALARY_PAYMENT', 'COMMISSION_PAYMENT'] as const) {
      expect(MOVEMENT_RULES[t].isExpense).toBe(true);
    }
  });

  it('التأمين لا يظهر في صندوق لوحة التحكم', () => {
    for (const t of ['INSURANCE_COLLECTION', 'INSURANCE_REFUND', 'INSURANCE_RETAINED'] as const) {
      expect(MOVEMENT_RULES[t].inDashboardMovement).toBe(false);
    }
  });

  it('الترحيل لا يظهر في صندوق اللوحة وليس مصروفًا ولا إيرادًا', () => {
    const r = MOVEMENT_RULES.TREASURY_TRANSFER;
    expect(r.inDashboardMovement).toBe(false);
    expect(r.isExpense).toBe(false);
    expect(r.isRevenue).toBe(false);
  });

  it('التأمين المُستبقى إيراد بلا حركة نقدية مادية', () => {
    const r = MOVEMENT_RULES.INSURANCE_RETAINED;
    expect(r.isRevenue).toBe(true);
    expect(r.direction).toBe('NONE');
    expect(r.affectsCompanyCash).toBe(true);
    expect(r.affectsInsuranceBalance).toBe(true);
  });
});

describe('صافي حركة النقدية اليوم (لوحة التحكم)', () => {
  const lines: CashLine[] = [
    { type: 'RENTAL_COLLECTION', amount: 300 },
    { type: 'SALE_COLLECTION', amount: 1300 },
    { type: 'EXPENSE_PAYMENT', amount: 100 },
    { type: 'INSURANCE_COLLECTION', amount: 1000 },   // مستبعد
    { type: 'INSURANCE_REFUND', amount: 200 },        // مستبعد
    { type: 'TREASURY_TRANSFER', amount: 1500 },      // مستبعد
  ];

  it('يحسب الداخل والخارج والصافي', () => {
    const r = dashboardMovement(lines);
    expect(s(r.inflow)).toBe('1600');
    expect(s(r.outflow)).toBe('100');
    expect(s(r.net)).toBe('1500');
  });

  it('لا يشمل التأمين ولا الترحيل', () => {
    const withoutInsurance = dashboardMovement(lines.filter(
      (l) => !l.type.startsWith('INSURANCE') && l.type !== 'TREASURY_TRANSFER',
    ));
    expect(s(withoutInsurance.net)).toBe(s(dashboardMovement(lines).net));
  });

  it('لا رصيد افتتاحي — قائمة فارغة تعطي صفرًا', () => {
    const r = dashboardMovement([]);
    expect(s(r.inflow)).toBe('0');
    expect(s(r.net)).toBe('0');
  });

  it('يرفض المبالغ السالبة', () => {
    expect(() => dashboardMovement([{ type: 'RENTAL_COLLECTION', amount: -1 }])).toThrow();
  });
});

describe('مركز نقدية الشركة — رقم مشتق', () => {
  it('يساوي حركة اليوم في التشغيل الطبيعي', () => {
    const lines: CashLine[] = [
      { type: 'RENTAL_COLLECTION', amount: 300 },
      { type: 'EXPENSE_PAYMENT', amount: 100 },
    ];
    expect(s(companyCashPosition(lines))).toBe('200');
    expect(s(dashboardMovement(lines).net)).toBe('200');
  });

  it('★ التأمين المُستبقى يزيد المركز بلا أي حركة نقدية', () => {
    const lines: CashLine[] = [{ type: 'INSURANCE_RETAINED', amount: 700 }];
    expect(s(companyCashPosition(lines))).toBe('700');
    expect(s(dashboardMovement(lines).net)).toBe('0');
  });

  it('تحصيل التأمين لا يزيد مركز الشركة', () => {
    expect(s(companyCashPosition([{ type: 'INSURANCE_COLLECTION', amount: 1000 }]))).toBe('0');
  });

  it('رد التأمين لا يخفض مركز الشركة', () => {
    expect(s(companyCashPosition([{ type: 'INSURANCE_REFUND', amount: 300 }]))).toBe('0');
  });

  it('الترحيل يخفض المركز', () => {
    const lines: CashLine[] = [
      { type: 'RENTAL_COLLECTION', amount: 500 },
      { type: 'TREASURY_TRANSFER', amount: 500 },
    ];
    expect(s(companyCashPosition(lines))).toBe('0');
  });

  it('السلفة والشراء والرد تخفض المركز بلا مصروف', () => {
    const lines: CashLine[] = [
      { type: 'RENTAL_COLLECTION', amount: 10000 },
      { type: 'EMPLOYEE_ADVANCE', amount: 500 },
      { type: 'PRODUCT_PURCHASE', amount: 6000 },
      { type: 'CUSTOMER_REFUND', amount: 300 },
    ];
    expect(s(companyCashPosition(lines))).toBe('3200');
  });
});

describe('رصيد نقدية التأمين — رصيد لا حركة', () => {
  it('يتراكم ولا يُصفَّر', () => {
    const b = insuranceCashBalance({
      openingBalance: 0, collected: 1000, refunded: 0, retained: 0,
    });
    expect(s(b)).toBe('1000');
  });

  it('يخفضه الرد والاستبقاء والمصادرة', () => {
    const b = insuranceCashBalance({
      openingBalance: 500, collected: 1000, refunded: 300, retained: 700, forfeited: 100,
    });
    expect(s(b)).toBe('400');
  });

  it('يرفض الرصيد السالب', () => {
    expect(() => insuranceCashBalance({
      openingBalance: 0, collected: 100, refunded: 500, retained: 0,
    })).toThrowError('INSURANCE_BALANCE_NEGATIVE');
  });
});

describe('الجرد المادي', () => {
  it('المتوقع = مركز الشركة + رصيد التأمين', () => {
    const r = countCash({ companyPosition: 200, insuranceBalance: 1000, actualCounted: 1200 });
    expect(s(r.expectedPhysical)).toBe('1200');
    expect(s(r.variance)).toBe('0');
    expect(r.status).toBe('MATCHED');
  });

  it('★ اليوم الثاني: خصم تأمين بلا حركة نقدية يتطابق', () => {
    // اليوم 1: تأمين 1,000 دخل الدرج · اليوم 2: خصم تلف 700 بلا حركة
    const position = companyCashPosition([{ type: 'INSURANCE_RETAINED', amount: 700 }]);
    const balance = insuranceCashBalance({
      openingBalance: 0, collected: 1000, refunded: 0, retained: 700,
    });
    const r = countCash({
      companyPosition: position, insuranceBalance: balance, actualCounted: 1000,
    });
    expect(s(r.companyPosition)).toBe('700');
    expect(s(r.insuranceBalance)).toBe('300');
    expect(s(r.expectedPhysical)).toBe('1000');
    expect(s(r.variance)).toBe('0');
  });

  it('★ التأمين المتراكم لا يُنتج زيادة وهمية في يوم بلا حركة', () => {
    // لا حركة إطلاقًا، والتأمين من أيام سابقة 1,000 ما زال بالدرج
    const r = countCash({ companyPosition: 0, insuranceBalance: 1000, actualCounted: 1000 });
    expect(s(r.variance)).toBe('0');
    expect(r.status).toBe('MATCHED');
  });

  it('العجز والزيادة يظهران بوضوح', () => {
    const shortage = countCash({ companyPosition: 5000, insuranceBalance: 0, actualCounted: 4950 });
    expect(s(shortage.variance)).toBe('-50');
    expect(shortage.status).toBe('SHORTAGE');
    expect(varianceLabel(shortage.variance)).toBe('عجز');

    const surplus = countCash({ companyPosition: 5000, insuranceBalance: 0, actualCounted: 5050 });
    expect(s(surplus.variance)).toBe('50');
    expect(surplus.status).toBe('SURPLUS');
    expect(varianceLabel(surplus.variance)).toBe('زيادة');
  });

  it('يرفض كاشًا فعليًا سالبًا', () => {
    expect(() => countCash({ companyPosition: 0, insuranceBalance: 0, actualCounted: -1 })).toThrow();
  });
});

describe('الترحيل الكامل إلزامي', () => {
  it('المطلوب = الفعلي − رصيد التأمين', () => {
    expect(s(requiredTransferAmount({ actualCounted: 4950, insuranceBalance: 1000 }))).toBe('3950');
  });

  it('لا يُرحَّل جنيه من التأمين', () => {
    const req = requiredTransferAmount({ actualCounted: 1000, insuranceBalance: 1000 });
    expect(s(req)).toBe('0');
  });

  it('يرفض الترحيل الجزئي', () => {
    expect(() => assertFullTransfer({
      amount: 3000, actualCounted: 4950, insuranceBalance: 1000,
    })).toThrowError(/الترحيل الكامل إلزامي/);
  });

  it('يرفض الترحيل الزائد', () => {
    expect(() => assertFullTransfer({
      amount: 4950, actualCounted: 4950, insuranceBalance: 1000,
    })).toThrow();
  });

  it('يقبل الترحيل الكامل', () => {
    expect(() => assertFullTransfer({
      amount: 3950, actualCounted: 4950, insuranceBalance: 1000,
    })).not.toThrow();
  });

  it('★ مثال العجز: متوقع 5,000 وفعلي 4,950 ⟹ يُرحَّل 4,950 والعجز يبقى', () => {
    const r = countCash({ companyPosition: 5000, insuranceBalance: 0, actualCounted: 4950 });
    const transfer = requiredTransferAmount({ actualCounted: 4950, insuranceBalance: 0 });
    expect(s(transfer)).toBe('4950');
    expect(s(r.variance)).toBe('-50');   // الترحيل لم يمس الفرق
  });
});

describe('سلف الموظفين', () => {
  it('الرصيد محسوب لا مُدخَل', () => {
    const st = advanceState({ amount: 500, repaidAmount: 200 });
    expect(s(st.balance)).toBe('300');
    expect(st.status).toBe('OPEN');
  });

  it('السداد الكامل يقفل السلفة', () => {
    expect(advanceState({ amount: 500, repaidAmount: 500 }).status).toBe('SETTLED');
  });

  it('يرفض مبلغًا غير صحيح', () => {
    expect(() => advanceState({ amount: 0, repaidAmount: 0 })).toThrow();
    expect(() => advanceState({ amount: -100, repaidAmount: 0 })).toThrow();
  });

  it('يرفض سدادًا أكبر من المبلغ', () => {
    expect(() => advanceState({ amount: 500, repaidAmount: 600 })).toThrow();
  });

  it('يرفض سدادًا يتجاوز الرصيد', () => {
    expect(() => assertRepaymentWithinBalance({
      amount: 500, repaidAmount: 300, newRepayment: 300,
    })).toThrowError(/يتجاوز رصيد السلفة/);
  });

  it('يقبل سدادًا داخل الرصيد', () => {
    expect(() => assertRepaymentWithinBalance({
      amount: 500, repaidAmount: 300, newRepayment: 200,
    })).not.toThrow();
  });
});

describe('الراتب مع خصم السلفة', () => {
  it('★ المصروف 6,000 والخروج النقدي 5,500', () => {
    const r = settleSalary({ grossSalary: 6000, advanceDeduction: 500 });
    expect(s(r.grossSalary)).toBe('6000');
    expect(s(r.salaryExpense)).toBe('6000');
    expect(s(r.cashPaidAmount)).toBe('5500');
    expect(s(r.netSalary)).toBe('5500');
    expect(s(r.advanceDeduction)).toBe('500');
  });

  it('السلفة لا تُحتسب مصروفًا مرة أخرى', () => {
    const r = settleSalary({ grossSalary: 6000, advanceDeduction: 500 });
    // المصروف = الإجمالي فقط، والفرق هو تسوية السلفة لا مصروف إضافي
    expect(s(r.salaryExpense)).toBe('6000');
    expect(s(r.salaryExpense.minus(r.cashPaidAmount))).toBe('500');
  });

  it('بلا خصم: المصروف = الخروج النقدي', () => {
    const r = settleSalary({ grossSalary: 6000 });
    expect(s(r.salaryExpense)).toBe(s(r.cashPaidAmount));
  });

  it('يرفض خصومات تتجاوز الراتب', () => {
    expect(() => settleSalary({ grossSalary: 1000, advanceDeduction: 1200 }))
      .toThrowError('DEDUCTIONS_EXCEED_SALARY');
  });

  it('يرفض راتبًا غير صحيح', () => {
    expect(() => settleSalary({ grossSalary: 0 })).toThrow();
  });
});

describe('المطابقة الشهرية', () => {
  const days = [
    { inflow: 1000, outflow: 200, variance: -50, transferred: 750, isClosed: true },
    { inflow: 500, outflow: 100, variance: 20, transferred: 420, isClosed: true },
    { inflow: 300, outflow: 0, variance: 0, transferred: 0, isClosed: false },
  ];

  it('يجمع الحركة والفروقات والترحيلات', () => {
    const r = monthlyReconciliation(days);
    expect(s(r.totalInflow)).toBe('1800');
    expect(s(r.totalOutflow)).toBe('300');
    expect(s(r.netMovement)).toBe('1500');
    expect(s(r.totalTransferred)).toBe('1170');
    expect(s(r.totalShortage)).toBe('50');
    expect(s(r.totalSurplus)).toBe('20');
    expect(r.closedDays).toBe(2);
    expect(r.openDays).toBe(1);
  });

  it('مجموع الفروقات = الزيادة − العجز', () => {
    const r = monthlyReconciliation(days);
    expect(s(r.totalVariance)).toBe('-30');
    expect(s(r.totalSurplus.minus(r.totalShortage))).toBe('-30');
  });

  it('المبالغ غير المرحَّلة تظهر', () => {
    const r = monthlyReconciliation(days);
    expect(s(r.notTransferred)).toBe('330');
  });
});
