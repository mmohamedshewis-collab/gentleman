import { describe, it, expect, vi, beforeEach } from 'vitest';
import { readFileSync, readdirSync, existsSync } from 'node:fs';
import { join } from 'node:path';
import {
  MAX_FAILED_ATTEMPTS, LOCK_MINUTES,
  isLocked, remainingLockMinutes, nextFailureState, successState,
} from '../src/lib/auth/lockout';

/** Q-1: قفل الحساب بعد 5 محاولات فاشلة لمدة 15 دقيقة. */

// ============================ الوحدة ============================

describe('منطق القفل', () => {
  const now = new Date('2026-08-18T10:00:00Z');

  it('الحد 5 محاولات والمدة 15 دقيقة', () => {
    expect(MAX_FAILED_ATTEMPTS).toBe(5);
    expect(LOCK_MINUTES).toBe(15);
  });

  it('★ 1 — المحاولة الفاشلة تزيد العدّاد', () => {
    expect(nextFailureState(0, now).failedAttempts).toBe(1);
    expect(nextFailureState(1, now).failedAttempts).toBe(2);
    expect(nextFailureState(3, now).failedAttempts).toBe(4);
  });

  it('★ 1 — ما دون الحد لا يقفل', () => {
    for (let i = 0; i < MAX_FAILED_ATTEMPTS - 1; i++) {
      expect(nextFailureState(i, now).lockedUntil, `بعد ${i + 1} محاولات`).toBeNull();
    }
  });

  it('★ 2 — المحاولة الخامسة تقفل الحساب 15 دقيقة', () => {
    const s = nextFailureState(4, now);
    expect(s.failedAttempts).toBe(5);
    expect(s.lockedUntil).not.toBeNull();
    expect(s.lockedUntil!.getTime() - now.getTime()).toBe(15 * 60_000);
  });

  it('★ 3 — الحساب مقفل أثناء المدة', () => {
    const until = new Date(now.getTime() + 15 * 60_000);
    expect(isLocked(until, now)).toBe(true);
    expect(isLocked(until, new Date(now.getTime() + 14 * 60_000))).toBe(true);
  });

  it('★ 4 — انتهاء المدة يفك القفل', () => {
    const until = new Date(now.getTime() + 15 * 60_000);
    expect(isLocked(until, new Date(now.getTime() + 15 * 60_000 + 1))).toBe(false);
    expect(isLocked(until, new Date(now.getTime() + 60 * 60_000))).toBe(false);
  });

  it('غير المقفل يعطي false', () => {
    expect(isLocked(null, now)).toBe(false);
  });

  it('الدقائق المتبقية لا تقل عن واحدة ولا تكون سالبة', () => {
    const until = new Date(now.getTime() + 15 * 60_000);
    expect(remainingLockMinutes(until, now)).toBe(15);
    expect(remainingLockMinutes(until, new Date(now.getTime() + 14.5 * 60_000))).toBe(1);
    expect(remainingLockMinutes(until, new Date(now.getTime() + 20 * 60_000))).toBe(0);
  });

  it('★ 5 — النجاح يصفّر العدّاد والقفل', () => {
    expect(successState()).toEqual({ failedAttempts: 0, lockedUntil: null });
  });
});

// ============================ الخدمة ============================

const H = vi.hoisted(() => ({ auditSpy: vi.fn(), createSessionSpy: vi.fn() }));
const { auditSpy, createSessionSpy } = H;

let userRow: Record<string, unknown> | null;
let lockedRow: { failed_attempts: number; locked_until: Date | null }[];
let passwordOk: boolean;
const updates: Record<string, unknown>[] = [];

const tx = {
  $queryRaw: vi.fn(async () => lockedRow),
  user: { update: vi.fn(async (a: any) => { updates.push(a.data); return a.data; }) },
};

vi.mock('@/lib/db', () => ({
  prisma: {
    $transaction: (fn: any) => fn(tx),
    user: {
      findUnique: vi.fn(async () => userRow),
      update: vi.fn(async (a: any) => { updates.push(a.data); return a.data; }),
    },
  },
}));

vi.mock('@/lib/audit', () => ({ writeAudit: H.auditSpy, redact: (x: unknown) => x }));
vi.mock('@/lib/auth/session', () => ({ createSession: H.createSessionSpy }));
vi.mock('@/lib/auth/password', () => ({ verifyPassword: async () => passwordOk }));

beforeEach(() => {
  auditSpy.mockClear();
  createSessionSpy.mockClear();
  tx.$queryRaw.mockClear();
  tx.user.update.mockClear();
  updates.length = 0;
  passwordOk = true;
  lockedRow = [{ failed_attempts: 0, locked_until: null }];
  userRow = {
    id: 1, username: 'admin', passwordHash: 'h', fullName: 'المدير',
    isActive: true, failedAttempts: 0, lockedUntil: null,
    role: { nameAr: 'مدير' },
  };
});

describe('★ 1 — المحاولة الفاشلة تزيد العدّاد', () => {
  it('تزيد العدّاد وتسجّل المحاولة', async () => {
    passwordOk = false;
    const { login } = await import('@/services/auth.service');
    await expect(login({ username: 'admin', password: 'خطأ' }))
      .rejects.toMatchObject({ code: 'AUTH_INVALID' });

    expect(updates[0]).toMatchObject({ failedAttempts: 1, lockedUntil: null });
    expect(auditSpy.mock.calls[0][0]).toMatchObject({ action: 'auth.login_failed' });
  });

  it('★ التحديث ذرّي — يقفل الصف قبل الزيادة', async () => {
    passwordOk = false;
    const { login } = await import('@/services/auth.service');
    await expect(login({ username: 'admin', password: 'خطأ' })).rejects.toThrow();

    const q = (tx.$queryRaw.mock.calls[0][0] as TemplateStringsArray).join(' ');
    expect(q).toContain('FOR UPDATE');
    expect(q).toContain('users');
  });
});

describe('★ 2 — خمس محاولات تقفل الحساب', () => {
  it('المحاولة الخامسة تقفل 15 دقيقة وتُسجَّل', async () => {
    passwordOk = false;
    lockedRow = [{ failed_attempts: 4, locked_until: null }];
    const { login } = await import('@/services/auth.service');
    await expect(login({ username: 'admin', password: 'خطأ' })).rejects.toThrow();

    expect(updates[0].failedAttempts).toBe(5);
    expect(updates[0].lockedUntil).toBeInstanceOf(Date);
    expect(auditSpy.mock.calls[0][0]).toMatchObject({ action: 'auth.account_locked' });
  });
});

describe('★ 3 — المحاولة أثناء القفل مرفوضة', () => {
  it('★ ترفض حتى بكلمة المرور الصحيحة', async () => {
    passwordOk = true;
    userRow = { ...userRow, lockedUntil: new Date(Date.now() + 10 * 60_000), failedAttempts: 5 };
    const { login } = await import('@/services/auth.service');

    await expect(login({ username: 'admin', password: 'صحيحة' }))
      .rejects.toMatchObject({ code: 'AUTH_LOCKED' });

    // ★ لا جلسة تُنشأ للحساب المقفل
    expect(createSessionSpy).not.toHaveBeenCalled();
  });

  it('★ الحساب المقفل لا يزيد عدّاده أكثر', async () => {
    passwordOk = false;
    lockedRow = [{ failed_attempts: 5, locked_until: new Date(Date.now() + 10 * 60_000) }];
    const { login } = await import('@/services/auth.service');
    await expect(login({ username: 'admin', password: 'خطأ' })).rejects.toThrow();

    expect(updates).toHaveLength(0);   // لا تحديث — القفل قائم
  });

  it('رسالة القفل تذكر المدة المتبقية', async () => {
    userRow = { ...userRow, lockedUntil: new Date(Date.now() + 10 * 60_000) };
    const { login } = await import('@/services/auth.service');
    await expect(login({ username: 'admin', password: 'صحيحة' }))
      .rejects.toMatchObject({ message: expect.stringContaining('دقيقة') });
  });
});

describe('★ 4 — انتهاء المدة يسمح بالدخول', () => {
  it('القفل المنتهي لا يمنع', async () => {
    passwordOk = true;
    userRow = { ...userRow, lockedUntil: new Date(Date.now() - 60_000), failedAttempts: 5 };
    const { login } = await import('@/services/auth.service');

    const r = await login({ username: 'admin', password: 'صحيحة' });
    expect(r.id).toBe(1);
    expect(createSessionSpy).toHaveBeenCalledOnce();
  });
});

describe('★ 5 — الدخول الناجح يصفّر كل شيء', () => {
  it('يصفّر العدّاد والقفل معًا', async () => {
    passwordOk = true;
    userRow = { ...userRow, failedAttempts: 3, lockedUntil: null };
    const { login } = await import('@/services/auth.service');
    await login({ username: 'admin', password: 'صحيحة' });

    expect(updates[0]).toMatchObject({ failedAttempts: 0, lockedUntil: null });
    expect(updates[0]).toHaveProperty('lastLoginAt');
  });

  it('يسجّل الدخول الناجح', async () => {
    const { login } = await import('@/services/auth.service');
    await login({ username: 'admin', password: 'صحيحة' });
    expect(auditSpy.mock.calls[0][0]).toMatchObject({ action: 'auth.login' });
  });
});

describe('★ 6 — المحاولات المتزامنة لا تتجاوز الحد', () => {
  it('★ القفل والقراءة داخل معاملة واحدة', () => {
    const src = readFileSync('src/services/auth.service.ts', 'utf8');
    const block = src.slice(src.indexOf('if (!okPw)'), src.indexOf('throw Errors.invalidCredentials();', src.indexOf('if (!okPw)')));
    expect(block).toContain('$transaction');
    expect(block).toContain('FOR UPDATE');
    // القراءة داخل المعاملة لا من الكائن المقروء مسبقًا
    expect(block).toContain('locked[0].failed_attempts');
  });

  it('★ العدّاد يُقرأ داخل القفل لا من قراءة سابقة', async () => {
    passwordOk = false;
    // القراءة الأولى أظهرت 0، لكن جلسة أخرى رفعته إلى 4
    userRow = { ...userRow, failedAttempts: 0 };
    lockedRow = [{ failed_attempts: 4, locked_until: null }];
    const { login } = await import('@/services/auth.service');
    await expect(login({ username: 'admin', password: 'خطأ' })).rejects.toThrow();

    // يعتمد القيمة المقفولة 4 ⟹ يقفل، لا 0 ⟹ 1
    expect(updates[0].failedAttempts).toBe(5);
    expect(updates[0].lockedUntil).toBeInstanceOf(Date);
  });
});

describe('★ 7 — لا كشف لوجود المستخدم', () => {
  it('★ المستخدم غير الموجود وكلمة المرور الخاطئة: نفس الرمز والرسالة', async () => {
    const { login } = await import('@/services/auth.service');

    userRow = null;
    const e1 = await login({ username: 'لا-يوجد', password: 'x' }).catch((e) => e);

    userRow = {
      id: 1, username: 'admin', passwordHash: 'h', fullName: 'المدير',
      isActive: true, failedAttempts: 0, lockedUntil: null, role: { nameAr: 'مدير' },
    };
    passwordOk = false;
    const e2 = await login({ username: 'admin', password: 'خطأ' }).catch((e) => e);

    expect(e1.code).toBe(e2.code);
    expect(e1.message).toBe(e2.message);
    expect(e1.status).toBe(e2.status);
  });

  it('★ رسالة القفل لا تظهر إلا بعد كلمة مرور صحيحة', () => {
    const src = readFileSync('src/services/auth.service.ts', 'utf8');
    const pwIdx = src.indexOf('const okPw = await verifyPassword');
    const lockIdx = src.indexOf('Errors.accountLocked');
    // فحص القفل يقع بعد التحقق من كلمة المرور
    expect(lockIdx).toBeGreaterThan(pwIdx);
  });

  it('★ المستخدم غير الموجود لا يُنشئ سجل تدقيق يكشفه', async () => {
    userRow = null;
    const { login } = await import('@/services/auth.service');
    await expect(login({ username: 'لا-يوجد', password: 'x' })).rejects.toThrow();
    expect(auditSpy).not.toHaveBeenCalled();
  });
});

describe('★ 8 — لا نظام مصادقة جديد ولا صلاحيات', () => {
  it('★ لا صلاحية جديدة', async () => {
    const { PERMISSIONS } = await import('../src/lib/auth/permissions');
    expect(PERMISSIONS.length).toBe(56);
    expect(PERMISSIONS.some((p) => p.code.includes('lock'))).toBe(false);
  });

  it('★ التخزين في جدول users القائم — لا جدول جديد', () => {
    const schema = readFileSync('prisma/schema.prisma', 'utf8');
    expect(schema).toContain('failedAttempts');
    expect(schema).toContain('lockedUntil');
    expect(schema).not.toContain('model LoginAttempt');
    expect(schema).not.toContain('model RateLimit');
  });

  it('★ لا حدّ في الذاكرة', () => {
    const src = readFileSync('src/lib/auth/lockout.ts', 'utf8');
    expect(src).not.toContain('new Map');
    expect(src).not.toContain('setTimeout');
    expect(src).toContain('لا في الذاكرة');
  });

  it('★ الجلسة وكلمة المرور بلا تغيير', () => {
    const pw = readFileSync('src/lib/auth/password.ts', 'utf8');
    expect(pw).toContain('bcrypt');
    const sess = readFileSync('src/lib/auth/session.ts', 'utf8');
    expect(sess).toContain('httpOnly: true');
    expect(sess).toContain("secure: process.env.NODE_ENV === 'production'");
  });

  it('★ الحساب المعطّل ما زال يُرفض', async () => {
    passwordOk = true;
    userRow = { ...userRow, isActive: false };
    const { login } = await import('@/services/auth.service');
    await expect(login({ username: 'admin', password: 'صحيحة' }))
      .rejects.toMatchObject({ code: 'AUTH_DISABLED' });
  });
});

// ==================== 7 · 9 · 10 ====================

describe('★ 7 — الفشل بعد نجاح يبدأ من الصفر', () => {
  it('★ العدّاد يبدأ من 1 لا من قيمته قبل النجاح', async () => {
    passwordOk = true;
    userRow = { ...userRow, failedAttempts: 4, lockedUntil: null };
    const { login } = await import('@/services/auth.service');

    // نجاح ⟹ تصفير
    await login({ username: 'admin', password: 'صحيحة' });
    expect(updates[0]).toMatchObject({ failedAttempts: 0, lockedUntil: null });

    // ثم فشل ⟹ يبدأ من 1 لا من 5
    updates.length = 0;
    passwordOk = false;
    lockedRow = [{ failed_attempts: 0, locked_until: null }];
    await expect(login({ username: 'admin', password: 'خطأ' })).rejects.toThrow();

    expect(updates[0]).toMatchObject({ failedAttempts: 1, lockedUntil: null });
  });
});

describe('★ 9 — المستخدمون القائمون يظلون صالحين', () => {
  it('★ مستخدم بلا قيم قفل (NULL/صفر) يدخل طبيعيًا', async () => {
    passwordOk = true;
    // مستخدم أُنشئ قبل الترقية: العدّاد صفر بالقيمة الافتراضية والقفل NULL
    userRow = {
      id: 7, username: 'قديم', passwordHash: 'h', fullName: 'مستخدم قديم',
      isActive: true, failedAttempts: 0, lockedUntil: null, role: { nameAr: 'مدير' },
    };
    const { login } = await import('@/services/auth.service');
    const r = await login({ username: 'قديم', password: 'صحيحة' });
    expect(r.id).toBe(7);
    expect(createSessionSpy).toHaveBeenCalledOnce();
  });

  it('★ الترحيل يعطي قيمًا افتراضية آمنة', () => {
    const mig = readFileSync(
      'prisma/migrations/20260818_add_login_lockout/migration.sql', 'utf8');
    expect(mig).toContain('DEFAULT 0');          // العدّاد يبدأ صفرًا
    expect(mig).toContain('locked_until timestamptz'); // القفل NULL افتراضيًا
    expect(mig).toContain('IF NOT EXISTS');       // آمن لإعادة التشغيل
  });
});

describe('★ 10 — لا تسريب لمعلومات حساسة', () => {
  it('★ العدّاد والقفل لا يظهران في مخرجات الدخول', async () => {
    passwordOk = true;
    userRow = { ...userRow, failedAttempts: 3 };
    const { login } = await import('@/services/auth.service');
    const r = await login({ username: 'admin', password: 'صحيحة' });

    expect(Object.keys(r)).toEqual(['id', 'fullName', 'role']);
    expect(r).not.toHaveProperty('failedAttempts');
    expect(r).not.toHaveProperty('lockedUntil');
    expect(r).not.toHaveProperty('passwordHash');
  });

  it('★ العدّاد لا يُعاد في أي مسار API', () => {
    const walk = (dir: string): string[] =>
      existsSync(dir)
        ? readdirSync(dir, { withFileTypes: true }).flatMap((e) => {
            const p = join(dir, e.name);
            return e.isDirectory() ? walk(p) : [p];
          })
        : [];
    const routes = walk('src/app/api').filter((f) => f.endsWith('route.ts'));
    const leaking = routes.filter((f) => {
      const s = readFileSync(f, 'utf8');
      return s.includes('failedAttempts') || s.includes('lockedUntil');
    });
    expect(leaking).toEqual([]);
  });

  it('★ خدمة المستخدمين لا تُعيد العدّاد ولا التجزئة', () => {
    const src = readFileSync('src/services/user.service.ts', 'utf8');
    expect(src).not.toContain('failedAttempts');
    expect(src).not.toContain('lockedUntil');
    // التجزئة تُكتب ولا تُقرأ للعرض
    const selects = src.match(/select:\s*\{[^}]*\}/g) ?? [];
    for (const sel of selects) expect(sel).not.toContain('passwordHash');
  });

  it('★ كلمة المرور لا تُسجَّل في سجل التدقيق', () => {
    const src = readFileSync('src/services/auth.service.ts', 'utf8');
    const auditBlocks = src.match(/writeAudit\([\s\S]*?\)/g) ?? [];
    for (const b of auditBlocks) {
      expect(b).not.toContain('password');
      expect(b).not.toContain('passwordHash');
    }
  });

  it('★ سجل القفل يحمل الحالة لا بيانات الاعتماد', async () => {
    passwordOk = false;
    lockedRow = [{ failed_attempts: 4, locked_until: null }];
    const { login } = await import('@/services/auth.service');
    await expect(login({ username: 'admin', password: 'سرّي' })).rejects.toThrow();

    const audit = auditSpy.mock.calls[0][0];
    expect(JSON.stringify(audit)).not.toContain('سرّي');
    expect(audit.after).toHaveProperty('failedAttempts');
  });
});

// ==================== Q-2: لا مسار حذف ====================

describe('★ Q-2 — لا مسار حذف للصيانة والتنظيف (حارس انحدار)', () => {
  const walk = (dir: string): string[] =>
    existsSync(dir)
      ? readdirSync(dir, { withFileTypes: true }).flatMap((e) => {
          const p = join(dir, e.name);
          return e.isDirectory() ? walk(p) : [p];
        })
      : [];
  const files = walk('src').filter((f) => f.endsWith('.ts') || f.endsWith('.tsx'));

  it('★ لا حذف في طبقة الخدمة', () => {
    const offenders = files.filter((f) => {
      const s = readFileSync(f, 'utf8');
      return /(maintenanceRecord|cleaningRecord)\.(delete|deleteMany)/.test(s);
    });
    expect(offenders).toEqual([]);
  });

  it('★ لا مسار DELETE في API', () => {
    const routes = walk('src/app/api').filter((f) => f.endsWith('route.ts'));
    const offenders = routes.filter((f) => {
      const s = readFileSync(f, 'utf8');
      return /export\s+(async\s+)?function\s+DELETE|export\s+const\s+DELETE/.test(s);
    });
    expect(offenders).toEqual([]);
  });

  it('★ لا زر حذف في واجهة الصيانة', () => {
    const panel = readFileSync('src/components/UpkeepPanel.tsx', 'utf8');
    expect(panel).not.toContain('حذف');
    expect(panel).not.toContain('/api/upkeep/delete');
  });

  it('★ لا Trigger ولا Migration أُضيفا (Q-2 = الخيار أ)', () => {
    const sql = readFileSync('prisma/sql/01_constraints.sql', 'utf8');
    expect(sql).not.toContain('ON maintenance_records');
    expect(sql).not.toContain('ON cleaning_records');
  });
});

// ==================== Q-3: التأجيل ====================

describe('★ Q-3 — ربط التنظيف بالعقد (اعتُمد في M13-1)', () => {
  it('★ الربط عبر rentalId لا contractId — والاسم يطابق تسمية المشروع', () => {
    const schema = readFileSync('prisma/schema.prisma', 'utf8');
    const model = schema.slice(
      schema.indexOf('model CleaningRecord'),
      schema.indexOf('}', schema.indexOf('model CleaningRecord')));
    // Q-3 كان مؤجَّلًا في M12 ثم اعتُمد في M13-1 بحقل rentalId
    expect(model).not.toContain('contractId');
    expect(model).toContain('rentalId     Int?');
  });

  it('★ التتبّع القائم كافٍ: وصف المصروف وسجل الحالة', () => {
    const src = readFileSync('src/services/upkeep.service.ts', 'utf8');
    expect(src).toContain('itemStatusHistory.create');
    expect(src).toContain('refType');
    expect(src).toContain('input.refType && input.refId');
  });
});

describe('★ 10 — المستخدمون لا يؤثر أحدهم على الآخر', () => {
  it('★ قفل حساب لا يقفل غيره', async () => {
    const { login } = await import('@/services/auth.service');

    // الحساب الأول مقفل
    passwordOk = true;
    userRow = {
      id: 1, username: 'admin', passwordHash: 'h', fullName: 'المدير', isActive: true,
      failedAttempts: 5, lockedUntil: new Date(Date.now() + 10 * 60_000), role: { nameAr: 'مدير' },
    };
    await expect(login({ username: 'admin', password: 'صحيحة' }))
      .rejects.toMatchObject({ code: 'AUTH_LOCKED' });

    // الثاني يدخل طبيعيًا
    userRow = {
      id: 2, username: 'user2', passwordHash: 'h', fullName: 'موظف', isActive: true,
      failedAttempts: 0, lockedUntil: null, role: { nameAr: 'موظف' },
    };
    const r = await login({ username: 'user2', password: 'صحيحة' });
    expect(r.id).toBe(2);
    expect(createSessionSpy).toHaveBeenCalledOnce();
  });

  it('★ القفل يُقرأ من صف المستخدم نفسه', () => {
    const src = readFileSync('src/services/auth.service.ts', 'utf8');
    expect(src).toContain('WHERE id = ${user.id} FOR UPDATE');
    expect(src).toContain('isLocked(user.lockedUntil, now)');
  });
});

describe('★ لا مسار دخول بديل يتجاوز القفل', () => {
  it('★ createSession لا تُستدعى إلا من login', () => {
    const walk = (dir: string): string[] =>
      existsSync(dir)
        ? readdirSync(dir, { withFileTypes: true }).flatMap((e) => {
            const p = join(dir, e.name);
            return e.isDirectory() ? walk(p) : [p];
          })
        : [];
    const callers = walk('src')
      .filter((f) => (f.endsWith('.ts') || f.endsWith('.tsx')) && !f.includes('session.ts'))
      .filter((f) => readFileSync(f, 'utf8').includes('createSession('));
    expect(callers).toEqual(['src/services/auth.service.ts']);
  });
});
