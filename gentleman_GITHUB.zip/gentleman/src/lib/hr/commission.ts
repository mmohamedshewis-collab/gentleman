import { Decimal } from 'decimal.js';
import { round2, add, sub, pct } from '@/lib/money';

/**
 * العمولة — خمس طبقات منفصلة، بلا التزام (Commission Payable).
 *
 *  1. Performance  رقم تحليلي لأي فترة — لا يُخزَّن ولا يدخل الربح
 *  2. Earned       دالة على العملية = صافيها × نسبة مجمَّدة عليها · صفر إن كانت ملغاة
 *  3. Paid         سجل يُنشأ عند الصرف فقط
 *  4. Expense      سجل مصروف واحد مربوط بسجل الصرف — الطريق الوحيد للربح
 *  5. Cash Outflow هو نفسه سجل المصروف لا سجل ثانٍ
 */

export type OperationKind = 'RENTAL' | 'SALE';

export interface EarningOperation {
  kind: OperationKind;
  netAmount: Decimal.Value;
  /** النسبة المجمَّدة على العملية وقت إنشائها — لا تُقرأ من ملف الموظف */
  ratePct: Decimal.Value | null;
  /** ملغاة ⟹ Earned = 0 بلا أي قيد عكسي */
  isVoided: boolean;
}

/**
 * عمولة عملية واحدة.
 * ملغاة أو بلا نسبة مجمَّدة ⟹ صفر.
 */
export function earnedForOperation(op: EarningOperation): Decimal {
  if (op.isVoided) return round2(0);
  if (op.ratePct === null || op.ratePct === undefined) return round2(0);
  const net = round2(op.netAmount);
  if (net.lte(0)) return round2(0);
  return pct(net, op.ratePct);
}

export interface EarnedBreakdown {
  rentalBase: Decimal;
  salesBase: Decimal;
  base: Decimal;
  rentalCommission: Decimal;
  salesCommission: Decimal;
  total: Decimal;
}

/** إجمالي العمولة المستحقة عن مجموعة عمليات — يستبعد الملغى تلقائيًا. */
export function earnedForPeriod(ops: EarningOperation[]): EarnedBreakdown {
  let rentalBase = new Decimal(0);
  let salesBase = new Decimal(0);
  let rentalCommission = new Decimal(0);
  let salesCommission = new Decimal(0);

  for (const op of ops) {
    if (op.isVoided) continue;            // ★ D1: الملغى خارج الوعاء
    const net = round2(op.netAmount);
    const earned = earnedForOperation(op);
    if (op.kind === 'RENTAL') {
      rentalBase = rentalBase.plus(net);
      rentalCommission = rentalCommission.plus(earned);
    } else {
      salesBase = salesBase.plus(net);
      salesCommission = salesCommission.plus(earned);
    }
  }

  return {
    rentalBase: round2(rentalBase),
    salesBase: round2(salesBase),
    base: add(rentalBase, salesBase),
    rentalCommission: round2(rentalCommission),
    salesCommission: round2(salesCommission),
    total: add(rentalCommission, salesCommission),
  };
}

// ======================= آلية الفرق (Variance) =======================

export interface PeriodVariance {
  periodMonth: string;
  earned: Decimal;
  paid: Decimal;
  variance: Decimal;
}

/**
 * فرق فترة سابقة = المستحق الآن − المصروف فعلًا.
 * سالب ⟹ صُرف أكثر مما استُحق (إلغاء عملية بعد الصرف).
 * لا يُعدَّل سجل الفترة المصروفة ولا يُحذف.
 */
export function periodVariance(input: {
  periodMonth: string;
  earned: Decimal.Value;
  paid: Decimal.Value;
}): PeriodVariance {
  const earned = round2(input.earned);
  const paid = round2(input.paid);
  return {
    periodMonth: input.periodMonth,
    earned,
    paid,
    variance: sub(earned, paid),
  };
}

export interface PayoutComputation {
  currentEarned: Decimal;
  priorVariance: Decimal;
  /** المستحق قبل تطبيق الحد الأدنى */
  rawPayout: Decimal;
  /** المبلغ المصروف فعلًا — لا يقل عن صفر */
  payable: Decimal;
  /** الرصيد السالب المرحَّل للفترة التالية */
  carryForward: Decimal;
}

/**
 * مبلغ الصرف = عمولة الفترة الحالية + مجموع فروق الفترات السابقة.
 * D8: لا صرف سالب — الحد الأدنى صفر والباقي يُرحَّل، ولا يُخصم من الراتب.
 */
export function computePayout(input: {
  currentEarned: Decimal.Value;
  priorVariances: Decimal.Value[];
}): PayoutComputation {
  const currentEarned = round2(input.currentEarned);
  const priorVariance = input.priorVariances.length
    ? round2(input.priorVariances.reduce<Decimal>((a, b) => a.plus(round2(b)), new Decimal(0)))
    : round2(0);

  const rawPayout = add(currentEarned, priorVariance);
  const payable = rawPayout.lt(0) ? round2(0) : rawPayout;
  const carryForward = rawPayout.lt(0) ? rawPayout : round2(0);

  return { currentEarned, priorVariance, rawPayout, payable, carryForward };
}

/** لا يُصرف مبلغ صفري: لا مصروف بلا مال يخرج. */
export function assertPayable(amount: Decimal.Value): void {
  if (round2(amount).lte(0)) {
    throw new Error('لا توجد عمولة مستحقة للصرف في هذه الفترة.');
  }
}

/** YYYY-MM */
export function periodMonthOf(date: Date): string {
  return `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, '0')}`;
}

export function previousMonths(periodMonth: string, count: number): string[] {
  const [y, m] = periodMonth.split('-').map(Number);
  const out: string[] = [];
  for (let i = 1; i <= count; i++) {
    const d = new Date(Date.UTC(y, m - 1 - i, 1));
    out.push(`${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}`);
  }
  return out;
}

/** حدود الشهر بصيغة نصية للاستعلام. */
export function monthBounds(periodMonth: string): { from: string; to: string } {
  const [y, m] = periodMonth.split('-').map(Number);
  const last = new Date(Date.UTC(y, m, 0)).getUTCDate();
  return {
    from: `${periodMonth}-01`,
    to: `${periodMonth}-${String(last).padStart(2, '0')}`,
  };
}
