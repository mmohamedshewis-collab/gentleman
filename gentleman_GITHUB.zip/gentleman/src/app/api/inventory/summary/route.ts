import { route } from '@/lib/api';
import { inventorySummary } from '@/services/inventory.service';

export const GET = route({ handler: () => inventorySummary() });
