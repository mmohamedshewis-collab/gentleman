import { z } from 'zod';
import type { Prisma } from '@prisma/client';
import { prisma } from '@/lib/db';
import { Errors } from '@/lib/errors';
import { writeAudit } from '@/lib/audit';
import { requirePermission, can } from '@/lib/auth/rbac';
import { businessToday, toBusinessDate, periodBounds } from '@/lib/date';
import { round2, VAT_DISABLED, type VatContext } from '@/lib/money';
import { getBoolSetting, getNumberSetting } from '@/lib/settings';
import { normalizeBarcode } from '@/lib/inventory/codes';
import { STATUS_LABELS, canBeSold, type ItemStatus } from '@/lib/inventory/item-state';
import {
  computeSaleTotals, assertFullPayment, buildInvoiceNo, exceedsDiscountLimit,
  SalePricingError, type SaleLineInput,
} from '@/lib/sales/sale-pricing';
import { canVoidSale, assertRestorable } from '@/lib/sales/sale-state';

const money = z.coerce.number().nonnegative('القيمة لا يمكن أن تكون سالبة');

export const saleLineSchema = z.object({
  itemId: z.number().int().positive(),
  unitPrice: money,
  discount: money.default(0),
});

export const createSaleSchema = z.object({
  customerId: z.number().int().positive().nullable().optional(),
  employeeId: z.number().int().positive().nullable().optional(),
  saleDate: z.string().optional(),
  items: z.array(saleLineSchema).min(1, 'أضف قطعة واحدة على الأقل'),
  paidAmount: money,
  paymentMethodId: z.number().int().positive(),
  notes: z.string().max(500).optional(),
});

export const voidSaleSchema = z.object({
  saleId: z.number().int().positive(),
  reason: z.string().trim().min(3, 'سبب الإلغاء مطلوب'),
});

export const saleQuerySchema = z.object({
  from: z.string().optional(),
  to: z.string().optional(),
  customerId: z.coerce.number().int().optional(),
  includeVoided: z.coerce.boolean().default(false),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(10).max(200).default(50),
});

// ======================= المسح للبيع =======================

export async function scanForSale(barcode: string) {
  await requirePermission('sales.create');
  const code = normalizeBarcode(barcode);

  const item = await prisma.productItem.findFirst({
    where: { OR: [{ barcode: code }, { itemCode: code }] },
    include: { product: { select: { nameAr: true, size: true, color: true, salePrice: true } } },
  });
  if (!item) throw Errors.notFound(`قطعة بالباركود ${code}`);

  const status = item.status as ItemStatus;
  const sellable = canBeSold(status);

  return {
    itemId: item.id,
    itemCode: item.itemCode,
    barcode: item.barcode,
    productName: item.product.nameAr,
    size: item.product.size,
    color: item.product.color,
    status,
    statusLabel: STATUS_LABELS[status],
    suggestedPrice: (item.salePrice ?? item.product.salePrice).toString(),
    purchaseCost: item.purchaseCost.toString(),
    canBeSold: sellable,
    blockedReason: sellable ? null : `لا يمكن بيع قطعة حالتها "${STATUS_LABELS[status]}".`,
  };
}

// ======================= إنشاء الفاتورة =======================

export async function createSale(input: z.infer<typeof createSaleSchema>) {
  const actor = await requirePermission('sales.create');

  const vatEnabled = await getBoolSetting('vat.enabled');
  const vat: VatContext = vatEnabled
    ? { enabled: true, rate: (await getNumberSetting('vat.rate')).toString() }
    : VAT_DISABLED;
  const maxDiscountPct = await getNumberSetting('discount.staff_max_percent');

  const saleDate = input.saleDate ? toBusinessDate(input.saleDate) : businessToday();

  return prisma.$transaction(async (tx) => {
    // 1) العميل — اختياري، والافتراضي هو العميل النقدي
    let customerId = input.customerId ?? null;
    if (!customerId) {
      const walkIn = await tx.customer.findUnique({ where: { code: 'WALKIN' }, select: { id: true } });
      if (!walkIn) throw Errors.notFound('العميل النقدي');
      customerId = walkIn.id;
    } else {
      const c = await tx.customer.findUnique({ where: { id: customerId }, select: { id: true, isActive: true } });
      if (!c) throw Errors.notFound('العميل');
      if (!c.isActive) throw Errors.rule('العميل معطّل ولا يمكن البيع له.');
    }

    // 2) قفل القطع ثم فحص حالتها
    const itemIds = input.items.map((i) => i.itemId);
    if (new Set(itemIds).size !== itemIds.length) {
      throw Errors.rule('لا يمكن تكرار نفس القطعة داخل الفاتورة.');
    }

    const locked = await tx.$queryRaw<
      { id: number; item_code: string; status: ItemStatus; purchase_cost: string }[]
    >`
      SELECT id, item_code, status, purchase_cost
        FROM product_items
       WHERE id = ANY(${itemIds}::int[])
       ORDER BY id
       FOR UPDATE
    `;
    if (locked.length !== itemIds.length) throw Errors.notFound('إحدى القطع');

    for (const l of locked) {
      if (!canBeSold(l.status)) {
        throw Errors.rule(
          `لا يمكن بيع القطعة ${l.item_code} لأن حالتها "${STATUS_LABELS[l.status]}".`,
        );
      }
    }

    // 3) الإجماليات على الخادم
    const byId = new Map(locked.map((l) => [l.id, l]));
    const lineInputs: SaleLineInput[] = input.items.map((i) => {
      const l = byId.get(i.itemId)!;
      return {
        itemId: i.itemId,
        unitPrice: i.unitPrice,
        discount: i.discount,
        purchaseCost: l.purchase_cost,
        preSaleStatus: l.status,
      };
    });

    let totals;
    try {
      totals = computeSaleTotals(lineInputs, vat);
    } catch (e) {
      if (e instanceof SalePricingError) throw Errors.rule(e.message);
      throw e;
    }

    // 4) حد الخصم
    for (const line of totals.lines) {
      if (exceedsDiscountLimit(line.unitPrice, line.discount, maxDiscountPct)) {
        if (!can(actor, 'discount.override')) throw Errors.forbidden('discount.override');
      }
    }

    // 5) البيع نقدي بالكامل
    try {
      assertFullPayment(totals.grossAmount, input.paidAmount);
    } catch (e) {
      if (e instanceof SalePricingError) throw Errors.rule(e.message);
      throw e;
    }

    // 6) رقم الفاتورة — قفل استشاري يمنع التكرار بين جلستين
    await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext('sale_invoice_no'))`;
    const year = saleDate.getUTCFullYear();
    const last = await tx.sale.findFirst({
      where: { invoiceNo: { startsWith: `INV-${year}-` } },
      orderBy: { invoiceNo: 'desc' },
      select: { invoiceNo: true },
    });
    const nextSeq = last ? Number.parseInt(last.invoiceNo.slice(9), 10) + 1 : 1;

    // 7) الفاتورة
    // ★ D9: تجميد نسبة عمولة البيع على الفاتورة
    const commissionEmployeeId = input.employeeId ?? actor.employeeId ?? null;
    const commissionEmployee = commissionEmployeeId
      ? await tx.employee.findUnique({
          where: { id: commissionEmployeeId },
          select: { salesCommissionPct: true },
        })
      : null;

    const sale = await tx.sale.create({
      data: {
        invoiceNo: buildInvoiceNo(year, Number.isFinite(nextSeq) ? nextSeq : 1),
        customerId,
        employeeId: input.employeeId ?? actor.employeeId ?? null,
        saleDate,
        subtotal: totals.subtotal.toString(),
        discount: totals.discount.toString(),
        netAmount: totals.netAmount.toString(),
        vatStatus: totals.vatStatus,
        vatRate: totals.vatRate ? totals.vatRate.toString() : null,
        vatAmount: totals.vatAmount.toString(),
        grossAmount: totals.grossAmount.toString(),
        paidAmount: round2(input.paidAmount).toString(),
        totalCost: totals.totalCost.toString(),
        commissionRatePct: commissionEmployee?.salesCommissionPct.toString() ?? null,
        status: 'COMPLETED',
        createdBy: actor.id,
      },
    });

    // 8) السطور + حالة القطع + سجل الحالة + حركة المخزون
    for (const line of totals.lines) {
      await tx.saleItem.create({
        data: {
          saleId: sale.id,
          itemId: line.itemId,
          unitPrice: line.unitPrice.toString(),
          discount: line.discount.toString(),
          netPrice: line.netPrice.toString(),
          vatStatus: line.vatStatus,
          vatRate: line.vatRate ? line.vatRate.toString() : null,
          vatAmount: line.vatAmount.toString(),
          grossAmount: line.grossAmount.toString(),
          purchaseCost: line.purchaseCost.toString(),
          preSaleStatus: line.preSaleStatus as ItemStatus,
          isDamagedSale: line.isDamagedSale,
        },
      });

      await tx.itemStatusHistory.create({
        data: {
          itemId: line.itemId,
          fromStatus: line.preSaleStatus as ItemStatus,
          toStatus: 'SOLD',
          reason: `فاتورة بيع ${sale.invoiceNo}`,
          refType: 'Sale',
          refId: sale.id,
          userId: actor.id,
        },
      });

      await tx.productItem.update({
        where: { id: line.itemId },
        data: { status: 'SOLD', disposedAt: new Date() },
      });

      await tx.inventoryTransaction.create({
        data: {
          itemId: line.itemId,
          trxDate: saleDate,
          type: 'SALE',
          refType: 'Sale',
          refId: sale.id,
          note: `بيع بفاتورة ${sale.invoiceNo}`,
          createdBy: actor.id,
        },
      });

      // تعطيل أي ارتباط زمني مستقبلي للقطعة المباعة
      await tx.itemBooking.updateMany({
        where: { itemId: line.itemId, isActive: true },
        data: { isActive: false },
      });
    }

    // 9) الدفعة — البيع نقدي بالكامل
    await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext('payment_no'))`;
    const lastPay = await tx.payment.findFirst({
      where: { paymentNo: { startsWith: `PAY-${year}-` } },
      orderBy: { paymentNo: 'desc' },
      select: { paymentNo: true },
    });
    const paySeq = lastPay ? Number.parseInt(lastPay.paymentNo.slice(9), 10) + 1 : 1;

    await tx.payment.create({
      data: {
        paymentNo: `PAY-${year}-${String(Number.isFinite(paySeq) ? paySeq : 1).padStart(6, '0')}`,
        paymentDate: saleDate,
        direction: 'IN',
        purpose: 'SALE',
        isInsurance: false,
        customerId,
        saleId: sale.id,
        amount: round2(input.paidAmount).toString(),
        paymentMethodId: input.paymentMethodId,
        notes: input.notes?.trim() || null,
        createdBy: actor.id,
      },
    });

    await writeAudit(
      {
        userId: actor.id,
        action: 'sale.create',
        entityType: 'Sale',
        entityId: sale.id,
        after: {
          invoiceNo: sale.invoiceNo,
          netAmount: totals.netAmount.toString(),
          totalCost: totals.totalCost.toString(),
        commissionRatePct: commissionEmployee?.salesCommissionPct.toString() ?? null,
          grossProfit: totals.grossProfit.toString(),
          items: totals.lines.map((l) => l.itemId),
        },
      },
      tx,
    );

    return {
      id: sale.id,
      invoiceNo: sale.invoiceNo,
      netAmount: totals.netAmount.toString(),
      grossAmount: totals.grossAmount.toString(),
      paidAmount: round2(input.paidAmount).toString(),
      remaining: '0',
      totalCost: totals.totalCost.toString(),
      grossProfit: totals.grossProfit.toString(),
    };
  });
}

// ======================= إلغاء الفاتورة =======================

export async function voidSale(input: z.infer<typeof voidSaleSchema>) {
  const actor = await requirePermission('sales.void');

  return prisma.$transaction(async (tx) => {
    const locked = await tx.$queryRaw<
      { id: number; invoice_no: string; status: string; net_amount: string; total_cost: string }[]
    >`
      SELECT id, invoice_no, status, net_amount, total_cost
        FROM sales WHERE id = ${input.saleId} FOR UPDATE
    `;
    if (locked.length === 0) throw Errors.notFound('الفاتورة');
    const sale = locked[0];

    const items = await tx.saleItem.findMany({ where: { saleId: sale.id } });
    const itemStatuses = await tx.productItem.findMany({
      where: { id: { in: items.map((i) => i.itemId) } },
      select: { id: true, status: true },
    });

    const check = canVoidSale({
      status: sale.status as 'COMPLETED' | 'VOIDED',
      itemStatuses: itemStatuses.map((i) => i.status),
    });
    if (!check.allowed) throw Errors.rule(check.reason!);

    // ★ تُلغى الفاتورة أولًا: قاعدة البيانات تسمح بخروج القطعة من حالة "مباعة"
    // فقط بعد أن تصبح فاتورتها ملغاة فعلًا، وإلى حالتها المحفوظة قبل البيع.
    const updated = await tx.sale.update({
      where: { id: sale.id },
      data: {
        status: 'VOIDED',
        voidReason: input.reason,
        voidedBy: actor.id,
        voidedAt: new Date(),
      },
    });

    for (const it of items) {
      const restore = it.preSaleStatus as ItemStatus;
      try {
        assertRestorable(restore);
      } catch (e) {
        throw Errors.rule((e as Error).message);
      }

      await tx.itemStatusHistory.create({
        data: {
          itemId: it.itemId,
          fromStatus: 'SOLD',
          toStatus: restore,
          reason: `إلغاء فاتورة ${sale.invoice_no}: ${input.reason}`,
          refType: 'Sale',
          refId: sale.id,
          userId: actor.id,
        },
      });

      await tx.productItem.update({
        where: { id: it.itemId },
        data: { status: restore, disposedAt: null },
      });

      await tx.inventoryTransaction.create({
        data: {
          itemId: it.itemId,
          trxDate: businessToday(),
          type: 'ADJUST',
          refType: 'Sale',
          refId: sale.id,
          note: `إلغاء بيع — عودة القطعة إلى المخزون (${input.reason})`,
          createdBy: actor.id,
        },
      });
    }

    // الدفعات تُلغى ولا تُحذف
    await tx.payment.updateMany({
      where: { saleId: sale.id, isVoided: false },
      data: { isVoided: true, voidReason: input.reason },
    });

    await writeAudit(
      {
        userId: actor.id,
        action: 'sale.void',
        entityType: 'Sale',
        entityId: sale.id,
        before: { status: 'COMPLETED', netAmount: sale.net_amount, totalCost: sale.total_cost },
        after: { status: 'VOIDED', netAmount: '0', totalCost: '0' },
        reason: input.reason,
      },
      tx,
    );

    return {
      id: updated.id,
      invoiceNo: updated.invoiceNo,
      status: updated.status,
      restoredItems: items.map((i) => ({ itemId: i.itemId, restoredTo: i.preSaleStatus })),
    };
  });
}

// ======================= الاستعلام =======================

export async function listSales(input: z.infer<typeof saleQuerySchema>) {
  await requirePermission('sales.view');

  const where: Prisma.SaleWhereInput = {
    ...(input.includeVoided ? {} : { status: 'COMPLETED' }),
    ...(input.customerId ? { customerId: input.customerId } : {}),
  };
  if (input.from && input.to) {
    const { start, end } = periodBounds(input.from, input.to);
    where.createdAt = { gte: start, lte: end };
  }

  const [rows, total] = await Promise.all([
    prisma.sale.findMany({
      where,
      include: {
        customer: { select: { fullName: true, isWalkIn: true } },
        items: { select: { itemId: true } },
      },
      orderBy: { id: 'desc' },
      skip: (input.page - 1) * input.pageSize,
      take: input.pageSize,
    }),
    prisma.sale.count({ where }),
  ]);

  return {
    rows: rows.map((s) => ({
      ...s,
      grossProfit: round2(s.netAmount.toString()).minus(s.totalCost.toString()).toString(),
    })),
    total,
    page: input.page,
    pageSize: input.pageSize,
  };
}

export async function getSale(id: number) {
  await requirePermission('sales.view');
  const sale = await prisma.sale.findUnique({
    where: { id },
    include: {
      customer: true,
      employee: { select: { fullName: true } },
      items: { include: { item: { include: { product: { select: { nameAr: true, size: true, color: true } } } } } },
      payments: { include: { paymentMethod: { select: { nameAr: true } } } },
    },
  });
  if (!sale) throw Errors.notFound('الفاتورة');

  return {
    ...sale,
    grossProfit: round2(sale.netAmount.toString()).minus(sale.totalCost.toString()).toString(),
    remaining: round2(sale.grossAmount.toString()).minus(sale.paidAmount.toString()).toString(),
  };
}
