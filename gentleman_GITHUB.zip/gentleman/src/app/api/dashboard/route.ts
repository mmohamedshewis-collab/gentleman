import { route } from '@/lib/api';
import { getDashboard, dashboardQuerySchema } from '@/services/dashboard.service';

export const GET = route({
  schema: dashboardQuerySchema,
  handler: ({ input }) => getDashboard(input),
});
