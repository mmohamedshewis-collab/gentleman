import Link from 'next/link';
import { redirect } from 'next/navigation';
import { getSession } from '@/lib/auth/session';
import type { PermissionCode } from '@/lib/auth/permissions';
import LogoutButton from './LogoutButton';

interface NavItem { href: string; label: string; perm: PermissionCode; ready?: boolean }

const NAV: NavItem[] = [
  { href: '/', label: 'لوحة التحكم', perm: 'dashboard.view', ready: true },
  { href: '/rentals', label: 'التأجير', perm: 'rentals.view', ready: true },
  { href: '/returns', label: 'الإرجاع', perm: 'returns.create', ready: true },
  { href: '/sales', label: 'المبيعات', perm: 'sales.view', ready: true },
  { href: '/reservations', label: 'الحجوزات', perm: 'reservations.view', ready: true },
  { href: '/customers', label: 'العملاء', perm: 'customers.view', ready: true },
  { href: '/inventory', label: 'المخزون', perm: 'items.view', ready: true },
  { href: '/products', label: 'المنتجات', perm: 'products.view', ready: true },
  { href: '/insurance', label: 'التأمينات', perm: 'insurance.view' },
  { href: '/expenses', label: 'المصروفات', perm: 'expenses.view' , ready: true },
  { href: '/employees', label: 'الموظفون', perm: 'employees.view' , ready: true },
  { href: '/reports', label: 'التقارير', perm: 'reports.operational.view', ready: true },
  { href: '/users', label: 'المستخدمون', perm: 'users.view', ready: true },
  { href: '/settings', label: 'الإعدادات', perm: 'settings.view', ready: true },
  { href: '/settings/operations', label: 'التشغيل والبيانات', perm: 'backup.run', ready: true },
  { href: '/audit', label: 'سجل التدقيق', perm: 'audit.view', ready: true },
];

export default async function Shell({ children }: { children: React.ReactNode }) {
  const user = await getSession();
  if (!user) redirect('/login');

  const items = NAV.filter((n) => user.permissions.has(n.perm));

  return (
    <div className="min-h-screen flex">
      <aside className="w-60 shrink-0 bg-brand text-white flex flex-col">
        <div className="px-5 py-5 border-b border-white/15">
          <div className="text-xl font-bold tracking-wide">Gentleman</div>
          <div className="text-xs text-brand-soft mt-1">إدارة تأجير وبيع البدلات</div>
        </div>

        <nav className="flex-1 overflow-y-auto py-3">
          {items.map((n) => (
            <Link
              key={n.href}
              href={n.ready ? n.href : '#'}
              className={`block px-5 py-2.5 text-sm transition ${
                n.ready ? 'hover:bg-white/10' : 'opacity-40 cursor-not-allowed'
              }`}
            >
              {n.label}
              {!n.ready && <span className="text-[10px] mr-2">(قيد الإنشاء)</span>}
            </Link>
          ))}
        </nav>

        <div className="px-5 py-4 border-t border-white/15 text-xs">
          <div className="font-semibold">{user.fullName}</div>
          <div className="text-brand-soft mb-3">{user.roleNameAr}</div>
          <LogoutButton />
        </div>
      </aside>

      <main className="flex-1 min-w-0 p-6 overflow-x-auto">{children}</main>
    </div>
  );
}
