import { describe, it, expect, vi, beforeEach } from 'vitest';
import { readFileSync } from 'node:fs';
import {
  ACTIVE_STATUS, TERMINAL_STATUSES, RESERVATION_LABELS, displayState,
  isTerminal, assertActionable, assertReservationDates, buildReservationNo,
} from '../src/lib/reservations/reservation-state';
import { MOVEMENT_RULES, dashboardMovement, companyCashPosition } from '../src/lib/cash/cash-movement';

// ============================ الوحدة ============================

describe('حالة الحجز — MVP بحالة نشطة واحدة (D4)', () => {
  it('الحالة النشطة الوحيدة عند الإنشاء', () => {
    expect(ACTIVE_STATUS).toBe('PENDING');
  });

  it('حالتان نهائيتان فقط', () => {
    expect(TERMINAL_STATUSES).toEqual(['CONVERTED', 'CANCELLED']);
    expect(isTerminal('CONVERTED')).toBe(true);
    expect(isTerminal('CANCELLED')).toBe(true);
    expect(isTerminal('PENDING')).toBe(false);
  });

  it('لا تمييز بين معلّق ومؤكَّد في العرض', () => {
    expect(RESERVATION_LABELS.PENDING).toBe('قائم');
    expect(RESERVATION_LABELS.CONFIRMED).toBe('قائم');
  });
});

describe('★ D2 — «فائت» حالة مشتقة لا تُخزَّن', () => {
  const today = new Date('2026-08-20T00:00:00Z');

  it('حجز قائم مضى موعد استلامه يُعرض «فائت»', () => {
    const v = displayState('PENDING', new Date('2026-08-15T00:00:00Z'), today);
    expect(v.isMissed).toBe(true);
    expect(v.label).toBe('فائت');
    // الحالة المخزَّنة لم تتغيّر
    expect(v.status).toBe('PENDING');
  });

  it('حجز قائم لم يحن موعده ليس فائتًا', () => {
    const v = displayState('PENDING', new Date('2026-08-25T00:00:00Z'), today);
    expect(v.isMissed).toBe(false);
    expect(v.label).toBe('قائم');
  });

  it('★ الحجز المحوَّل أو الملغى لا يُعد فائتًا مهما مضى موعده', () => {
    for (const s of ['CONVERTED', 'CANCELLED'] as const) {
      const v = displayState(s, new Date('2026-01-01T00:00:00Z'), today);
      expect(v.isMissed).toBe(false);
    }
  });

  it('★ لا كتابة لحالة مشتقة في أي مكان بالخدمة', () => {
    const src = readFileSync('src/services/reservation.service.ts', 'utf8');
    expect(src).not.toContain("status: 'EXPIRED'");
    expect(src).not.toContain('EXPIRED');
  });

  it('★ لا مهمة مجدولة للحجوزات', () => {
    const src = readFileSync('vercel.json', 'utf8');
    expect(src).not.toContain('reservation');
    expect(src).not.toContain('expire');
  });
});

describe('انتقالات الحجز', () => {
  it('لا تحويل لحجز محوَّل', () => {
    expect(() => assertActionable('CONVERTED', 'convert')).toThrowError(/محوَّل/);
  });
  it('لا إلغاء لحجز محوَّل — يُلغى العقد', () => {
    expect(() => assertActionable('CONVERTED', 'cancel')).toThrowError(/عقد التأجير/);
  });
  it('لا إلغاء لحجز ملغى', () => {
    expect(() => assertActionable('CANCELLED', 'cancel')).toThrowError(/ملغى/);
  });
  it('الحجز القائم قابل للتحويل والإلغاء', () => {
    expect(() => assertActionable('PENDING', 'convert')).not.toThrow();
    expect(() => assertActionable('PENDING', 'cancel')).not.toThrow();
  });
});

describe('تواريخ الحجز', () => {
  const today = new Date('2026-08-13T00:00:00Z');
  const d = (s: string) => new Date(`${s}T00:00:00Z`);

  it('يقبل تواريخ سليمة', () => {
    expect(() => assertReservationDates({
      pickupDate: d('2026-08-20'), returnDate: d('2026-08-22'),
      eventDate: d('2026-08-21'), today,
    })).not.toThrow();
  });

  it('يرفض استلامًا في الماضي', () => {
    expect(() => assertReservationDates({
      pickupDate: d('2026-08-10'), returnDate: d('2026-08-22'),
      eventDate: d('2026-08-21'), today,
    })).toThrowError(/الماضي/);
  });

  it('يرفض إرجاعًا قبل الاستلام', () => {
    expect(() => assertReservationDates({
      pickupDate: d('2026-08-20'), returnDate: d('2026-08-15'),
      eventDate: d('2026-08-21'), today,
    })).toThrowError(/الإرجاع/);
  });

  it('يرفض مناسبة قبل الاستلام', () => {
    expect(() => assertReservationDates({
      pickupDate: d('2026-08-20'), returnDate: d('2026-08-22'),
      eventDate: d('2026-08-18'), today,
    })).toThrowError(/المناسبة/);
  });

  it('رقم الحجز بست خانات', () => {
    expect(buildReservationNo(2026, 1)).toBe('RES-2026-000001');
  });
});

// ==================== ★ الفصل المالي ====================

describe('★ الفصل المالي: العربون نقدية لا إيرادًا', () => {
  it('★ العربون دخول نقدي وليس إيرادًا ولا مصروفًا', () => {
    const r = MOVEMENT_RULES.RESERVATION_DEPOSIT;
    expect(r.direction).toBe('IN');
    expect(r.affectsCompanyCash).toBe(true);
    expect(r.isRevenue).toBe(false);     // ⛔ ليس إيرادًا
    expect(r.isExpense).toBe(false);     // ⛔ ليس مصروفًا
    expect(r.inDashboardMovement).toBe(true);
  });

  it('★ رد العربون خروج نقدي فقط', () => {
    const r = MOVEMENT_RULES.CUSTOMER_REFUND;
    expect(r.direction).toBe('OUT');
    expect(r.affectsCompanyCash).toBe(true);
    expect(r.isRevenue).toBe(false);
    expect(r.isExpense).toBe(false);
  });

  it('★ العربون يظهر في حركة النقدية اليومية', () => {
    const m = dashboardMovement([{ type: 'RESERVATION_DEPOSIT', amount: 300 }]);
    expect(m.inflow.toString()).toBe('300');
    expect(m.outflow.toString()).toBe('0');
    expect(m.net.toString()).toBe('300');
  });

  it('★ العربون يزيد مركز نقدية الشركة', () => {
    expect(companyCashPosition([{ type: 'RESERVATION_DEPOSIT', amount: 300 }]).toString()).toBe('300');
  });

  it('★ دورة كاملة: عربون 300 ثم رده ⟹ صافي نقدية صفر', () => {
    const m = dashboardMovement([
      { type: 'RESERVATION_DEPOSIT', amount: 300 },
      { type: 'CUSTOMER_REFUND', amount: 300 },
    ]);
    expect(m.inflow.toString()).toBe('300');
    expect(m.outflow.toString()).toBe('300');
    expect(m.net.toString()).toBe('0');
    expect(companyCashPosition([
      { type: 'RESERVATION_DEPOSIT', amount: 300 },
      { type: 'CUSTOMER_REFUND', amount: 300 },
    ]).toString()).toBe('0');
  });

  it('★ لا يوجد نوع حركة للحجز نفسه — الحجز لا يحرّك نقدًا', () => {
    expect(Object.keys(MOVEMENT_RULES)).not.toContain('RESERVATION_CREATED');
  });
});

// ============================ الخدمة ============================

const H = vi.hoisted(() => ({
  auditSpy: vi.fn(),
  createRentalSpy: vi.fn(),
}));
const { auditSpy, createRentalSpy } = H;

let currentUser: { id: number; employeeId: number | null; permissions: Set<string> };
let reservationRow: Record<string, unknown> | null;
let itemRows: { id: number; item_code: string; status: string }[];
const created: Record<string, unknown[]> = {};
const track = (k: string) => (a: { data: Record<string, unknown> }) => {
  (created[k] ??= []).push(a.data);
  return { id: created[k].length, ...a.data };
};

const tx = {
  $queryRaw: vi.fn(async (strings: TemplateStringsArray) => {
    const q = strings.join(' ');
    if (q.includes('product_items')) return itemRows;
    if (q.includes('reservations')) {
      return reservationRow
        ? [{ ...reservationRow, status: (reservationRow as { status?: string }).status ?? 'PENDING' }]
        : [];
    }
    return [];
  }),
  $executeRaw: vi.fn(async () => 1),
  reservation: {
    findFirst: vi.fn(async () => null),
    create: vi.fn(track('reservation')),
    update: vi.fn(async (a: any) => ({
      id: 1, reservationNo: 'RES-2026-000001', ...a.data,
    })),
  },
  reservationItem: { create: vi.fn(track('reservationItem')) },
  itemBooking: {
    create: vi.fn(track('booking')),
    updateMany: vi.fn(async () => ({ count: 1 })),
  },
  payment: {
    findFirst: vi.fn(async () => null),
    findMany: vi.fn(async () => unappliedDeposits),
    create: vi.fn(track('payment')),
    updateMany: vi.fn(async () => ({ count: unappliedDeposits.length })),
    aggregate: vi.fn(async () => ({ _sum: { amount: refundedTotal } })),
  },
  rental: {
    findUniqueOrThrow: vi.fn(async () => rentalAfter),
  },
};

/** العرابين غير المخصَّصة ومجموع ما رُدَّ — يضبطها كل اختبار */
let unappliedDeposits: { id: number; amount: { toString: () => string } }[] = [];
let refundedTotal: string | null = null;
let rentalAfter = {
  totalDue: { toString: () => '1500' },
  paidAmount: { toString: () => '300' },
  remainingAmount: { toString: () => '1200' },
};

vi.mock('@/lib/db', () => ({
  prisma: {
    $transaction: (fn: any) => fn(tx),
    customer: { findUnique: vi.fn(async () => ({ id: 2, isActive: true, fullName: 'أحمد' })) },
    reservation: {
      findMany: vi.fn(async () => []),
      findUnique: vi.fn(async () => reservationRow),
      update: vi.fn(async (a: any) => ({ id: 1, reservationNo: 'RES-2026-000001', ...a.data })),
    },
    itemBooking: { findMany: vi.fn(async () => []), updateMany: vi.fn(async () => ({ count: 1 })) },
  },
}));

vi.mock('@/lib/audit', () => ({ writeAudit: H.auditSpy, redact: (x: unknown) => x }));
vi.mock('@/services/rental.service', () => ({ createRental: H.createRentalSpy }));

vi.mock('@/lib/auth/rbac', async (importOriginal) => {
  const actual = await importOriginal<typeof import('@/lib/auth/rbac')>();
  return {
    ...actual,
    requirePermission: async (perm: string) => {
      if (!currentUser.permissions.has(perm)) {
        const { Errors } = await import('@/lib/errors');
        throw Errors.forbidden(perm);
      }
      return currentUser as never;
    },
  };
});

const future = (days: number) => {
  const d = new Date(Date.now() + days * 86_400_000);
  return d.toISOString().slice(0, 10);
};

const asStaff = () => {
  currentUser = {
    id: 9, employeeId: 3,
    permissions: new Set(['reservations.view', 'reservations.create', 'reservations.convert']),
  };
};
const asAdmin = () => {
  currentUser = {
    id: 1, employeeId: 1,
    permissions: new Set([
      'reservations.view', 'reservations.create',
      'reservations.cancel', 'reservations.convert', 'payments.refund',
    ]),
  };
};

beforeEach(() => {
  auditSpy.mockClear();
  createRentalSpy.mockReset();
  for (const k of Object.keys(created)) delete created[k];
  for (const m of Object.values(tx)) {
    if (typeof m === 'object' && m !== null) {
      for (const f of Object.values(m)) if (typeof f === 'function' && 'mockClear' in f) (f as any).mockClear();
    } else if (typeof m === 'function' && 'mockClear' in m) (m as any).mockClear();
  }
  itemRows = [{ id: 1, item_code: 'SUIT-0001', status: 'AVAILABLE' }];
  reservationRow = null;
  unappliedDeposits = [];
  refundedTotal = null;
  rentalAfter = {
    totalDue: { toString: () => '1500' },
    paidAmount: { toString: () => '300' },
    remainingAmount: { toString: () => '1200' },
  };
  asAdmin();
});

const validReservation = {
  customerId: 2,
  eventDate: future(12),
  pickupDate: future(10),
  returnDate: future(12),
  items: [{ itemId: 1, agreedPrice: 750 }],
  depositAmount: 0,
};

describe('إنشاء الحجز', () => {
  it('★ ينشئ الحجز والسطر وحجز الفترة بلا إيراد', async () => {
    const { createReservation } = await import('@/services/reservation.service');
    const r = await createReservation(validReservation);

    expect(r.reservationNo).toMatch(/^RES-\d{4}-\d{6}$/);
    expect(created.reservation[0]).toMatchObject({ status: 'PENDING' });
    expect(created.reservationItem).toHaveLength(1);
    expect(created.booking[0]).toMatchObject({ sourceType: 'RESERVATION' });
    // ⛔ لا دفعة بلا عربون
    expect(created.payment).toBeUndefined();
    expect(auditSpy.mock.calls[0][0]).toMatchObject({
      action: 'reservation.create',
      after: { revenueImpact: '0' },
    });
  });

  it('★ العربون يُسجَّل دفعة بغرض RESERVATION_DEPOSIT', async () => {
    const { createReservation } = await import('@/services/reservation.service');
    await createReservation({ ...validReservation, depositAmount: 300, paymentMethodId: 1 });
    expect(created.payment[0]).toMatchObject({
      purpose: 'RESERVATION_DEPOSIT',
      direction: 'IN',
      isInsurance: false,
      amount: '300',
    });
  });

  it('★ لا يغيّر حالة القطعة', async () => {
    const { createReservation } = await import('@/services/reservation.service');
    await createReservation(validReservation);
    expect(created.itemUpdate).toBeUndefined();
    const src = readFileSync('src/services/reservation.service.ts', 'utf8');
    expect(src).not.toContain('productItem.update');
  });

  it('يرفض قطعة غير قابلة للحجز', async () => {
    itemRows = [{ id: 1, item_code: 'SUIT-0001', status: 'SOLD' }];
    const { createReservation } = await import('@/services/reservation.service');
    await expect(createReservation(validReservation)).rejects.toMatchObject({ code: 'BUSINESS_RULE' });
  });

  it('يرفض تكرار القطعة داخل الحجز', async () => {
    const { createReservation } = await import('@/services/reservation.service');
    await expect(createReservation({
      ...validReservation,
      items: [{ itemId: 1, agreedPrice: 100 }, { itemId: 1, agreedPrice: 100 }],
    })).rejects.toMatchObject({ code: 'BUSINESS_RULE' });
  });

  it('يرفض عربونًا يتجاوز قيمة الحجز', async () => {
    const { createReservation } = await import('@/services/reservation.service');
    await expect(createReservation({
      ...validReservation, depositAmount: 5000, paymentMethodId: 1,
    })).rejects.toMatchObject({ code: 'BUSINESS_RULE' });
  });

  it('يرفض عربونًا بلا طريقة دفع', async () => {
    const { createReservation } = await import('@/services/reservation.service');
    await expect(createReservation({ ...validReservation, depositAmount: 300 }))
      .rejects.toMatchObject({ code: 'BUSINESS_RULE' });
  });

  it('★ يترجم تعارض قيد القاعدة إلى رسالة عربية', async () => {
    tx.itemBooking.create.mockRejectedValueOnce(
      Object.assign(new Error('conflicting key value violates exclusion constraint "ex_item_booking_overlap"')),
    );
    const { createReservation } = await import('@/services/reservation.service');
    await expect(createReservation(validReservation)).rejects.toMatchObject({ code: 'CONFLICT' });
  });

  it('يحتاج صلاحية reservations.create', async () => {
    currentUser = { id: 5, employeeId: null, permissions: new Set(['reservations.view']) };
    const { createReservation } = await import('@/services/reservation.service');
    await expect(createReservation(validReservation))
      .rejects.toMatchObject({ code: 'PERM_DENIED', details: { permission: 'reservations.create' } });
  });
});

describe('إلغاء الحجز', () => {
  beforeEach(() => {
    reservationRow = { id: 1, reservation_no: 'RES-2026-000001', status: 'PENDING', customer_id: 2 };
  });

  it('يحرّر الفترة ويسجّل السبب', async () => {
    const { cancelReservation } = await import('@/services/reservation.service');
    const r = await cancelReservation({
      reservationId: 1, reason: 'العميل ألغى', cancelledByShop: false,
    });
    expect(r.status).toBe('CANCELLED');
    expect(tx.itemBooking.updateMany).toHaveBeenCalledWith(
      expect.objectContaining({ data: { isActive: false } }),
    );
    // إلغاء العميل ⟹ لا رد (Q4)
    expect(r.depositRefunded).toBe('0');
    expect(created.payment).toBeUndefined();
  });

  it('★ إلغاء المحل يرد العربون كاملًا (Q4)', async () => {
    tx.payment.aggregate
      .mockResolvedValueOnce({ _sum: { amount: '300' } })   // المحصَّل
      .mockResolvedValueOnce({ _sum: { amount: null } });   // المردود سابقًا

    const { cancelReservation } = await import('@/services/reservation.service');
    const r = await cancelReservation({
      reservationId: 1, reason: 'المحل ألغى', cancelledByShop: true, refundPaymentMethodId: 1,
    });
    expect(r.depositRefunded).toBe('300');
    expect(created.payment[0]).toMatchObject({
      direction: 'OUT', purpose: 'CUSTOMER_REFUND', reservationId: 1, amount: '300',
    });
  });

  it('★ لا رد مزدوج — المردود سابقًا يُخصم', async () => {
    tx.payment.aggregate
      .mockResolvedValueOnce({ _sum: { amount: '300' } })
      .mockResolvedValueOnce({ _sum: { amount: '300' } });

    const { cancelReservation } = await import('@/services/reservation.service');
    const r = await cancelReservation({
      reservationId: 1, reason: 'إلغاء', cancelledByShop: true, refundPaymentMethodId: 1,
    });
    expect(r.depositRefunded).toBe('0');
    expect(created.payment).toBeUndefined();
  });

  it('يرفض إلغاء حجز ملغى', async () => {
    reservationRow = { ...reservationRow, status: 'CANCELLED' };
    const { cancelReservation } = await import('@/services/reservation.service');
    await expect(cancelReservation({ reservationId: 1, reason: 'ثانية', cancelledByShop: false }))
      .rejects.toMatchObject({ code: 'BUSINESS_RULE' });
  });

  it('يرفض إلغاء حجز محوَّل', async () => {
    reservationRow = { ...reservationRow, status: 'CONVERTED' };
    const { cancelReservation } = await import('@/services/reservation.service');
    await expect(cancelReservation({ reservationId: 1, reason: 'إلغاء', cancelledByShop: false }))
      .rejects.toMatchObject({ code: 'BUSINESS_RULE' });
  });

  it('الإلغاء صلاحية مدير — الموظف يُرفض', async () => {
    asStaff();
    const { cancelReservation } = await import('@/services/reservation.service');
    await expect(cancelReservation({ reservationId: 1, reason: 'إلغاء', cancelledByShop: false }))
      .rejects.toMatchObject({ code: 'PERM_DENIED', details: { permission: 'reservations.cancel' } });
  });

  it('سبب الإلغاء إلزامي', async () => {
    const { cancelReservationSchema } = await import('@/services/reservation.service');
    expect(cancelReservationSchema.safeParse({ reservationId: 1 }).success).toBe(false);
    expect(cancelReservationSchema.safeParse({ reservationId: 1, reason: 'سبب' }).success).toBe(true);
  });
});

describe('★ التحويل إلى تأجير', () => {
  beforeEach(() => {
    reservationRow = {
      id: 1, reservationNo: 'RES-2026-000001', status: 'PENDING',
      customerId: 2, employeeId: 3,
      returnDate: new Date(Date.now() + 12 * 86_400_000),
      depositAmount: { toString: () => '300' },
      items: [{ itemId: 1, agreedPrice: 750 }],
    };
    createRentalSpy.mockResolvedValue({
      id: 55, rentalNo: 'R-2026-000010', totalDue: '1500',
    });
  });

  it('★ يستدعي createRental القائمة ولا يُنشئ منطق تأجير جديد', async () => {
    const { convertReservation } = await import('@/services/reservation.service');
    const r = await convertReservation({ reservationId: 1, paidAmount: 450, paymentMethodId: 1 });

    expect(createRentalSpy).toHaveBeenCalledTimes(1);
    expect(createRentalSpy.mock.calls[0][0]).toMatchObject({
      customerId: 2,
      items: [{ itemId: 1, unitRentalPrice: 750 }],
      paidAmount: 450,
    });
    expect(r.rentalNo).toBe('R-2026-000010');
    expect(r.status).toBe('CONVERTED');
  });

  it('★ الخدمة لا تحتوي أي منطق تأجير مكرر', () => {
    const src = readFileSync('src/services/reservation.service.ts', 'utf8');
    expect(src).toContain("from '@/services/rental.service'");
    expect(src).not.toContain('rental.create');
    expect(src).not.toContain('rentalItem.create');
  });

  it('★ يحرّر فترة الحجز قبل إنشاء العقد', async () => {
    const { convertReservation } = await import('@/services/reservation.service');
    await convertReservation({ reservationId: 1, paidAmount: 0 });
    expect(tx.itemBooking.updateMany).toHaveBeenCalled();
  });

  it('★ لا تحويل مرتين', async () => {
    reservationRow = { ...reservationRow, status: 'CONVERTED' };
    const { convertReservation } = await import('@/services/reservation.service');
    await expect(convertReservation({ reservationId: 1, paidAmount: 0 }))
      .rejects.toMatchObject({ code: 'BUSINESS_RULE' });
    expect(createRentalSpy).not.toHaveBeenCalled();
  });

  it('لا تحويل لحجز ملغى', async () => {
    reservationRow = { ...reservationRow, status: 'CANCELLED' };
    const { convertReservation } = await import('@/services/reservation.service');
    await expect(convertReservation({ reservationId: 1, paidAmount: 0 }))
      .rejects.toMatchObject({ code: 'BUSINESS_RULE' });
  });

  it('★ فشل إنشاء العقد يعيد تفعيل حجز الفترة', async () => {
    createRentalSpy.mockRejectedValue(new Error('القطعة غير متاحة'));
    const { convertReservation } = await import('@/services/reservation.service');
    await expect(convertReservation({ reservationId: 1, paidAmount: 0 })).rejects.toThrow();

    const { prisma } = await import('@/lib/db');
    expect(prisma.itemBooking.updateMany).toHaveBeenCalledWith(
      expect.objectContaining({ data: { isActive: true } }),
    );
  });

  it('يسجّل التحويل في التدقيق برقم العقد', async () => {
    const { convertReservation } = await import('@/services/reservation.service');
    await convertReservation({ reservationId: 1, paidAmount: 0 });
    expect(auditSpy.mock.calls[0][0]).toMatchObject({
      action: 'reservation.convert',
      after: { status: 'CONVERTED', rentalNo: 'R-2026-000010' },
    });
  });

  it('التحويل صلاحية مستقلة', async () => {
    currentUser = { id: 5, employeeId: null, permissions: new Set(['reservations.view']) };
    const { convertReservation } = await import('@/services/reservation.service');
    await expect(convertReservation({ reservationId: 1, paidAmount: 0 }))
      .rejects.toMatchObject({ code: 'PERM_DENIED', details: { permission: 'reservations.convert' } });
  });
});

describe('النطاق والصلاحيات', () => {
  it('★ لا صلاحية جديدة — الأربع موجودة مسبقًا', async () => {
    const { ALL_PERMISSION_CODES } = await import('../src/lib/auth/permissions');
    for (const p of ['reservations.view', 'reservations.create',
                     'reservations.cancel', 'reservations.convert']) {
      expect(ALL_PERMISSION_CODES).toContain(p as never);
    }
    // العدد الفعلي وقت التشغيل — 56 بعد حذف صلاحيتين بلا تنفيذ في ترقيع M-2
    expect(ALL_PERMISSION_CODES.length).toBe(56);
  });

  it('★ D6 — الصيانة والتنظيف خارج M10', async () => {
    const { ALL_PERMISSION_CODES } = await import('../src/lib/auth/permissions');
    expect(ALL_PERMISSION_CODES.some((p) => String(p).startsWith('maintenance.'))).toBe(false);
    expect(ALL_PERMISSION_CODES.some((p) => String(p).startsWith('cleaning.'))).toBe(false);
  });

  it('★ لا منطق مالي جديد في خدمة الحجز', () => {
    const src = readFileSync('src/services/reservation.service.ts', 'utf8');
    expect(/journal|chart_of_accounts|double-entry/i.test(src)).toBe(false);
    // لا حساب إيراد
    expect(src).not.toContain('netAmount');
  });
});

// ==================== ★ الإصلاح الحرج: تخصيص عربون الحجز ====================

describe('★ CRITICAL — تخصيص عربون الحجز للعقد عند التحويل', () => {
  beforeEach(() => {
    reservationRow = {
      id: 1, reservationNo: 'RES-2026-000001', status: 'PENDING',
      customerId: 2, employeeId: 3,
      returnDate: new Date(Date.now() + 12 * 86_400_000),
      depositAmount: { toString: () => '300' },
      items: [{ itemId: 1, agreedPrice: 1500 }],
    };
    createRentalSpy.mockResolvedValue({
      id: 55, rentalNo: 'R-2026-000010', totalDue: '1500',
    });
  });

  it('★ A — عربون 300 · عقد 1,500 ⟹ المتبقي 1,200 لا 1,500', async () => {
    unappliedDeposits = [{ id: 77, amount: { toString: () => '300' } }];
    const { convertReservation } = await import('@/services/reservation.service');
    const r = await convertReservation({ reservationId: 1, paidAmount: 0 });

    expect(r.depositApplied).toBe('300');
    expect(r.rentalTotalDue).toBe('1500');
    expect(r.rentalPaidAmount).toBe('300');
    expect(r.rentalRemaining).toBe('1200');   // ★ العميل لا يُطالَب بـ1,500 مجددًا
  });

  it('★ B — لا حركة نقدية جديدة: تخصيص لا دفعة', async () => {
    unappliedDeposits = [{ id: 77, amount: { toString: () => '300' } }];
    const { convertReservation } = await import('@/services/reservation.service');
    await convertReservation({ reservationId: 1, paidAmount: 0 });

    // ⛔ لا دفعة جديدة تُنشأ في مسار التخصيص
    expect(created.payment).toBeUndefined();
    // ★ الدفعة القائمة رُبطت بالعقد
    expect(tx.payment.updateMany).toHaveBeenCalledWith(
      expect.objectContaining({ data: { rentalId: 55 } }),
    );
  });

  it('★ C و D — لا إيراد جديد ولا أثر على الربح من التخصيص', async () => {
    unappliedDeposits = [{ id: 77, amount: { toString: () => '300' } }];
    const { convertReservation } = await import('@/services/reservation.service');
    await convertReservation({ reservationId: 1, paidAmount: 0 });

    expect(auditSpy.mock.calls[0][0]).toMatchObject({
      after: { newCashInflow: '0', newRevenue: '0' },
    });
    // العربون نفسه ليس إيرادًا في جدول التصنيف
    const { MOVEMENT_RULES } = await import('../src/lib/cash/cash-movement');
    expect(MOVEMENT_RULES.RESERVATION_DEPOSIT.isRevenue).toBe(false);
    expect(MOVEMENT_RULES.RESERVATION_DEPOSIT.isExpense).toBe(false);
  });

  it('★ E — الدفعة الأصلية تبقى متتبَّعة: لا حذف ولا تعديل للمبلغ', async () => {
    unappliedDeposits = [{ id: 77, amount: { toString: () => '300' } }];
    const { convertReservation } = await import('@/services/reservation.service');
    await convertReservation({ reservationId: 1, paidAmount: 0 });

    const call = tx.payment.updateMany.mock.calls[0][0] as {
      data: Record<string, unknown>; where: Record<string, unknown>;
    };
    // يُضاف ربط العقد فقط — الحجز والمبلغ والتاريخ بلا مساس
    expect(Object.keys(call.data)).toEqual(['rentalId']);
    expect(call.where).toMatchObject({ rentalId: null });

    const src = readFileSync('src/services/reservation.service.ts', 'utf8');
    expect(src).not.toContain('payment.delete');
    expect(src).not.toContain('reservationId: null');
  });

  it('★ F — لا يُخصَّص العربون مرتين', async () => {
    // الدفعة صارت مرتبطة بعقد ⟹ لا تظهر ضمن غير المخصَّص
    unappliedDeposits = [];
    const { convertReservation } = await import('@/services/reservation.service');
    const r = await convertReservation({ reservationId: 1, paidAmount: 0 });
    expect(r.depositApplied).toBe('0');
    expect(tx.payment.updateMany).not.toHaveBeenCalled();
  });

  it('★ G — عربون مردود لا يُخصَّص', async () => {
    unappliedDeposits = [{ id: 77, amount: { toString: () => '300' } }];
    refundedTotal = '300';
    const { convertReservation } = await import('@/services/reservation.service');
    await expect(convertReservation({ reservationId: 1, paidAmount: 0 }))
      .rejects.toMatchObject({ code: 'BUSINESS_RULE' });
    expect(tx.payment.updateMany).not.toHaveBeenCalled();
  });

  it('★ H — التخصيص مقصور على عقد هذا الحجز وحده', async () => {
    unappliedDeposits = [{ id: 77, amount: { toString: () => '300' } }];
    const { convertReservation } = await import('@/services/reservation.service');
    await convertReservation({ reservationId: 1, paidAmount: 0 });

    const call = tx.payment.updateMany.mock.calls[0][0] as {
      where: { id: { in: number[] } }; data: { rentalId: number };
    };
    expect(call.where.id.in).toEqual([77]);
    expect(call.data.rentalId).toBe(55);   // العقد الناتج عن هذا الحجز
  });

  it('★ I — لا تحويل مرتين (قفل + فحص الحالة)', async () => {
    reservationRow = { ...reservationRow, status: 'CONVERTED' };
    const { convertReservation } = await import('@/services/reservation.service');
    await expect(convertReservation({ reservationId: 1, paidAmount: 0 }))
      .rejects.toMatchObject({ code: 'BUSINESS_RULE' });
    expect(createRentalSpy).not.toHaveBeenCalled();
  });

  it('★ K — سجل التدقيق لا يدّعي تخصيصًا لم يحدث', async () => {
    unappliedDeposits = [];
    const { convertReservation } = await import('@/services/reservation.service');
    await convertReservation({ reservationId: 1, paidAmount: 0 });
    expect(auditSpy.mock.calls[0][0]).toMatchObject({
      after: { depositApplied: '0', allocatedPaymentIds: [] },
    });
  });

  it('★ سجل التدقيق يوثّق الرصيد الفعلي بعد التخصيص', async () => {
    unappliedDeposits = [{ id: 77, amount: { toString: () => '300' } }];
    const { convertReservation } = await import('@/services/reservation.service');
    await convertReservation({ reservationId: 1, paidAmount: 0 });
    expect(auditSpy.mock.calls[0][0]).toMatchObject({
      after: {
        depositApplied: '300', allocatedPaymentIds: [77],
        rentalPaidAmount: '300', rentalRemaining: '1200',
      },
    });
  });

  it('★ عربون يتجاوز قيمة العقد يُرفض بوضوح', async () => {
    unappliedDeposits = [{ id: 77, amount: { toString: () => '2000' } }];
    const { convertReservation } = await import('@/services/reservation.service');
    await expect(convertReservation({ reservationId: 1, paidAmount: 0 }))
      .rejects.toMatchObject({ code: 'BUSINESS_RULE' });
  });

  it('★ لا نظام مدفوعات ثانٍ ولا دفتر عرابين', () => {
    const src = readFileSync('src/services/reservation.service.ts', 'utf8');
    expect(src).not.toContain('depositLedger');
    expect(src).not.toContain('allocationRecord');
    // التخصيص عبر جدول المدفوعات القائم
    expect(src).toContain('tx.payment.updateMany');
  });
});
