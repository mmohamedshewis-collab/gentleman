'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function VoidSaleForm({ saleId, invoiceNo }: { saleId: number; invoiceNo: string }) {
  const router = useRouter();
  const [reason, setReason] = useState('');
  const [confirming, setConfirming] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit() {
    setBusy(true); setMsg(null);
    const res = await fetch('/api/sales/void', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ saleId, reason }),
    });
    const json = await res.json();
    setBusy(false);
    if (!json.ok) { setMsg(json.error?.message ?? 'تعذّر الإلغاء.'); return; }
    router.refresh();
  }

  return (
    <div className="card print:hidden border-red-200">
      <div className="card-header bg-danger">إلغاء الفاتورة</div>
      <div className="p-5 space-y-3">
        <p className="text-sm text-slate-600">
          الإلغاء لا يحذف الفاتورة: تبقى محفوظة بعلامة "ملغاة"، وتعود القطع إلى حالتها قبل البيع،
          وتُلغى الدفعات، ويُسجَّل ذلك في سجل التدقيق.
        </p>
        <div>
          <label className="label">سبب الإلغاء (إلزامي)</label>
          <input className="input" value={reason} onChange={(e) => setReason(e.target.value)} />
        </div>
        {!confirming ? (
          <button className="btn-danger" disabled={reason.trim().length < 3}
                  onClick={() => setConfirming(true)}>
            إلغاء الفاتورة {invoiceNo}
          </button>
        ) : (
          <div className="flex gap-3 items-center">
            <span className="text-sm font-semibold text-danger">تأكيد الإلغاء نهائيًا؟</span>
            <button className="btn-danger" onClick={submit} disabled={busy}>
              {busy ? 'جارٍ…' : 'نعم، ألغِ'}
            </button>
            <button className="btn-secondary" onClick={() => setConfirming(false)}>تراجع</button>
          </div>
        )}
        {msg && <p className="text-sm font-semibold text-danger">{msg}</p>}
      </div>
    </div>
  );
}
