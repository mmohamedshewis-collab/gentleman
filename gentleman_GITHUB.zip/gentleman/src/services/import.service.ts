import { z } from 'zod';
import { Errors } from '@/lib/errors';
import { requirePermission } from '@/lib/auth/rbac';
import { writeAudit } from '@/lib/audit';
import { parseCsv, MAX_IMPORT_ROWS } from '@/lib/import/csv';
import { createItems } from '@/services/item.service';
import { createCustomer } from '@/services/customer.service';

/**
 * استيراد البيانات الافتتاحية.
 *
 * ★ **لا كتابة مباشرة في قاعدة البيانات إطلاقًا.** كل صف يمر بالخدمة المعتمدة
 *   لوحدته، فيخضع لنفس التحقق والصلاحيات وآلة الحالة والقيود وسجل التدقيق
 *   ومنع التكرار. الاستيراد طريق إدخال، لا طريق التفاف.
 *
 * ★ كل صف مستقل: الفاشل يُرفض بسببه ولا يُفسد الناجح.
 */

export const importSchema = z.object({
  csv: z.string().min(1, 'الملف فارغ'),
});

export interface RowOutcome {
  row: number;
  ok: boolean;
  reference?: string;
  error?: string;
}

export interface ImportResult {
  total: number;
  succeeded: number;
  failed: number;
  outcomes: RowOutcome[];
  note: string;
}

const NOTE =
  'كل صف مرّ بالخدمة المعتمدة لوحدته — لم تُكتب أي بيانات مباشرةً في قاعدة البيانات.';

function summarize(outcomes: RowOutcome[]): ImportResult {
  return {
    total: outcomes.length,
    succeeded: outcomes.filter((o) => o.ok).length,
    failed: outcomes.filter((o) => !o.ok).length,
    outcomes,
    note: NOTE,
  };
}

const errorOf = (e: unknown): string => {
  const err = e as { message?: string };
  return err?.message ?? 'خطأ غير متوقع';
};

/**
 * استيراد القطع.
 * الأعمدة: productCode, quantity, codePrefix, purchaseCost, barcode?
 * ★ لا يُسجَّل خروج نقدي: القطع القائمة اشتُريت قبل تشغيل النظام (D5 المعتمد).
 */
export async function importItems(input: z.infer<typeof importSchema>): Promise<ImportResult> {
  const actor = await requirePermission('items.manage');

  const { rows, error } = parseCsv(input.csv, [
    'productId', 'quantity', 'codePrefix', 'purchaseCost',
  ]);
  if (error) throw Errors.rule(error);
  if (rows.length > MAX_IMPORT_ROWS) {
    throw Errors.rule(`الحد الأقصى ${MAX_IMPORT_ROWS} صفًا في الملف الواحد.`);
  }

  const outcomes: RowOutcome[] = [];

  for (const [i, row] of rows.entries()) {
    const lineNo = i + 2; // السطر 1 رؤوس الأعمدة
    try {
      const result = await createItems({
        productId: Number(row.productId),
        quantity: Number(row.quantity || 1),
        codePrefix: String(row.codePrefix),
        purchaseCost: Number(row.purchaseCost || 0),
        barcodes: row.barcode ? [String(row.barcode)] : undefined,
      });
      outcomes.push({
        row: lineNo,
        ok: true,
        reference: result.items.map((x) => x.itemCode).join('، '),
      });
    } catch (e) {
      outcomes.push({ row: lineNo, ok: false, error: errorOf(e) });
    }
  }

  const summary = summarize(outcomes);
  await writeAudit({
    userId: actor.id,
    action: 'import.items',
    entityType: 'ProductItem',
    after: { total: summary.total, succeeded: summary.succeeded, failed: summary.failed },
  });
  return summary;
}

/**
 * استيراد العملاء.
 * الأعمدة: fullName, phone, nationalId?, notes?
 */
export async function importCustomers(input: z.infer<typeof importSchema>): Promise<ImportResult> {
  const actor = await requirePermission('customers.create');

  const { rows, error } = parseCsv(input.csv, ['fullName', 'phone']);
  if (error) throw Errors.rule(error);
  if (rows.length > MAX_IMPORT_ROWS) {
    throw Errors.rule(`الحد الأقصى ${MAX_IMPORT_ROWS} صفًا في الملف الواحد.`);
  }

  const outcomes: RowOutcome[] = [];

  for (const [i, row] of rows.entries()) {
    const lineNo = i + 2;
    try {
      const c = await createCustomer({
        fullName: String(row.fullName),
        phone: String(row.phone),
        nationalId: row.nationalId ? String(row.nationalId) : undefined,
        notes: row.notes ? String(row.notes) : undefined,
      });
      outcomes.push({ row: lineNo, ok: true, reference: c.code });
    } catch (e) {
      outcomes.push({ row: lineNo, ok: false, error: errorOf(e) });
    }
  }

  const summary = summarize(outcomes);
  await writeAudit({
    userId: actor.id,
    action: 'import.customers',
    entityType: 'Customer',
    after: { total: summary.total, succeeded: summary.succeeded, failed: summary.failed },
  });
  return summary;
}
