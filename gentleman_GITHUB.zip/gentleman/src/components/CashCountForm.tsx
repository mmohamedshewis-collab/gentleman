'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

interface Preview {
  date: string;
  todayMovement: string;
  companyPosition: string;
  insuranceCashBalance: string;
  expectedPhysical: string;
  status: string;
  actualCounted: string | null;
  variance: string | null;
  notes: string | null;
}

const egp = (v: string | number) =>
  new Intl.NumberFormat('ar-EG', { numberingSystem: 'latn', minimumFractionDigits: 2 })
    .format(Number(v));

export default function CashCountForm({
  preview, canClose, canTransfer,
}: { preview: Preview; canClose: boolean; canTransfer: boolean }) {
  const router = useRouter();
  const [actual, setActual] = useState(preview.actualCounted ?? '');
  const [notes, setNotes] = useState(preview.notes ?? '');
  const [msg, setMsg] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  const closed = preview.status === 'CLOSED';
  const variance = preview.variance !== null ? Number(preview.variance) : null;
  const requiredTransfer =
    Number(preview.actualCounted ?? 0) - Number(preview.insuranceCashBalance);

  async function call(url: string, body: Record<string, unknown>) {
    setBusy(true); setMsg(null);
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    const json = await res.json();
    setBusy(false);
    if (!json.ok) { setMsg({ type: 'err', text: json.error?.message ?? 'تعذّر التنفيذ.' }); return null; }
    router.refresh();
    return json.data;
  }

  return (
    <div className="card">
      <div className="card-header">جرد نقدية اليوم</div>
      <div className="p-5 space-y-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
          <div>
            <div className="text-slate-500">صافي حركة الشركة اليوم</div>
            <div className="num font-bold">{egp(preview.todayMovement)}</div>
          </div>
          <div>
            <div className="text-slate-500">مركز الشركة النقدي المتوقع</div>
            <div className="num font-bold">{egp(preview.companyPosition)}</div>
          </div>
          <div>
            <div className="text-slate-500">رصيد التأمينات بالمحل</div>
            <div className="num font-bold text-brand-light">{egp(preview.insuranceCashBalance)}</div>
          </div>
          <div>
            <div className="text-slate-500">النقدية المتوقعة فعليًا</div>
            <div className="num font-bold text-brand">{egp(preview.expectedPhysical)}</div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end border-t border-slate-200 pt-4">
          <div>
            <label className="label">الكاش الفعلي الموجود بالمحل</label>
            <input
              className="input num" dir="ltr" inputMode="decimal" disabled={closed}
              value={actual} onChange={(e) => setActual(e.target.value)}
            />
          </div>
          <div className="md:col-span-2">
            <label className="label">ملاحظات</label>
            <input className="input" disabled={closed} value={notes}
                   onChange={(e) => setNotes(e.target.value)} />
          </div>
        </div>

        {variance !== null && (
          <div className={`rounded-lg p-4 font-bold ${
            variance === 0 ? 'bg-green-50 text-ok'
            : variance < 0 ? 'bg-red-50 text-danger' : 'bg-amber-50 text-warn'}`}>
            الفرق: <span className="num">{egp(variance)}</span>
            {' — '}
            {variance === 0 ? 'مطابق' : variance < 0 ? 'عجز' : 'زيادة'}
          </div>
        )}

        <div className="flex flex-wrap gap-3 items-center">
          {!closed && (
            <button className="btn-primary" disabled={busy || !actual}
                    onClick={() => call('/api/cash/count', { actualCounted: Number(actual), notes })}>
              {busy ? 'جارٍ…' : 'حفظ الجرد'}
            </button>
          )}
          {!closed && canClose && preview.actualCounted !== null && (
            <button className="btn-secondary" disabled={busy}
                    onClick={() => call('/api/cash/close', {})}>
              إغلاق اليوم
            </button>
          )}
          {closed && canTransfer && (
            <button className="btn-primary" disabled={busy}
                    onClick={() => call('/api/cash/transfer', { amount: requiredTransfer })}>
              ترحيل {egp(requiredTransfer)} إلى الخزينة
            </button>
          )}
          <span className={`badge ${closed ? 'bg-slate-100 text-slate-500' : 'bg-green-100 text-ok'}`}>
            {closed ? 'اليوم مغلق' : 'اليوم مفتوح'}
          </span>
        </div>

        {closed && (
          <p className="text-xs text-slate-500">
            الترحيل الكامل إلزامي: يُرحَّل كل كاش الشركة ولا يُرحَّل جنيه من رصيد التأمينات.
            الفرق يبقى ظاهرًا ولا يُصفَّر بالترحيل.
          </p>
        )}

        {msg && (
          <p className={`text-sm font-semibold ${msg.type === 'ok' ? 'text-ok' : 'text-danger'}`}>
            {msg.text}
          </p>
        )}
      </div>
    </div>
  );
}
