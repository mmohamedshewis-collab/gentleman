import Link from 'next/link';
import { listSales } from '@/services/sale.service';
import { getSession } from '@/lib/auth/session';
import { formatEGP } from '@/lib/money';
import { formatDate } from '@/lib/date';
import SalePos from '@/components/SalePos';

export const dynamic = 'force-dynamic';

export default async function SalesPage() {
  const session = await getSession();
  const canCreate = session?.permissions.has('sales.create') ?? false;
  const { rows, total } = await listSales({ includeVoided: true, page: 1, pageSize: 50 });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="section-title">المبيعات</h1>
        <p className="text-sm text-slate-600 mt-1">
          عدد الفواتير: <span className="num">{total}</span>
        </p>
      </div>

      {canCreate && <SalePos />}

      <div className="card overflow-hidden">
        <div className="card-header">الفواتير</div>
        <div className="overflow-x-auto">
          <table className="table">
            <thead>
              <tr>
                <th>الفاتورة</th><th>التاريخ</th><th>العميل</th>
                <th>صافي البيع</th><th>التكلفة</th><th>مجمل الربح</th><th>الحالة</th><th></th>
              </tr>
            </thead>
            <tbody>
              {rows.map((s) => (
                <tr key={s.id} className={s.status === 'VOIDED' ? 'opacity-50' : ''}>
                  <td className="num">{s.invoiceNo}</td>
                  <td className="num">{formatDate(s.saleDate)}</td>
                  <td>{s.customer.isWalkIn ? 'عميل نقدي' : s.customer.fullName}</td>
                  <td className="num">{formatEGP(s.netAmount.toString())}</td>
                  <td className="num">{formatEGP(s.totalCost.toString())}</td>
                  <td className={`num font-semibold ${Number(s.grossProfit) < 0 ? 'text-danger' : 'text-ok'}`}>
                    {formatEGP(s.grossProfit)}
                  </td>
                  <td>
                    <span className={`badge ${s.status === 'VOIDED' ? 'bg-red-100 text-danger' : 'bg-green-100 text-ok'}`}>
                      {s.status === 'VOIDED' ? 'ملغاة' : 'مكتملة'}
                    </span>
                  </td>
                  <td><Link className="text-brand-light font-semibold" href={`/sales/${s.id}`}>الفاتورة</Link></td>
                </tr>
              ))}
              {rows.length === 0 && (
                <tr><td colSpan={8} className="text-center text-slate-500 py-8">لا توجد فواتير بعد.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
