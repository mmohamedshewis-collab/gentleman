import { describe, it, expect, vi, beforeEach } from 'vitest';
import { readFileSync } from 'node:fs';
import { revenueOf, expenseOf, auditClassification } from '../src/lib/finance/reconciliation';
import { lifetimeProfit } from '../src/lib/inventory/upkeep';

/**
 * M13-1: ربط سجل التنظيف بعقد التأجير.
 * ★ rentalId بيانات وصفية بحتة — صفر أثر مالي.
 */

const H = vi.hoisted(() => ({ auditSpy: vi.fn() }));
const { auditSpy } = H;

let currentUser: { id: number; employeeId: number | null; permissions: Set<string> };
let itemRow: { id: number; item_code: string; status: string };
let rentalLine: { id: number } | null;
let rentalRow: { rentalNo: string } | null;
let categoryRow: Record<string, unknown> | null;
const created: Record<string, unknown[]> = {};
const track = (k: string) => (a: { data: Record<string, unknown> }) => {
  (created[k] ??= []).push(a.data);
  return { id: created[k].length, ...a.data };
};

const tx = {
  $queryRaw: vi.fn(async () => [itemRow]),
  $executeRaw: vi.fn(async () => 1),
  expenseCategory: { findFirst: vi.fn(async () => categoryRow) },
  expense: { findFirst: vi.fn(async () => null), create: vi.fn(track('expense')) },
  maintenanceRecord: { create: vi.fn(track('maintenance')) },
  cleaningRecord: { create: vi.fn(track('cleaning')) },
  itemStatusHistory: { create: vi.fn(track('history')) },
  productItem: { update: vi.fn(track('itemUpdate')) },
};

vi.mock('@/lib/db', () => ({
  prisma: {
    $transaction: (fn: any) => fn(tx),
    rentalItem: { findFirst: vi.fn(async () => rentalLine), findMany: vi.fn(async () => []) },
    rental: { findUnique: vi.fn(async () => rentalRow) },
    maintenanceRecord: { findMany: vi.fn(async () => []) },
    cleaningRecord: { findMany: vi.fn(async () => []) },
  },
}));

vi.mock('@/lib/audit', () => ({ writeAudit: H.auditSpy, redact: (x: unknown) => x }));

vi.mock('@/lib/auth/rbac', async (importOriginal) => {
  const actual = await importOriginal<typeof import('@/lib/auth/rbac')>();
  return {
    ...actual,
    requirePermission: async (perm: string) => {
      if (!currentUser.permissions.has(perm)) {
        const { Errors } = await import('@/lib/errors');
        throw Errors.forbidden(perm);
      }
      return currentUser as never;
    },
  };
});

beforeEach(() => {
  auditSpy.mockClear();
  for (const k of Object.keys(created)) delete created[k];
  for (const m of Object.values(tx)) {
    if (typeof m === 'object' && m !== null) {
      for (const f of Object.values(m)) if (typeof f === 'function' && 'mockClear' in f) (f as any).mockClear();
    } else if (typeof m === 'function' && 'mockClear' in m) (m as any).mockClear();
  }
  itemRow = { id: 1, item_code: 'SUIT-0001', status: 'RENTED' };
  rentalLine = { id: 10 };            // العقد يحوي القطعة
  rentalRow = { rentalNo: 'R-2026-000001' };
  categoryRow = { id: 6, nameAr: 'تنظيف' };
  currentUser = {
    id: 1, employeeId: 1,
    permissions: new Set(['items.view', 'items.manage']),
  };
});

// ==================== A–F: القبول والرفض ====================

describe('★ A — تنظيف بلا عقد يُقبل', () => {
  it('يُنشأ السجل و rentalId = null', async () => {
    const { startUpkeep } = await import('@/services/upkeep.service');
    await startUpkeep({ itemId: 1, kind: 'CLEANING', cost: 150, paymentMethodId: 1 });

    expect(created.cleaning[0]).toMatchObject({ itemId: 1, rentalId: null });
  });

  it('لا يُستعلم عن العقد أصلًا حين لا يُرسل', async () => {
    const { startUpkeep } = await import('@/services/upkeep.service');
    const { prisma } = await import('@/lib/db');
    await startUpkeep({ itemId: 1, kind: 'CLEANING', cost: 0 });
    expect(prisma.rentalItem.findFirst).not.toHaveBeenCalled();
  });
});

describe('★ B — عقد صحيح لنفس القطعة يُقبل', () => {
  it('يُحفظ rentalId', async () => {
    const { startUpkeep } = await import('@/services/upkeep.service');
    await startUpkeep({
      itemId: 1, kind: 'CLEANING', cost: 150, paymentMethodId: 1, rentalId: 55,
    });
    expect(created.cleaning[0]).toMatchObject({ itemId: 1, rentalId: 55 });
  });

  it('★ التحقق يمر عبر rental_items لا بوجود العقد فقط', async () => {
    const { startUpkeep } = await import('@/services/upkeep.service');
    const { prisma } = await import('@/lib/db');
    await startUpkeep({ itemId: 1, kind: 'CLEANING', cost: 0, rentalId: 55 });

    expect(prisma.rentalItem.findFirst).toHaveBeenCalledWith(
      expect.objectContaining({ where: { rentalId: 55, itemId: 1 } }),
    );
  });

  it('يسجّل العقد في التدقيق', async () => {
    const { startUpkeep } = await import('@/services/upkeep.service');
    await startUpkeep({ itemId: 1, kind: 'CLEANING', cost: 0, rentalId: 55 });
    expect(auditSpy.mock.calls[0][0].after).toMatchObject({ rentalId: 55, revenueImpact: '0' });
  });
});

describe('★ C — عقد يخص قطعة مختلفة يُرفض', () => {
  it('★ يُرفض ولا يُنشأ سجل ولا مصروف', async () => {
    rentalLine = null;                 // العقد لا يحوي هذه القطعة
    rentalRow = { rentalNo: 'R-2026-000009' };
    const { startUpkeep } = await import('@/services/upkeep.service');

    await expect(startUpkeep({
      itemId: 1, kind: 'CLEANING', cost: 150, paymentMethodId: 1, rentalId: 99,
    })).rejects.toMatchObject({ code: 'BUSINESS_RULE' });

    expect(created.cleaning).toBeUndefined();
    expect(created.expense).toBeUndefined();
    expect(auditSpy).not.toHaveBeenCalled();
  });

  it('الرسالة تذكر رقم العقد ولا تكشف تفاصيل داخلية', async () => {
    rentalLine = null;
    rentalRow = { rentalNo: 'R-2026-000009' };
    const { startUpkeep } = await import('@/services/upkeep.service');
    const err = await startUpkeep({ itemId: 1, kind: 'CLEANING', cost: 0, rentalId: 99 })
      .catch((e) => e);
    expect(err.message).toContain('R-2026-000009');
    expect(err.message).toContain('لا يحتوي هذه القطعة');
    expect(err.message).not.toMatch(/SQL|prisma|rental_items/i);
  });
});

describe('★ D — عقد غير موجود يُرفض', () => {
  it('★ يُرفض برسالة واضحة', async () => {
    rentalLine = null;
    rentalRow = null;                  // العقد نفسه غير موجود
    const { startUpkeep } = await import('@/services/upkeep.service');

    await expect(startUpkeep({ itemId: 1, kind: 'CLEANING', cost: 0, rentalId: 12345 }))
      .rejects.toMatchObject({ code: 'BUSINESS_RULE', message: expect.stringContaining('غير موجود') });
    expect(created.cleaning).toBeUndefined();
  });
});

describe('★ E/F — الربط للتنظيف فقط', () => {
  it('★ ربط العقد بصيانة يُرفض (خارج النطاق المعتمد)', async () => {
    itemRow = { id: 1, item_code: 'SUIT-0001', status: 'AVAILABLE' };
    categoryRow = { id: 5, nameAr: 'صيانة' };
    const { startUpkeep } = await import('@/services/upkeep.service');

    await expect(startUpkeep({ itemId: 1, kind: 'MAINTENANCE', cost: 0, rentalId: 55 }))
      .rejects.toMatchObject({ code: 'BUSINESS_RULE' });
    expect(created.maintenance).toBeUndefined();
  });

  it('★ التحقق يقع قبل أي كتابة', () => {
    const src = readFileSync('src/services/upkeep.service.ts', 'utf8');
    const validateIdx = src.indexOf('const line = await prisma.rentalItem.findFirst');
    const txIdx = src.indexOf('return prisma.$transaction');
    expect(validateIdx).toBeGreaterThan(0);
    expect(validateIdx).toBeLessThan(txIdx);
  });
});

// ==================== G: منع اليتيم ====================

describe('★ G — حذف عقد مرتبط مرفوض', () => {
  it('★ ON DELETE RESTRICT في الترحيل', () => {
    const mig = readFileSync(
      'prisma/migrations/20260819_cleaning_rental_link/migration.sql', 'utf8');
    expect(mig).toContain('ON DELETE RESTRICT');
    expect(mig).toContain('REFERENCES rentals(id)');
  });

  it('★ onDelete: Restrict في المخطط', () => {
    const schema = readFileSync('prisma/schema.prisma', 'utf8');
    const model = schema.slice(
      schema.indexOf('model CleaningRecord'),
      schema.indexOf('}', schema.indexOf('model CleaningRecord')));
    expect(model).toContain('onDelete: Restrict');
  });

  it('العقود محمية أصلًا من الحذف (خط دفاع أول)', () => {
    const sql = readFileSync('prisma/sql/01_constraints.sql', 'utf8');
    expect(sql).toContain("'rentals'");
    expect(sql).toContain('prevent_hard_delete');
  });
});

// ==================== H: لا ملء رجعي ====================

describe('★ H — لا ملء رجعي للسجلات التاريخية', () => {
  it('★ الترحيل لا يحوي UPDATE ولا INSERT', () => {
    const mig = readFileSync(
      'prisma/migrations/20260819_cleaning_rental_link/migration.sql', 'utf8');
    expect(mig).not.toMatch(/\bUPDATE\b/i);
    expect(mig).not.toMatch(/\bINSERT\b/i);
    expect(mig).not.toMatch(/\bSET rental_id\b/i);
  });

  it('★ العمود بلا قيمة افتراضية — يبدأ NULL', () => {
    const mig = readFileSync(
      'prisma/migrations/20260819_cleaning_rental_link/migration.sql', 'utf8');
    expect(mig).toContain('ADD COLUMN IF NOT EXISTS rental_id integer;');
    expect(mig).not.toContain('rental_id integer DEFAULT');
    expect(mig).not.toContain('NOT NULL');
  });

  it('★ لا استنتاج من أي مصدر في الخدمة', () => {
    const src = readFileSync('src/services/upkeep.service.ts', 'utf8');
    // الحقل يُؤخذ من المدخل فقط
    expect(src).toContain('rentalId: input.rentalId ?? null');
    // لا استنتاج من آخر عقد أو سجل حالة أو تاريخ
    expect(src).not.toMatch(/lastRental|latestRental|orderBy:\s*\{\s*rentalId:\s*'desc'\s*\}[\s\S]{0,200}cleaningRecord\.create/);
  });

  it('★ الاقتراح قراءة فقط ولا يربط', () => {
    const src = readFileSync('src/services/upkeep.service.ts', 'utf8');
    const fn = src.slice(
      src.indexOf('export async function suggestRentalsForItem'),
      src.indexOf('// ============================ البدء'));
    expect(fn).not.toContain('.create(');
    expect(fn).not.toContain('.update(');
    expect(fn).toContain('لا يُربط أي عقد تلقائيًا');
  });
});

// ==================== I/J: صفر أثر مالي ====================

describe('★ I/J — rentalId بيانات وصفية بلا أثر مالي', () => {
  it('★ المصروف نفسه سواء رُبط العقد أو لا', async () => {
    const { startUpkeep } = await import('@/services/upkeep.service');

    await startUpkeep({ itemId: 1, kind: 'CLEANING', cost: 150, paymentMethodId: 1 });
    const withoutLink = { ...created.expense[0] };

    for (const k of Object.keys(created)) delete created[k];
    await startUpkeep({
      itemId: 1, kind: 'CLEANING', cost: 150, paymentMethodId: 1, rentalId: 55,
    });
    const withLink = { ...created.expense[0] };

    expect(withLink.amount).toBe(withoutLink.amount);
    expect(withLink.cashPaidAmount).toBe(withoutLink.cashPaidAmount);
    expect(withLink.categoryId).toBe(withoutLink.categoryId);
  });

  it('★ تصنيف الحركات لم يتغيّر', () => {
    expect(auditClassification()).toEqual([]);
  });

  it('★ التنظيف يبقى مصروفًا ولا يصير إيرادًا', () => {
    expect(expenseOf([{ type: 'EXPENSE_PAYMENT', amount: 150 }]).toString()).toBe('150');
    expect(revenueOf([{ type: 'EXPENSE_PAYMENT', amount: 150 }]).toString()).toBe('0');
  });

  it('★ ربحية القطعة بلا تغيير', () => {
    const r = lifetimeProfit({
      rentalRevenue: 9000, feesRevenue: 500, saleRevenue: 1300,
      purchaseCost: 6000, maintenanceCost: 800, cleaningCost: 450,
    });
    expect(r.profit.toString()).toBe('3550');
  });

  it('★ لا Trigger مالي أُضيف أو عُدِّل', () => {
    const sql = readFileSync('prisma/sql/01_constraints.sql', 'utf8');
    expect(sql).not.toContain('cleaning_records_rental');
    expect(sql).not.toContain('ON cleaning_records');
  });
});

// ==================== النطاق ====================

describe('★ انضباط النطاق', () => {
  it('★ لا صلاحية جديدة', async () => {
    const { PERMISSIONS } = await import('../src/lib/auth/permissions');
    expect(PERMISSIONS.length).toBe(56);
  });

  it('★ لا جدول جديد', () => {
    const schema = readFileSync('prisma/schema.prisma', 'utf8');
    expect((schema.match(/^model /gm) ?? []).length).toBe(38);
  });

  it('★ لا فهرس أُضيف', () => {
    const mig = readFileSync(
      'prisma/migrations/20260819_cleaning_rental_link/migration.sql', 'utf8');
    expect(mig).not.toMatch(/CREATE\s+(UNIQUE\s+)?INDEX/i);
  });

  it('★ M4 لم يُمس — الإرجاع لا ينشئ ولا يربط سجل تنظيف', () => {
    const src = readFileSync('src/services/return.service.ts', 'utf8');
    // لا إنشاء سجل تنظيف ولا استيراد لخدمة الصيانة/التنظيف
    expect(src).not.toContain('cleaningRecord');
    expect(src).not.toContain('upkeep.service');
    expect(src).not.toContain('startUpkeep');
    // ملاحظة: rentalId موجود في M4 أصلًا لدفعات الإرجاع — سياق مختلف تمامًا
  });

  it('★ الواجهة توضّح أنه اقتراح لا استنتاج', () => {
    const ui = readFileSync('src/components/UpkeepPanel.tsx', 'utf8');
    expect(ui).toContain('اقتراحات');
    expect(ui).toContain('وليست رابطًا مستنتجًا');
    expect(ui).toContain('بلا عقد');
    // لا يُرسل إلا إن اختاره المستخدم
    expect(ui).toContain("rentalId !== '' ? rentalId : undefined");
  });
});
