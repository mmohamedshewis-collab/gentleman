import { route } from '@/lib/api';
import { login, loginSchema } from '@/services/auth.service';

export const POST = route({
  schema: loginSchema,
  handler: ({ input }) => login(input),
});
