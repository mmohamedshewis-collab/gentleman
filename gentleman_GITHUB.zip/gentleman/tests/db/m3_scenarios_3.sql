\set ON_ERROR_STOP off
\pset pager off
\t on

-- إجراء الإلغاء كما تنفّذه الخدمة
CREATE OR REPLACE FUNCTION do_void(p_rental int, p_reason text) RETURNS void AS $$
DECLARE r record; v_bal numeric; v_status text; v_ins numeric;
BEGIN
  SELECT status::text, insurance_amount INTO v_status, v_ins FROM rentals WHERE id = p_rental FOR UPDATE;
  IF v_status IS NULL THEN RAISE EXCEPTION 'العقد غير موجود'; END IF;
  IF v_status <> 'ACTIVE' THEN RAISE EXCEPTION 'لا يمكن إلغاء عقد حالته %', v_status; END IF;
  IF EXISTS (SELECT 1 FROM returns WHERE rental_id = p_rental) THEN
    RAISE EXCEPTION 'لا يمكن إلغاء عقد سُجّل عليه إرجاع';
  END IF;

  FOR r IN SELECT ri.id, ri.item_id FROM rental_items ri WHERE ri.rental_id = p_rental AND ri.status='OUT' LOOP
    UPDATE product_items SET status='AVAILABLE', rental_count = GREATEST(rental_count-1,0) WHERE id = r.item_id;
    INSERT INTO item_status_history (item_id, from_status, to_status, reason, ref_type, ref_id, user_id)
    VALUES (r.item_id, 'RENTED', 'AVAILABLE', 'إلغاء عقد: ' || p_reason, 'Rental', p_rental, 1);
    INSERT INTO inventory_transactions (item_id, trx_date, type, ref_type, ref_id, note, created_by)
    VALUES (r.item_id, CURRENT_DATE, 'ADJUST', 'Rental', p_rental, 'إلغاء عقد', 1);
    UPDATE rental_items SET status='VOIDED' WHERE id = r.id;
  END LOOP;

  UPDATE item_bookings SET is_active=false WHERE source_type='RENTAL' AND source_id=p_rental;
  UPDATE payments SET is_voided=true, void_reason=p_reason WHERE rental_id=p_rental AND is_voided=false;

  IF v_ins > 0 THEN
    SELECT COALESCE((SELECT balance_after FROM insurance_transactions ORDER BY id DESC LIMIT 1),0) INTO v_bal;
    INSERT INTO insurance_transactions (type, rental_id, amount, balance_after, reason, created_by)
    VALUES ('REFUNDED', p_rental, v_ins, v_bal - v_ins, 'إلغاء عقد: ' || p_reason, 1);
  END IF;

  UPDATE rentals SET status='VOIDED', void_reason=p_reason, voided_by=1, voided_at=now() WHERE id=p_rental;

  INSERT INTO audit_logs (user_id, action, entity_type, entity_id, before_json, after_json, reason)
  VALUES (1, 'rental.void', 'Rental', p_rental::text,
          jsonb_build_object('status','ACTIVE'), jsonb_build_object('status','VOIDED'), p_reason);
END;
$$ LANGUAGE plpgsql;

\echo '=== T13: إلغاء عقد تأجير ==='
SELECT 'قبل الإلغاء: حالة العقد 7=' || status || ' | القطع=' ||
       (SELECT string_agg(pi.item_code||'='||pi.status,', ') FROM rental_items ri JOIN product_items pi ON pi.id=ri.item_id WHERE ri.rental_id=7)
  FROM rentals WHERE id=7;
SELECT 'رصيد التأمين قبل=' || balance_after FROM insurance_transactions ORDER BY id DESC LIMIT 1;
SELECT do_void(7, 'العميل ألغى المناسبة');
SELECT 'بعد الإلغاء: حالة العقد=' || status || ' السبب=' || void_reason FROM rentals WHERE id=7;
SELECT 'حالة السطور=' || string_agg(DISTINCT status::text, ', ') FROM rental_items WHERE rental_id=7;
SELECT 'حالة القطع=' || string_agg(pi.item_code||'='||pi.status,', ')
  FROM rental_items ri JOIN product_items pi ON pi.id=ri.item_id WHERE ri.rental_id=7;
SELECT 'حجوزات نشطة متبقية=' || count(*) FROM item_bookings WHERE source_type='RENTAL' AND source_id=7 AND is_active;
SELECT 'دفعات غير ملغاة متبقية=' || count(*) FROM payments WHERE rental_id=7 AND is_voided=false;
SELECT 'دفعات ملغاة (محفوظة لا محذوفة)=' || count(*) FROM payments WHERE rental_id=7 AND is_voided;
SELECT 'رصيد التأمين بعد=' || balance_after FROM insurance_transactions ORDER BY id DESC LIMIT 1;

\echo ''
\echo '=== T14: إعادة تأجير القطع المحرَّرة بعد الإلغاء (يجب أن تنجح) ==='
SELECT 'العقد الجديد ' || do_rental(ARRAY['SUIT-0003'], 2, 500, 0, 0, 0, 0);

\echo ''
\echo '=== T15: محاولة إلغاء العقد مرة ثانية (يجب أن تُرفض) ==='
SELECT do_void(7, 'محاولة ثانية');

\echo ''
\echo '=== T16: محاولة إلغاء عقد عليه إرجاع (يجب أن تُرفض) ==='
INSERT INTO returns (rental_id, return_date) VALUES (10, CURRENT_DATE);
SELECT do_void(10, 'محاولة إلغاء بعد إرجاع');

\echo ''
\echo '=== T17: تغيير حالة عقد ملغى (يجب أن يُرفض) ==='
UPDATE rentals SET status='ACTIVE' WHERE id=7;

\echo ''
\echo '=== T18: سجل التدقيق ==='
SELECT action || ' | كيان=' || entity_type || ' | مرجع=' || entity_id ||
       ' | السبب=' || COALESCE(reason,'—') FROM audit_logs ORDER BY id;
SELECT 'إجمالي سجلات التدقيق=' || count(*) FROM audit_logs;
DELETE FROM audit_logs WHERE id = 1;
