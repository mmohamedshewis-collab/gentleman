import { z } from 'zod';
import { prisma } from '@/lib/db';
import { Errors } from '@/lib/errors';
import { writeAudit } from '@/lib/audit';
import { requirePermission, can } from '@/lib/auth/rbac';
import { round2 } from '@/lib/money';
import { businessToday } from '@/lib/date';
import { overdueItemRefs, overdueMap } from '@/lib/inventory/overdue';
import {
  canTransition, canBeRented, canBeSold, manualTargets,
  STATUS_LABELS, type ItemStatus,
} from '@/lib/inventory/item-state';
import {
  buildItemCode, parseSequence, validateBarcode, defaultBarcode, normalizePrefix,
  normalizeBarcode,
} from '@/lib/inventory/codes';

const money = z.coerce.number().min(0).max(9999999);

// ============================ إنشاء القطع ============================

export const createItemsSchema = z.object({
  productId: z.number().int().positive(),
  count: z.number().int().min(1, 'العدد يجب أن يكون واحدًا على الأقل').max(200, 'الحد الأقصى 200 قطعة في المرة'),
  codePrefix: z.string().min(1).max(8),
  purchaseCost: money,
  purchaseDate: z.string().optional(),
  supplierId: z.number().int().positive().nullable().optional(),
  rentalPrice: money.nullable().optional(),
  salePrice: money.nullable().optional(),
  barcodes: z.array(z.string()).optional(),
});

/**
 * إنشاء قطع فعلية لمنتج.
 * تكلفة الشراء تُحفظ لتحليل ربحية القطعة تشغيليًا فقط — ولا تُعامل كمصروف.
 */
export async function createItems(input: z.infer<typeof createItemsSchema>) {
  const actor = await requirePermission('items.manage');

  const product = await prisma.product.findUnique({ where: { id: input.productId } });
  if (!product) throw Errors.notFound('المنتج');

  const prefix = normalizePrefix(input.codePrefix);

  if (input.barcodes && input.barcodes.length !== input.count) {
    throw Errors.rule('عدد الباركودات المدخلة لا يطابق عدد القطع.');
  }
  for (const b of input.barcodes ?? []) {
    const err = validateBarcode(b.trim());
    if (err) throw Errors.rule(err);
  }
  if (input.barcodes) {
    const set = new Set(input.barcodes.map((b) => b.trim()));
    if (set.size !== input.barcodes.length) throw Errors.rule('يوجد باركود مكرر ضمن القائمة المدخلة.');
  }

  const purchaseDate = input.purchaseDate ? new Date(input.purchaseDate) : businessToday();

  return prisma.$transaction(async (tx) => {
    // نبدأ من آخر رقم تسلسلي مستخدم لنفس البادئة
    const last = await tx.productItem.findFirst({
      where: { itemCode: { startsWith: `${prefix}-` } },
      orderBy: { itemCode: 'desc' },
      select: { itemCode: true },
    });
    let seq = (last ? parseSequence(last.itemCode) ?? 0 : 0) + 1;

    const created: { id: number; itemCode: string; barcode: string }[] = [];

    for (let i = 0; i < input.count; i++) {
      const itemCode = buildItemCode(prefix, seq++);
      const barcode = (input.barcodes?.[i] ?? defaultBarcode(itemCode)).trim();

      const item = await tx.productItem.create({
        data: {
          itemCode,
          barcode,
          productId: input.productId,
          supplierId: input.supplierId ?? null,
          purchaseDate,
          purchaseCost: round2(input.purchaseCost).toString(),
          rentalPrice: input.rentalPrice != null ? round2(input.rentalPrice).toString() : null,
          salePrice: input.salePrice != null ? round2(input.salePrice).toString() : null,
          status: 'AVAILABLE',
        },
        select: { id: true, itemCode: true, barcode: true },
      });

      await tx.itemStatusHistory.create({
        data: {
          itemId: item.id,
          fromStatus: 'AVAILABLE',
          toStatus: 'AVAILABLE',
          reason: 'إضافة القطعة إلى المخزون',
          userId: actor.id,
        },
      });

      await tx.inventoryTransaction.create({
        data: {
          itemId: item.id,
          trxDate: purchaseDate,
          type: 'PURCHASE',
          refType: 'Product',
          refId: input.productId,
          note: 'شراء وإضافة للمخزون',
          createdBy: actor.id,
        },
      });

      created.push(item);
    }

    await writeAudit(
      {
        userId: actor.id,
        action: 'items.create',
        entityType: 'ProductItem',
        entityId: created.map((c) => c.itemCode).join(','),
        after: { productId: input.productId, count: created.length, purchaseCost: input.purchaseCost },
      },
      tx,
    );

    return { created, count: created.length };
  });
}

// ============================ البحث والمسح ============================

export const scanSchema = z.object({ barcode: z.string().min(1, 'الباركود مطلوب') });

/** مسح الباركود — أسرع مسار في النظام، يعرض كل ما يحتاجه الموظف فورًا. */
export async function scanItem(barcode: string) {
  await requirePermission('items.view');
  const code = normalizeBarcode(barcode);

  const item = await prisma.productItem.findFirst({
    where: { OR: [{ barcode: code }, { itemCode: code }] },
    include: {
      product: { include: { category: { select: { nameAr: true } }, brand: { select: { name: true } } } },
    },
  });

  if (!item) throw Errors.notFound(`القطعة صاحبة الباركود "${code}"`);

  const status = item.status as ItemStatus;
  return {
    id: item.id,
    itemCode: item.itemCode,
    barcode: item.barcode,
    productName: item.product.nameAr,
    category: item.product.category?.nameAr ?? null,
    brand: item.product.brand?.name ?? null,
    size: item.product.size,
    color: item.product.color,
    status,
    statusLabel: STATUS_LABELS[status],
    rentalPrice: item.rentalPrice ?? item.product.rentalPrice,
    salePrice: item.salePrice ?? item.product.salePrice,
    rentalCount: item.rentalCount,
    lastRentalDate: item.lastRentalDate,
    lastReturnDate: item.lastReturnDate,
    canBeRented: canBeRented(status),
    canBeSold: canBeSold(status),
  };
}

export const itemQuerySchema = z.object({
  q: z.string().optional(),
  status: z.string().optional(),
  productId: z.coerce.number().int().optional(),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(10).max(200).default(50),
});

export async function listItems(input: z.infer<typeof itemQuerySchema>) {
  await requirePermission('items.view');
  const where: Record<string, unknown> = {};
  if (input.status) where.status = input.status;
  if (input.productId) where.productId = input.productId;
  if (input.q) {
    where.OR = [
      { itemCode: { contains: input.q, mode: 'insensitive' } },
      { barcode: { contains: input.q, mode: 'insensitive' } },
      { product: { nameAr: { contains: input.q, mode: 'insensitive' } } },
    ];
  }

  const [rows, total] = await Promise.all([
    prisma.productItem.findMany({
      where,
      include: { product: { select: { nameAr: true, size: true, color: true } } },
      orderBy: { itemCode: 'asc' },
      skip: (input.page - 1) * input.pageSize,
      take: input.pageSize,
    }),
    prisma.productItem.count({ where }),
  ]);

  // ★ العرض فقط: القطعة المؤجرة المستحقة تُعرض «متأخرة» من مصدر الحقيقة الواحد.
  //   حالتها المخزَّنة تبقى RENTED ولا تُكتب — آلة الحالة لم تتغيّر.
  const overdue = overdueMap(await overdueItemRefs(prisma));

  const decorated = rows.map((r) => {
    const late = r.status === 'RENTED' ? overdue.get(r.id) : undefined;
    const displayStatus = (late ? 'OVERDUE' : r.status) as ItemStatus;
    return {
      ...r,
      displayStatus,
      displayStatusLabel: STATUS_LABELS[displayStatus],
      isOverdue: Boolean(late),
      daysLate: late?.daysLate ?? 0,
      overdueRentalNo: late?.rentalNo ?? null,
    };
  });

  return { rows: decorated, total, page: input.page, pageSize: input.pageSize };
}

/** بطاقة القطعة: البيانات + السجل الكامل + الربحية التشغيلية. */
export async function getItemDetails(id: number) {
  const user = await requirePermission('items.view');

  const item = await prisma.productItem.findUnique({
    where: { id },
    include: {
      product: { include: { category: true, brand: true } },
      supplier: true,
      statusHistory: { orderBy: { createdAt: 'desc' }, take: 100 },
      inventoryTrx: { orderBy: { createdAt: 'desc' }, take: 100 },
      maintenance: { orderBy: { startDate: 'desc' } },
      cleaning: { orderBy: { sentDate: 'desc' } },
    },
  });
  if (!item) throw Errors.notFound('القطعة');

  const status = item.status as ItemStatus;
  const showCost = can(user, 'products.manage');

  return {
    item,
    status,
    statusLabel: STATUS_LABELS[status],
    availableTransitions: manualTargets(status),
    showCost,
  };
}

export async function getItemHistory(id: number) {
  await requirePermission('items.view');
  const [statusHistory, inventoryTrx] = await Promise.all([
    prisma.itemStatusHistory.findMany({
      where: { itemId: id },
      orderBy: { createdAt: 'desc' },
    }),
    prisma.inventoryTransaction.findMany({
      where: { itemId: id },
      orderBy: { createdAt: 'desc' },
    }),
  ]);
  return { statusHistory, inventoryTrx };
}

// ============================ تغيير الحالة ============================

export const changeStatusSchema = z.object({
  itemId: z.number().int().positive(),
  toStatus: z.enum([
    'AVAILABLE', 'RENTED', 'OVERDUE', 'RESERVED', 'SOLD',
    'DAMAGED', 'LOST', 'CLEANING', 'MAINTENANCE', 'DISPOSED',
  ]),
  reason: z.string().min(3, 'السبب مطلوب').max(300),
});

/**
 * تغيير حالة القطعة يدويًا من شاشة المخزون.
 * يمر إجباريًا بآلة الحالة، ويقفل السطر لمنع التعارض بين مستخدمين.
 */
export async function changeItemStatus(input: z.infer<typeof changeStatusSchema>) {
  const actor = await requirePermission('items.manage');

  return prisma.$transaction(async (tx) => {
    // قفل السطر: أي عملية متزامنة على نفس القطعة تنتظر ثم تُقيَّم من جديد
    const locked = await tx.$queryRaw<{ id: number; status: ItemStatus }[]>`
      SELECT id, status FROM product_items WHERE id = ${input.itemId} FOR UPDATE
    `;
    if (locked.length === 0) throw Errors.notFound('القطعة');

    const from = locked[0].status;
    const to = input.toStatus as ItemStatus;

    const check = canTransition(from, to, { manual: true });
    if (!check.allowed) throw Errors.rule(check.reason!);

    // إخراج القطعة من الخدمة (تلف/فقد/استبعاد) يتطلب صلاحية إضافية
    if (check.requiresOverride && !can(actor, 'items.status.override')) {
      throw Errors.forbidden('items.status.override');
    }

    const updated = await tx.productItem.update({
      where: { id: input.itemId },
      data: {
        status: to,
        disposedAt: to === 'DISPOSED' ? new Date() : undefined,
        isActive: to === 'DISPOSED' ? false : undefined,
      },
    });

    await tx.itemStatusHistory.create({
      data: {
        itemId: input.itemId,
        fromStatus: from,
        toStatus: to,
        reason: input.reason,
        refType: 'Manual',
        userId: actor.id,
      },
    });

    if (to === 'DISPOSED' || to === 'LOST') {
      await tx.inventoryTransaction.create({
        data: {
          itemId: input.itemId,
          trxDate: businessToday(),
          type: 'WRITE_OFF',
          refType: 'Manual',
          note: input.reason,
          createdBy: actor.id,
        },
      });
    }

    await writeAudit(
      {
        userId: actor.id,
        action: 'item.status_change',
        entityType: 'ProductItem',
        entityId: input.itemId,
        before: { status: from },
        after: { status: to },
        reason: input.reason,
      },
      tx,
    );

    return { id: updated.id, from, to, label: STATUS_LABELS[to] };
  });
}

// ============================ تعديل الباركود ============================

export const updateBarcodeSchema = z.object({
  itemId: z.number().int().positive(),
  barcode: z.string().min(4).max(32),
});

export async function updateItemBarcode(input: z.infer<typeof updateBarcodeSchema>) {
  const actor = await requirePermission('items.manage');
  const barcode = normalizeBarcode(input.barcode);

  const err = validateBarcode(barcode);
  if (err) throw Errors.rule(err);

  const before = await prisma.productItem.findUnique({ where: { id: input.itemId } });
  if (!before) throw Errors.notFound('القطعة');

  const taken = await prisma.productItem.findUnique({ where: { barcode } });
  if (taken && taken.id !== input.itemId) {
    throw Errors.conflict(`الباركود "${barcode}" مستخدم بالفعل للقطعة ${taken.itemCode}.`);
  }

  return prisma.$transaction(async (tx) => {
    const after = await tx.productItem.update({
      where: { id: input.itemId },
      data: { barcode },
    });
    await writeAudit(
      {
        userId: actor.id,
        action: 'item.barcode_change',
        entityType: 'ProductItem',
        entityId: input.itemId,
        before: { barcode: before.barcode },
        after: { barcode },
      },
      tx,
    );
    return { id: after.id, barcode };
  });
}
