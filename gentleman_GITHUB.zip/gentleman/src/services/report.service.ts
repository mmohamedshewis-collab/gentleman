import { z } from 'zod';
import { Decimal } from 'decimal.js';
import { prisma } from '@/lib/db';
import { Errors } from '@/lib/errors';
import { requirePermission } from '@/lib/auth/rbac';
import { periodBounds, toBusinessDate, businessToday, formatDate, formatDateTime } from '@/lib/date';
import { round2, add, sub } from '@/lib/money';
import { STATUS_LABELS, type ItemStatus } from '@/lib/inventory/item-state';
import { overdueRentalWhere, daysLateOf } from '@/lib/inventory/overdue';
import {
  buildTotals, money, sumMoney, NOTES,
  type ReportResult, type ReportRow, type ReportColumn,
} from '@/lib/reports/report-types';

/**
 * التقارير — طبقة قراءة فقط.
 * ⛔ لا تُنشئ ولا تعدّل ولا تحذف · لا منطق مالي جديد · لا تغيير في قاعدة البيانات.
 * كل رقم مشتق من مصادر M0–M6 بالقواعد المعتمدة نفسها.
 */

export const REPORT_KEYS = [
  'daily-sales', 'daily-rentals', 'monthly-sales', 'monthly-rentals',
  'revenue', 'expenses', 'net-profit', 'outstanding', 'insurance-balance',
  'inventory', 'available-items', 'rented-items', 'overdue-items',
  'lost-damaged', 'item-profitability', 'rental-performance',
  'sales-performance', 'payment-methods',
] as const;

export type ReportKey = (typeof REPORT_KEYS)[number];

/** التقارير المالية تحتاج صلاحية أعلى — الباقي تشغيلي. */
const FINANCIAL: ReportKey[] = [
  'revenue', 'expenses', 'net-profit', 'outstanding',
  'insurance-balance', 'item-profitability', 'payment-methods',
];

export const reportQuerySchema = z.object({
  key: z.enum(REPORT_KEYS),
  from: z.string().optional(),
  to: z.string().optional(),
  customerId: z.coerce.number().int().positive().optional(),
  employeeId: z.coerce.number().int().positive().optional(),
  productId: z.coerce.number().int().positive().optional(),
  itemId: z.coerce.number().int().positive().optional(),
  status: z.string().optional(),
  paymentMethodId: z.coerce.number().int().positive().optional(),
  categoryId: z.coerce.number().int().positive().optional(),
});

export type ReportQuery = z.infer<typeof reportQuerySchema>;

// ============================ أدوات مشتركة ============================

function resolvePeriod(input: ReportQuery) {
  const today = formatDate(businessToday());
  const from = input.from ?? `${today.slice(0, 8)}01`;
  const to = input.to ?? today;
  const { start, end } = periodBounds(from, to);
  return { from, to, start, end, label: `من ${from} إلى ${to}` };
}

async function describeFilters(input: ReportQuery) {
  const out: { label: string; value: string }[] = [];
  if (input.customerId) {
    const c = await prisma.customer.findUnique({ where: { id: input.customerId } });
    if (c) out.push({ label: 'العميل', value: c.fullName });
  }
  if (input.employeeId) {
    const e = await prisma.employee.findUnique({ where: { id: input.employeeId } });
    if (e) out.push({ label: 'الموظف', value: e.fullName });
  }
  if (input.productId) {
    const p = await prisma.product.findUnique({ where: { id: input.productId } });
    if (p) out.push({ label: 'المنتج', value: p.nameAr });
  }
  if (input.itemId) {
    const i = await prisma.productItem.findUnique({ where: { id: input.itemId } });
    if (i) out.push({ label: 'القطعة', value: i.itemCode });
  }
  if (input.paymentMethodId) {
    const m = await prisma.paymentMethod.findUnique({ where: { id: input.paymentMethodId } });
    if (m) out.push({ label: 'طريقة الدفع', value: m.nameAr });
  }
  if (input.categoryId) {
    const c = await prisma.expenseCategory.findUnique({ where: { id: input.categoryId } });
    if (c) out.push({ label: 'فئة المصروف', value: c.nameAr });
  }
  if (input.status) {
    out.push({ label: 'الحالة', value: STATUS_LABELS[input.status as ItemStatus] ?? input.status });
  }
  return out;
}

function assemble(
  key: string, title: string, period: string,
  appliedFilters: { label: string; value: string }[],
  columns: ReportColumn[], rows: ReportRow[], notes: string[],
): ReportResult {
  return {
    key, title, period, appliedFilters, columns, rows,
    totals: buildTotals(columns, rows),
    notes,
    generatedAt: formatDateTime(new Date()),
  };
}

// ============================ التقارير ============================

async function dailySales(q: ReportQuery, p: ReturnType<typeof resolvePeriod>): Promise<ReportRow[]> {
  const sales = await prisma.sale.findMany({
    where: {
      status: 'COMPLETED',
      createdAt: { gte: p.start, lte: p.end },
      customerId: q.customerId,
      employeeId: q.employeeId,
    },
    include: { customer: true, employee: true, items: true },
    orderBy: { id: 'asc' },
  });

  return sales.map((s) => ({
    invoiceNo: s.invoiceNo,
    date: formatDate(s.saleDate),
    customer: s.customer.isWalkIn ? 'عميل نقدي' : s.customer.fullName,
    employee: s.employee?.fullName ?? '—',
    itemCount: s.items.length,
    subtotal: money(s.subtotal.toString()),
    discount: money(s.discount.toString()),
    netAmount: money(s.netAmount.toString()),
    totalCost: money(s.totalCost.toString()),
    grossProfit: sub(s.netAmount.toString(), s.totalCost.toString()).toString(),
  }));
}

async function dailyRentals(q: ReportQuery, p: ReturnType<typeof resolvePeriod>): Promise<ReportRow[]> {
  const rentals = await prisma.rental.findMany({
    where: {
      status: { not: 'VOIDED' },
      createdAt: { gte: p.start, lte: p.end },
      customerId: q.customerId,
      employeeId: q.employeeId,
    },
    include: { customer: true, employee: true, items: true },
    orderBy: { id: 'asc' },
  });

  return rentals.map((r) => ({
    rentalNo: r.rentalNo,
    date: formatDate(r.rentalDate),
    expectedReturn: formatDate(r.expectedReturnDate),
    customer: r.customer.isWalkIn ? 'عميل نقدي' : r.customer.fullName,
    employee: r.employee?.fullName ?? '—',
    itemCount: r.items.length,
    netAmount: money(r.netAmount.toString()),
    extraCharges: money(r.extraCharges.toString()),
    paidAmount: money(r.paidAmount.toString()),
    remaining: money(r.remainingAmount.toString()),
    insurance: money(r.insuranceAmount.toString()),
    status: r.status,
  }));
}

/** تجميع شهري مشترك للمبيعات والتأجير. */
function groupByMonth(
  rows: { date: Date; values: Record<string, Decimal.Value> }[],
): ReportRow[] {
  const map = new Map<string, Record<string, Decimal>>();
  for (const r of rows) {
    const m = `${r.date.getUTCFullYear()}-${String(r.date.getUTCMonth() + 1).padStart(2, '0')}`;
    const acc = map.get(m) ?? {};
    for (const [k, v] of Object.entries(r.values)) {
      acc[k] = (acc[k] ?? new Decimal(0)).plus(round2(v));
    }
    acc.count = (acc.count ?? new Decimal(0)).plus(1);
    map.set(m, acc);
  }
  return [...map.entries()]
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([month, acc]) => {
      const row: ReportRow = { month, count: acc.count.toNumber() };
      for (const [k, v] of Object.entries(acc)) {
        if (k !== 'count') row[k] = round2(v).toString();
      }
      return row;
    });
}

async function revenueReport(q: ReportQuery, p: ReturnType<typeof resolvePeriod>): Promise<ReportRow[]> {
  const [rentals, sales, returns, insurance] = await Promise.all([
    prisma.rental.aggregate({
      _sum: { netAmount: true },
      where: { status: { not: 'VOIDED' }, createdAt: { gte: p.start, lte: p.end }, employeeId: q.employeeId },
    }),
    prisma.sale.findMany({
      where: { status: 'COMPLETED', createdAt: { gte: p.start, lte: p.end }, employeeId: q.employeeId },
      include: { items: { select: { isDamagedSale: true, netPrice: true } } },
    }),
    prisma.returnItem.findMany({
      where: { return: { createdAt: { gte: p.start, lte: p.end } } },
      select: { lateFee: true, damageFee: true, lossFee: true },
    }),
    prisma.insuranceTransaction.findMany({
      where: {
        isVoided: false,
        createdAt: { gte: p.start, lte: p.end },
        type: { in: ['DEDUCTED_DAMAGE', 'DEDUCTED_LOSS', 'TRANSFERRED_TO_COMPANY'] },
      },
      select: { amount: true },
    }),
  ]);

  let normalSales = new Decimal(0);
  let damagedSales = new Decimal(0);
  for (const s of sales) {
    for (const li of s.items) {
      if (li.isDamagedSale) damagedSales = damagedSales.plus(li.netPrice.toString());
      else normalSales = normalSales.plus(li.netPrice.toString());
    }
  }

  const lateFees = sumMoney(returns.map((r) => r.lateFee.toString()));
  const damageFees = sumMoney(returns.map((r) => r.damageFee.toString()));
  const lossFees = sumMoney(returns.map((r) => r.lossFee.toString()));
  const retained = sumMoney(insurance.map((i) => i.amount.toString()));

  return [
    { source: 'إيراد التأجير', amount: money(rentals._sum.netAmount?.toString() ?? 0) },
    { source: 'إيراد المبيعات', amount: money(normalSales) },
    { source: 'إيراد بيع القطع التالفة', amount: money(damagedSales) },
    { source: 'غرامات التأخير', amount: lateFees },
    { source: 'تعويضات التلف', amount: damageFees },
    { source: 'تعويضات الفقد', amount: lossFees },
    { source: 'تأمينات مُستبقاة للمحل', amount: retained },
  ];
}

async function expensesReport(q: ReportQuery, p: ReturnType<typeof resolvePeriod>): Promise<ReportRow[]> {
  const rows = await prisma.expense.findMany({
    where: {
      isVoided: false,
      expenseDate: { gte: toBusinessDate(p.from), lte: toBusinessDate(p.to) },
      categoryId: q.categoryId,
      employeeId: q.employeeId,
      paymentMethodId: q.paymentMethodId,
    },
    include: { category: true, paymentMethod: true, employee: true },
    orderBy: { id: 'asc' },
  });

  return rows.map((e) => ({
    expenseNo: e.expenseNo,
    date: formatDate(e.expenseDate),
    category: e.category.nameAr,
    description: e.description ?? '—',
    employee: e.employee?.fullName ?? '—',
    method: e.paymentMethod.nameAr,
    amount: money(e.amount.toString()),
    cashPaid: money((e.cashPaidAmount ?? e.amount).toString()),
  }));
}

async function netProfit(q: ReportQuery, p: ReturnType<typeof resolvePeriod>): Promise<ReportRow[]> {
  const revenueRows = await revenueReport(q, p);
  const totalRevenue = sumMoney(revenueRows.map((r) => String(r.amount)));

  const sales = await prisma.sale.aggregate({
    _sum: { totalCost: true },
    where: { status: 'COMPLETED', createdAt: { gte: p.start, lte: p.end } },
  });

  const writeOffs = await prisma.productItem.aggregate({
    _sum: { purchaseCost: true },
    where: {
      status: 'DISPOSED',
      disposedAt: { gte: p.start, lte: p.end },
    },
  });

  const expenses = await prisma.expense.aggregate({
    _sum: { amount: true },
    where: {
      isVoided: false,
      expenseDate: { gte: toBusinessDate(p.from), lte: toBusinessDate(p.to) },
    },
  });

  const cogs = money(sales._sum.totalCost?.toString() ?? 0);
  const disposal = money(writeOffs._sum.purchaseCost?.toString() ?? 0);
  const opex = money(expenses._sum.amount?.toString() ?? 0);
  const profit = sub(sub(sub(totalRevenue, cogs), disposal), opex);

  return [
    { line: 'إجمالي الإيرادات', amount: totalRevenue },
    { line: 'تكلفة شراء القطع المباعة', amount: `-${cogs}` },
    { line: 'تكلفة القطع المُستبعدة', amount: `-${disposal}` },
    { line: 'المصروفات التشغيلية', amount: `-${opex}` },
    { line: 'صافي الربح التقديري', amount: profit.toString() },
  ];
}

async function outstanding(q: ReportQuery): Promise<ReportRow[]> {
  const rentals = await prisma.rental.findMany({
    where: {
      status: { not: 'VOIDED' },
      remainingAmount: { gt: 0 },
      customerId: q.customerId,
    },
    include: { customer: true },
    orderBy: { id: 'asc' },
  });

  return rentals.map((r) => ({
    rentalNo: r.rentalNo,
    date: formatDate(r.rentalDate),
    customer: r.customer.isWalkIn ? 'عميل نقدي' : r.customer.fullName,
    phone: r.customer.phone ?? '—',
    totalDue: money(r.totalDue.toString()),
    paid: money(r.paidAmount.toString()),
    remaining: money(r.remainingAmount.toString()),
    status: r.status,
  }));
}

async function insuranceBalance(p: ReturnType<typeof resolvePeriod>): Promise<ReportRow[]> {
  const trx = await prisma.insuranceTransaction.findMany({
    where: { isVoided: false, createdAt: { gte: p.start, lte: p.end } },
    include: { customer: true, rental: { select: { rentalNo: true } } },
    orderBy: { id: 'asc' },
  });

  const LABELS: Record<string, string> = {
    COLLECTED: 'محصَّل', REFUNDED: 'مردود',
    DEDUCTED_DAMAGE: 'مخصوم لتلف', DEDUCTED_LOSS: 'مخصوم لفقد',
    TRANSFERRED_TO_COMPANY: 'محوَّل للمحل',
  };

  return trx.map((t) => ({
    date: formatDate(t.trxDate),
    type: LABELS[t.type] ?? t.type,
    customer: t.customer?.fullName ?? '—',
    rental: t.rental?.rentalNo ?? '—',
    amount: money(t.amount.toString()),
    balanceAfter: money(t.balanceAfter.toString()),
    reason: t.reason ?? '—',
  }));
}

async function inventoryReport(q: ReportQuery): Promise<ReportRow[]> {
  const products = await prisma.product.findMany({
    where: { isActive: true, id: q.productId },
    include: { items: { where: { isActive: true }, select: { status: true, purchaseCost: true } } },
    orderBy: { nameAr: 'asc' },
  });

  return products.map((p) => {
    const c: Record<string, number> = {};
    let cost = new Decimal(0);
    for (const it of p.items) {
      c[it.status] = (c[it.status] ?? 0) + 1;
      cost = cost.plus(it.purchaseCost.toString());
    }
    return {
      code: p.code,
      product: p.nameAr,
      total: p.items.length,
      available: c.AVAILABLE ?? 0,
      rented: c.RENTED ?? 0,
      overdue: c.OVERDUE ?? 0,
      sold: c.SOLD ?? 0,
      damaged: c.DAMAGED ?? 0,
      lost: c.LOST ?? 0,
      totalCost: money(cost),
    };
  });
}

async function itemsByStatus(q: ReportQuery, statuses: ItemStatus[]): Promise<ReportRow[]> {
  const items = await prisma.productItem.findMany({
    where: {
      isActive: true,
      status: { in: statuses },
      productId: q.productId,
      id: q.itemId,
    },
    include: { product: true },
    orderBy: { itemCode: 'asc' },
  });

  return items.map((i) => ({
    itemCode: i.itemCode,
    product: i.product.nameAr,
    size: i.product.size ?? '—',
    color: i.product.color ?? '—',
    status: STATUS_LABELS[i.status as ItemStatus],
    rentalCount: i.rentalCount,
    lastRental: i.lastRentalDate ? formatDate(i.lastRentalDate) : '—',
    purchaseCost: money(i.purchaseCost.toString()),
  }));
}

async function overdueItems(): Promise<ReportRow[]> {
  const today = businessToday();
  // ★ نفس شرط التأخير المستخدم في شاشة المخزون — مصدر واحد بلا تعريفين
  const rentals = await prisma.rental.findMany({
    where: overdueRentalWhere(today),
    include: {
      customer: true,
      items: { where: { status: 'OUT' }, include: { item: { include: { product: true } } } },
    },
    orderBy: { expectedReturnDate: 'asc' },
  });

  const rows: ReportRow[] = [];
  for (const r of rentals) {
    const daysLate = daysLateOf(r.expectedReturnDate, today);
    for (const li of r.items) {
      rows.push({
        rentalNo: r.rentalNo,
        itemCode: li.item.itemCode,
        product: li.item.product.nameAr,
        customer: r.customer.fullName,
        phone: r.customer.phone ?? '—',
        expectedReturn: formatDate(r.expectedReturnDate),
        daysLate,
        remaining: money(r.remainingAmount.toString()),
      });
    }
  }
  return rows;
}

async function itemProfitability(q: ReportQuery): Promise<ReportRow[]> {
  const items = await prisma.productItem.findMany({
    where: { productId: q.productId, id: q.itemId },
    include: {
      product: true,
      saleItems: { include: { sale: { select: { status: true } } } },
      maintenance: true,
      cleaning: true,
    },
    orderBy: { itemCode: 'asc' },
  });

  return items.map((i) => {
    const rentalRevenue = round2(i.totalRentalRevenue.toString());
    const feesRevenue = round2(i.totalFeesRevenue.toString());
    const saleRevenue = i.saleItems
      .filter((si) => si.sale.status === 'COMPLETED')
      .reduce<Decimal>((a, si) => a.plus(si.netPrice.toString()), new Decimal(0));
    const cost = round2(i.purchaseCost.toString());
    const maintenance = i.maintenance.reduce<Decimal>((a, m) => a.plus(m.cost.toString()), new Decimal(0));
    const cleaning = i.cleaning.reduce<Decimal>((a, c) => a.plus(c.cost.toString()), new Decimal(0));
    const upkeep = add(maintenance, cleaning);
    const profit = sub(sub(add(rentalRevenue, feesRevenue, saleRevenue), cost), upkeep);

    return {
      itemCode: i.itemCode,
      product: i.product.nameAr,
      status: STATUS_LABELS[i.status as ItemStatus],
      rentalCount: i.rentalCount,
      rentalRevenue: rentalRevenue.toString(),
      feesRevenue: feesRevenue.toString(),
      saleRevenue: round2(saleRevenue).toString(),
      purchaseCost: cost.toString(),
      upkeepCost: upkeep.toString(),
      lifetimeProfit: profit.toString(),
    };
  });
}

async function rentalPerformance(q: ReportQuery, p: ReturnType<typeof resolvePeriod>): Promise<ReportRow[]> {
  const items = await prisma.rentalItem.findMany({
    where: {
      rental: { status: { not: 'VOIDED' }, createdAt: { gte: p.start, lte: p.end } },
      item: { productId: q.productId },
    },
    include: { item: { include: { product: true } } },
  });

  const map = new Map<number, { name: string; code: string; count: number; revenue: Decimal }>();
  for (const li of items) {
    const key = li.item.productId;
    const acc = map.get(key) ?? {
      name: li.item.product.nameAr, code: li.item.product.code, count: 0, revenue: new Decimal(0),
    };
    acc.count += 1;
    acc.revenue = acc.revenue.plus(li.netPrice.toString());
    map.set(key, acc);
  }

  return [...map.values()]
    .sort((a, b) => b.count - a.count)
    .map((v) => ({
      code: v.code,
      product: v.name,
      rentalCount: v.count,
      revenue: round2(v.revenue).toString(),
    }));
}

async function salesPerformance(q: ReportQuery, p: ReturnType<typeof resolvePeriod>): Promise<ReportRow[]> {
  const items = await prisma.saleItem.findMany({
    where: {
      sale: { status: 'COMPLETED', createdAt: { gte: p.start, lte: p.end } },
      item: { productId: q.productId },
    },
    include: { item: { include: { product: true } } },
  });

  const map = new Map<number, { name: string; code: string; count: number; revenue: Decimal; cost: Decimal }>();
  for (const si of items) {
    const key = si.item.productId;
    const acc = map.get(key) ?? {
      name: si.item.product.nameAr, code: si.item.product.code,
      count: 0, revenue: new Decimal(0), cost: new Decimal(0),
    };
    acc.count += 1;
    acc.revenue = acc.revenue.plus(si.netPrice.toString());
    acc.cost = acc.cost.plus(si.purchaseCost.toString());
    map.set(key, acc);
  }

  return [...map.values()]
    .sort((a, b) => b.count - a.count)
    .map((v) => ({
      code: v.code,
      product: v.name,
      saleCount: v.count,
      revenue: round2(v.revenue).toString(),
      cost: round2(v.cost).toString(),
      grossProfit: sub(v.revenue, v.cost).toString(),
    }));
}

async function paymentMethods(q: ReportQuery, p: ReturnType<typeof resolvePeriod>): Promise<ReportRow[]> {
  const payments = await prisma.payment.findMany({
    where: {
      isVoided: false,
      paymentDate: { gte: toBusinessDate(p.from), lte: toBusinessDate(p.to) },
      paymentMethodId: q.paymentMethodId,
    },
    include: { paymentMethod: true },
  });

  const map = new Map<number, {
    name: string; isCash: boolean; inCount: number;
    inflow: Decimal; outflow: Decimal; insurance: Decimal;
  }>();

  for (const pay of payments) {
    const acc = map.get(pay.paymentMethodId) ?? {
      name: pay.paymentMethod.nameAr, isCash: pay.paymentMethod.isCash,
      inCount: 0, inflow: new Decimal(0), outflow: new Decimal(0), insurance: new Decimal(0),
    };
    const amt = round2(pay.amount.toString());
    if (pay.isInsurance) acc.insurance = acc.insurance.plus(amt);
    else if (pay.direction === 'IN') { acc.inflow = acc.inflow.plus(amt); acc.inCount += 1; }
    else acc.outflow = acc.outflow.plus(amt);
    map.set(pay.paymentMethodId, acc);
  }

  return [...map.values()].map((v) => ({
    method: v.name,
    kind: v.isCash ? 'نقدي' : 'غير نقدي',
    count: v.inCount,
    inflow: round2(v.inflow).toString(),
    outflow: round2(v.outflow).toString(),
    insurance: round2(v.insurance).toString(),
  }));
}

// ============================ الموزّع ============================

const COLUMNS: Record<ReportKey, ReportColumn[]> = {
  'daily-sales': [
    { key: 'invoiceNo', label: 'الفاتورة', type: 'text' },
    { key: 'date', label: 'التاريخ', type: 'date' },
    { key: 'customer', label: 'العميل', type: 'text' },
    { key: 'employee', label: 'الموظف', type: 'text' },
    { key: 'itemCount', label: 'القطع', type: 'number', sum: true },
    { key: 'subtotal', label: 'قبل الخصم', type: 'money', sum: true },
    { key: 'discount', label: 'الخصم', type: 'money', sum: true },
    { key: 'netAmount', label: 'صافي البيع', type: 'money', sum: true },
    { key: 'totalCost', label: 'التكلفة', type: 'money', sum: true },
    { key: 'grossProfit', label: 'مجمل الربح', type: 'money', sum: true },
  ],
  'daily-rentals': [
    { key: 'rentalNo', label: 'العقد', type: 'text' },
    { key: 'date', label: 'التاريخ', type: 'date' },
    { key: 'expectedReturn', label: 'الإرجاع المتوقع', type: 'date' },
    { key: 'customer', label: 'العميل', type: 'text' },
    { key: 'employee', label: 'الموظف', type: 'text' },
    { key: 'itemCount', label: 'القطع', type: 'number', sum: true },
    { key: 'netAmount', label: 'صافي التأجير', type: 'money', sum: true },
    { key: 'extraCharges', label: 'غرامات', type: 'money', sum: true },
    { key: 'paidAmount', label: 'المدفوع', type: 'money', sum: true },
    { key: 'remaining', label: 'المتبقي', type: 'money', sum: true },
    { key: 'insurance', label: 'التأمين', type: 'money', sum: true },
    { key: 'status', label: 'الحالة', type: 'text' },
  ],
  'monthly-sales': [
    { key: 'month', label: 'الشهر', type: 'text' },
    { key: 'count', label: 'عدد الفواتير', type: 'number', sum: true },
    { key: 'netAmount', label: 'صافي البيع', type: 'money', sum: true },
    { key: 'totalCost', label: 'التكلفة', type: 'money', sum: true },
  ],
  'monthly-rentals': [
    { key: 'month', label: 'الشهر', type: 'text' },
    { key: 'count', label: 'عدد العقود', type: 'number', sum: true },
    { key: 'netAmount', label: 'صافي التأجير', type: 'money', sum: true },
    { key: 'extraCharges', label: 'الغرامات', type: 'money', sum: true },
  ],
  revenue: [
    { key: 'source', label: 'مصدر الإيراد', type: 'text' },
    { key: 'amount', label: 'المبلغ', type: 'money', sum: true },
  ],
  expenses: [
    { key: 'expenseNo', label: 'الرقم', type: 'text' },
    { key: 'date', label: 'التاريخ', type: 'date' },
    { key: 'category', label: 'التصنيف', type: 'text' },
    { key: 'description', label: 'الوصف', type: 'text' },
    { key: 'employee', label: 'الموظف', type: 'text' },
    { key: 'method', label: 'طريقة الدفع', type: 'text' },
    { key: 'amount', label: 'المصروف', type: 'money', sum: true },
    { key: 'cashPaid', label: 'المدفوع نقدًا', type: 'money', sum: true },
  ],
  'net-profit': [
    { key: 'line', label: 'البند', type: 'text' },
    { key: 'amount', label: 'المبلغ', type: 'money' },
  ],
  outstanding: [
    { key: 'rentalNo', label: 'العقد', type: 'text' },
    { key: 'date', label: 'التاريخ', type: 'date' },
    { key: 'customer', label: 'العميل', type: 'text' },
    { key: 'phone', label: 'الجوال', type: 'text' },
    { key: 'totalDue', label: 'الإجمالي', type: 'money', sum: true },
    { key: 'paid', label: 'المدفوع', type: 'money', sum: true },
    { key: 'remaining', label: 'المتبقي', type: 'money', sum: true },
    { key: 'status', label: 'الحالة', type: 'text' },
  ],
  'insurance-balance': [
    { key: 'date', label: 'التاريخ', type: 'date' },
    { key: 'type', label: 'نوع الحركة', type: 'text' },
    { key: 'customer', label: 'العميل', type: 'text' },
    { key: 'rental', label: 'العقد', type: 'text' },
    { key: 'amount', label: 'المبلغ', type: 'money', sum: true },
    { key: 'balanceAfter', label: 'الرصيد بعدها', type: 'money' },
    { key: 'reason', label: 'السبب', type: 'text' },
  ],
  inventory: [
    { key: 'code', label: 'كود المنتج', type: 'text' },
    { key: 'product', label: 'المنتج', type: 'text' },
    { key: 'total', label: 'الإجمالي', type: 'number', sum: true },
    { key: 'available', label: 'متاحة', type: 'number', sum: true },
    { key: 'rented', label: 'مؤجرة', type: 'number', sum: true },
    { key: 'overdue', label: 'متأخرة', type: 'number', sum: true },
    { key: 'sold', label: 'مباعة', type: 'number', sum: true },
    { key: 'damaged', label: 'تالفة', type: 'number', sum: true },
    { key: 'lost', label: 'مفقودة', type: 'number', sum: true },
    { key: 'totalCost', label: 'تكلفة الشراء', type: 'money', sum: true },
  ],
  'available-items': [
    { key: 'itemCode', label: 'كود القطعة', type: 'text' },
    { key: 'product', label: 'المنتج', type: 'text' },
    { key: 'size', label: 'المقاس', type: 'text' },
    { key: 'color', label: 'اللون', type: 'text' },
    { key: 'status', label: 'الحالة', type: 'text' },
    { key: 'rentalCount', label: 'مرات التأجير', type: 'number', sum: true },
    { key: 'lastRental', label: 'آخر تأجير', type: 'date' },
    { key: 'purchaseCost', label: 'التكلفة', type: 'money', sum: true },
  ],
  'rented-items': [
    { key: 'itemCode', label: 'كود القطعة', type: 'text' },
    { key: 'product', label: 'المنتج', type: 'text' },
    { key: 'size', label: 'المقاس', type: 'text' },
    { key: 'color', label: 'اللون', type: 'text' },
    { key: 'status', label: 'الحالة', type: 'text' },
    { key: 'rentalCount', label: 'مرات التأجير', type: 'number', sum: true },
    { key: 'lastRental', label: 'آخر تأجير', type: 'date' },
    { key: 'purchaseCost', label: 'التكلفة', type: 'money', sum: true },
  ],
  'overdue-items': [
    { key: 'rentalNo', label: 'العقد', type: 'text' },
    { key: 'itemCode', label: 'القطعة', type: 'text' },
    { key: 'product', label: 'المنتج', type: 'text' },
    { key: 'customer', label: 'العميل', type: 'text' },
    { key: 'phone', label: 'الجوال', type: 'text' },
    { key: 'expectedReturn', label: 'الإرجاع المتوقع', type: 'date' },
    { key: 'daysLate', label: 'أيام التأخير', type: 'number', sum: true },
    { key: 'remaining', label: 'المتبقي', type: 'money', sum: true },
  ],
  'lost-damaged': [
    { key: 'itemCode', label: 'كود القطعة', type: 'text' },
    { key: 'product', label: 'المنتج', type: 'text' },
    { key: 'size', label: 'المقاس', type: 'text' },
    { key: 'color', label: 'اللون', type: 'text' },
    { key: 'status', label: 'الحالة', type: 'text' },
    { key: 'rentalCount', label: 'مرات التأجير', type: 'number', sum: true },
    { key: 'lastRental', label: 'آخر تأجير', type: 'date' },
    { key: 'purchaseCost', label: 'التكلفة', type: 'money', sum: true },
  ],
  'item-profitability': [
    { key: 'itemCode', label: 'كود القطعة', type: 'text' },
    { key: 'product', label: 'المنتج', type: 'text' },
    { key: 'status', label: 'الحالة', type: 'text' },
    { key: 'rentalCount', label: 'مرات التأجير', type: 'number', sum: true },
    { key: 'rentalRevenue', label: 'إيراد التأجير', type: 'money', sum: true },
    { key: 'feesRevenue', label: 'إيراد الغرامات', type: 'money', sum: true },
    { key: 'saleRevenue', label: 'إيراد البيع', type: 'money', sum: true },
    { key: 'purchaseCost', label: 'تكلفة الشراء', type: 'money', sum: true },
    { key: 'upkeepCost', label: 'صيانة وتنظيف', type: 'money', sum: true },
    { key: 'lifetimeProfit', label: 'ربحية العمر', type: 'money', sum: true },
  ],
  'rental-performance': [
    { key: 'code', label: 'كود المنتج', type: 'text' },
    { key: 'product', label: 'المنتج', type: 'text' },
    { key: 'rentalCount', label: 'مرات التأجير', type: 'number', sum: true },
    { key: 'revenue', label: 'الإيراد', type: 'money', sum: true },
  ],
  'sales-performance': [
    { key: 'code', label: 'كود المنتج', type: 'text' },
    { key: 'product', label: 'المنتج', type: 'text' },
    { key: 'saleCount', label: 'عدد المبيعات', type: 'number', sum: true },
    { key: 'revenue', label: 'الإيراد', type: 'money', sum: true },
    { key: 'cost', label: 'التكلفة', type: 'money', sum: true },
    { key: 'grossProfit', label: 'مجمل الربح', type: 'money', sum: true },
  ],
  'payment-methods': [
    { key: 'method', label: 'طريقة الدفع', type: 'text' },
    { key: 'kind', label: 'النوع', type: 'text' },
    { key: 'count', label: 'عدد التحصيلات', type: 'number', sum: true },
    { key: 'inflow', label: 'المحصَّل', type: 'money', sum: true },
    { key: 'outflow', label: 'المدفوع', type: 'money', sum: true },
    { key: 'insurance', label: 'تأمينات', type: 'money', sum: true },
  ],
};

const TITLES: Record<ReportKey, string> = {
  'daily-sales': 'المبيعات اليومية',
  'daily-rentals': 'التأجير اليومي',
  'monthly-sales': 'المبيعات الشهرية',
  'monthly-rentals': 'التأجير الشهري',
  revenue: 'الإيرادات',
  expenses: 'المصروفات',
  'net-profit': 'صافي الربح التقديري',
  outstanding: 'مستحقات العملاء',
  'insurance-balance': 'حركة صندوق التأمينات',
  inventory: 'المخزون',
  'available-items': 'القطع المتاحة',
  'rented-items': 'القطع المؤجرة',
  'overdue-items': 'القطع المتأخرة',
  'lost-damaged': 'القطع التالفة والمفقودة',
  'item-profitability': 'ربحية القطعة عبر عمرها',
  'rental-performance': 'أداء التأجير حسب المنتج',
  'sales-performance': 'أداء المبيعات حسب المنتج',
  'payment-methods': 'ملخص طرق الدفع',
};

const REPORT_NOTES: Record<ReportKey, string[]> = {
  'daily-sales': [NOTES.voidedExcluded, NOTES.costForProfitOnly],
  'daily-rentals': [NOTES.voidedExcluded, NOTES.insuranceNotRevenue],
  'monthly-sales': [NOTES.voidedExcluded],
  'monthly-rentals': [NOTES.voidedExcluded],
  revenue: [NOTES.insuranceNotRevenue, NOTES.voidedExcluded],
  expenses: [NOTES.notExpenses, NOTES.commissionViaExpense],
  'net-profit': [
    NOTES.estimatedProfit, NOTES.notExpenses,
    NOTES.costForProfitOnly, NOTES.commissionViaExpense,
  ],
  outstanding: [NOTES.voidedExcluded],
  'insurance-balance': [NOTES.insuranceNotRevenue],
  inventory: [NOTES.costForProfitOnly],
  'available-items': [],
  'rented-items': [],
  'overdue-items': [],
  'lost-damaged': [NOTES.costForProfitOnly],
  'item-profitability': [NOTES.lifetimeProfit, NOTES.costForProfitOnly],
  'rental-performance': [NOTES.voidedExcluded],
  'sales-performance': [NOTES.voidedExcluded, NOTES.costForProfitOnly],
  'payment-methods': [NOTES.cashOnly, NOTES.insuranceNotRevenue],
};

/** نقطة الدخول الوحيدة — تستهلكها الشاشة و Excel و PDF بلا ازدواج. */
export async function runReport(input: ReportQuery): Promise<ReportResult> {
  const key = input.key;
  await requirePermission(
    FINANCIAL.includes(key) ? 'reports.financial.view' : 'reports.operational.view',
  );

  const p = resolvePeriod(input);
  const filters = await describeFilters(input);
  let rows: ReportRow[];

  switch (key) {
    case 'daily-sales': rows = await dailySales(input, p); break;
    case 'daily-rentals': rows = await dailyRentals(input, p); break;
    case 'monthly-sales': {
      const sales = await prisma.sale.findMany({
        where: { status: 'COMPLETED', createdAt: { gte: p.start, lte: p.end } },
        select: { saleDate: true, netAmount: true, totalCost: true },
      });
      rows = groupByMonth(sales.map((s) => ({
        date: s.saleDate,
        values: { netAmount: s.netAmount.toString(), totalCost: s.totalCost.toString() },
      })));
      break;
    }
    case 'monthly-rentals': {
      const rentals = await prisma.rental.findMany({
        where: { status: { not: 'VOIDED' }, createdAt: { gte: p.start, lte: p.end } },
        select: { rentalDate: true, netAmount: true, extraCharges: true },
      });
      rows = groupByMonth(rentals.map((r) => ({
        date: r.rentalDate,
        values: { netAmount: r.netAmount.toString(), extraCharges: r.extraCharges.toString() },
      })));
      break;
    }
    case 'revenue': rows = await revenueReport(input, p); break;
    case 'expenses': rows = await expensesReport(input, p); break;
    case 'net-profit': rows = await netProfit(input, p); break;
    case 'outstanding': rows = await outstanding(input); break;
    case 'insurance-balance': rows = await insuranceBalance(p); break;
    case 'inventory': rows = await inventoryReport(input); break;
    case 'available-items': rows = await itemsByStatus(input, ['AVAILABLE']); break;
    case 'rented-items': rows = await itemsByStatus(input, ['RENTED', 'OVERDUE']); break;
    case 'overdue-items': rows = await overdueItems(); break;
    case 'lost-damaged': rows = await itemsByStatus(input, ['DAMAGED', 'LOST', 'DISPOSED']); break;
    case 'item-profitability': rows = await itemProfitability(input); break;
    case 'rental-performance': rows = await rentalPerformance(input, p); break;
    case 'sales-performance': rows = await salesPerformance(input, p); break;
    case 'payment-methods': rows = await paymentMethods(input, p); break;
    default: throw Errors.notFound('التقرير');
  }

  return assemble(key, TITLES[key], p.label, filters, COLUMNS[key], rows, REPORT_NOTES[key]);
}

export const reportCatalog = () =>
  REPORT_KEYS.map((k) => ({
    key: k,
    title: TITLES[k],
    isFinancial: FINANCIAL.includes(k),
  }));
