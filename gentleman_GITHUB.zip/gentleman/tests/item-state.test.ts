import { describe, it, expect } from 'vitest';
import {
  canTransition, canBeRented, canBeSold, manualTargets,
  ALLOWED_TRANSITIONS, TERMINAL_STATUSES, type ItemStatus,
} from '../src/lib/inventory/item-state';

const ALL = Object.keys(ALLOWED_TRANSITIONS) as ItemStatus[];

describe('آلة حالة القطعة — الانتقالات المسموحة', () => {
  it('متاحة → مؤجرة مسموح (من عملية تأجير)', () => {
    expect(canTransition('AVAILABLE', 'RENTED').allowed).toBe(true);
  });
  it('مؤجرة → متأخرة مسموح', () => {
    expect(canTransition('RENTED', 'OVERDUE').allowed).toBe(true);
  });
  it('مؤجرة → متاحة مسموح (إرجاع سليم)', () => {
    expect(canTransition('RENTED', 'AVAILABLE').allowed).toBe(true);
  });
  it('مؤجرة → تحت التنظيف مسموح (عند تفعيل التنظيف)', () => {
    expect(canTransition('RENTED', 'CLEANING').allowed).toBe(true);
  });
  it('تالفة → صيانة → متاحة مسموح', () => {
    expect(canTransition('DAMAGED', 'MAINTENANCE').allowed).toBe(true);
    expect(canTransition('MAINTENANCE', 'AVAILABLE').allowed).toBe(true);
  });
  it('محجوزة → مؤجرة مسموح (الاستلام)', () => {
    expect(canTransition('RESERVED', 'RENTED').allowed).toBe(true);
  });
});

describe('آلة حالة القطعة — الانتقالات المرفوضة', () => {
  it('مؤجرة → مباعة مرفوض', () => {
    const r = canTransition('RENTED', 'SOLD');
    expect(r.allowed).toBe(false);
    expect(r.reason).toContain('لا يمكن نقل القطعة');
  });
  it('مباعة حالة نهائية — لا خروج منها إطلاقًا', () => {
    for (const to of ALL) expect(canTransition('SOLD', to).allowed).toBe(false);
  });
  it('مستبعدة حالة نهائية', () => {
    for (const to of ALL) expect(canTransition('DISPOSED', to).allowed).toBe(false);
  });
  it('تالفة → متاحة مباشرة مرفوض (يجب المرور بالصيانة)', () => {
    expect(canTransition('DAMAGED', 'AVAILABLE').allowed).toBe(false);
  });
  it('مفقودة → مؤجرة مرفوض يدويًا (مسموح فقط كعكس إرجاع خاطئ)', () => {
    expect(canTransition('LOST', 'RENTED', { manual: true }).allowed).toBe(false);
    expect(canTransition('LOST', 'RENTED').allowed).toBe(true);
  });

  it('تالفة → مؤجرة مرفوض يدويًا (مسموح فقط كعكس إرجاع خاطئ)', () => {
    expect(canTransition('DAMAGED', 'RENTED', { manual: true }).allowed).toBe(false);
    expect(canTransition('DAMAGED', 'RENTED').allowed).toBe(true);
  });
  it('الانتقال إلى نفس الحالة مرفوض', () => {
    expect(canTransition('AVAILABLE', 'AVAILABLE').allowed).toBe(false);
  });
  it('متأخرة → مؤجرة مرفوض', () => {
    expect(canTransition('OVERDUE', 'RENTED').allowed).toBe(false);
  });
});

describe('الحالات التي تُدار من العمليات لا يدويًا', () => {
  it('لا يمكن ضبط "مؤجرة" أو "مباعة" أو "محجوزة" يدويًا من شاشة المخزون', () => {
    for (const to of ['RENTED', 'SOLD', 'RESERVED'] as ItemStatus[]) {
      const r = canTransition('AVAILABLE', to, { manual: true });
      expect(r.allowed).toBe(false);
      expect(r.reason).toContain('وليس يدويًا');
    }
  });
  it('الخيارات اليدوية من "متاحة" هي الصيانة والتنظيف والتلف والفقد والاستبعاد فقط', () => {
    expect(manualTargets('AVAILABLE').sort())
      .toEqual(['CLEANING', 'DAMAGED', 'DISPOSED', 'LOST', 'MAINTENANCE'].sort());
  });
  it('إخراج القطعة من الخدمة يدويًا يتطلب صلاحية مدير', () => {
    for (const to of ['DAMAGED', 'LOST', 'DISPOSED'] as ItemStatus[]) {
      expect(canTransition('AVAILABLE', to, { manual: true }).requiresOverride).toBe(true);
    }
    expect(canTransition('AVAILABLE', 'CLEANING', { manual: true }).requiresOverride).toBe(false);
  });
});

describe('قيود التأجير والبيع', () => {
  it('المتاحة وحدها قابلة للتأجير', () => {
    expect(canBeRented('AVAILABLE')).toBe(true);
    for (const s of ALL.filter((x) => x !== 'AVAILABLE')) expect(canBeRented(s)).toBe(false);
  });
  it('لا يمكن بيع المؤجرة أو المباعة أو المفقودة أو المحجوزة', () => {
    for (const s of ['RENTED', 'SOLD', 'LOST', 'RESERVED', 'OVERDUE'] as ItemStatus[]) {
      expect(canBeSold(s)).toBe(false);
    }
  });
  it('يمكن بيع التالفة والمتاحة والتي تحت الصيانة', () => {
    for (const s of ['DAMAGED', 'AVAILABLE', 'MAINTENANCE'] as ItemStatus[]) {
      expect(canBeSold(s)).toBe(true);
    }
  });
});

describe('سلامة المصفوفة', () => {
  it('كل الحالات معرّفة ولا توجد حالة مجهولة في الانتقالات', () => {
    for (const from of ALL) {
      for (const to of ALLOWED_TRANSITIONS[from]) expect(ALL).toContain(to);
    }
  });
  it('الحالات النهائية بلا مخارج', () => {
    for (const s of TERMINAL_STATUSES) expect(ALLOWED_TRANSITIONS[s]).toHaveLength(0);
  });
});

describe('عرض الحالة في الواجهة', () => {
  it('لكل حالة تسمية عربية ولون شارة — لا حالة بلا عرض', async () => {
    const { STATUS_LABELS, STATUS_TONE } = await import('../src/lib/inventory/item-state');
    for (const s of ALL) {
      expect(STATUS_LABELS[s]).toBeTruthy();
      expect(['ok', 'busy', 'warn', 'danger', 'muted']).toContain(STATUS_TONE[s]);
    }
  });
});
