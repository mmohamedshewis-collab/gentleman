\set ON_ERROR_STOP off
\pset pager off
\t on

\echo '=== R3: إرجاع قطعة أُرجعت من قبل (يجب أن يُرفض) ==='
SELECT do_return(1, 'SUIT-0001', 'GOOD', 0, 0, 0, CURRENT_DATE);

\echo ''
\echo '=== R4: إرجاع لعقد مغلق (يجب أن يُرفض) ==='
SELECT do_return(1, 'SUIT-0003', 'GOOD', 0, 0, 0, CURRENT_DATE);

\echo ''
\echo '=== R5: خرق معادلة التسوية (تسريب تأمين) — إدراج يدوي خاطئ ==='
INSERT INTO return_items (return_id, rental_item_id, item_id, actual_return_date,
  late_fee, condition, damage_fee, insurance_used, insurance_refunded, extra_due_from_customer)
VALUES (1, 2, 2, CURRENT_DATE, 200, 'GOOD', 0, 500, 500, 0);

\echo ''
\echo '=== R6: تلف بقيمة صفر مع حالة "تالفة" (يجب أن يُرفض) ==='
INSERT INTO return_items (return_id, rental_item_id, item_id, actual_return_date,
  late_fee, condition, damage_fee, insurance_used, insurance_refunded, extra_due_from_customer)
VALUES (1, 2, 2, CURRENT_DATE, 0, 'DAMAGED', 0, 0, 0, 0);

\echo ''
\echo '=== R7: تلف مسجّل على قطعة "سليمة" (يجب أن يُرفض) ==='
INSERT INTO return_items (return_id, rental_item_id, item_id, actual_return_date,
  late_fee, condition, damage_fee, insurance_used, insurance_refunded, extra_due_from_customer)
VALUES (1, 2, 2, CURRENT_DATE, 0, 'GOOD', 300, 300, 0, 0);

\echo ''
\echo '=== R8: مبالغ سالبة في الإرجاع (يجب أن تُرفض) ==='
INSERT INTO return_items (return_id, rental_item_id, item_id, actual_return_date,
  late_fee, condition, insurance_used, insurance_refunded, extra_due_from_customer)
VALUES (1, 2, 2, CURRENT_DATE, -100, 'GOOD', 0, 0, -100);

\echo ''
\echo '=== R9: تهيئة عقد جديد ثم اختبار التراجع الكامل عند الفشل ==='
INSERT INTO rentals (rental_no, customer_id, rental_date, expected_return_date,
  subtotal, discount, net_amount, gross_amount, total_due, remaining_amount, insurance_amount, created_by)
VALUES ('R-200', 2, CURRENT_DATE - 2, CURRENT_DATE, 500, 0, 500, 500, 500, 500, 1000, 1);
INSERT INTO rental_items (rental_id, item_id, unit_rental_price, net_price, gross_amount, insurance_per_item, expected_return_date)
VALUES (2, 3, 500, 500, 500, 1000, CURRENT_DATE);
UPDATE product_items SET status='RENTED' WHERE id=3;
INSERT INTO insurance_transactions (type, rental_id, amount, balance_after, created_by)
VALUES ('COLLECTED', 2, 1000, 1000, 1);

SELECT 'قبل: إرجاعات=' || (SELECT count(*) FROM returns) ||
       ' سطور إرجاع=' || (SELECT count(*) FROM return_items) ||
       ' سجل حالة=' || (SELECT count(*) FROM item_status_history) ||
       ' حركات مخزون=' || (SELECT count(*) FROM inventory_transactions) ||
       ' حركات تأمين=' || (SELECT count(*) FROM insurance_transactions) ||
       ' تدقيق=' || (SELECT count(*) FROM audit_logs) ||
       ' | حالة القطعة=' || (SELECT status FROM product_items WHERE id=3) ||
       ' | رصيد التأمين=' || (SELECT balance_after FROM insurance_transactions ORDER BY id DESC LIMIT 1);

SELECT do_return(2, 'SUIT-0003', 'DAMAGED', 100, 400, 0, CURRENT_DATE, false, true);

SELECT 'بعد الفشل: إرجاعات=' || (SELECT count(*) FROM returns) ||
       ' سطور إرجاع=' || (SELECT count(*) FROM return_items) ||
       ' سجل حالة=' || (SELECT count(*) FROM item_status_history) ||
       ' حركات مخزون=' || (SELECT count(*) FROM inventory_transactions) ||
       ' حركات تأمين=' || (SELECT count(*) FROM insurance_transactions) ||
       ' تدقيق=' || (SELECT count(*) FROM audit_logs) ||
       ' | حالة القطعة=' || (SELECT status FROM product_items WHERE id=3) ||
       ' | رصيد التأمين=' || (SELECT balance_after FROM insurance_transactions ORDER BY id DESC LIMIT 1);
SELECT 'حالة العقد 2=' || status || ' | مستحق=' || total_due FROM rentals WHERE id=2;
