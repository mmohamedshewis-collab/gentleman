import { route } from '@/lib/api';
import { changeItemStatus, changeStatusSchema } from '@/services/item.service';

export const POST = route({ schema: changeStatusSchema, handler: ({ input }) => changeItemStatus(input) });
