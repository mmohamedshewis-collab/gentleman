import type { Metadata } from 'next';
import { Cairo } from 'next/font/google';
import './globals.css';

const appFont = Cairo({
  subsets: ['arabic', 'latin'],
  variable: '--font-app',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'Gentleman — نظام إدارة تأجير وبيع البدلات',
  description: 'نظام إدارة محل تأجير وبيع البدلات والملابس الرسمية',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ar" dir="rtl" className={appFont.variable}>
      <body>{children}</body>
    </html>
  );
}
