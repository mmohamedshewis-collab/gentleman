'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function CustomerForm({
  customer,
}: {
  customer: { id: number; fullName: string; phone: string; nationalId: string; notes: string };
}) {
  const router = useRouter();
  const [form, setForm] = useState(customer);
  const [msg, setMsg] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  async function save() {
    setBusy(true); setMsg(null);
    const res = await fetch('/api/customers', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...form, id: customer.id }),
    });
    const json = await res.json();
    setBusy(false);
    if (!json.ok) { setMsg({ type: 'err', text: json.error?.message ?? 'تعذّر الحفظ.' }); return; }
    setMsg({ type: 'ok', text: 'تم حفظ التعديلات.' });
    router.refresh();
  }

  return (
    <div className="card">
      <div className="card-header">تعديل البيانات</div>
      <div className="p-5 grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="label">الاسم</label>
          <input className="input" value={form.fullName}
                 onChange={(e) => setForm({ ...form, fullName: e.target.value })} />
        </div>
        <div>
          <label className="label">رقم الجوال</label>
          <input className="input num" dir="ltr" value={form.phone}
                 onChange={(e) => setForm({ ...form, phone: e.target.value })} />
        </div>
        <div>
          <label className="label">الرقم القومي (اختياري)</label>
          <input className="input num" dir="ltr" value={form.nationalId}
                 onChange={(e) => setForm({ ...form, nationalId: e.target.value })} />
        </div>
        <div className="md:col-span-2">
          <label className="label">ملاحظات</label>
          <input className="input" value={form.notes}
                 onChange={(e) => setForm({ ...form, notes: e.target.value })} />
        </div>
      </div>
      <div className="px-5 pb-5 flex items-center gap-4">
        <button className="btn-primary" onClick={save} disabled={busy}>
          {busy ? 'جارٍ الحفظ…' : 'حفظ'}
        </button>
        {msg && (
          <span className={`text-sm font-semibold ${msg.type === 'ok' ? 'text-ok' : 'text-danger'}`}>
            {msg.text}
          </span>
        )}
      </div>
    </div>
  );
}
