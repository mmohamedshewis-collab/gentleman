/**
 * آلة حالة القطعة — منطق خالص بلا اعتماد على قاعدة البيانات.
 * تُطبَّق على الخادم وعلى قاعدة البيانات معًا، وليس في الواجهة.
 */

export type ItemStatus =
  | 'AVAILABLE' | 'RENTED' | 'OVERDUE' | 'RESERVED' | 'SOLD'
  | 'DAMAGED' | 'LOST' | 'CLEANING' | 'MAINTENANCE' | 'DISPOSED';

export const STATUS_LABELS: Record<ItemStatus, string> = {
  AVAILABLE: 'متاحة',
  RENTED: 'مؤجرة',
  OVERDUE: 'متأخرة',
  RESERVED: 'محجوزة',
  SOLD: 'مباعة',
  DAMAGED: 'تالفة',
  LOST: 'مفقودة',
  CLEANING: 'تحت التنظيف',
  MAINTENANCE: 'تحت الصيانة',
  DISPOSED: 'مستبعدة',
};

/** لون شارة الحالة في الواجهة. */
export type StatusTone = 'ok' | 'busy' | 'warn' | 'danger' | 'muted';

export const STATUS_TONE: Record<ItemStatus, StatusTone> = {
  AVAILABLE: 'ok',
  RENTED: 'busy',
  RESERVED: 'busy',
  CLEANING: 'warn',
  MAINTENANCE: 'warn',
  OVERDUE: 'danger',
  DAMAGED: 'danger',
  LOST: 'danger',
  SOLD: 'muted',
  DISPOSED: 'muted',
};

/** الانتقالات المسموح بها. أي انتقال خارج هذه المصفوفة مرفوض. */
export const ALLOWED_TRANSITIONS: Record<ItemStatus, ItemStatus[]> = {
  AVAILABLE:   ['RENTED', 'RESERVED', 'SOLD', 'CLEANING', 'MAINTENANCE', 'DAMAGED', 'LOST', 'DISPOSED'],
  RESERVED:    ['AVAILABLE', 'RENTED', 'CLEANING', 'MAINTENANCE'],
  RENTED:      ['AVAILABLE', 'OVERDUE', 'CLEANING', 'DAMAGED', 'LOST'],
  OVERDUE:     ['AVAILABLE', 'CLEANING', 'DAMAGED', 'LOST'],
  CLEANING:    ['AVAILABLE', 'DAMAGED', 'MAINTENANCE'],
  MAINTENANCE: ['AVAILABLE', 'SOLD', 'DAMAGED', 'CLEANING', 'DISPOSED'],
  // 'RENTED' هنا مسار عكس إرجاع سُجِّل بالخطأ فقط — القطعة ما زالت مع العميل.
  // وهو محظور يدويًا لأن RENTED ضمن OPERATION_DRIVEN.
  DAMAGED:     ['MAINTENANCE', 'SOLD', 'DISPOSED', 'RENTED'],
  LOST:        ['AVAILABLE', 'MAINTENANCE', 'DISPOSED', 'RENTED'],
  SOLD:        [],
  DISPOSED:    [],
};

/** حالات نهائية لا خروج منها إطلاقًا. */
export const TERMINAL_STATUSES: ItemStatus[] = ['SOLD', 'DISPOSED'];

/** حالات تُضبط من العمليات نفسها (تأجير/بيع/حجز) ولا تُضبط يدويًا من شاشة المخزون. */
export const OPERATION_DRIVEN: ItemStatus[] = ['RENTED', 'SOLD', 'RESERVED', 'OVERDUE'];

/** انتقالات يدوية تُخرج القطعة من الخدمة — تتطلب صلاحية مدير وسببًا. */
export const OVERRIDE_TARGETS: ItemStatus[] = ['DAMAGED', 'LOST', 'DISPOSED'];

export const canBeRented = (s: ItemStatus): boolean => s === 'AVAILABLE';

export const canBeSold = (s: ItemStatus): boolean =>
  s === 'AVAILABLE' || s === 'DAMAGED' || s === 'MAINTENANCE';

export const canBeReserved = (s: ItemStatus): boolean =>
  !TERMINAL_STATUSES.includes(s) && s !== 'LOST';

export interface TransitionResult {
  allowed: boolean;
  reason?: string;
  requiresOverride: boolean;
}

/**
 * فحص الانتقال. `manual: true` يعني أن الطلب جاء من شاشة المخزون يدويًا،
 * وليس من عملية تأجير أو بيع أو إرجاع.
 */
export function canTransition(
  from: ItemStatus,
  to: ItemStatus,
  opts: { manual?: boolean; allowVoidSaleExit?: boolean } = {},
): TransitionResult {
  // الاستثناء الوحيد للخروج من "مباعة": إلغاء فاتورة البيع
  if (from === 'SOLD' && opts.allowVoidSaleExit) {
    if ((['AVAILABLE', 'DAMAGED', 'MAINTENANCE'] as ItemStatus[]).includes(to)) {
      return { allowed: true, requiresOverride: false };
    }
    return {
      allowed: false,
      reason: `بعد إلغاء البيع تعود القطعة إلى حالتها السابقة فقط، لا إلى "${STATUS_LABELS[to]}".`,
      requiresOverride: false,
    };
  }

  const requiresOverride = Boolean(opts.manual) && OVERRIDE_TARGETS.includes(to);

  if (from === to) {
    return { allowed: false, reason: `القطعة بالفعل في حالة "${STATUS_LABELS[to]}".`, requiresOverride };
  }
  if (TERMINAL_STATUSES.includes(from)) {
    return {
      allowed: false,
      reason: `القطعة ${STATUS_LABELS[from]} — لا يمكن نقل القطعة إلى أي حالة أخرى.`,
      requiresOverride,
    };
  }
  if (opts.manual && OPERATION_DRIVEN.includes(to)) {
    return {
      allowed: false,
      reason: `حالة "${STATUS_LABELS[to]}" تُضبط من العملية نفسها وليس يدويًا.`,
      requiresOverride,
    };
  }
  if (!ALLOWED_TRANSITIONS[from].includes(to)) {
    return {
      allowed: false,
      reason: `لا يمكن نقل القطعة من "${STATUS_LABELS[from]}" إلى "${STATUS_LABELS[to]}".`,
      requiresOverride,
    };
  }
  return { allowed: true, requiresOverride };
}

/** الحالات التي يمكن للمستخدم اختيارها يدويًا من شاشة المخزون. */
export function manualTargets(from: ItemStatus): ItemStatus[] {
  return ALLOWED_TRANSITIONS[from].filter(
    (to) => canTransition(from, to, { manual: true }).allowed,
  );
}
