import ReturnPanel from '@/components/ReturnPanel';
import { listReturns } from '@/services/return.service';
import { formatDate } from '@/lib/date';

export const dynamic = 'force-dynamic';

export default async function ReturnsPage() {
  const { rows } = await listReturns({ page: 1, pageSize: 20 });

  return (
    <div className="space-y-6">
      <h1 className="section-title">الإرجاع</h1>
      <ReturnPanel />

      <div className="card overflow-hidden">
        <div className="card-header">آخر عمليات الإرجاع</div>
        <div className="overflow-x-auto">
          <table className="table">
            <thead>
              <tr><th>رقم الإرجاع</th><th>العقد</th><th>العميل</th><th>التاريخ</th><th>القطع</th><th>الحالة</th></tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.id}>
                  <td className="num">{r.returnNo}</td>
                  <td className="num">{r.rental.rentalNo}</td>
                  <td>{r.rental.customer.fullName}</td>
                  <td className="num">{formatDate(r.returnDate)}</td>
                  <td className="num">{r.items.map((i) => i.item.itemCode).join('، ')}</td>
                  <td>
                    <span className={`badge ${r.isVoided ? 'bg-red-100 text-danger' : 'bg-green-100 text-ok'}`}>
                      {r.isVoided ? 'ملغاة' : 'مسجّلة'}
                    </span>
                  </td>
                </tr>
              ))}
              {rows.length === 0 && (
                <tr><td colSpan={6} className="text-center text-slate-500 py-8">لا توجد عمليات إرجاع بعد.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
