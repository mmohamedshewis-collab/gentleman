import { z } from 'zod';
import { prisma } from '@/lib/db';
import { Errors } from '@/lib/errors';
import { writeAudit } from '@/lib/audit';
import { requirePermission } from '@/lib/auth/rbac';
import { businessToday, toBusinessDate, formatDate } from '@/lib/date';
import { round2, add } from '@/lib/money';
import { STATUS_LABELS, type ItemStatus } from '@/lib/inventory/item-state';
import { BLOCKING_STATUSES, overlaps } from '@/lib/availability';
import {
  ACTIVE_STATUS, displayState, assertActionable, assertReservationDates,
  buildReservationNo, RESERVATION_LABELS, type ReservationStatus,
} from '@/lib/reservations/reservation-state';
import { createRental } from '@/services/rental.service';

/**
 * الحجز المسبق — MVP.
 *
 * ★ يعيد استخدام ما هو مبنيٌّ بالفعل:
 *   - `item_bookings` وقيد `ex_item_booking_overlap` لمنع التعارض (M3)
 *   - `createRental` للتحويل — بلا أي منطق تأجير مكرر
 *   - `payments` بغرض `RESERVATION_DEPOSIT` القائم للعربون
 *
 * ★ الأثر المالي: **صفر إيراد**. الحجز وعد لا عملية.
 *   العربون دخول نقدي فقط، ويُعترف بالإيراد عند التحويل داخل العقد.
 */

const money = z.coerce.number().nonnegative('القيمة لا يمكن أن تكون سالبة');

export const createReservationSchema = z.object({
  customerId: z.number().int().positive('يجب اختيار العميل'),
  employeeId: z.number().int().positive().nullable().optional(),
  eventDate: z.string(),
  pickupDate: z.string(),
  returnDate: z.string(),
  items: z
    .array(z.object({
      itemId: z.number().int().positive(),
      agreedPrice: money.default(0),
    }))
    .min(1, 'يجب اختيار قطعة واحدة على الأقل'),
  depositAmount: money.default(0),
  paymentMethodId: z.number().int().positive().nullable().optional(),
  notes: z.string().max(500).optional(),
});

export const cancelReservationSchema = z.object({
  reservationId: z.number().int().positive(),
  reason: z.string().trim().min(3, 'سبب الإلغاء مطلوب'),
  /** الإلغاء من المحل يوجب رد العربون كاملًا (Q4 المعتمد) */
  cancelledByShop: z.boolean().default(false),
  refundPaymentMethodId: z.number().int().positive().nullable().optional(),
});

export const convertReservationSchema = z.object({
  reservationId: z.number().int().positive(),
  paidAmount: money.default(0),
  paymentMethodId: z.number().int().positive().nullable().optional(),
  insurancePerItem: money.default(0),
  insurancePaymentMethodId: z.number().int().positive().nullable().optional(),
});

export const reservationQuerySchema = z.object({
  status: z.string().optional(),
  from: z.string().optional(),
  to: z.string().optional(),
  customerId: z.coerce.number().int().positive().optional(),
});

// ============================ العرض ============================

export async function listReservations(input: z.infer<typeof reservationQuerySchema>) {
  await requirePermission('reservations.view');
  const today = businessToday();

  const rows = await prisma.reservation.findMany({
    where: {
      customerId: input.customerId,
      ...(input.status ? { status: input.status as ReservationStatus } : {}),
      ...(input.from && input.to
        ? { pickupDate: { gte: toBusinessDate(input.from), lte: toBusinessDate(input.to) } }
        : {}),
    },
    include: {
      customer: { select: { fullName: true, phone: true, isWalkIn: true } },
      employee: { select: { fullName: true } },
      items: { include: { item: { include: { product: { select: { nameAr: true } } } } } },
      convertedRental: { select: { rentalNo: true } },
      payments: { where: { isVoided: false }, select: { amount: true, direction: true } },
    },
    orderBy: { pickupDate: 'asc' },
  });

  return rows.map((r) => {
    const view = displayState(r.status as ReservationStatus, r.pickupDate, today);
    const collected = r.payments
      .filter((p) => p.direction === 'IN')
      .reduce((a, p) => a.plus(p.amount.toString()), round2(0));
    const refunded = r.payments
      .filter((p) => p.direction === 'OUT')
      .reduce((a, p) => a.plus(p.amount.toString()), round2(0));

    return {
      id: r.id,
      reservationNo: r.reservationNo,
      customer: r.customer.isWalkIn ? 'عميل نقدي' : r.customer.fullName,
      phone: r.customer.phone,
      employee: r.employee?.fullName ?? null,
      eventDate: formatDate(r.eventDate),
      pickupDate: formatDate(r.pickupDate),
      returnDate: formatDate(r.returnDate),
      depositAmount: r.depositAmount.toString(),
      depositCollected: collected.toString(),
      depositRefunded: refunded.toString(),
      status: r.status,
      // ★ حالة مشتقة — غير مخزَّنة
      displayLabel: view.label,
      isMissed: view.isMissed,
      convertedRentalNo: r.convertedRental?.rentalNo ?? null,
      cancelReason: r.cancelReason,
      items: r.items.map((li) => ({
        itemId: li.itemId,
        itemCode: li.item?.itemCode ?? null,
        product: li.item?.product.nameAr ?? null,
        agreedPrice: li.agreedPrice.toString(),
      })),
      notes: r.notes,
    };
  });
}

// ============================ الإنشاء ============================

export async function createReservation(input: z.infer<typeof createReservationSchema>) {
  const actor = await requirePermission('reservations.create');

  const pickupDate = toBusinessDate(input.pickupDate);
  const returnDate = toBusinessDate(input.returnDate);
  const eventDate = toBusinessDate(input.eventDate);

  try {
    assertReservationDates({ pickupDate, returnDate, eventDate });
  } catch (e) {
    throw Errors.rule((e as Error).message);
  }

  const itemIds = input.items.map((i) => i.itemId);
  if (new Set(itemIds).size !== itemIds.length) {
    throw Errors.rule('لا يمكن تكرار نفس القطعة داخل الحجز.');
  }

  const deposit = round2(input.depositAmount);
  const total = add(...input.items.map((i) => i.agreedPrice));
  if (deposit.gt(total) && total.gt(0)) {
    throw Errors.rule('العربون لا يمكن أن يتجاوز قيمة الحجز.');
  }
  if (deposit.gt(0) && !input.paymentMethodId) {
    throw Errors.rule('يجب تحديد طريقة الدفع لتحصيل العربون.');
  }

  const customer = await prisma.customer.findUnique({ where: { id: input.customerId } });
  if (!customer) throw Errors.notFound('العميل');
  if (!customer.isActive) throw Errors.rule('العميل معطّل.');

  return prisma.$transaction(async (tx) => {
    // 1) قفل القطع وفحص صلاحيتها للحجز
    const locked = await tx.$queryRaw<{ id: number; item_code: string; status: ItemStatus }[]>`
      SELECT id, item_code, status FROM product_items
       WHERE id = ANY(${itemIds}::int[]) ORDER BY id FOR UPDATE
    `;
    if (locked.length !== itemIds.length) throw Errors.notFound('إحدى القطع');

    for (const l of locked) {
      if ((BLOCKING_STATUSES as readonly string[]).includes(l.status)) {
        throw Errors.rule(
          `لا يمكن حجز القطعة ${l.item_code} لأن حالتها "${STATUS_LABELS[l.status]}".`,
        );
      }
    }

    // 2) رقم الحجز — قفل استشاري يمنع التكرار بين جلستين
    await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext('reservation_no'))`;
    const year = pickupDate.getUTCFullYear();
    const last = await tx.reservation.findFirst({
      where: { reservationNo: { startsWith: `RES-${year}-` } },
      orderBy: { reservationNo: 'desc' },
      select: { reservationNo: true },
    });
    const seq = last ? Number.parseInt(last.reservationNo.slice(9), 10) + 1 : 1;

    const reservation = await tx.reservation.create({
      data: {
        reservationNo: buildReservationNo(year, Number.isFinite(seq) ? seq : 1),
        customerId: input.customerId,
        employeeId: input.employeeId ?? actor.employeeId ?? null,
        eventDate,
        pickupDate,
        returnDate,
        depositAmount: deposit.toString(),
        status: ACTIVE_STATUS,
        notes: input.notes?.trim() || null,
        createdBy: actor.id,
      },
    });

    // 3) السطور + حجز الفترة زمنيًا
    for (const line of input.items) {
      await tx.reservationItem.create({
        data: {
          reservationId: reservation.id,
          itemId: line.itemId,
          quantity: 1,
          agreedPrice: round2(line.agreedPrice).toString(),
        },
      });

      // ★ قيد ex_item_booking_overlap يرفض أي تعارض — خط الدفاع الأخير
      try {
        await tx.itemBooking.create({
          data: {
            itemId: line.itemId,
            startDate: pickupDate,
            endDate: returnDate,
            sourceType: 'RESERVATION',
            sourceId: reservation.id,
            createdBy: actor.id,
          },
        });
      } catch (e) {
        const code = (e as { code?: string })?.code;
        const msg = (e as Error).message ?? '';
        if (code === 'P2010' || /ex_item_booking_overlap|exclusion/i.test(msg)) {
          const item = locked.find((l) => l.id === line.itemId);
          throw Errors.conflict(
            `القطعة ${item?.item_code ?? line.itemId} محجوزة أو مؤجرة في فترة متقاطعة مع هذا الحجز.`,
          );
        }
        throw e;
      }
    }

    // 4) العربون — دخول نقدي فقط، لا إيراد
    if (deposit.gt(0)) {
      await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext('payment_no'))`;
      const lastPay = await tx.payment.findFirst({
        where: { paymentNo: { startsWith: `PAY-${year}-` } },
        orderBy: { paymentNo: 'desc' },
        select: { paymentNo: true },
      });
      const paySeq = lastPay ? Number.parseInt(lastPay.paymentNo.slice(9), 10) + 1 : 1;

      await tx.payment.create({
        data: {
          paymentNo: `PAY-${year}-${String(Number.isFinite(paySeq) ? paySeq : 1).padStart(6, '0')}`,
          paymentDate: businessToday(),
          direction: 'IN',
          purpose: 'RESERVATION_DEPOSIT',
          isInsurance: false,
          customerId: input.customerId,
          reservationId: reservation.id,
          amount: deposit.toString(),
          paymentMethodId: input.paymentMethodId!,
          createdBy: actor.id,
        },
      });
    }

    await writeAudit(
      {
        userId: actor.id,
        action: 'reservation.create',
        entityType: 'Reservation',
        entityId: reservation.id,
        after: {
          reservationNo: reservation.reservationNo,
          customerId: input.customerId,
          pickupDate: formatDate(pickupDate),
          returnDate: formatDate(returnDate),
          items: itemIds,
          depositAmount: deposit.toString(),
          // ★ توثيق صريح: الحجز لا يولّد إيرادًا
          revenueImpact: '0',
        },
      },
      tx,
    );

    return {
      id: reservation.id,
      reservationNo: reservation.reservationNo,
      depositAmount: deposit.toString(),
      itemCount: itemIds.length,
    };
  });
}

// ============================ الإلغاء ============================

export async function cancelReservation(input: z.infer<typeof cancelReservationSchema>) {
  const actor = await requirePermission('reservations.cancel');

  return prisma.$transaction(async (tx) => {
    const locked = await tx.$queryRaw<
      { id: number; reservation_no: string; status: ReservationStatus; customer_id: number }[]
    >`
      SELECT id, reservation_no, status, customer_id FROM reservations
       WHERE id = ${input.reservationId} FOR UPDATE
    `;
    if (locked.length === 0) throw Errors.notFound('الحجز');
    const res = locked[0];

    try {
      assertActionable(res.status, 'cancel');
    } catch (e) {
      throw Errors.rule((e as Error).message);
    }

    // 1) تحرير الفترة المحجوزة
    await tx.itemBooking.updateMany({
      where: { sourceType: 'RESERVATION', sourceId: res.id, isActive: true },
      data: { isActive: false },
    });

    // 2) رد العربون — عند إلغاء المحل فقط (Q4 المعتمد)
    let refunded = round2(0);
    if (input.cancelledByShop) {
      const collected = await tx.payment.aggregate({
        _sum: { amount: true },
        where: {
          reservationId: res.id, direction: 'IN',
          isInsurance: false, isVoided: false,
        },
      });
      const alreadyRefunded = await tx.payment.aggregate({
        _sum: { amount: true },
        where: {
          reservationId: res.id, direction: 'OUT',
          purpose: 'CUSTOMER_REFUND', isVoided: false,
        },
      });
      const refundable = round2(collected._sum.amount?.toString() ?? 0)
        .minus(alreadyRefunded._sum.amount?.toString() ?? 0);

      if (refundable.gt(0)) {
        if (!input.refundPaymentMethodId) {
          throw Errors.rule('يجب تحديد طريقة الدفع لرد العربون.');
        }
        await requirePermission('payments.refund');

        await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext('payment_no'))`;
        const year = businessToday().getUTCFullYear();
        const lastPay = await tx.payment.findFirst({
          where: { paymentNo: { startsWith: `PAY-${year}-` } },
          orderBy: { paymentNo: 'desc' },
          select: { paymentNo: true },
        });
        const paySeq = lastPay ? Number.parseInt(lastPay.paymentNo.slice(9), 10) + 1 : 1;

        await tx.payment.create({
          data: {
            paymentNo: `PAY-${year}-${String(Number.isFinite(paySeq) ? paySeq : 1).padStart(6, '0')}`,
            paymentDate: businessToday(),
            direction: 'OUT',
            purpose: 'CUSTOMER_REFUND',
            isInsurance: false,
            customerId: res.customer_id,
            reservationId: res.id,
            amount: refundable.toString(),
            paymentMethodId: input.refundPaymentMethodId,
            notes: `رد عربون حجز ${res.reservation_no}: ${input.reason}`,
            createdBy: actor.id,
          },
        });
        refunded = refundable;
      }
    }

    // 3) الحالة النهائية
    const updated = await tx.reservation.update({
      where: { id: res.id },
      data: { status: 'CANCELLED', cancelReason: input.reason },
    });

    await writeAudit(
      {
        userId: actor.id,
        action: 'reservation.cancel',
        entityType: 'Reservation',
        entityId: res.id,
        before: { status: res.status },
        after: {
          status: 'CANCELLED',
          cancelledByShop: input.cancelledByShop,
          depositRefunded: refunded.toString(),
        },
        reason: input.reason,
      },
      tx,
    );

    return {
      id: updated.id,
      reservationNo: updated.reservationNo,
      status: updated.status,
      depositRefunded: refunded.toString(),
    };
  });
}

// ============================ التحويل إلى تأجير ============================

/**
 * التحويل: يحرّر حجز الفترة ثم يستدعي `createRental` القائمة.
 * ⛔ لا منطق تأجير مكرر — كل قواعد M3 تنطبق كما هي.
 */
export async function convertReservation(input: z.infer<typeof convertReservationSchema>) {
  const actor = await requirePermission('reservations.convert');

  // 1) قراءة الحجز والتحقق منه
  const reservation = await prisma.reservation.findUnique({
    where: { id: input.reservationId },
    include: { items: true },
  });
  if (!reservation) throw Errors.notFound('الحجز');

  try {
    assertActionable(reservation.status as ReservationStatus, 'convert');
  } catch (e) {
    throw Errors.rule((e as Error).message);
  }
  if (reservation.items.length === 0) throw Errors.rule('الحجز بلا قطع.');

  const itemIds = reservation.items
    .map((i) => i.itemId)
    .filter((id): id is number => id !== null);
  if (itemIds.length === 0) throw Errors.rule('الحجز بلا قطع محددة.');

  // 2) تحرير فترة الحجز قبل إنشاء العقد، وإلا رفضها قيد التعارض بحجزها هي
  await prisma.$transaction(async (tx) => {
    const locked = await tx.$queryRaw<{ status: ReservationStatus }[]>`
      SELECT status FROM reservations WHERE id = ${reservation.id} FOR UPDATE
    `;
    if (locked.length === 0) throw Errors.notFound('الحجز');
    if (locked[0].status !== reservation.status) {
      throw Errors.conflict('تغيّرت حالة الحجز — أعد المحاولة.');
    }
    await tx.itemBooking.updateMany({
      where: { sourceType: 'RESERVATION', sourceId: reservation.id, isActive: true },
      data: { isActive: false },
    });
  });

  try {
    // 3) ★ إنشاء العقد بالخدمة المعتمدة — بلا أي تكرار لمنطق التأجير
    const rental = await createRental({
      customerId: reservation.customerId,
      employeeId: reservation.employeeId ?? undefined,
      rentalDate: formatDate(businessToday()),
      expectedReturnDate: formatDate(reservation.returnDate),
      items: reservation.items
        .filter((i) => i.itemId !== null)
        .map((i) => ({
          itemId: i.itemId!,
          unitRentalPrice: Number(i.agreedPrice),
          discount: 0,
          insurancePerItem: Number(input.insurancePerItem),
        })),
      paidAmount: Number(input.paidAmount),
      paymentMethodId: input.paymentMethodId ?? undefined,
      insurancePaymentMethodId: input.insurancePaymentMethodId ?? undefined,
      notes: `محوَّل من حجز ${reservation.reservationNo}`,
    });

    // 4) ★ تخصيص عربون الحجز للعقد + ربط الحجز وإقفاله — في معاملة واحدة
    const result = await prisma.$transaction(async (tx) => {
      // قفل الحجز يمنع تحويلين متزامنين
      const lockedRes = await tx.$queryRaw<{ status: ReservationStatus }[]>`
        SELECT status FROM reservations WHERE id = ${reservation.id} FOR UPDATE
      `;
      if (lockedRes.length === 0) throw Errors.notFound('الحجز');
      if (lockedRes[0].status === 'CONVERTED') {
        throw Errors.conflict('الحجز محوَّل بالفعل — لا يُحوَّل مرتين.');
      }

      // ★ العربون المدفوع وغير المخصَّص بعد
      const unapplied = await tx.payment.findMany({
        where: {
          reservationId: reservation.id,
          direction: 'IN',
          purpose: 'RESERVATION_DEPOSIT',
          isVoided: false,
          rentalId: null,          // لم يُخصَّص لأي عقد
        },
        select: { id: true, amount: true },
      });

      let depositApplied = round2(0);

      if (unapplied.length > 0) {
        // ★ عربون رُدَّ جزئيًا أو كليًا لا يُخصَّص — الرد يسبق التحويل منطقيًا
        const refunded = await tx.payment.aggregate({
          _sum: { amount: true },
          where: {
            reservationId: reservation.id,
            direction: 'OUT',
            purpose: 'CUSTOMER_REFUND',
            isVoided: false,
          },
        });
        if (round2(refunded._sum.amount?.toString() ?? 0).gt(0)) {
          throw Errors.rule('عربون هذا الحجز رُدَّ للعميل ولا يمكن تخصيصه لعقد.');
        }

        const total = add(...unapplied.map((p) => p.amount.toString()));

        // العربون لا يتجاوز قيمة العقد — قيد ck_rental_no_overpay يرفض السداد الزائد
        const rentalGross = round2(rental.totalDue);
        if (total.gt(rentalGross)) {
          throw Errors.rule(
            `العربون (${total.toString()}) يتجاوز قيمة العقد (${rentalGross.toString()}). ` +
            'يجب رد الفرق للعميل قبل التحويل.',
          );
        }

        // ★ تخصيص لا دفعة جديدة: نربط الدفعة القائمة بالعقد ونبقي ربطها بالحجز.
        //   Trigger مزامنة المدفوعات يعيد حساب المدفوع والمتبقي تلقائيًا،
        //   ولا تُنشأ حركة نقدية جديدة لأن تاريخ الدفعة ومبلغها لم يتغيّرا.
        const allocated = await tx.payment.updateMany({
          where: { id: { in: unapplied.map((p) => p.id) }, rentalId: null },
          data: { rentalId: rental.id },
        });
        if (allocated.count !== unapplied.length) {
          throw Errors.conflict('تعذّر تخصيص العربون — أعد المحاولة.');
        }
        depositApplied = total;
      }

      const row = await tx.reservation.update({
        where: { id: reservation.id },
        data: { status: 'CONVERTED', convertedRentalId: rental.id },
      });

      // الرصيد بعد التخصيص كما حسبه Trigger المزامنة
      const after = await tx.rental.findUniqueOrThrow({
        where: { id: rental.id },
        select: { totalDue: true, paidAmount: true, remainingAmount: true },
      });

      await writeAudit(
        {
          userId: actor.id,
          action: 'reservation.convert',
          entityType: 'Reservation',
          entityId: reservation.id,
          before: { status: reservation.status },
          after: {
            status: 'CONVERTED',
            rentalId: rental.id,
            rentalNo: rental.rentalNo,
            // ★ لا يُسجَّل إلا ما خُصِّص فعلًا — ولا ادعاء بلا أثر
            depositApplied: depositApplied.toString(),
            allocatedPaymentIds: unapplied.map((p) => p.id),
            rentalTotalDue: after.totalDue.toString(),
            rentalPaidAmount: after.paidAmount.toString(),
            rentalRemaining: after.remainingAmount.toString(),
            // التخصيص ليس حركة نقدية ولا إيرادًا
            newCashInflow: '0',
            newRevenue: '0',
          },
        },
        tx,
      );

      return { row, depositApplied, after };
    });

    return {
      reservationId: result.row.id,
      reservationNo: result.row.reservationNo,
      rentalId: rental.id,
      rentalNo: rental.rentalNo,
      status: result.row.status,
      depositApplied: result.depositApplied.toString(),
      rentalTotalDue: result.after.totalDue.toString(),
      rentalPaidAmount: result.after.paidAmount.toString(),
      rentalRemaining: result.after.remainingAmount.toString(),
    };
  } catch (e) {
    // فشل إنشاء العقد ⇒ نعيد تفعيل حجز الفترة حتى لا تُفقد
    await prisma.itemBooking.updateMany({
      where: { sourceType: 'RESERVATION', sourceId: reservation.id, isActive: false },
      data: { isActive: true },
    });
    throw e;
  }
}

/** التوفر: القطع المتاحة لفترة مستقبلية — يعيد استخدام منطق M3. */
export async function availabilityCheck(input: {
  itemIds: number[];
  pickupDate: string;
  returnDate: string;
}) {
  await requirePermission('reservations.view');
  const start = toBusinessDate(input.pickupDate);
  const end = toBusinessDate(input.returnDate);

  const conflicts = await prisma.itemBooking.findMany({
    where: {
      itemId: { in: input.itemIds },
      isActive: true,
      startDate: { lte: end },
      endDate: { gte: start },
    },
    include: { item: { select: { itemCode: true } } },
  });

  return {
    period: { from: formatDate(start), to: formatDate(end) },
    conflicts: conflicts.map((c) => ({
      itemId: c.itemId,
      itemCode: c.item.itemCode,
      from: formatDate(c.startDate),
      to: formatDate(c.endDate),
      source: c.sourceType,
      sourceId: c.sourceId,
    })),
    allAvailable: conflicts.length === 0,
  };
}

export { RESERVATION_LABELS, overlaps };
