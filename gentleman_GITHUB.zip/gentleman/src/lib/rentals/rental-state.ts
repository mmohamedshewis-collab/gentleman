/** آلة حالة عملية التأجير — منطق خالص. */

export type RentalStatus = 'ACTIVE' | 'PARTIALLY_RETURNED' | 'CLOSED' | 'VOIDED';

export const RENTAL_STATUS_LABELS: Record<RentalStatus, string> = {
  ACTIVE: 'نشط',
  PARTIALLY_RETURNED: 'مُرجَع جزئيًا',
  CLOSED: 'مغلق',
  VOIDED: 'ملغى',
};

export const RENTAL_ALLOWED_TRANSITIONS: Record<RentalStatus, RentalStatus[]> = {
  ACTIVE: ['PARTIALLY_RETURNED', 'CLOSED', 'VOIDED'],
  PARTIALLY_RETURNED: ['CLOSED', 'ACTIVE'],
  // العقد المغلق يُعاد فتحه فقط عند إلغاء إرجاع سُجِّل بالخطأ.
  CLOSED: ['ACTIVE', 'PARTIALLY_RETURNED'],
  VOIDED: [],
};

/** الملغى وحده نهائي فعلًا — المغلق قابل لإعادة الفتح بإلغاء إرجاع. */
export const RENTAL_TERMINAL: RentalStatus[] = ['VOIDED'];

/** العقد قابل للإلغاء ما دام نشطًا ولم تُرجَع منه أي قطعة. */
export function canVoidRental(status: RentalStatus): { allowed: boolean; reason?: string } {
  if (status === 'VOIDED') return { allowed: false, reason: 'العقد ملغى بالفعل.' };
  if (status === 'CLOSED') return { allowed: false, reason: 'العقد مغلق ولا يمكن إلغاؤه.' };
  if (status === 'PARTIALLY_RETURNED') {
    return { allowed: false, reason: 'تم إرجاع بعض القطع — أكمل الإرجاع بدل الإلغاء.' };
  }
  return { allowed: true };
}

export function canTransitionRental(
  from: RentalStatus,
  to: RentalStatus,
): { allowed: boolean; reason?: string } {
  if (from === to) return { allowed: false, reason: `العقد بالفعل في حالة "${RENTAL_STATUS_LABELS[to]}".` };
  if (RENTAL_TERMINAL.includes(from)) {
    return { allowed: false, reason: `العقد ${RENTAL_STATUS_LABELS[from]} ولا يقبل أي تغيير.` };
  }
  if (!RENTAL_ALLOWED_TRANSITIONS[from].includes(to)) {
    return {
      allowed: false,
      reason: `لا يمكن نقل العقد من "${RENTAL_STATUS_LABELS[from]}" إلى "${RENTAL_STATUS_LABELS[to]}".`,
    };
  }
  return { allowed: true };
}

/** العقد قابل للتعديل أو إضافة دفعات ما لم يكن نهائيًا. */
/** العقد مفتوح تشغيليًا: ما زالت فيه قطع لم تُرجَع. */
export const isRentalOpen = (s: RentalStatus): boolean =>
  s === 'ACTIVE' || s === 'PARTIALLY_RETURNED';

/**
 * العقد يقبل تحصيل دفعات: أي عقد غير ملغى.
 * العقد المغلق قد يبقى عليه مستحق (غرامات إرجاع) يُسدَّد لاحقًا.
 */
export const acceptsPayments = (s: RentalStatus): boolean => s !== 'VOIDED';
