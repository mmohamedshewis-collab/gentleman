import { Decimal } from 'decimal.js';
import { add, sub, mul, round2, pct, computeDocumentTotals, VAT_DISABLED, type VatContext } from '@/lib/money';

/**
 * حسابات تشغيلية مبسّطة — ليست محاسبة.
 * كل رقم هنا يخدم شاشة أو تقريرًا مذكورًا في نطاق المشروع.
 */

/** إجمالي عملية التأجير أو البيع: Subtotal → Discount → Net → VAT → Grand Total. */
export function documentTotals(input: {
  subtotal: Decimal.Value;
  discount: Decimal.Value;
  vat?: VatContext | null;
}) {
  return computeDocumentTotals({ ...input, vat: input.vat ?? VAT_DISABLED });
}

/** المتبقي على العميل في عملية تأجير. */
export const remaining = (grossAmount: Decimal.Value, paid: Decimal.Value) =>
  sub(grossAmount, paid);

/**
 * رسوم التأخير: لكل قطعة في اليوم، مع حد أقصى اختياري من الإعدادات.
 * الإرجاع في يوم الاستحقاق أو قبله = صفر.
 */
export function lateFee(daysLate: number, feePerDay: Decimal.Value, cap: Decimal.Value = 0) {
  if (daysLate <= 0) return round2(0);
  const raw = mul(feePerDay, daysLate);
  const capD = round2(cap);
  return capD.gt(0) && raw.gt(capD) ? capD : raw;
}

/**
 * عمولة الموظف — على صافي التأجير وصافي البيع فقط.
 * التأمين والغرامات والضريبة لا تدخل الوعاء إطلاقًا.
 */
export function commission(input: {
  netRental: Decimal.Value;
  netSales: Decimal.Value;
  rentalPct: Decimal.Value;
  salesPct: Decimal.Value;
}) {
  const rentalCommission = pct(input.netRental, input.rentalPct);
  const salesCommission = pct(input.netSales, input.salesPct);
  return {
    base: add(input.netRental, input.netSales),
    rentalCommission,
    salesCommission,
    total: add(rentalCommission, salesCommission),
  };
}

/** مؤشر أداء الموظف = مبيعاته ÷ تكلفته، مع توزيع الراتب على أيام الفترة. */
export function employeePerformance(input: {
  netRental: Decimal.Value;
  netSales: Decimal.Value;
  monthlySalary: Decimal.Value;
  periodDays: number;
  monthDays: number;
  commissionAmount: Decimal.Value;
}) {
  const sales = add(input.netRental, input.netSales);
  const allocatedSalary = round2(
    new Decimal(input.monthlySalary).times(input.periodDays).dividedBy(input.monthDays),
  );
  const cost = add(allocatedSalary, input.commissionAmount);
  return {
    sales,
    allocatedSalary,
    cost,
    index: cost.isZero() ? null : round2(sales.dividedBy(cost)),
  };
}

/** ربحية القطعة عبر عمرها — تقرير مطلوب صراحةً في النطاق. */
export function itemProfitability(input: {
  purchaseCost: Decimal.Value;
  rentalRevenue: Decimal.Value;
  finesRevenue: Decimal.Value;
  maintenanceCost: Decimal.Value;
  saleRevenue?: Decimal.Value;
  isSold?: boolean;
}) {
  const revenue = add(input.rentalRevenue, input.finesRevenue, input.saleRevenue ?? 0);
  const cost = add(input.maintenanceCost, input.isSold ? input.purchaseCost : 0);
  const profit = sub(revenue, cost);
  const recovery = new Decimal(input.purchaseCost).isZero()
    ? null
    : round2(new Decimal(input.rentalRevenue).dividedBy(input.purchaseCost).times(100));
  return { revenue, cost, profit, costRecoveryPct: recovery };
}

/** صافي الربح المبسّط: الإيراد − تكلفة القطع المباعة − المصروفات. */
export function simplifiedNetProfit(input: {
  rentalRevenue: Decimal.Value;
  salesRevenue: Decimal.Value;
  finesRevenue: Decimal.Value;
  insuranceRetained: Decimal.Value;
  costOfSoldItems: Decimal.Value;
  expenses: Decimal.Value;
}) {
  const revenue = add(
    input.rentalRevenue, input.salesRevenue, input.finesRevenue, input.insuranceRetained,
  );
  return {
    revenue,
    costOfSoldItems: round2(input.costOfSoldItems),
    expenses: round2(input.expenses),
    netProfit: sub(sub(revenue, input.costOfSoldItems), input.expenses),
  };
}

/**
 * رصيد صندوق التأمين — سجل مستقل، ولا يدخل الإيراد ولا الربح.
 * المحتجز (تلف/فقد/مصادرة) هو وحده ما يصبح إيرادًا للمحل.
 */
export type InsuranceTrxType =
  | 'COLLECTED' | 'REFUNDED' | 'DEDUCTED_DAMAGE' | 'DEDUCTED_LOSS' | 'TRANSFERRED_TO_COMPANY';

const RETAINING: InsuranceTrxType[] = ['DEDUCTED_DAMAGE', 'DEDUCTED_LOSS', 'TRANSFERRED_TO_COMPANY'];

export function insuranceBalance(trx: { type: InsuranceTrxType; amount: Decimal.Value }[]) {
  let collected = new Decimal(0), refunded = new Decimal(0), retained = new Decimal(0);
  for (const t of trx) {
    const a = round2(t.amount);
    if (t.type === 'COLLECTED') collected = collected.plus(a);
    else if (t.type === 'REFUNDED') refunded = refunded.plus(a);
    else if (RETAINING.includes(t.type)) retained = retained.plus(a);
  }
  return {
    collected: round2(collected),
    refunded: round2(refunded),
    retained: round2(retained),
    balance: round2(collected.minus(refunded).minus(retained)),
  };
}
