\set ON_ERROR_STOP off
\pset pager off
\t on

\echo '=== C5: سلفة بمبلغ صفر أو سالب (تُرفض) ==='
INSERT INTO employee_advances (advance_no, employee_id, amount, balance, payment_method_id)
VALUES ('ADV-0', 1, 0, 0, 1);
INSERT INTO employee_advances (advance_no, employee_id, amount, balance, payment_method_id)
VALUES ('ADV-NEG', 1, -500, -500, 1);

\echo '=== C5ب: رصيد لا يساوي المبلغ − المسدد (يُرفض) ==='
INSERT INTO employee_advances (advance_no, employee_id, amount, repaid_amount, balance, payment_method_id)
VALUES ('ADV-BAD', 1, 500, 0, 999, 1);

\echo '=== C5ج: سلفة صحيحة (تُقبل) ==='
INSERT INTO employee_advances (advance_no, employee_id, amount, balance, payment_method_id, created_by)
VALUES ('ADV-1', 1, 500, 500, 1, 1);
SELECT 'السلفة: مبلغ=' || amount || ' مسدد=' || repaid_amount || ' رصيد=' || balance || ' حالة=' || status
  FROM employee_advances WHERE advance_no='ADV-1';

\echo ''
\echo '=== C5د: سداد جزئي 200 — الرصيد يتحدث تلقائيًا ==='
INSERT INTO employee_advance_repayments (advance_id, amount, method, created_by)
SELECT id, 200, 'CASH', 1 FROM employee_advances WHERE advance_no='ADV-1';
SELECT 'بعد السداد: مسدد=' || repaid_amount || ' رصيد=' || balance || ' حالة=' || status
  FROM employee_advances WHERE advance_no='ADV-1';

\echo ''
\echo '=== C5هـ: سداد يتجاوز الرصيد (يُرفض) — الرصيد 300 ==='
INSERT INTO employee_advance_repayments (advance_id, amount, method, created_by)
SELECT id, 400, 'CASH', 1 FROM employee_advances WHERE advance_no='ADV-1';

\echo '=== C5و: خصم من الراتب بلا مصروف مرتبط (يُرفض) ==='
INSERT INTO employee_advance_repayments (advance_id, amount, method, created_by)
SELECT id, 100, 'SALARY_DEDUCTION', 1 FROM employee_advances WHERE advance_no='ADV-1';

\echo '=== C5ز: خصم من الراتب بمصروف مرتبط (يُقبل) — راتب 6,000 وخروج 5,700 ==='
INSERT INTO expenses (expense_no, category_id, amount, cash_paid_amount, payment_method_id, employee_id, created_by)
VALUES ('SAL-1', 3, 6000, 5700, 1, 1, 1);
INSERT INTO employee_advance_repayments (advance_id, amount, method, expense_id, created_by)
SELECT a.id, 300, 'SALARY_DEDUCTION', e.id, 1
  FROM employee_advances a, expenses e WHERE a.advance_no='ADV-1' AND e.expense_no='SAL-1';
SELECT 'السلفة أُقفلت: مسدد=' || repaid_amount || ' رصيد=' || balance || ' حالة=' || status
  FROM employee_advances WHERE advance_no='ADV-1';
SELECT 'الراتب: مصروف=' || amount || ' | خروج نقدي فعلي=' || cash_paid_amount ||
       ' | الفرق (تسوية سلفة لا مصروف)=' || (amount - cash_paid_amount)
  FROM expenses WHERE expense_no='SAL-1';

\echo ''
\echo '=== C6: خروج نقدي أكبر من المصروف (يُرفض) ==='
INSERT INTO expenses (expense_no, category_id, amount, cash_paid_amount, payment_method_id, created_by)
VALUES ('SAL-BAD', 3, 1000, 1500, 1, 1);

\echo ''
\echo '=== C7: رد لعميل بلا عملية أصلية (يُرفض) ==='
INSERT INTO payments (payment_no, direction, purpose, customer_id, amount, payment_method_id, created_by)
VALUES ('REF-1', 'OUT', 'CUSTOMER_REFUND', 2, 100, 1, 1);

\echo '=== تهيئة: عقد محصَّل 300 ثم إلغاؤه ==='
INSERT INTO rentals (rental_no, customer_id, rental_date, expected_return_date, subtotal, discount,
  net_amount, gross_amount, total_due, remaining_amount, created_by)
VALUES ('R-REF', 2, CURRENT_DATE, CURRENT_DATE+1, 750, 0, 750, 750, 750, 750, 1);
INSERT INTO payments (payment_no, purpose, rental_id, customer_id, amount, payment_method_id, created_by)
SELECT 'PAY-REF', 'RENTAL', id, 2, 300, 1, 1 FROM rentals WHERE rental_no='R-REF';

\echo '=== C7ب: رد على عملية سارية (يُرفض) ==='
INSERT INTO payments (payment_no, direction, purpose, rental_id, customer_id, amount, payment_method_id, created_by)
SELECT 'REF-2', 'OUT', 'CUSTOMER_REFUND', id, 2, 300, 1, 1 FROM rentals WHERE rental_no='R-REF';

UPDATE rentals SET status='VOIDED', void_reason='إلغاء من المحل' WHERE rental_no='R-REF';

\echo '=== C7ج: رد أكبر من القابل للرد (يُرفض) — المتاح 300 ==='
INSERT INTO payments (payment_no, direction, purpose, rental_id, customer_id, amount, payment_method_id, created_by)
SELECT 'REF-3', 'OUT', 'CUSTOMER_REFUND', id, 2, 500, 1, 1 FROM rentals WHERE rental_no='R-REF';

\echo '=== C7د: رد صحيح 300 (يُقبل) ==='
INSERT INTO payments (payment_no, direction, purpose, rental_id, customer_id, amount, payment_method_id, created_by)
SELECT 'REF-4', 'OUT', 'CUSTOMER_REFUND', id, 2, 300, 1, 1 FROM rentals WHERE rental_no='R-REF';
SELECT 'رُدَّ: ' || amount FROM payments WHERE payment_no='REF-4';

\echo '=== C7هـ: رد ثانٍ (يُرفض) — القابل للرد صار صفرًا ==='
INSERT INTO payments (payment_no, direction, purpose, rental_id, customer_id, amount, payment_method_id, created_by)
SELECT 'REF-5', 'OUT', 'CUSTOMER_REFUND', id, 2, 1, 1, 1 FROM rentals WHERE rental_no='R-REF';
