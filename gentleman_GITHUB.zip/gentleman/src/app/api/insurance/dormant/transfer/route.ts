import { route } from '@/lib/api';
import { transferDormantInsurance, transferDormantSchema } from '@/services/finance.service';

export const POST = route({
  schema: transferDormantSchema,
  handler: ({ input }) => transferDormantInsurance(input),
});
