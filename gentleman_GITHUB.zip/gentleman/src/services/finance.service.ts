import { z } from 'zod';
import type { Prisma } from '@prisma/client';
import { prisma } from '@/lib/db';
import { Errors } from '@/lib/errors';
import { writeAudit } from '@/lib/audit';
import { requirePermission, can } from '@/lib/auth/rbac';
import { businessToday, toBusinessDate, periodBounds, formatDate } from '@/lib/date';
import { round2, add } from '@/lib/money';
import { getNumberSetting } from '@/lib/settings';

const money = z.coerce.number().positive('المبلغ يجب أن يكون أكبر من صفر');

// ==================== المدفوعات ====================

export const rentalPaymentSchema = z.object({
  rentalId: z.number().int().positive(),
  amount: money,
  paymentMethodId: z.number().int().positive(),
  paymentDate: z.string().optional(),
  notes: z.string().max(300).optional(),
});

export const voidPaymentSchema = z.object({
  paymentId: z.number().int().positive(),
  reason: z.string().trim().min(3, 'سبب الإلغاء مطلوب'),
});

export const paymentQuerySchema = z.object({
  from: z.string().optional(),
  to: z.string().optional(),
  rentalId: z.coerce.number().int().optional(),
  includeVoided: z.coerce.boolean().default(false),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(10).max(200).default(50),
});

/**
 * تحصيل دفعة على عقد تأجير.
 * المدفوع والمتبقي لا يُكتبان هنا — Trigger قاعدة البيانات يعيد حسابهما
 * من مجموع الدفعات غير الملغاة وغير التأمينية.
 */
export async function collectRentalPayment(input: z.infer<typeof rentalPaymentSchema>) {
  const actor = await requirePermission('payments.create');
  const paymentDate = input.paymentDate ? toBusinessDate(input.paymentDate) : businessToday();

  if (paymentDate > businessToday()) {
    throw Errors.rule('لا يمكن تسجيل دفعة بتاريخ مستقبلي.');
  }

  return prisma.$transaction(async (tx) => {
    const locked = await tx.$queryRaw<
      { id: number; rental_no: string; status: string; total_due: string; paid_amount: string }[]
    >`
      SELECT id, rental_no, status, total_due, paid_amount
        FROM rentals WHERE id = ${input.rentalId} FOR UPDATE
    `;
    if (locked.length === 0) throw Errors.notFound('عقد التأجير');
    const rental = locked[0];

    if (rental.status === 'VOIDED') {
      throw Errors.rule('لا يمكن تحصيل دفعة على عقد ملغى.');
    }

    const amount = round2(input.amount);
    const remaining = round2(rental.total_due).minus(rental.paid_amount);
    if (amount.gt(remaining)) {
      throw Errors.rule(
        `الدفعة تتجاوز المتبقي على العقد: المتبقي ${remaining.toString()} والمدخل ${amount.toString()}.`,
      );
    }

    const method = await tx.paymentMethod.findUnique({ where: { id: input.paymentMethodId } });
    if (!method || !method.isActive) throw Errors.rule('طريقة الدفع غير صالحة.');

    await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext('payment_no'))`;
    const year = paymentDate.getUTCFullYear();
    const last = await tx.payment.findFirst({
      where: { paymentNo: { startsWith: `PAY-${year}-` } },
      orderBy: { paymentNo: 'desc' },
      select: { paymentNo: true },
    });
    const seq = last ? Number.parseInt(last.paymentNo.slice(9), 10) + 1 : 1;

    const payment = await tx.payment.create({
      data: {
        paymentNo: `PAY-${year}-${String(Number.isFinite(seq) ? seq : 1).padStart(6, '0')}`,
        paymentDate,
        direction: 'IN',
        purpose: 'RENTAL',
        isInsurance: false,
        rentalId: rental.id,
        amount: amount.toString(),
        paymentMethodId: input.paymentMethodId,
        notes: input.notes?.trim() || null,
        createdBy: actor.id,
      },
    });

    await writeAudit(
      {
        userId: actor.id,
        action: 'payment.create',
        entityType: 'Payment',
        entityId: payment.id,
        after: {
          paymentNo: payment.paymentNo,
          rentalNo: rental.rental_no,
          amount: amount.toString(),
          method: method.nameAr,
        },
      },
      tx,
    );

    const after = await tx.rental.findUnique({
      where: { id: rental.id },
      select: { paidAmount: true, remainingAmount: true },
    });

    return {
      id: payment.id,
      paymentNo: payment.paymentNo,
      amount: amount.toString(),
      rentalPaid: after?.paidAmount.toString() ?? '0',
      rentalRemaining: after?.remainingAmount.toString() ?? '0',
    };
  });
}

export async function voidPayment(input: z.infer<typeof voidPaymentSchema>) {
  const actor = await requirePermission('payments.void');

  return prisma.$transaction(async (tx) => {
    const locked = await tx.$queryRaw<
      { id: number; payment_no: string; is_voided: boolean; amount: string; is_insurance: boolean }[]
    >`
      SELECT id, payment_no, is_voided, amount, is_insurance
        FROM payments WHERE id = ${input.paymentId} FOR UPDATE
    `;
    if (locked.length === 0) throw Errors.notFound('الدفعة');
    const payment = locked[0];

    if (payment.is_voided) throw Errors.rule('الدفعة ملغاة بالفعل.');
    if (payment.is_insurance) {
      throw Errors.rule('دفعات التأمين تُعالَج من سجل التأمين وليس من هنا.');
    }

    const updated = await tx.payment.update({
      where: { id: payment.id },
      data: { isVoided: true, voidReason: input.reason },
    });

    await writeAudit(
      {
        userId: actor.id,
        action: 'payment.void',
        entityType: 'Payment',
        entityId: payment.id,
        before: { isVoided: false, amount: payment.amount },
        after: { isVoided: true, amount: payment.amount },
        reason: input.reason,
      },
      tx,
    );

    return { id: updated.id, paymentNo: updated.paymentNo, status: 'ملغاة' };
  });
}

export async function listPayments(input: z.infer<typeof paymentQuerySchema>) {
  await requirePermission('payments.view');

  const where: Prisma.PaymentWhereInput = {
    ...(input.includeVoided ? {} : { isVoided: false }),
    ...(input.rentalId ? { rentalId: input.rentalId } : {}),
  };
  if (input.from && input.to) {
    const { start, end } = periodBounds(input.from, input.to);
    where.createdAt = { gte: start, lte: end };
  }

  const [rows, total] = await Promise.all([
    prisma.payment.findMany({
      where,
      include: {
        paymentMethod: { select: { nameAr: true, isCash: true } },
        rental: { select: { rentalNo: true } },
        sale: { select: { invoiceNo: true } },
        customer: { select: { fullName: true } },
      },
      orderBy: { id: 'desc' },
      skip: (input.page - 1) * input.pageSize,
      take: input.pageSize,
    }),
    prisma.payment.count({ where }),
  ]);

  return { rows, total, page: input.page, pageSize: input.pageSize };
}

// ==================== المصروفات ====================

export const expenseSchema = z.object({
  categoryId: z.number().int().positive(),
  amount: money,
  paymentMethodId: z.number().int().positive(),
  expenseDate: z.string().optional(),
  description: z.string().max(300).optional(),
  employeeId: z.number().int().positive().nullable().optional(),
});

export const voidExpenseSchema = z.object({
  expenseId: z.number().int().positive(),
  reason: z.string().trim().min(3, 'سبب الإلغاء مطلوب'),
});

export const expenseQuerySchema = z.object({
  from: z.string().optional(),
  to: z.string().optional(),
  categoryId: z.coerce.number().int().optional(),
  includeVoided: z.coerce.boolean().default(false),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(10).max(200).default(50),
});

export async function createExpense(input: z.infer<typeof expenseSchema>) {
  const actor = await requirePermission('expenses.create');

  const expenseDate = input.expenseDate ? toBusinessDate(input.expenseDate) : businessToday();
  if (expenseDate > businessToday()) {
    throw Errors.rule('لا يمكن تسجيل مصروف بتاريخ مستقبلي.');
  }

  // حد مصروف الموظف — القيمة 0 تعني **ممنوع** لا «بلا حد»،
  // فالافتراض الآمن أن الصلاحية مغلقة حتى يفتحها المدير صراحةً.
  // التجاوز بصلاحية مخصصة وحدها: expenses.void للإلغاء فقط ولا تمنح تجاوزًا.
  const staffCap = await getNumberSetting('expenses.staff_max_amount');
  const amount = round2(input.amount);
  if (!can(actor, 'expenses.limit.override')) {
    if (staffCap.lte(0) || amount.gt(staffCap)) {
      throw Errors.forbidden('expenses.limit.override');
    }
  }

  return prisma.$transaction(async (tx) => {
    const category = await tx.expenseCategory.findUnique({ where: { id: input.categoryId } });
    if (!category || !category.isActive) throw Errors.rule('فئة المصروف غير صالحة.');

    const method = await tx.paymentMethod.findUnique({ where: { id: input.paymentMethodId } });
    if (!method || !method.isActive) throw Errors.rule('طريقة الدفع غير صالحة.');

    await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext('expense_no'))`;
    const year = expenseDate.getUTCFullYear();
    const last = await tx.expense.findFirst({
      where: { expenseNo: { startsWith: `EXP-${year}-` } },
      orderBy: { expenseNo: 'desc' },
      select: { expenseNo: true },
    });
    const seq = last ? Number.parseInt(last.expenseNo.slice(9), 10) + 1 : 1;

    const expense = await tx.expense.create({
      data: {
        expenseNo: `EXP-${year}-${String(Number.isFinite(seq) ? seq : 1).padStart(6, '0')}`,
        expenseDate,
        categoryId: input.categoryId,
        amount: amount.toString(),
        paymentMethodId: input.paymentMethodId,
        description: input.description?.trim() || null,
        employeeId: input.employeeId ?? null,
        createdBy: actor.id,
      },
    });

    await writeAudit(
      {
        userId: actor.id,
        action: 'expense.create',
        entityType: 'Expense',
        entityId: expense.id,
        after: {
          expenseNo: expense.expenseNo,
          category: category.nameAr,
          amount: amount.toString(),
        },
      },
      tx,
    );

    return { id: expense.id, expenseNo: expense.expenseNo, amount: amount.toString() };
  });
}

export async function voidExpense(input: z.infer<typeof voidExpenseSchema>) {
  const actor = await requirePermission('expenses.void');

  return prisma.$transaction(async (tx) => {
    const locked = await tx.$queryRaw<
      { id: number; expense_no: string; is_voided: boolean; amount: string }[]
    >`
      SELECT id, expense_no, is_voided, amount FROM expenses WHERE id = ${input.expenseId} FOR UPDATE
    `;
    if (locked.length === 0) throw Errors.notFound('المصروف');
    const expense = locked[0];
    if (expense.is_voided) throw Errors.rule('المصروف ملغى بالفعل.');

    const linkedCommission = await tx.commission.findFirst({
      where: { paidExpenseId: expense.id },
      select: { id: true },
    });
    if (linkedCommission) {
      throw Errors.rule('هذا المصروف مرتبط بصرف عمولة — ألغِ صرف العمولة أولًا.');
    }

    await tx.expense.update({
      where: { id: expense.id },
      data: { isVoided: true, voidReason: input.reason },
    });

    await writeAudit(
      {
        userId: actor.id,
        action: 'expense.void',
        entityType: 'Expense',
        entityId: expense.id,
        before: { isVoided: false, amount: expense.amount },
        after: { isVoided: true, amount: expense.amount },
        reason: input.reason,
      },
      tx,
    );

    return { id: expense.id, expenseNo: expense.expense_no, status: 'ملغى' };
  });
}

export async function listExpenses(input: z.infer<typeof expenseQuerySchema>) {
  await requirePermission('expenses.view');

  const where: Prisma.ExpenseWhereInput = {
    ...(input.includeVoided ? {} : { isVoided: false }),
    ...(input.categoryId ? { categoryId: input.categoryId } : {}),
  };
  if (input.from && input.to) {
    const { start, end } = periodBounds(input.from, input.to);
    where.createdAt = { gte: start, lte: end };
  }

  const [rows, total, sum] = await Promise.all([
    prisma.expense.findMany({
      where,
      include: {
        category: { select: { nameAr: true } },
        paymentMethod: { select: { nameAr: true } },
        employee: { select: { fullName: true } },
      },
      orderBy: { id: 'desc' },
      skip: (input.page - 1) * input.pageSize,
      take: input.pageSize,
    }),
    prisma.expense.count({ where }),
    prisma.expense.aggregate({ where, _sum: { amount: true } }),
  ]);

  return {
    rows,
    total,
    totalAmount: (sum._sum.amount ?? 0).toString(),
    page: input.page,
    pageSize: input.pageSize,
  };
}

export async function listExpenseCategories() {
  await requirePermission('expenses.view');
  return prisma.expenseCategory.findMany({ where: { isActive: true }, orderBy: { nameAr: 'asc' } });
}

export async function listPaymentMethods() {
  await requirePermission('payments.view');
  return prisma.paymentMethod.findMany({ where: { isActive: true }, orderBy: { id: 'asc' } });
}

// ============================ Q13: التأمين الراكد ============================

/**
 * التأمينات الراكدة — Q13 المعتمد:
 * تأمين لم يُطالَب به بعد `insurance.dormant_days` يُحوَّل للمحل
 * **باعتماد مدير وسبب مكتوب**.
 *
 * ★ يعيد استخدام آلية M6 نفسها حرفيًا: نوع `TRANSFERRED_TO_COMPANY`
 *   بنفس دفتر التأمين ورصيده الجاري. إيراد بلا تحصيل نقدي جديد —
 *   المال في الدرج أصلًا، تمامًا كـ «التأمين المُستبقى».
 * ⛔ لا منطق تأمين ثانٍ ولا نموذج محاسبي جديد.
 */

export const dormantQuerySchema = z.object({
  asOf: z.string().optional(),
});

export const transferDormantSchema = z.object({
  rentalId: z.number().int().positive(),
  amount: z.coerce.number().positive('المبلغ يجب أن يكون أكبر من صفر'),
  reason: z.string().trim().min(3, 'سبب التحويل مطلوب'),
});

/** قائمة العقود ذات التأمين الراكد — قراءة فقط. */
export async function listDormantInsurance(input: z.infer<typeof dormantQuerySchema>) {
  await requirePermission('insurance.view');

  const days = await getNumberSetting('insurance.dormant_days');
  const asOf = input.asOf ? toBusinessDate(input.asOf) : businessToday();
  const cutoff = new Date(asOf.getTime() - days.toNumber() * 86_400_000);

  // عقود مغلقة أو ملغاة مضى على آخر حركة تأمين فيها المدة المحددة
  const rentals = await prisma.rental.findMany({
    where: {
      status: { in: ['CLOSED', 'VOIDED'] },
      insuranceAmount: { gt: 0 },
      updatedAt: { lt: cutoff },
    },
    include: {
      customer: { select: { fullName: true, phone: true } },
      insuranceTransactions: { where: { isVoided: false } },
    },
    orderBy: { updatedAt: 'asc' },
  });

  const rows = [];
  for (const r of rentals) {
    let held = round2(0);
    for (const t of r.insuranceTransactions) {
      const amt = round2(t.amount.toString());
      if (t.type === 'COLLECTED') held = held.plus(amt);
      else held = held.minus(amt);   // مردود · مستقطع · محوَّل
    }
    if (held.lte(0)) continue;

    rows.push({
      rentalId: r.id,
      rentalNo: r.rentalNo,
      customer: r.customer.fullName,
      phone: r.customer.phone,
      lastActivity: formatDate(r.updatedAt),
      heldAmount: held.toString(),
      daysDormant: Math.floor((asOf.getTime() - r.updatedAt.getTime()) / 86_400_000),
    });
  }

  return {
    dormantDays: days.toString(),
    asOf: formatDate(asOf),
    rows,
    totalHeld: rows.length ? add(...rows.map((x) => x.heldAmount)).toString() : '0',
    note:
      'التحويل للمحل يعترف بالمبلغ إيرادًا بلا تحصيل نقدي جديد — المال في الدرج أصلًا. ' +
      'يتطلب اعتماد مدير وسببًا مكتوبًا.',
  };
}

/** تحويل تأمين راكد للمحل — باعتماد مدير وسبب (Q13). */
export async function transferDormantInsurance(input: z.infer<typeof transferDormantSchema>) {
  const actor = await requirePermission('insurance.manage');
  const amount = round2(input.amount);

  return prisma.$transaction(async (tx) => {
    const locked = await tx.$queryRaw<{ id: number; rental_no: string; status: string }[]>`
      SELECT id, rental_no, status FROM rentals WHERE id = ${input.rentalId} FOR UPDATE
    `;
    if (locked.length === 0) throw Errors.notFound('عقد التأجير');
    const rental = locked[0];
    if (rental.status !== 'CLOSED' && rental.status !== 'VOIDED') {
      throw Errors.rule('لا يُحوَّل التأمين إلا من عقد مغلق أو ملغى.');
    }

    // المتاح فعلًا للتحويل من هذا العقد
    const trx = await tx.insuranceTransaction.findMany({
      where: { rentalId: rental.id, isVoided: false },
      select: { type: true, amount: true },
    });
    let held = round2(0);
    for (const t of trx) {
      const amt = round2(t.amount.toString());
      held = t.type === 'COLLECTED' ? held.plus(amt) : held.minus(amt);
    }
    if (amount.gt(held)) {
      throw Errors.rule(`المبلغ يتجاوز التأمين المحتفظ به: المتاح ${held.toString()}.`);
    }

    // ★ نفس آلية M6: قفل الدفتر ثم رصيد جارٍ
    await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext('insurance_ledger'))`;
    const last = await tx.insuranceTransaction.findFirst({
      orderBy: { id: 'desc' },
      select: { balanceAfter: true },
    });
    const balance = round2(last?.balanceAfter?.toString() ?? 0).minus(amount);

    const row = await tx.insuranceTransaction.create({
      data: {
        trxDate: businessToday(),
        type: 'TRANSFERRED_TO_COMPANY',
        rentalId: rental.id,
        amount: amount.toString(),
        balanceAfter: balance.toString(),
        reason: input.reason,
        approvedBy: actor.id,   // الاعتماد إلزامي بقيد قاعدة البيانات
        createdBy: actor.id,
      },
    });

    await writeAudit(
      {
        userId: actor.id,
        action: 'insurance.transfer_dormant',
        entityType: 'InsuranceTransaction',
        entityId: row.id,
        after: {
          rentalNo: rental.rental_no,
          amount: amount.toString(),
          balanceAfter: balance.toString(),
          approvedBy: actor.id,
          // ★ إيراد بلا تحصيل نقدي — نفس منطق التأمين المُستبقى
          cashInflow: '0',
        },
        reason: input.reason,
      },
      tx,
    );

    return {
      id: row.id,
      rentalNo: rental.rental_no,
      amount: amount.toString(),
      insuranceBalanceAfter: balance.toString(),
      cashInflow: '0',
    };
  });
}
