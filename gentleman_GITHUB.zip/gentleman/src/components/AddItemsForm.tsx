'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function AddItemsForm({
  products,
}: { products: { id: number; code: string; nameAr: string }[] }) {
  const router = useRouter();
  const [productId, setProductId] = useState(String(products[0]?.id ?? ''));
  const [count, setCount] = useState(1);
  const [codePrefix, setCodePrefix] = useState(products[0]?.code ?? '');
  const [purchaseCost, setPurchaseCost] = useState(0);
  const [msg, setMsg] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit() {
    setBusy(true); setMsg(null);
    const res = await fetch('/api/items', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        productId: Number(productId), count: Number(count), codePrefix, purchaseCost,
      }),
    });
    const json = await res.json();
    setBusy(false);
    if (!json.ok) { setMsg({ type: 'err', text: json.error?.message ?? 'تعذّرت الإضافة.' }); return; }
    const codes = json.data.created.map((c: { itemCode: string }) => c.itemCode);
    setMsg({ type: 'ok', text: `تمت إضافة ${json.data.count} قطعة: ${codes[0]} … ${codes[codes.length - 1]}` });
    router.refresh();
  }

  return (
    <div className="card">
      <div className="card-header">إضافة قطع فعلية للمخزون</div>
      <div className="p-5 grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="md:col-span-2">
          <label className="label">المنتج</label>
          <select
            className="input"
            value={productId}
            onChange={(e) => {
              setProductId(e.target.value);
              const p = products.find((x) => String(x.id) === e.target.value);
              if (p) setCodePrefix(p.code);
            }}
          >
            {products.map((p) => <option key={p.id} value={p.id}>{p.nameAr} ({p.code})</option>)}
          </select>
        </div>
        <div>
          <label className="label">بادئة الكود</label>
          <input className="input num" dir="ltr" value={codePrefix}
                 onChange={(e) => setCodePrefix(e.target.value)} />
        </div>
        <div>
          <label className="label">عدد القطع</label>
          <input className="input num" type="number" dir="ltr" min={1} max={200} value={count}
                 onChange={(e) => setCount(Number(e.target.value))} />
        </div>
        <div>
          <label className="label">تكلفة شراء القطعة</label>
          <input className="input num" type="number" dir="ltr" value={purchaseCost}
                 onChange={(e) => setPurchaseCost(Number(e.target.value))} />
          <p className="text-[11px] text-slate-400 mt-1">
            تُحفظ لتحليل ربحية القطعة فقط، ولا تُعامل كمصروف تشغيلي.
          </p>
        </div>
      </div>
      <div className="px-5 pb-5 flex items-center gap-4">
        <button className="btn-primary" onClick={submit} disabled={busy}>
          {busy ? 'جارٍ الإضافة…' : 'إضافة القطع'}
        </button>
        {msg && (
          <span className={`text-sm font-semibold ${msg.type === 'ok' ? 'text-ok' : 'text-danger'}`}>
            {msg.text}
          </span>
        )}
      </div>
    </div>
  );
}
