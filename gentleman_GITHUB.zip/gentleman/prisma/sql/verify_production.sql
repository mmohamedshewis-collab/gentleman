-- التحقق من سلامة النشر — يفشل بصوت عالٍ إن نقص أي عنصر حماية.
-- يُشغَّل بعد الترحيلات وملف القيود مباشرةً.
DO $$
DECLARE
  v_checks int; v_triggers int; v_fks int; v_tables int;
  v_missing text;
BEGIN
  SELECT count(*) INTO v_checks FROM pg_constraint
    WHERE contype IN ('c','x') AND conname ~ '^(ck|ex)_';
  SELECT count(*) INTO v_triggers FROM pg_trigger WHERE NOT tgisinternal;
  SELECT count(*) INTO v_fks FROM pg_constraint WHERE contype='f';
  SELECT count(*) INTO v_tables FROM information_schema.tables
    WHERE table_schema='public' AND table_type='BASE TABLE';

  RAISE NOTICE 'الجداول=% | قيود CHECK/EXCLUDE=% | مفاتيح أجنبية=% | Triggers=%',
    v_tables, v_checks, v_fks, v_triggers;

  IF v_checks < 47 THEN
    RAISE EXCEPTION 'قيود ناقصة: الموجود % والمطلوب 47 على الأقل. أعد تطبيق 01_constraints.sql', v_checks;
  END IF;
  IF v_triggers < 44 THEN
    RAISE EXCEPTION 'Triggers ناقصة: الموجود % والمطلوب 44 على الأقل.', v_triggers;
  END IF;

  -- عناصر حماية مالية بعينها لا يجوز غيابها
  SELECT string_agg(c, ', ') INTO v_missing FROM unnest(ARRAY[
    'ck_rental_no_overpay','ex_item_booking_overlap','ck_return_settlement',
    'ck_refund_requires_source','ck_user_failed_attempts','ck_closing_amounts'
  ]) c WHERE NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = c);
  IF v_missing IS NOT NULL THEN
    RAISE EXCEPTION 'قيود مالية حرجة مفقودة: %', v_missing;
  END IF;

  SELECT string_agg(t, ', ') INTO v_missing FROM unnest(ARRAY[
    'sync_rental_payment_totals','assert_day_not_closed','prevent_hard_delete',
    'assert_refund_allowed','protect_final_reservation'
  ]) t WHERE NOT EXISTS (SELECT 1 FROM pg_proc WHERE proname = t);
  IF v_missing IS NOT NULL THEN
    RAISE EXCEPTION 'دوال حماية مفقودة: %', v_missing;
  END IF;

  RAISE NOTICE '✅ التحقق من النشر نجح: كل عناصر الحماية المالية موجودة.';
END $$;
