import { z } from 'zod';
import { prisma } from '@/lib/db';
import { Errors } from '@/lib/errors';
import { verifyPassword } from '@/lib/auth/password';
import {
  isLocked, remainingLockMinutes, nextFailureState, successState,
} from '@/lib/auth/lockout';
import { createSession, destroySession } from '@/lib/auth/session';
import { writeAudit } from '@/lib/audit';

export const loginSchema = z.object({
  username: z.string().min(1, 'اسم المستخدم مطلوب'),
  password: z.string().min(1, 'كلمة المرور مطلوبة'),
});

export async function login(input: z.infer<typeof loginSchema>) {
  const username = input.username.trim();
  const now = new Date();

  const user = await prisma.user.findUnique({
    where: { username },
    include: { role: true },
  });

  // رسالة موحدة حتى لا يُكشف وجود اسم المستخدم من عدمه.
  // ★ نتحقق من كلمة المرور دائمًا قبل أي إفصاح عن حالة الحساب،
  //   فلا تفرّق الرسائل ولا التوقيت بين مستخدم موجود وغير موجود.
  if (!user) throw Errors.invalidCredentials();

  const okPw = await verifyPassword(input.password, user.passwordHash);

  if (!okPw) {
    // ★ زيادة ذرّية: قفل صف المستخدم ثم التحديث داخل معاملة واحدة،
    //   فلا تتجاوز المحاولات المتزامنة الحدَّ المسموح.
    await prisma.$transaction(async (tx) => {
      const locked = await tx.$queryRaw<{ failed_attempts: number; locked_until: Date | null }[]>`
        SELECT failed_attempts, locked_until FROM users WHERE id = ${user.id} FOR UPDATE
      `;
      if (locked.length === 0) return;

      // الحساب المقفل لا يزيد عدّاده أكثر — القفل قائم بالفعل
      if (isLocked(locked[0].locked_until, now)) return;

      const next = nextFailureState(locked[0].failed_attempts, now);
      await tx.user.update({
        where: { id: user.id },
        data: { failedAttempts: next.failedAttempts, lockedUntil: next.lockedUntil },
      });

      await writeAudit(
        {
          userId: user.id,
          action: next.lockedUntil ? 'auth.account_locked' : 'auth.login_failed',
          entityType: 'User',
          entityId: user.id,
          after: {
            failedAttempts: next.failedAttempts,
            lockedUntil: next.lockedUntil ? next.lockedUntil.toISOString() : null,
          },
        },
        tx,
      );
    });

    throw Errors.invalidCredentials();
  }

  // ★ القفل يُفحص بعد صحة كلمة المرور فقط:
  //   لو أُعلن قبلها لأصبح فرقُ الرسالة كاشفًا لوجود اسم المستخدم.
  if (isLocked(user.lockedUntil, now)) {
    throw Errors.accountLocked(remainingLockMinutes(user.lockedUntil!, now));
  }

  if (!user.isActive) throw Errors.accountDisabled();

  await createSession(user.id);

  // ★ الدخول الناجح يصفّر العدّاد والقفل معًا
  await prisma.user.update({
    where: { id: user.id },
    data: { lastLoginAt: now, ...successState() },
  });

  await writeAudit({
    userId: user.id,
    action: 'auth.login',
    entityType: 'User',
    entityId: user.id,
  });

  return { id: user.id, fullName: user.fullName, role: user.role.nameAr };
}

export async function logout(userId: number | null) {
  await destroySession();
  if (userId) {
    await writeAudit({ userId, action: 'auth.logout', entityType: 'User', entityId: userId });
  }
  return { done: true };
}
