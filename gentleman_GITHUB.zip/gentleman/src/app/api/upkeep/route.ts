import { route } from '@/lib/api';
import {
  itemUpkeepHistory, upkeepQuerySchema,
  startUpkeep, startUpkeepSchema,
} from '@/services/upkeep.service';

export const GET = route({ schema: upkeepQuerySchema, handler: ({ input }) => itemUpkeepHistory(input) });
export const POST = route({ schema: startUpkeepSchema, handler: ({ input }) => startUpkeep(input) });
