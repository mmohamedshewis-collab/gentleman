import { route } from '@/lib/api';
import {
  listReservations, reservationQuerySchema,
  createReservation, createReservationSchema,
} from '@/services/reservation.service';

export const GET = route({ schema: reservationQuerySchema, handler: ({ input }) => listReservations(input) });
export const POST = route({ schema: createReservationSchema, handler: ({ input }) => createReservation(input) });
