BEGIN;
-- المسار الحقيقي للخدمة: قفل العقد أولًا ثم التحقق ثم الإدراج
SELECT total_due, paid_amount FROM rentals WHERE rental_no='R-M7' FOR UPDATE;
SELECT pg_sleep(0.3);
INSERT INTO payments (payment_no, purpose, rental_id, customer_id, amount, payment_method_id, created_by)
SELECT 'PAY-D' || floor(random()*1000000)::text, 'RENTAL', id, customer_id, 500, 1, 1
  FROM rentals WHERE rental_no='R-M7' AND (total_due - paid_amount) >= 500;
COMMIT;
