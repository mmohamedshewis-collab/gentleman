\set ON_ERROR_STOP off
\pset pager off
\t on

\echo '=== T7: التأمين ليس إيرادًا ولا يدخل المدفوع ولا المتبقي ==='
SELECT 'العقد 1: الإجمالي=' || total_due || ' المدفوع=' || paid_amount ||
       ' المتبقي=' || remaining_amount || ' | التأمين محفوظ منفصلًا=' || insurance_amount
  FROM rentals WHERE id = 1;
SELECT 'مجموع دفعات العقد غير التأمينية=' ||
       COALESCE(SUM(amount) FILTER (WHERE is_insurance = false), 0) ||
       ' | مجموع الدفعات التأمينية=' || COALESCE(SUM(amount) FILTER (WHERE is_insurance), 0)
  FROM payments WHERE rental_id = 1;
SELECT 'إيراد التأجير (من السطور فقط)=' || SUM(net_price) FROM rental_items WHERE rental_id = 1;
SELECT 'سجل التأمين مستقل: عدد الحركات=' || count(*) || ' الرصيد=' ||
       (SELECT balance_after FROM insurance_transactions ORDER BY id DESC LIMIT 1)
  FROM insurance_transactions;

\echo ''
\echo '=== T8: منع السداد الزائد ==='
INSERT INTO payments (payment_no, purpose, rental_id, customer_id, amount, payment_method_id, created_by)
VALUES ('PAY-OVER', 'RENTAL', 1, 2, 5000, 1, 1);
SELECT 'العقد 1 بعد المحاولة: المدفوع=' || paid_amount || ' المتبقي=' || remaining_amount FROM rentals WHERE id=1;

\echo ''
\echo '=== T9: دفعة جزئية صحيحة تحدّث المتبقي تلقائيًا ==='
INSERT INTO payments (payment_no, purpose, rental_id, customer_id, amount, payment_method_id, created_by)
VALUES ('PAY-100', 'RENTAL', 1, 2, 100, 1, 1);
SELECT 'المدفوع=' || paid_amount || ' المتبقي=' || remaining_amount FROM rentals WHERE id=1;

\echo ''
\echo '=== T10: التراجع الكامل عند فشل في منتصف العملية ==='
SELECT 'قبل: عقود=' || (SELECT count(*) FROM rentals) ||
       ' سطور=' || (SELECT count(*) FROM rental_items) ||
       ' حجوزات=' || (SELECT count(*) FROM item_bookings) ||
       ' سجل حالة=' || (SELECT count(*) FROM item_status_history) ||
       ' حركات مخزون=' || (SELECT count(*) FROM inventory_transactions) ||
       ' دفعات=' || (SELECT count(*) FROM payments) ||
       ' تدقيق=' || (SELECT count(*) FROM audit_logs);
SELECT 'حالة القطعة SUIT-0005 قبل=' || status FROM product_items WHERE item_code='SUIT-0005';
UPDATE product_items SET status='MAINTENANCE' WHERE item_code='SUIT-0005';
UPDATE product_items SET status='AVAILABLE' WHERE item_code='SUIT-0005';
SELECT do_rental(ARRAY['SUIT-0005'], 2, 500, 0, 200, 0, 1000, CURRENT_DATE, CURRENT_DATE+1, true);
SELECT 'بعد الفشل: عقود=' || (SELECT count(*) FROM rentals) ||
       ' سطور=' || (SELECT count(*) FROM rental_items) ||
       ' حجوزات=' || (SELECT count(*) FROM item_bookings) ||
       ' سجل حالة=' || (SELECT count(*) FROM item_status_history) ||
       ' حركات مخزون=' || (SELECT count(*) FROM inventory_transactions) ||
       ' دفعات=' || (SELECT count(*) FROM payments) ||
       ' تدقيق=' || (SELECT count(*) FROM audit_logs);
SELECT 'حالة القطعة SUIT-0005 بعد الفشل=' || status FROM product_items WHERE item_code='SUIT-0005';

\echo ''
\echo '=== T11: التعارض الزمني مع حجز مستقبلي ==='
INSERT INTO item_bookings (item_id, start_date, end_date, source_type, source_id)
VALUES (5, CURRENT_DATE + 10, CURRENT_DATE + 12, 'RESERVATION', 99);
SELECT do_rental(ARRAY['SUIT-0005'], 2, 500, 0, 0, 0, 0, CURRENT_DATE + 9, CURRENT_DATE + 11);
SELECT 'فترة غير متقاطعة:';
SELECT 'العقد ' || do_rental(ARRAY['SUIT-0005'], 2, 500, 0, 0, 0, 0, CURRENT_DATE + 13, CURRENT_DATE + 14);
