import { describe, it, expect, vi, beforeEach } from 'vitest';
import { readFileSync } from 'node:fs';
import { MOVEMENT_RULES, dashboardMovement, companyCashPosition } from '../src/lib/cash/cash-movement';
import { revenueOf, expenseOf } from '../src/lib/finance/reconciliation';

/**
 * الإصلاح الحرج: تخصيص عربون الحجز للعقد عند التحويل.
 * كان العميل يُطالَب بمبلغ دفعه بالفعل.
 */

const H = vi.hoisted(() => ({ auditSpy: vi.fn(), createRentalSpy: vi.fn() }));
const { auditSpy, createRentalSpy } = H;

let currentUser: { id: number; employeeId: number | null; permissions: Set<string> };
let reservationRow: Record<string, unknown> | null;
let lockedStatus: string;
let unappliedDeposits: { id: number; amount: string }[];
let refundedSum: string | null;
let rentalAfter: Record<string, unknown>;
let allocatedCount: number | null;
const updateManyCalls: Record<string, unknown>[] = [];

const tx = {
  $queryRaw: vi.fn(async () => [{ status: lockedStatus }]),
  $executeRaw: vi.fn(async () => 1),
  payment: {
    findMany: vi.fn(async () => unappliedDeposits),
    aggregate: vi.fn(async () => ({ _sum: { amount: refundedSum } })),
    updateMany: vi.fn(async (a: any) => {
      updateManyCalls.push(a);
      return { count: allocatedCount ?? unappliedDeposits.length };
    }),
    create: vi.fn(),
  },
  reservation: {
    update: vi.fn(async (a: any) => ({
      id: 1, reservationNo: 'RES-2026-000001', ...a.data,
    })),
  },
  rental: { findUniqueOrThrow: vi.fn(async () => rentalAfter) },
  itemBooking: { updateMany: vi.fn(async () => ({ count: 1 })) },
};

vi.mock('@/lib/db', () => ({
  prisma: {
    $transaction: (fn: any) => fn(tx),
    reservation: { findUnique: vi.fn(async () => reservationRow), findMany: vi.fn(async () => []) },
    itemBooking: { updateMany: vi.fn(async () => ({ count: 1 })), findMany: vi.fn(async () => []) },
    customer: { findUnique: vi.fn(async () => ({ id: 2, isActive: true })) },
    payment: { findMany: vi.fn(async () => unappliedDeposits) },
  },
}));

vi.mock('@/lib/audit', () => ({ writeAudit: H.auditSpy, redact: (x: unknown) => x }));
vi.mock('@/services/rental.service', () => ({ createRental: H.createRentalSpy }));

vi.mock('@/lib/auth/rbac', async (importOriginal) => {
  const actual = await importOriginal<typeof import('@/lib/auth/rbac')>();
  return {
    ...actual,
    requirePermission: async (perm: string) => {
      if (!currentUser.permissions.has(perm)) {
        const { Errors } = await import('@/lib/errors');
        throw Errors.forbidden(perm);
      }
      return currentUser as never;
    },
  };
});

beforeEach(() => {
  auditSpy.mockClear();
  createRentalSpy.mockReset();
  updateManyCalls.length = 0;
  for (const m of Object.values(tx)) {
    if (typeof m === 'object' && m !== null) {
      for (const f of Object.values(m)) if (typeof f === 'function' && 'mockClear' in f) (f as any).mockClear();
    } else if (typeof m === 'function' && 'mockClear' in m) (m as any).mockClear();
  }

  currentUser = {
    id: 1, employeeId: 1,
    permissions: new Set(['reservations.view', 'reservations.convert']),
  };
  lockedStatus = 'PENDING';
  unappliedDeposits = [{ id: 77, amount: '300' }];
  refundedSum = null;
  allocatedCount = null;

  reservationRow = {
    id: 1, reservationNo: 'RES-2026-000001', status: 'PENDING',
    customerId: 2, employeeId: 3,
    returnDate: new Date(Date.now() + 12 * 86_400_000),
    depositAmount: { toString: () => '300' },
    items: [{ itemId: 1, agreedPrice: { toString: () => '1500' } }],
  };

  // العقد بعد تخصيص العربون — كما يحسبه Trigger المزامنة
  rentalAfter = {
    totalDue: { toString: () => '1500' },
    paidAmount: { toString: () => '300' },
    remainingAmount: { toString: () => '1200' },
  };

  createRentalSpy.mockResolvedValue({
    id: 55, rentalNo: 'R-2026-000010', totalDue: '1500',
  });
});

// ==================== A: السيناريو المرجعي ====================

describe('★ A — عربون 300 · عقد 1,500 ⟹ المتبقي 1,200', () => {
  it('★ العميل لا يُطالَب بالـ1,500 كاملة', async () => {
    const { convertReservation } = await import('@/services/reservation.service');
    const r = await convertReservation({ reservationId: 1, paidAmount: 0 });

    expect(r.depositApplied).toBe('300');
    expect(r.rentalTotalDue).toBe('1500');
    expect(r.rentalPaidAmount).toBe('300');
    expect(r.rentalRemaining).toBe('1200');   // ★ كان 1,500 قبل الإصلاح
  });

  it('★ التخصيص يربط الدفعة القائمة بالعقد', async () => {
    const { convertReservation } = await import('@/services/reservation.service');
    await convertReservation({ reservationId: 1, paidAmount: 0 });

    expect(updateManyCalls).toHaveLength(1);
    expect(updateManyCalls[0]).toMatchObject({
      where: { id: { in: [77] }, rentalId: null },
      data: { rentalId: 55 },
    });
  });
});

// ==================== B–D: لا ازدواج مالي ====================

describe('★ B–D — التخصيص لا يُنشئ نقدًا ولا إيرادًا ولا مصروفًا', () => {
  it('★ لا دفعة جديدة تُنشأ', async () => {
    const { convertReservation } = await import('@/services/reservation.service');
    await convertReservation({ reservationId: 1, paidAmount: 0 });
    expect(tx.payment.create).not.toHaveBeenCalled();
  });

  it('★ الدفعة الأصلية لا تُحذف ولا يتغيّر مبلغها ولا تاريخها', async () => {
    const { convertReservation } = await import('@/services/reservation.service');
    await convertReservation({ reservationId: 1, paidAmount: 0 });
    const data = updateManyCalls[0].data as Record<string, unknown>;
    expect(Object.keys(data)).toEqual(['rentalId']);   // لا مبلغ ولا تاريخ
  });

  it('★ التدقيق يوثّق صفر نقد وصفر إيراد', async () => {
    const { convertReservation } = await import('@/services/reservation.service');
    await convertReservation({ reservationId: 1, paidAmount: 0 });
    expect(auditSpy.mock.calls[0][0]).toMatchObject({
      action: 'reservation.convert',
      after: { newCashInflow: '0', newRevenue: '0', depositApplied: '300' },
    });
  });

  it('★ العربون بقي دخولًا نقديًا واحدًا لا إيرادًا', () => {
    const rule = MOVEMENT_RULES.RESERVATION_DEPOSIT;
    expect(rule.isRevenue).toBe(false);
    expect(rule.isExpense).toBe(false);
    // العربون محسوب مرة واحدة يوم تحصيله
    const lines = [{ type: 'RESERVATION_DEPOSIT' as const, amount: 300 }];
    expect(dashboardMovement(lines).net.toString()).toBe('300');
    expect(companyCashPosition(lines).toString()).toBe('300');
    expect(revenueOf(lines).toString()).toBe('0');
    expect(expenseOf(lines).toString()).toBe('0');
  });
});

// ==================== E: التتبّع ====================

describe('★ E — الدفعة تبقى متتبَّعة', () => {
  it('★ تبقى مربوطة بالحجز وبالعقد معًا', async () => {
    const { convertReservation } = await import('@/services/reservation.service');
    await convertReservation({ reservationId: 1, paidAmount: 0 });
    // لم يُمسح reservationId
    const data = updateManyCalls[0].data as Record<string, unknown>;
    expect(data).not.toHaveProperty('reservationId');
    expect(data.rentalId).toBe(55);
  });

  it('★ التدقيق يذكر معرّفات الدفعات المخصَّصة', async () => {
    const { convertReservation } = await import('@/services/reservation.service');
    await convertReservation({ reservationId: 1, paidAmount: 0 });
    expect(auditSpy.mock.calls[0][0].after).toMatchObject({
      allocatedPaymentIds: [77],
    });
  });
});

// ==================== F–I: منع الازدواج ====================

describe('★ F–I — حمايات منع الازدواج', () => {
  it('★ F — لا تخصيص للعربون مرتين: الدفعة المخصَّصة لا تُلتقَط', async () => {
    unappliedDeposits = [];   // كلها مخصَّصة بالفعل
    const { convertReservation } = await import('@/services/reservation.service');
    const r = await convertReservation({ reservationId: 1, paidAmount: 0 });
    expect(r.depositApplied).toBe('0');
    expect(tx.payment.updateMany).not.toHaveBeenCalled();
  });

  it('★ F — شرط rentalId=null يحرس التزامن', async () => {
    const { convertReservation } = await import('@/services/reservation.service');
    await convertReservation({ reservationId: 1, paidAmount: 0 });
    expect((updateManyCalls[0].where as Record<string, unknown>).rentalId).toBeNull();
  });

  it('★ F — فشل التخصيص المتزامن يوقف العملية', async () => {
    allocatedCount = 0;   // جلسة أخرى سبقتنا
    const { convertReservation } = await import('@/services/reservation.service');
    await expect(convertReservation({ reservationId: 1, paidAmount: 0 }))
      .rejects.toMatchObject({ code: 'CONFLICT' });
  });

  it('★ G — عربون مردود لا يُخصَّص', async () => {
    refundedSum = '300';
    const { convertReservation } = await import('@/services/reservation.service');
    await expect(convertReservation({ reservationId: 1, paidAmount: 0 }))
      .rejects.toMatchObject({ code: 'BUSINESS_RULE' });
    expect(tx.payment.updateMany).not.toHaveBeenCalled();
  });

  it('★ H — لا تُخصَّص إلا دفعات هذا الحجز', async () => {
    const { convertReservation } = await import('@/services/reservation.service');
    await convertReservation({ reservationId: 1, paidAmount: 0 });
    const where = tx.payment.findMany.mock.calls[0][0].where;
    expect(where).toMatchObject({
      reservationId: 1, purpose: 'RESERVATION_DEPOSIT', direction: 'IN',
      isVoided: false, rentalId: null,
    });
  });

  it('★ I — لا تحويل مرتين: القفل يكشف الحالة المحوَّلة', async () => {
    lockedStatus = 'CONVERTED';
    const { convertReservation } = await import('@/services/reservation.service');
    await expect(convertReservation({ reservationId: 1, paidAmount: 0 }))
      .rejects.toMatchObject({ code: 'CONFLICT' });
  });

  it('★ I — التحقق المسبق يرفض حجزًا محوَّلًا', async () => {
    reservationRow = { ...reservationRow, status: 'CONVERTED' };
    const { convertReservation } = await import('@/services/reservation.service');
    await expect(convertReservation({ reservationId: 1, paidAmount: 0 }))
      .rejects.toMatchObject({ code: 'BUSINESS_RULE' });
    expect(createRentalSpy).not.toHaveBeenCalled();
  });

  it('★ عربون يتجاوز قيمة العقد يُرفض — يمنع السداد الزائد', async () => {
    unappliedDeposits = [{ id: 77, amount: '2000' }];
    createRentalSpy.mockResolvedValue({ id: 55, rentalNo: 'R-1', totalDue: '1500' });
    const { convertReservation } = await import('@/services/reservation.service');
    await expect(convertReservation({ reservationId: 1, paidAmount: 0 }))
      .rejects.toMatchObject({ code: 'BUSINESS_RULE' });
  });
});

// ==================== J: التزامن ====================

describe('★ J — التحويل المتزامن', () => {
  it('★ القفل على صف الحجز يسبق كل شيء', async () => {
    const { convertReservation } = await import('@/services/reservation.service');
    await convertReservation({ reservationId: 1, paidAmount: 0 });
    const q = (tx.$queryRaw.mock.calls[0][0] as TemplateStringsArray).join(' ');
    expect(q).toContain('FOR UPDATE');
    expect(q).toContain('reservations');
  });
});

// ==================== K: صدق التدقيق ====================

describe('★ K — التدقيق لا يدّعي تخصيصًا لم يقع', () => {
  it('★ بلا عربون: depositApplied = 0 لا قيمة الحجز', async () => {
    unappliedDeposits = [];
    rentalAfter = {
      totalDue: { toString: () => '1500' },
      paidAmount: { toString: () => '0' },
      remainingAmount: { toString: () => '1500' },
    };
    const { convertReservation } = await import('@/services/reservation.service');
    await convertReservation({ reservationId: 1, paidAmount: 0 });
    expect(auditSpy.mock.calls[0][0].after).toMatchObject({
      depositApplied: '0', allocatedPaymentIds: [],
    });
  });

  it('★ التدقيق يحمل رصيد العقد الفعلي بعد التخصيص', async () => {
    const { convertReservation } = await import('@/services/reservation.service');
    await convertReservation({ reservationId: 1, paidAmount: 0 });
    expect(auditSpy.mock.calls[0][0].after).toMatchObject({
      rentalTotalDue: '1500', rentalPaidAmount: '300', rentalRemaining: '1200',
    });
  });
});

// ==================== L: الدورة الكاملة ====================

describe('★ L — الدورة الكاملة: حجز ← عربون ← تحويل ← عقد', () => {
  it('★ العربون يُحصَّل مرة ويُخصَّص مرة، والمتبقي صحيح', async () => {
    const { convertReservation } = await import('@/services/reservation.service');
    const r = await convertReservation({ reservationId: 1, paidAmount: 0 });

    // نقدًا: 300 دخلت يوم الحجز فقط
    const cashLines = [{ type: 'RESERVATION_DEPOSIT' as const, amount: 300 }];
    expect(dashboardMovement(cashLines).net.toString()).toBe('300');
    // إيرادًا: صفر من العربون — الإيراد من العقد
    expect(revenueOf(cashLines).toString()).toBe('0');
    // على العقد: مدفوع 300 ومتبقٍ 1,200
    expect(r.rentalPaidAmount).toBe('300');
    expect(r.rentalRemaining).toBe('1200');
    // ولا دفعة ثانية
    expect(tx.payment.create).not.toHaveBeenCalled();
  });

  it('★ التحويل يستدعي createRental ولا يكرّر منطق التأجير', async () => {
    const { convertReservation } = await import('@/services/reservation.service');
    await convertReservation({ reservationId: 1, paidAmount: 0 });
    expect(createRentalSpy).toHaveBeenCalledTimes(1);
    const src = readFileSync('src/services/reservation.service.ts', 'utf8');
    expect(src).not.toContain('rental.create');
  });
});

// ==================== البنية ====================

describe('★ البنية: تخصيص لا نظام دفعات ثانٍ', () => {
  const src = readFileSync('src/services/reservation.service.ts', 'utf8');

  it('★ لا دفتر عرابين ثانٍ', () => {
    expect(src).not.toContain('depositLedger');
    expect(src).not.toContain('reservationPayment');
  });

  it('★ يعيد استخدام payments و rental و audit القائمة', () => {
    expect(src).toContain('tx.payment.updateMany');
    expect(src).toContain('tx.rental.findUniqueOrThrow');
    expect(src).toContain('writeAudit');
  });

  it('★ لا نموذج محاسبي جديد', () => {
    expect(/journal|chart_of_accounts|double-entry/i.test(src)).toBe(false);
  });
});

// ==================== L: التراجع لا يُبقي أثرًا ====================

describe('★ L — فشل التحويل يترك العربون غير مخصَّص', () => {
  it('★ فشل إنشاء العقد ⟹ لا تخصيص إطلاقًا', async () => {
    createRentalSpy.mockRejectedValue(new Error('القطعة غير متاحة'));
    const { convertReservation } = await import('@/services/reservation.service');

    await expect(convertReservation({ reservationId: 1, paidAmount: 0 })).rejects.toThrow();

    // لم تُلمس أي دفعة
    expect(tx.payment.updateMany).not.toHaveBeenCalled();
    expect(tx.payment.create).not.toHaveBeenCalled();
    // ولا سجل تدقيق يدّعي تخصيصًا
    expect(auditSpy).not.toHaveBeenCalled();
  });

  it('★ فشل داخل المعاملة يتراجع عن التخصيص وإقفال الحجز معًا', async () => {
    // التخصيص وإقفال الحجز والتدقيق في معاملة واحدة
    const src = readFileSync('src/services/reservation.service.ts', 'utf8');
    const block = src.slice(
      src.indexOf('const result = await prisma.$transaction'),
      src.indexOf('return { row, depositApplied, after }'),
    );
    expect(block).toContain('tx.payment.updateMany');
    expect(block).toContain('tx.reservation.update');
    expect(block).toContain('writeAudit');
  });

  it('★ فشل التحويل يعيد تفعيل حجز الفترة', async () => {
    createRentalSpy.mockRejectedValue(new Error('فشل'));
    const { convertReservation } = await import('@/services/reservation.service');
    await expect(convertReservation({ reservationId: 1, paidAmount: 0 })).rejects.toThrow();

    const { prisma } = await import('@/lib/db');
    expect(prisma.itemBooking.updateMany).toHaveBeenCalledWith(
      expect.objectContaining({ data: { isActive: true } }),
    );
  });
});

// ==================== I/J: الرد والعقد الآخر ====================

describe('★ I/J — الرد والعقد الآخر', () => {
  it('★ I — عربون رُدَّ جزئيًا لا يُخصَّص', async () => {
    refundedSum = '100';   // رُدَّ جزء منه
    const { convertReservation } = await import('@/services/reservation.service');
    await expect(convertReservation({ reservationId: 1, paidAmount: 0 }))
      .rejects.toMatchObject({ code: 'BUSINESS_RULE' });
    expect(tx.payment.updateMany).not.toHaveBeenCalled();
  });

  it('★ J — الاستعلام مقيَّد بمعرّف الحجز نفسه', async () => {
    const { convertReservation } = await import('@/services/reservation.service');
    await convertReservation({ reservationId: 1, paidAmount: 0 });
    const where = tx.payment.findMany.mock.calls[0][0].where;
    expect(where.reservationId).toBe(1);
    // ولا يمكن التقاط دفعة مخصَّصة لعقد آخر
    expect(where.rentalId).toBeNull();
  });
});
