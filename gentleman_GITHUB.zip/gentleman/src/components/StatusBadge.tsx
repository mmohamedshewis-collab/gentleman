import { STATUS_LABELS, STATUS_TONE, type ItemStatus } from '@/lib/inventory/item-state';

const TONE_CLASS: Record<string, string> = {
  ok: 'bg-green-100 text-ok',
  busy: 'bg-blue-100 text-brand-light',
  warn: 'bg-amber-100 text-warn',
  danger: 'bg-red-100 text-danger',
  muted: 'bg-slate-100 text-slate-500',
};

export default function StatusBadge({ status }: { status: ItemStatus }) {
  return (
    <span className={`badge ${TONE_CLASS[STATUS_TONE[status]]}`}>{STATUS_LABELS[status]}</span>
  );
}
