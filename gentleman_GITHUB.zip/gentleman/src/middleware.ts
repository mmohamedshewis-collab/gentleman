import { NextResponse, type NextRequest } from 'next/server';

const COOKIE = process.env.SESSION_COOKIE_NAME || 'gentleman_session';

/**
 * حارس أولي فقط لتحسين التجربة (توجيه غير المسجّل إلى شاشة الدخول).
 * التحقق الحقيقي من الجلسة والصلاحيات يتم داخل الخدمات على الخادم — BR-17.
 */
export function middleware(req: NextRequest) {
  const hasCookie = Boolean(req.cookies.get(COOKIE)?.value);
  const isLogin = req.nextUrl.pathname.startsWith('/login');

  if (!hasCookie && !isLogin) {
    const url = req.nextUrl.clone();
    url.pathname = '/login';
    return NextResponse.redirect(url);
  }
  if (hasCookie && isLogin) {
    const url = req.nextUrl.clone();
    url.pathname = '/';
    return NextResponse.redirect(url);
  }
  return NextResponse.next();
}

export const config = {
  matcher: ['/((?!api|_next/static|_next/image|favicon.ico).*)'],
};
