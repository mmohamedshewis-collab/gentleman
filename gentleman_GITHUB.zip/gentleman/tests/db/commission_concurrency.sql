BEGIN;
SELECT pg_advisory_xact_lock(hashtext('commission:1:2026-10'));
SELECT pg_sleep(0.2);
INSERT INTO commissions (employee_id, period_month, commission_amount, status, paid_expense_id)
SELECT 1, '2026-10', 30, 'PAID', id FROM expenses
 WHERE expense_no NOT IN (SELECT expense_no FROM expenses e JOIN commissions c ON c.paid_expense_id=e.id)
   AND expense_no LIKE 'EXP-C%' LIMIT 1;
COMMIT;
