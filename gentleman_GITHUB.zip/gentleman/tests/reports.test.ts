import { describe, it, expect, vi, beforeEach } from 'vitest';
import {
  buildTotals, formatCell, NOTES, type ReportResult, type ReportColumn,
} from '../src/lib/reports/report-types';
import { reportToPrintableHtml } from '../src/lib/reports/pdf';
import { reportToExcel } from '../src/lib/reports/excel';

// ============================ الوحدة ============================

const columns: ReportColumn[] = [
  { key: 'name', label: 'البند', type: 'text' },
  { key: 'count', label: 'العدد', type: 'number', sum: true },
  { key: 'amount', label: 'المبلغ', type: 'money', sum: true },
  { key: 'note', label: 'ملاحظة', type: 'text' },
];

const rows = [
  { name: 'تأجير', count: 2, amount: '750.00', note: 'أ' },
  { name: 'بيع', count: 1, amount: '1300.50', note: null },
];

describe('سطر الإجماليات', () => {
  it('يجمع الأعمدة المعلَّمة فقط', () => {
    const t = buildTotals(columns, rows)!;
    expect(t.count).toBe(3);
    expect(t.amount).toBe('2050.5');
    expect(t.note).toBeNull();
  });

  it('يضع «الإجمالي» في العمود الأول', () => {
    expect(buildTotals(columns, rows)!.name).toBe('الإجمالي');
  });

  it('بلا صفوف ⟹ بلا إجمالي', () => {
    expect(buildTotals(columns, [])).toBeNull();
  });

  it('يتجاهل القيم الفارغة بلا انهيار', () => {
    const t = buildTotals(columns, [{ name: 'س', count: null, amount: '', note: null }])!;
    expect(t.count).toBe(0);
    expect(t.amount).toBe('0');
  });
});

describe('تنسيق الخلايا', () => {
  it('المال بمنزلتين والأرقام لاتينية', () => {
    expect(formatCell('750.5', 'money')).toBe('750.50');
    expect(formatCell(1300, 'money')).toBe('1,300.00');
  });
  it('الفارغ يظهر شرطة', () => {
    expect(formatCell(null, 'text')).toBe('—');
    expect(formatCell('', 'money')).toBe('—');
  });
  it('النسبة تحمل علامتها', () => {
    expect(formatCell(14, 'percent')).toBe('14%');
  });
});

// ============================ التصدير ============================

const sample: ReportResult = {
  key: 'revenue',
  title: 'الإيرادات',
  period: 'من 2026-08-01 إلى 2026-08-31',
  appliedFilters: [{ label: 'الموظف', value: 'محمد علي' }],
  columns,
  rows,
  totals: buildTotals(columns, rows),
  notes: [NOTES.insuranceNotRevenue, NOTES.voidedExcluded],
  generatedAt: '2026-08-31 20:00',
};

describe('تصدير PDF — صفحة طباعة عربية', () => {
  const html = reportToPrintableHtml(sample, {
    name: 'Gentleman', phone: '01012345678', address: 'القاهرة',
  });

  it('اتجاه الصفحة من اليمين لليسار وباللغة العربية', () => {
    expect(html).toContain('lang="ar"');
    expect(html).toContain('dir="rtl"');
  });

  it('يستخدم الخط نفسه المستخدم في الواجهة', () => {
    expect(html).toContain('Cairo');
  });

  it('يستخدم اللون الأساسي المعتمد', () => {
    expect(html).toContain('#002060');
  });

  it('★ يعرض العنوان والفترة والفلاتر المطبَّقة', () => {
    expect(html).toContain('الإيرادات');
    expect(html).toContain('من 2026-08-01 إلى 2026-08-31');
    expect(html).toContain('محمد علي');
  });

  it('★ يحتوي كل صفوف الشاشة بالقيم نفسها', () => {
    expect(html).toContain('تأجير');
    expect(html).toContain('750.00');
    expect(html).toContain('بيع');
    expect(html).toContain('1,300.50');
  });

  it('★ يحتوي سطر الإجماليات نفسه', () => {
    expect(html).toContain('2,050.50');
  });

  it('يحتوي الملاحظات المحاسبية', () => {
    expect(html).toContain('التأمين المحصَّل ليس إيرادًا');
    expect(html).toContain('العمليات الملغاة مستبعدة');
  });

  it('يهرّب المحتوى فلا يُحقن HTML', () => {
    const evil = reportToPrintableHtml(
      { ...sample, rows: [{ name: '<script>x</script>', count: 1, amount: '1', note: null }] },
      { name: 'Gentleman', phone: '', address: '' },
    );
    expect(evil).not.toContain('<script>x</script>');
    expect(evil).toContain('&lt;script&gt;');
  });

  it('جدول فارغ يعرض رسالة عربية لا صفحة مكسورة', () => {
    const empty = reportToPrintableHtml(
      { ...sample, rows: [], totals: null },
      { name: 'Gentleman', phone: '', address: '' },
    );
    expect(empty).toContain('لا توجد بيانات في هذه الفترة');
  });
});

describe('تصدير Excel', () => {
  it('★ ينتج ملفًا صالحًا', async () => {
    const buf = await reportToExcel(sample);
    expect(Buffer.isBuffer(buf)).toBe(true);
    expect(buf.length).toBeGreaterThan(1000);
    // توقيع ملفات xlsx المضغوطة
    expect(buf.subarray(0, 2).toString('binary')).toBe('PK');
  });

  it('★ الورقة بالاتجاه من اليمين لليسار', async () => {
    const ExcelJS = (await import('exceljs')).default;
    const wb = new ExcelJS.Workbook();
    await wb.xlsx.load(await reportToExcel(sample));
    expect(wb.worksheets[0].views[0].rightToLeft).toBe(true);
  });

  it('★ الأرقام تُصدَّر أرقامًا لا نصوصًا', async () => {
    const ExcelJS = (await import('exceljs')).default;
    const wb = new ExcelJS.Workbook();
    await wb.xlsx.load(await reportToExcel(sample));
    const ws = wb.worksheets[0];

    let found = false;
    ws.eachRow((row) => {
      row.eachCell((cell) => {
        if (cell.value === 1300.5) found = true;
      });
    });
    expect(found).toBe(true);
  });

  it('★ يحتوي العنوان والفترة والفلاتر والملاحظات', async () => {
    const ExcelJS = (await import('exceljs')).default;
    const wb = new ExcelJS.Workbook();
    await wb.xlsx.load(await reportToExcel(sample));

    const texts: string[] = [];
    wb.worksheets[0].eachRow((row) => {
      row.eachCell((cell) => {
        if (typeof cell.value === 'string') texts.push(cell.value);
      });
    });
    const all = texts.join(' | ');
    expect(all).toContain('الإيرادات');
    expect(all).toContain('من 2026-08-01 إلى 2026-08-31');
    expect(all).toContain('محمد علي');
    expect(all).toContain('التأمين المحصَّل ليس إيرادًا');
  });

  it('★ يحتوي رؤوس الأعمدة نفسها المعروضة', async () => {
    const ExcelJS = (await import('exceljs')).default;
    const wb = new ExcelJS.Workbook();
    await wb.xlsx.load(await reportToExcel(sample));

    const texts: string[] = [];
    wb.worksheets[0].eachRow((row) => {
      row.eachCell((cell) => {
        if (typeof cell.value === 'string') texts.push(cell.value);
      });
    });
    for (const c of columns) expect(texts).toContain(c.label);
  });

  it('يعمل مع تقرير فارغ', async () => {
    const buf = await reportToExcel({ ...sample, rows: [], totals: null });
    expect(buf.length).toBeGreaterThan(500);
  });
});

// ============================ الخدمة ============================

let currentUser: { id: number; employeeId: number | null; permissions: Set<string> };

vi.mock('@/lib/db', () => {
  const empty = { findMany: async () => [], aggregate: async () => ({ _sum: {}, _count: {} }), findUnique: async () => null };
  return {
    prisma: {
      sale: empty, rental: empty, expense: empty, payment: empty,
      returnItem: empty, insuranceTransaction: empty, product: empty,
      productItem: empty, rentalItem: empty, saleItem: empty,
      customer: empty, employee: empty, paymentMethod: empty, expenseCategory: empty,
    },
  };
});

vi.mock('@/lib/auth/rbac', async (importOriginal) => {
  const actual = await importOriginal<typeof import('@/lib/auth/rbac')>();
  return {
    ...actual,
    requirePermission: async (perm: string) => {
      if (!currentUser.permissions.has(perm)) {
        const { Errors } = await import('@/lib/errors');
        throw Errors.forbidden(perm);
      }
      return currentUser as never;
    },
  };
});

beforeEach(() => {
  currentUser = {
    id: 1, employeeId: 1,
    permissions: new Set(['reports.operational.view', 'reports.financial.view', 'reports.export']),
  };
});

describe('كتالوج التقارير وصلاحياتها', () => {
  it('يعرض 18 تقريرًا مصنّفة', async () => {
    const { reportCatalog } = await import('@/services/report.service');
    const c = reportCatalog();
    expect(c.length).toBe(18);
    expect(c.filter((r) => r.isFinancial).length).toBe(7);
  });

  it('★ التقارير المالية تحتاج reports.financial.view', async () => {
    currentUser = { id: 9, employeeId: 3, permissions: new Set(['reports.operational.view']) };
    const { runReport } = await import('@/services/report.service');
    for (const key of ['revenue', 'net-profit', 'outstanding', 'item-profitability'] as const) {
      await expect(runReport({ key })).rejects.toMatchObject({
        code: 'PERM_DENIED', details: { permission: 'reports.financial.view' },
      });
    }
  });

  it('التقارير التشغيلية تكفيها صلاحية الموظف', async () => {
    currentUser = { id: 9, employeeId: 3, permissions: new Set(['reports.operational.view']) };
    const { runReport } = await import('@/services/report.service');
    const r = await runReport({ key: 'available-items' });
    expect(r.key).toBe('available-items');
    expect(r.title).toBe('القطع المتاحة');
  });

  it('يرفض مفتاح تقرير غير معروف', async () => {
    const { reportQuerySchema } = await import('@/services/report.service');
    expect(reportQuerySchema.safeParse({ key: 'لا-يوجد' }).success).toBe(false);
  });

  it('كل تقرير يحمل أعمدة وملاحظات وطابع إصدار', async () => {
    const { runReport, REPORT_KEYS } = await import('@/services/report.service');
    for (const key of REPORT_KEYS) {
      const r = await runReport({ key });
      expect(r.columns.length).toBeGreaterThan(0);
      expect(r.title).toBeTruthy();
      expect(r.generatedAt).toBeTruthy();
      expect(Array.isArray(r.notes)).toBe(true);
    }
  });

  it('★ الملاحظات المحاسبية تظهر في التقارير الحساسة', async () => {
    const { runReport } = await import('@/services/report.service');
    expect((await runReport({ key: 'revenue' })).notes).toContain(NOTES.insuranceNotRevenue);
    expect((await runReport({ key: 'net-profit' })).notes).toContain(NOTES.notExpenses);
    expect((await runReport({ key: 'item-profitability' })).notes).toContain(NOTES.lifetimeProfit);
    expect((await runReport({ key: 'payment-methods' })).notes).toContain(NOTES.cashOnly);
  });
});

describe('★ التصدير يطابق الشاشة — مصدر واحد للأرقام', () => {
  it('Excel و PDF يستهلكان نفس ReportResult', async () => {
    const { runReport } = await import('@/services/report.service');
    const report = await runReport({ key: 'revenue', from: '2026-08-01', to: '2026-08-31' });

    const html = reportToPrintableHtml(report, { name: 'Gentleman', phone: '', address: '' });
    const xlsx = await reportToExcel(report);

    // نفس العنوان ونفس عدد الأعمدة في الثلاثة
    expect(html).toContain(report.title);
    expect(Buffer.isBuffer(xlsx)).toBe(true);

    const ExcelJS = (await import('exceljs')).default;
    const wb = new ExcelJS.Workbook();
    await wb.xlsx.load(xlsx);
    const texts: string[] = [];
    wb.worksheets[0].eachRow((row) => {
      row.eachCell((cell) => { if (typeof cell.value === 'string') texts.push(cell.value); });
    });
    for (const c of report.columns) {
      expect(texts).toContain(c.label);
      expect(html).toContain(c.label);
    }
  });
});
