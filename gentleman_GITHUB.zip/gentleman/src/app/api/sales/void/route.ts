import { route } from '@/lib/api';
import { voidSale, voidSaleSchema } from '@/services/sale.service';

export const POST = route({ schema: voidSaleSchema, handler: ({ input }) => voidSale(input) });
