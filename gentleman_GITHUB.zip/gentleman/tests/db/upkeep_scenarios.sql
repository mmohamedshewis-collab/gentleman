\set ON_ERROR_STOP off
\pset pager off
\t on

-- محاكاة معاملة الصيانة/التنظيف كما تنفّذها upkeep.service بالترتيب نفسه
CREATE OR REPLACE FUNCTION do_upkeep(
  p_item_code text, p_kind text, p_cost numeric, p_method int DEFAULT 1
) RETURNS int AS $$
DECLARE
  v_item int; v_status text; v_target text; v_cat int; v_exp int := NULL; v_rec int;
BEGIN
  -- 1) قفل القطعة وفحص الحالة
  SELECT id, status::text INTO v_item, v_status
    FROM product_items WHERE item_code = p_item_code FOR UPDATE;
  IF v_item IS NULL THEN RAISE EXCEPTION 'القطعة % غير موجودة', p_item_code; END IF;

  v_target := CASE p_kind WHEN 'MAINTENANCE' THEN 'MAINTENANCE' ELSE 'CLEANING' END;
  IF v_status = v_target THEN
    RAISE EXCEPTION 'القطعة بالفعل في حالة %', v_target;
  END IF;

  -- 2) المصروف يُنشأ فقط إذا كانت التكلفة موجبة
  IF p_cost > 0 THEN
    SELECT id INTO v_cat FROM expense_categories
     WHERE name_ar = CASE p_kind WHEN 'MAINTENANCE' THEN 'صيانة' ELSE 'تنظيف' END;
    IF v_cat IS NULL THEN RAISE EXCEPTION 'فئة المصروف غير موجودة'; END IF;

    INSERT INTO expenses (expense_no, expense_date, category_id, amount, cash_paid_amount,
                          payment_method_id, description, created_by)
    VALUES ('EXP-UP-' || nextval('expense_no_seq'), CURRENT_DATE, v_cat, p_cost, p_cost,
            p_method, p_kind || ' القطعة ' || p_item_code, 1)
    RETURNING id INTO v_exp;
  END IF;

  -- 3) السجل مربوط بالقطعة وبالمصروف
  IF p_kind = 'MAINTENANCE' THEN
    INSERT INTO maintenance_records (item_id, start_date, cost, expense_id, created_by)
    VALUES (v_item, CURRENT_DATE, p_cost, v_exp, 1) RETURNING id INTO v_rec;
  ELSE
    INSERT INTO cleaning_records (item_id, sent_date, cost, expense_id, created_by)
    VALUES (v_item, CURRENT_DATE, p_cost, v_exp, 1) RETURNING id INTO v_rec;
  END IF;

  -- 4) سجل الحالة ثم نقل القطعة
  INSERT INTO item_status_history (item_id, from_status, to_status, reason, ref_type, ref_id, user_id)
  VALUES (v_item, v_status::"ItemStatus", v_target::"ItemStatus",
          'بدء ' || p_kind || CASE WHEN p_cost > 0 THEN ' بتكلفة ' || p_cost ELSE ' بلا تكلفة' END,
          CASE p_kind WHEN 'MAINTENANCE' THEN 'MaintenanceRecord' ELSE 'CleaningRecord' END, v_rec, 1);

  UPDATE product_items SET status = v_target::"ItemStatus" WHERE id = v_item;
  RETURN v_rec;
END;
$$ LANGUAGE plpgsql;

UPDATE product_items SET status='AVAILABLE' WHERE item_code IN ('SUIT-0001','SUIT-0002','SUIT-0003');
DELETE FROM maintenance_records; DELETE FROM cleaning_records;

\echo '=== A: صيانة بتكلفة 800 ==='
SELECT 'السجل ' || do_upkeep('SUIT-0001', 'MAINTENANCE', 800);
SELECT '  القطعة المرتبطة=' || (SELECT item_code FROM product_items WHERE id=m.item_id)
    || ' | التكلفة=' || m.cost
    || ' | المصروف=' || (SELECT expense_no FROM expenses WHERE id=m.expense_id)
    || ' | الفئة=' || (SELECT name_ar FROM expense_categories c
                        JOIN expenses e ON e.category_id=c.id WHERE e.id=m.expense_id)
  FROM maintenance_records m;
SELECT '  عدد المصروفات المنشأة = ' || count(*) FROM expenses WHERE description LIKE '%SUIT-0001%';
SELECT '  الخروج النقدي = ' || cash_paid_amount || ' | حالة القطعة = ' ||
       (SELECT status FROM product_items WHERE item_code='SUIT-0001')
  FROM expenses WHERE id=(SELECT expense_id FROM maintenance_records);
SELECT '  سجل الحالة: ' || from_status || ' → ' || to_status || ' | مرجع=' || ref_type
  FROM item_status_history WHERE ref_type='MaintenanceRecord' ORDER BY id DESC LIMIT 1;

\echo ''
\echo '=== B: تنظيف بتكلفة 450 ==='
SELECT 'السجل ' || do_upkeep('SUIT-0002', 'CLEANING', 450);
SELECT '  القطعة=' || (SELECT item_code FROM product_items WHERE id=c.item_id)
    || ' | التكلفة=' || c.cost
    || ' | المصروف=' || (SELECT expense_no FROM expenses WHERE id=c.expense_id)
    || ' | الفئة=' || (SELECT name_ar FROM expense_categories ec
                        JOIN expenses e ON e.category_id=ec.id WHERE e.id=c.expense_id)
  FROM cleaning_records c WHERE c.cost > 0;
SELECT '  عدد المصروفات = ' || count(*) FROM expenses WHERE description LIKE '%SUIT-0002%';
SELECT '  حالة القطعة = ' || status FROM product_items WHERE item_code='SUIT-0002';

\echo ''
\echo '=== C: تنظيف بتكلفة صفر — لا مصروف ولا خروج نقدي ==='
SELECT 'السجل ' || do_upkeep('SUIT-0003', 'CLEANING', 0);
SELECT '  السجل أُنشئ: تكلفة=' || cost || ' | المصروف المرتبط=' || COALESCE(expense_id::text,'لا شيء')
  FROM cleaning_records WHERE item_id=(SELECT id FROM product_items WHERE item_code='SUIT-0003');
SELECT '  عدد المصروفات لهذه القطعة = ' || count(*) FROM expenses WHERE description LIKE '%SUIT-0003%';
SELECT '  حالة القطعة = ' || status FROM product_items WHERE item_code='SUIT-0003';

\echo ''
\echo '=== D: تكرار — القطعة في الحالة نفسها (يجب أن يُرفض) ==='
SELECT do_upkeep('SUIT-0001', 'MAINTENANCE', 800);

\echo ''
\echo '=== D2: انتقال غير مسموح (مباعة → صيانة) ==='
UPDATE product_items SET status='SOLD' WHERE item_code='SUIT-0002';
SELECT do_upkeep('SUIT-0002', 'MAINTENANCE', 100);

\echo ''
\echo '=== E: تكلفة سالبة (يجب أن تُرفض) ==='
INSERT INTO expenses (expense_no, category_id, amount, cash_paid_amount, payment_method_id, created_by)
VALUES ('EXP-NEG', 1, -100, -100, 1, 1);

\echo ''
\echo '=== F: خروج نقدي أكبر من المصروف (يجب أن يُرفض) ==='
INSERT INTO expenses (expense_no, category_id, amount, cash_paid_amount, payment_method_id, created_by)
VALUES ('EXP-BAD', 1, 100, 500, 1, 1);

\echo ''
\echo '=== G: إجمالي التكاليف للقطعة — بلا ازدواج ==='
SELECT '  SUIT-0001: صيانة=' || COALESCE((SELECT SUM(cost) FROM maintenance_records WHERE item_id=(SELECT id FROM product_items WHERE item_code='SUIT-0001')),0)
    || ' | مصروفات مرتبطة=' || (SELECT count(*) FROM expenses WHERE description LIKE '%SUIT-0001%');
