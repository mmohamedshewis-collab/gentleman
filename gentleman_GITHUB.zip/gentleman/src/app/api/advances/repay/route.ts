import { route } from '@/lib/api';
import { repayAdvance, repayAdvanceSchema } from '@/services/advance.service';

export const POST = route({ schema: repayAdvanceSchema, handler: ({ input }) => repayAdvance(input) });
