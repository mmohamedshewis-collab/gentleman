import { describe, it, expect, vi, beforeEach } from 'vitest';

/**
 * اختبارات طبقة الخدمة لتغيير حالة القطعة والمسح.
 * قاعدة البيانات مُحاكاة، والهدف التحقق من: الصلاحيات، السبب الإلزامي،
 * آلة الحالة، تسجيل التدقيق، وتوحيد الباركود.
 */

const auditSpy = vi.fn();
let currentUser: { id: number; permissions: Set<string> };
let itemStatus = 'AVAILABLE';

const tx = {
  $queryRaw: vi.fn(async () => [{ id: 1, status: itemStatus }]),
  productItem: { update: vi.fn(async ({ data }: any) => ({ id: 1, ...data })) },
  itemStatusHistory: { create: vi.fn(async () => ({ id: 1 })) },
  inventoryTransaction: { create: vi.fn(async () => ({ id: 1 })) },
};

const findFirstSpy = vi.fn(async () => ({
  id: 1, itemCode: 'SUIT-0001', barcode: 'SUIT-0001', status: itemStatus,
  rentalPrice: null, salePrice: null, rentalCount: 3,
  lastRentalDate: null, lastReturnDate: null,
  product: { nameAr: 'بدلة كلاسيك أسود', size: '52', color: 'أسود', rentalPrice: 500, salePrice: 3000, category: { nameAr: 'بدل' }, brand: { name: 'Armani' } },
}));

vi.mock('@/lib/db', () => ({
  prisma: {
    $transaction: (fn: any) => fn(tx),
    productItem: { findFirst: (...a: any[]) => findFirstSpy(...(a as [])) },
  },
}));

vi.mock('@/lib/audit', () => ({
  writeAudit: (...args: any[]) => auditSpy(...args),
  redact: (x: any) => x,
}));

vi.mock('@/lib/auth/rbac', async (importOriginal) => {
  const actual = await importOriginal<typeof import('@/lib/auth/rbac')>();
  return {
    ...actual,
    requirePermission: async (perm: string) => {
      if (!currentUser.permissions.has(perm)) {
        const { Errors } = await import('@/lib/errors');
        throw Errors.forbidden(perm);
      }
      return currentUser as never;
    },
  };
});

const asStaff = () => { currentUser = { id: 9, permissions: new Set(['items.view', 'products.view']) }; };
const asManagerNoOverride = () => { currentUser = { id: 5, permissions: new Set(['items.view', 'items.manage']) }; };
const asAdmin = () => { currentUser = { id: 1, permissions: new Set(['items.view', 'items.manage', 'items.status.override']) }; };

beforeEach(() => {
  auditSpy.mockClear();
  itemStatus = 'AVAILABLE';
  asAdmin();
});

describe('نقطة 5 — تحويل قطعة إلى "تالفة" بحساب موظف', () => {
  it('يُرفض لعدم وجود صلاحية إدارة القطع', async () => {
    asStaff();
    const { changeItemStatus } = await import('@/services/item.service');
    await expect(
      changeItemStatus({ itemId: 1, toStatus: 'DAMAGED', reason: 'تلف أثناء العرض' }),
    ).rejects.toMatchObject({ code: 'PERM_DENIED' });
  });

  it('يُرفض لمدير قطع بلا صلاحية إخراج القطعة من الخدمة', async () => {
    asManagerNoOverride();
    const { changeItemStatus } = await import('@/services/item.service');
    await expect(
      changeItemStatus({ itemId: 1, toStatus: 'DAMAGED', reason: 'تلف أثناء العرض' }),
    ).rejects.toMatchObject({ code: 'PERM_DENIED', details: { permission: 'items.status.override' } });
  });

  it('ينجح لصاحب الصلاحية الكاملة', async () => {
    const { changeItemStatus } = await import('@/services/item.service');
    const r = await changeItemStatus({ itemId: 1, toStatus: 'DAMAGED', reason: 'تلف أثناء العرض' });
    expect(r).toMatchObject({ from: 'AVAILABLE', to: 'DAMAGED', label: 'تالفة' });
  });
});

describe('نقطة 6 — تحويل قطعة إلى "تالفة" بدون سبب', () => {
  it('يُرفض من التحقق قبل لمس قاعدة البيانات', async () => {
    const { changeStatusSchema } = await import('@/services/item.service');
    expect(changeStatusSchema.safeParse({ itemId: 1, toStatus: 'DAMAGED' }).success).toBe(false);
    expect(changeStatusSchema.safeParse({ itemId: 1, toStatus: 'DAMAGED', reason: '' }).success).toBe(false);
    expect(changeStatusSchema.safeParse({ itemId: 1, toStatus: 'DAMAGED', reason: 'تلف' }).success).toBe(true);
  });
});

describe('آلة الحالة داخل الخدمة', () => {
  it('لا يمكن ضبط "مؤجرة" يدويًا من شاشة المخزون', async () => {
    const { changeItemStatus } = await import('@/services/item.service');
    await expect(
      changeItemStatus({ itemId: 1, toStatus: 'RENTED', reason: 'محاولة يدوية' }),
    ).rejects.toMatchObject({ code: 'BUSINESS_RULE' });
  });

  it('القطعة المباعة لا تتغير حالتها', async () => {
    itemStatus = 'SOLD';
    const { changeItemStatus } = await import('@/services/item.service');
    await expect(
      changeItemStatus({ itemId: 1, toStatus: 'AVAILABLE', reason: 'محاولة' }),
    ).rejects.toMatchObject({ code: 'BUSINESS_RULE' });
  });

  it('التالفة لا تعود متاحة إلا عبر الصيانة', async () => {
    itemStatus = 'DAMAGED';
    const { changeItemStatus } = await import('@/services/item.service');
    await expect(
      changeItemStatus({ itemId: 1, toStatus: 'AVAILABLE', reason: 'محاولة' }),
    ).rejects.toMatchObject({ code: 'BUSINESS_RULE' });
    await expect(
      changeItemStatus({ itemId: 1, toStatus: 'MAINTENANCE', reason: 'إرسال للإصلاح' }),
    ).resolves.toMatchObject({ to: 'MAINTENANCE' });
  });
});

describe('نقطة 7 — تسجيل تغيير الحالات الحساسة في سجل التدقيق', () => {
  it('يسجّل العملية بالحالة قبل وبعد والسبب والمستخدم', async () => {
    const { changeItemStatus } = await import('@/services/item.service');
    await changeItemStatus({ itemId: 1, toStatus: 'LOST', reason: 'لم تُرجَع من العميل' });

    expect(auditSpy).toHaveBeenCalledTimes(1);
    expect(auditSpy.mock.calls[0][0]).toMatchObject({
      userId: 1,
      action: 'item.status_change',
      entityType: 'ProductItem',
      entityId: 1,
      before: { status: 'AVAILABLE' },
      after: { status: 'LOST' },
      reason: 'لم تُرجَع من العميل',
    });
  });

  it('يسجّل تاريخ حالة القطعة داخل نفس المعاملة', async () => {
    tx.itemStatusHistory.create.mockClear();
    const { changeItemStatus } = await import('@/services/item.service');
    await changeItemStatus({ itemId: 1, toStatus: 'CLEANING', reason: 'إرسال للمغسلة' });
    expect(tx.itemStatusHistory.create).toHaveBeenCalledOnce();
    expect(tx.itemStatusHistory.create.mock.calls[0][0].data).toMatchObject({
      itemId: 1, fromStatus: 'AVAILABLE', toStatus: 'CLEANING', userId: 1,
    });
  });

  it('العملية المرفوضة لا تترك أي أثر', async () => {
    itemStatus = 'SOLD';
    const { changeItemStatus } = await import('@/services/item.service');
    await expect(changeItemStatus({ itemId: 1, toStatus: 'AVAILABLE', reason: 'محاولة' })).rejects.toThrow();
    expect(auditSpy).not.toHaveBeenCalled();
  });
});

describe('نقطة 8 — توحيد الباركود لا يكسر البحث', () => {
  it('يبحث بالحروف الكبيرة مهما كتب الموظف أو أرسل القارئ', async () => {
    const { scanItem } = await import('@/services/item.service');
    for (const input of ['suit-0001', '  SUIT-0001  ', 'Suit-0001']) {
      findFirstSpy.mockClear();
      await scanItem(input);
      const where = (findFirstSpy.mock.calls[0] as any)[0].where;
      expect(where.OR).toEqual([{ barcode: 'SUIT-0001' }, { itemCode: 'SUIT-0001' }]);
    }
  });

  it('يبحث بكود القطعة أيضًا وليس بالباركود فقط', async () => {
    findFirstSpy.mockClear();
    const r = await (await import('@/services/item.service')).scanItem('SUIT-0001');
    expect(r.itemCode).toBe('SUIT-0001');
    expect(r.statusLabel).toBe('متاحة');
    expect(r.canBeRented).toBe(true);
  });

  it('القطعة المؤجرة تظهر غير قابلة للتأجير أو البيع', async () => {
    itemStatus = 'RENTED';
    const r = await (await import('@/services/item.service')).scanItem('SUIT-0001');
    expect(r.canBeRented).toBe(false);
    expect(r.canBeSold).toBe(false);
    expect(r.statusLabel).toBe('مؤجرة');
  });
});
