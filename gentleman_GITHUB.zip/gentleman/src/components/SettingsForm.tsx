'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

type Setting = {
  key: string; nameAr: string; group: string;
  dataType: string; value: unknown;
};

export default function SettingsForm({
  groups, canEdit,
}: { groups: Record<string, Setting[]>; canEdit: boolean }) {
  const router = useRouter();
  const [values, setValues] = useState<Record<string, string | number | boolean>>({});
  const [msg, setMsg] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  const get = (s: Setting) =>
    values[s.key] !== undefined ? values[s.key] : (s.value as string | number | boolean);

  async function save() {
    if (Object.keys(values).length === 0) return;
    setBusy(true); setMsg(null);
    const res = await fetch('/api/settings', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ values }),
    });
    const json = await res.json();
    setBusy(false);
    if (!json.ok) { setMsg({ type: 'err', text: json.error?.message ?? 'تعذّر الحفظ.' }); return; }
    setMsg({ type: 'ok', text: 'تم حفظ الإعدادات وتسجيلها في سجل التدقيق.' });
    setValues({});
    router.refresh();
  }

  return (
    <div className="space-y-5">
      {Object.entries(groups).map(([group, items]) => (
        <div key={group} className="card">
          <div className="card-header">{group}</div>
          <div className="p-5 grid grid-cols-1 md:grid-cols-2 gap-4">
            {items.map((s) => (
              <div key={s.key}>
                <label className="label">{s.nameAr}</label>
                {s.dataType === 'BOOLEAN' ? (
                  <select
                    className="input" disabled={!canEdit}
                    value={String(get(s))}
                    onChange={(e) => setValues({ ...values, [s.key]: e.target.value === 'true' })}
                  >
                    <option value="true">مفعّل</option>
                    <option value="false">غير مفعّل</option>
                  </select>
                ) : (
                  <input
                    className="input"
                    disabled={!canEdit}
                    type={s.dataType === 'NUMBER' ? 'number' : 'text'}
                    dir={s.dataType === 'NUMBER' ? 'ltr' : undefined}
                    value={String(get(s) ?? '')}
                    onChange={(e) =>
                      setValues({
                        ...values,
                        [s.key]: s.dataType === 'NUMBER' ? Number(e.target.value) : e.target.value,
                      })
                    }
                  />
                )}
                <p className="text-[11px] text-slate-400 mt-1 num">{s.key}</p>
              </div>
            ))}
          </div>
        </div>
      ))}

      {canEdit && (
        <div className="flex items-center gap-4">
          <button className="btn-primary" onClick={save} disabled={busy || Object.keys(values).length === 0}>
            {busy ? 'جارٍ الحفظ…' : 'حفظ التعديلات'}
          </button>
          {msg && (
            <span className={`text-sm font-semibold ${msg.type === 'ok' ? 'text-ok' : 'text-danger'}`}>
              {msg.text}
            </span>
          )}
        </div>
      )}
    </div>
  );
}
