import { route } from '@/lib/api';
import { lookupByPhone, lookupSchema } from '@/services/customer.service';

export const GET = route({ schema: lookupSchema, handler: ({ input }) => lookupByPhone(input.phone) });
