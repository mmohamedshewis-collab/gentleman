'use client';

import { useRouter } from 'next/navigation';

export default function LogoutButton() {
  const router = useRouter();
  return (
    <button
      className="w-full rounded-lg bg-white/10 hover:bg-white/20 py-2 text-xs font-semibold"
      onClick={async () => {
        await fetch('/api/auth/logout', { method: 'POST' });
        router.replace('/login');
        router.refresh();
      }}
    >
      تسجيل الخروج
    </button>
  );
}
