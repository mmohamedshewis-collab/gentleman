\set ON_ERROR_STOP off
\pset pager off
\t on

\echo '=== G: حذف عقد مرتبط بتنظيف (يجب أن يُرفض) ==='
-- نربط سجل تنظيف بعقد قائم
UPDATE cleaning_records SET rental_id = (SELECT id FROM rentals LIMIT 1) WHERE id = 1;
SELECT '  رُبط سجل التنظيف بالعقد: ' || (SELECT rental_no FROM rentals WHERE id=(SELECT rental_id FROM cleaning_records WHERE id=1));
-- محاولة الحذف
DELETE FROM rentals WHERE id = (SELECT rental_id FROM cleaning_records WHERE id=1);

\echo ''
\echo '=== H: السجلات التاريخية تبقى NULL ==='
SELECT '  إجمالي=' || count(*) || ' | NULL=' || count(*) FILTER (WHERE rental_id IS NULL)
    || ' | مرتبط=' || count(*) FILTER (WHERE rental_id IS NOT NULL) FROM cleaning_records;

\echo ''
\echo '=== D: rental_id لعقد غير موجود (يجب أن يُرفض) ==='
INSERT INTO cleaning_records (item_id, cost, rental_id) VALUES (1, 100, 999999);

\echo ''
\echo '=== A: تنظيف بلا عقد (يُقبل) ==='
INSERT INTO cleaning_records (item_id, cost) VALUES (1, 75);
SELECT '  أُنشئ بلا عقد: rental_id=' || COALESCE(rental_id::text,'NULL') FROM cleaning_records ORDER BY id DESC LIMIT 1;

\echo ''
\echo '=== I: القيم المالية لم تتغيّر ==='
SELECT '  مجموع تكاليف التنظيف = ' || COALESCE(SUM(cost),0) FROM cleaning_records;
SELECT '  مصروفات مرتبطة = ' || count(*) FROM cleaning_records WHERE expense_id IS NOT NULL;
