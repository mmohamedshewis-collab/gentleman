\set ON_ERROR_STOP off
\pset pager off
\t on

\echo '=== S9: البيع المزدوج لنفس القطعة عبر الفهرس الفريد (يجب أن يُرفض) ==='
INSERT INTO sale_items (sale_id, item_id, unit_price, discount, net_price, gross_amount, purchase_cost, pre_sale_status)
VALUES (2, 1, 100, 0, 100, 100, 6000, 'AVAILABLE');

\echo ''
\echo '=== S10: تغيير حالة قطعة مباعة خارج مسار الإلغاء (يجب أن يُرفض) ==='
UPDATE product_items SET status='AVAILABLE' WHERE item_code='SUIT-0001';

\echo ''
\echo '=== S11: العَلَم يسمح بالعودة لكن إلى حالة مسموحة فقط ==='
BEGIN;
SELECT set_config('app.void_sale','1',true);
UPDATE product_items SET status='RENTED' WHERE item_code='SUIT-0001';
ROLLBACK;

\echo ''
\echo '=== S12: التراجع الكامل عند فشل في منتصف البيع ==='
UPDATE product_items SET status='AVAILABLE' WHERE item_code='SUIT-0006';
SELECT 'قبل: فواتير=' || (SELECT count(*) FROM sales) ||
       ' سطور=' || (SELECT count(*) FROM sale_items) ||
       ' سجل حالة=' || (SELECT count(*) FROM item_status_history) ||
       ' حركات مخزون=' || (SELECT count(*) FROM inventory_transactions) ||
       ' دفعات=' || (SELECT count(*) FROM payments) ||
       ' تدقيق=' || (SELECT count(*) FROM audit_logs) ||
       ' | حالة القطعة=' || (SELECT status FROM product_items WHERE item_code='SUIT-0006');
SELECT do_sale(ARRAY['SUIT-0006'], 2, 900, 0, NULL, true);
SELECT 'بعد الفشل: فواتير=' || (SELECT count(*) FROM sales) ||
       ' سطور=' || (SELECT count(*) FROM sale_items) ||
       ' سجل حالة=' || (SELECT count(*) FROM item_status_history) ||
       ' حركات مخزون=' || (SELECT count(*) FROM inventory_transactions) ||
       ' دفعات=' || (SELECT count(*) FROM payments) ||
       ' تدقيق=' || (SELECT count(*) FROM audit_logs) ||
       ' | حالة القطعة=' || (SELECT status FROM product_items WHERE item_code='SUIT-0006');

\echo ''
\echo '=== S13: إلغاء الفاتورة (Void) ==='
CREATE OR REPLACE FUNCTION do_void_sale(p_sale int, p_reason text) RETURNS void AS $$
DECLARE r record; v_status text;
BEGIN
  SELECT status::text INTO v_status FROM sales WHERE id = p_sale FOR UPDATE;
  IF v_status IS NULL THEN RAISE EXCEPTION 'الفاتورة غير موجودة.'; END IF;
  IF v_status = 'VOIDED' THEN RAISE EXCEPTION 'الفاتورة ملغاة بالفعل.'; END IF;

  FOR r IN SELECT si.item_id, si.pre_sale_status FROM sale_items si WHERE si.sale_id = p_sale LOOP
    IF (SELECT status::text FROM product_items WHERE id=r.item_id) <> 'SOLD' THEN
      RAISE EXCEPTION 'حالة القطعة تغيّرت بعد البيع — لا يمكن الإلغاء.';
    END IF;
  END LOOP;

  PERFORM set_config('app.void_sale','1',true);

  FOR r IN SELECT si.item_id, si.pre_sale_status FROM sale_items si WHERE si.sale_id = p_sale LOOP
    INSERT INTO item_status_history (item_id, from_status, to_status, reason, ref_type, ref_id, user_id)
    VALUES (r.item_id, 'SOLD', r.pre_sale_status, 'إلغاء فاتورة: ' || p_reason, 'Sale', p_sale, 1);
    UPDATE product_items SET status = r.pre_sale_status, disposed_at = NULL WHERE id = r.item_id;
    INSERT INTO inventory_transactions (item_id, trx_date, type, ref_type, ref_id, note, created_by)
    VALUES (r.item_id, CURRENT_DATE, 'ADJUST', 'Sale', p_sale, 'إلغاء بيع', 1);
  END LOOP;

  UPDATE payments SET is_voided = true, void_reason = p_reason WHERE sale_id = p_sale AND is_voided = false;
  UPDATE sales SET status='VOIDED', void_reason=p_reason, voided_by=1, voided_at=now() WHERE id=p_sale;

  INSERT INTO audit_logs (user_id, action, entity_type, entity_id, before_json, after_json, reason)
  VALUES (1,'sale.void','Sale',p_sale::text,
          jsonb_build_object('status','COMPLETED'), jsonb_build_object('status','VOIDED'), p_reason);
END;
$$ LANGUAGE plpgsql;

SELECT 'قبل: فاتورة=' || (SELECT status FROM sales WHERE id=1) ||
       ' | القطعة=' || (SELECT status FROM product_items WHERE item_code='SUIT-0001') ||
       ' | دفعات نشطة=' || (SELECT count(*) FROM payments WHERE sale_id=1 AND is_voided=false);
SELECT do_void_sale(1, 'العميل أعاد القطعة فورًا');
SELECT 'بعد: فاتورة=' || (SELECT status FROM sales WHERE id=1) ||
       ' | القطعة=' || (SELECT status FROM product_items WHERE item_code='SUIT-0001') ||
       ' | دفعات نشطة=' || (SELECT count(*) FROM payments WHERE sale_id=1 AND is_voided=false) ||
       ' | دفعات ملغاة محفوظة=' || (SELECT count(*) FROM payments WHERE sale_id=1 AND is_voided);
SELECT '★ الفاتورة لم تُحذف: موجودة برقم ' || invoice_no || ' وحالتها ' || status || ' والسبب: ' || void_reason
  FROM sales WHERE id=1;
SELECT '★ الإيراد بعد الإلغاء = ' || COALESCE(SUM(net_amount),0) || ' (تُحسب المكتملة فقط)'
  FROM sales WHERE status='COMPLETED' AND id=1;
SELECT '★ التكلفة بعد الإلغاء = ' || COALESCE(SUM(total_cost),0) FROM sales WHERE status='COMPLETED' AND id=1;

\echo ''
\echo '=== S14: القطعة التالفة تعود تالفة لا متاحة ==='
SELECT do_void_sale(2, 'إلغاء بيع التالف');
SELECT 'القطعة SUIT-0005 عادت إلى: ' || status FROM product_items WHERE item_code='SUIT-0005';

\echo ''
\echo '=== S15: إلغاء فاتورة ملغاة (يجب أن يُرفض) ==='
SELECT do_void_sale(1, 'محاولة ثانية');

\echo ''
\echo '=== S16: إعادة تفعيل فاتورة ملغاة (يجب أن يُرفض) ==='
UPDATE sales SET status='COMPLETED' WHERE id=1;

\echo ''
\echo '=== S17: حذف الفاتورة أو سطورها (يجب أن يُرفض) ==='
DELETE FROM sales WHERE id=1;
DELETE FROM sale_items WHERE sale_id=1;

\echo ''
\echo '=== S18: إعادة بيع القطعة بعد الإلغاء (يجب أن تنجح) ==='
SELECT 'الفاتورة الجديدة ' || do_sale(ARRAY['SUIT-0001'], 2, 1200, 0);

\echo ''
\echo '=== S19: سجل التدقيق ==='
SELECT action || ' | مرجع=' || entity_id || ' | سبب=' || COALESCE(reason,'—') FROM audit_logs ORDER BY id;
