import { route } from '@/lib/api';
import { monthlyTreasuryReconciliation, monthQuerySchema } from '@/services/cash.service';

export const GET = route({
  schema: monthQuerySchema,
  handler: ({ input }) => monthlyTreasuryReconciliation(input),
});
