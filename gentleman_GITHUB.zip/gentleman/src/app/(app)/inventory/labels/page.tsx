import { itemsForLabels } from '@/services/inventory.service';
import BarcodeLabels from '@/components/BarcodeLabels';

export const dynamic = 'force-dynamic';

export default async function LabelsPage({
  searchParams,
}: { searchParams: { ids?: string; productId?: string } }) {
  const items = await itemsForLabels({
    ids: searchParams.ids,
    productId: searchParams.productId ? Number(searchParams.productId) : undefined,
  });

  return (
    <div className="space-y-5">
      <div className="no-print">
        <h1 className="section-title">ملصقات الباركود</h1>
        <p className="text-sm text-slate-600 mt-1">
          اختر منتجًا من شاشة المنتجات لطباعة ملصقات كل قطعه.
        </p>
      </div>

      {items.length === 0 ? (
        <p className="text-slate-500">لم تُحدَّد أي قطع للطباعة.</p>
      ) : (
        <BarcodeLabels items={items} />
      )}
    </div>
  );
}
