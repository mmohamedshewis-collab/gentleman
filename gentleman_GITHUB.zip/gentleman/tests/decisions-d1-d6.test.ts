import { describe, it, expect, vi, beforeEach } from 'vitest';
import { readFileSync } from 'node:fs';
import { NOTES } from '../src/lib/reports/report-types';

/**
 * تحقق من القرارات D1–D6 المعتمدة.
 * D1 و D3 تغييران فعليان · D2 و D4 و D5 و D6 تأكيدات على سلوك قائم.
 */

let currentUser: { id: number; employeeId: number | null; permissions: Set<string> };

vi.mock('@/lib/db', () => {
  const empty = {
    findMany: async () => [],
    aggregate: async () => ({ _sum: {}, _count: {} }),
    findUnique: async () => null,
  };
  return {
    prisma: {
      sale: empty, rental: empty, expense: empty, payment: empty,
      returnItem: empty, insuranceTransaction: empty, product: empty,
      productItem: empty, rentalItem: empty, saleItem: empty,
      customer: empty, employee: empty, paymentMethod: empty, expenseCategory: empty,
    },
  };
});

vi.mock('@/lib/auth/rbac', async (importOriginal) => {
  const actual = await importOriginal<typeof import('@/lib/auth/rbac')>();
  return {
    ...actual,
    requirePermission: async (perm: string) => {
      if (!currentUser.permissions.has(perm)) {
        const { Errors } = await import('@/lib/errors');
        throw Errors.forbidden(perm);
      }
      return currentUser as never;
    },
  };
});

beforeEach(() => {
  currentUser = {
    id: 1, employeeId: 1,
    permissions: new Set(['reports.operational.view', 'reports.financial.view', 'reports.export']),
  };
});

// ============================ D1 ============================

describe('D1 — إزالة البطاقتين التطويريتين من شاشة التشغيل', () => {
  const page = readFileSync('src/app/(app)/page.tsx', 'utf8');

  it('لا تحتوي اللوحة على وصف مرحلة M0', () => {
    expect(page).not.toContain('M0_DONE');
    expect(page).not.toContain('المرحلة M0');
  });

  it('لا تحتوي على إشعار «تُبنى في M8»', () => {
    expect(page).not.toContain('تُبنى في المرحلة M8');
  });

  it('★ صندوق حركة النقدية باقٍ كما هو', () => {
    expect(page).toContain('CashMovementBox');
    expect(page).toContain("permissions.has('cash.movement.view')");
  });

  it('الترحيب بالاسم والدور باقٍ', () => {
    expect(page).toContain('user.fullName');
    expect(page).toContain('user.roleNameAr');
  });
});

// ============================ D2 ============================

describe('D2 — الإيراد والنقدية مؤشران منفصلان', () => {
  it('★ صندوق النقدية يعرض حركة النقدية لا الإيراد', () => {
    const box = readFileSync('src/components/CashMovementBox.tsx', 'utf8');
    expect(box).toContain('صافي حركة النقدية اليوم');
    expect(box).toContain('المقبوضات النقدية');
    expect(box).toContain('المدفوعات النقدية');
    expect(box).not.toContain('الإيراد');
  });

  it('★ تقرير الإيرادات لا يحسب من النقدية', async () => {
    const { runReport } = await import('@/services/report.service');
    const r = await runReport({ key: 'revenue' });
    expect(r.title).toBe('الإيرادات');
    // مصادر الإيراد السبعة لا تشمل أي بند نقدي
    const sources = r.rows.map((x) => String(x.source));
    expect(sources).toContain('إيراد التأجير');
    expect(sources).toContain('إيراد المبيعات');
    expect(sources.some((s) => s.includes('نقدية'))).toBe(false);
  });

  it('الإيراد والنقدية مصدران مختلفان في الكود', () => {
    const cash = readFileSync('src/services/cash.service.ts', 'utf8');
    const report = readFileSync('src/services/report.service.ts', 'utf8');
    expect(cash).toContain('isCash: true');       // النقدية تصفّي النقد
    expect(report).not.toContain('dashboardMovement'); // الإيراد لا يمر بحركة النقدية
  });
});

// ============================ D3 ============================

describe('D3 — صافي الربح موسوم بأنه تقديري', () => {
  it('★ عنوان التقرير يحمل كلمة «التقديري»', async () => {
    const { runReport } = await import('@/services/report.service');
    const r = await runReport({ key: 'net-profit' });
    expect(r.title).toBe('صافي الربح التقديري');
  });

  it('★ سطر النتيجة موسوم كذلك', async () => {
    const { runReport } = await import('@/services/report.service');
    const r = await runReport({ key: 'net-profit' });
    const lines = r.rows.map((x) => String(x.line));
    expect(lines).toContain('صافي الربح التقديري');
    expect(lines).not.toContain('صافي الربح المبسّط');
  });

  it('★ يوضّح سبب كونه تقديريًا ويحيل إلى ربحية القطعة', async () => {
    const { runReport } = await import('@/services/report.service');
    const r = await runReport({ key: 'net-profit' });
    expect(r.notes).toContain(NOTES.estimatedProfit);
    expect(NOTES.estimatedProfit).toContain('ربحية القطعة');
  });

  it('★ منطق حساب الربح لم يتغيّر — نفس البنود الخمسة', async () => {
    const { runReport } = await import('@/services/report.service');
    const r = await runReport({ key: 'net-profit' });
    const lines = r.rows.map((x) => String(x.line));
    expect(lines).toEqual([
      'إجمالي الإيرادات',
      'تكلفة شراء القطع المباعة',
      'تكلفة القطع المُستبعدة',
      'المصروفات التشغيلية',
      'صافي الربح التقديري',
    ]);
  });

  it('تقرير ربحية القطعة يبقى العرض التفصيلي للعمر', async () => {
    const { runReport } = await import('@/services/report.service');
    const r = await runReport({ key: 'item-profitability' });
    expect(r.title).toBe('ربحية القطعة عبر عمرها');
    expect(r.notes).toContain(NOTES.lifetimeProfit);
  });
});

// ============================ D4 ============================

describe('D4 — المؤشرات الرصيدية أرصدة لحظية لا مجاميع فترة', () => {
  it('★ تقرير المستحقات لا يتأثر بالفترة', async () => {
    const { runReport } = await import('@/services/report.service');
    const a = await runReport({ key: 'outstanding', from: '2020-01-01', to: '2020-01-31' });
    const b = await runReport({ key: 'outstanding', from: '2026-08-01', to: '2026-08-31' });
    expect(a.rows).toEqual(b.rows);
  });

  it('★ تقرير المخزون لا يتأثر بالفترة', async () => {
    const { runReport } = await import('@/services/report.service');
    const a = await runReport({ key: 'inventory', from: '2020-01-01', to: '2020-01-31' });
    const b = await runReport({ key: 'inventory', from: '2026-08-01', to: '2026-08-31' });
    expect(a.rows).toEqual(b.rows);
  });

  it('★ القطع المتاحة والمؤجرة أرصدة لحظية', async () => {
    const { runReport } = await import('@/services/report.service');
    for (const key of ['available-items', 'rented-items'] as const) {
      const a = await runReport({ key, from: '2020-01-01', to: '2020-01-31' });
      const b = await runReport({ key, from: '2026-08-01', to: '2026-08-31' });
      expect(a.rows).toEqual(b.rows);
    }
  });

  it('المتأخرات لحظية بطبيعتها', async () => {
    const { runReport } = await import('@/services/report.service');
    const a = await runReport({ key: 'overdue-items', from: '2020-01-01', to: '2020-01-31' });
    const b = await runReport({ key: 'overdue-items', from: '2026-08-01', to: '2026-08-31' });
    expect(a.rows).toEqual(b.rows);
  });

  it('رصيد التأمين اللحظي دالة مستقلة عن تقرير الحركة', () => {
    const cash = readFileSync('src/services/cash.service.ts', 'utf8');
    expect(cash).toContain('export async function currentInsuranceCashBalance');
  });

  it('تقرير التأمينات معنون «حركة» لا «رصيد» فلا يختلط بالرصيد اللحظي', async () => {
    const { runReport } = await import('@/services/report.service');
    const r = await runReport({ key: 'insurance-balance' });
    expect(r.title).toBe('حركة صندوق التأمينات');
  });
});

// ============================ D5 ============================

describe('D5 — قواعد الفصل المالي كما اعتُمدت', () => {
  it('★ التأمين مستبعد من الإيراد', async () => {
    const { runReport } = await import('@/services/report.service');
    const r = await runReport({ key: 'revenue' });
    expect(r.notes).toContain(NOTES.insuranceNotRevenue);
    const sources = r.rows.map((x) => String(x.source));
    expect(sources).not.toContain('التأمينات المحصَّلة');
    // المُستبقى وحده إيراد
    expect(sources).toContain('تأمينات مُستبقاة للمحل');
  });

  it('★ الملغى مستبعد من كل التقارير المالية', () => {
    const src = readFileSync('src/services/report.service.ts', 'utf8');
    expect(src).toContain("status: { not: 'VOIDED' }");
    expect(src).toContain("status: 'COMPLETED'");
    expect(src).toContain('isVoided: false');
  });

  it('★ السلف والردود والشراء والترحيل ليست مصروفات', async () => {
    const { runReport } = await import('@/services/report.service');
    const r = await runReport({ key: 'expenses' });
    expect(r.notes).toContain(NOTES.notExpenses);

    const { MOVEMENT_RULES } = await import('../src/lib/cash/cash-movement');
    for (const t of ['EMPLOYEE_ADVANCE', 'CUSTOMER_REFUND',
                     'PRODUCT_PURCHASE', 'TREASURY_TRANSFER'] as const) {
      expect(MOVEMENT_RULES[t].isExpense).toBe(false);
    }
  });

  it('★ العمولة تدخل الربح عبر مصروفها فقط', async () => {
    const { runReport } = await import('@/services/report.service');
    const r = await runReport({ key: 'net-profit' });
    expect(r.notes).toContain(NOTES.commissionViaExpense);

    // تقرير الأرباح يقرأ المصروفات لا الأرقام التحليلية للعمولة
    const src = readFileSync('src/services/report.service.ts', 'utf8');
    expect(src).not.toContain('earnedForMonth');
    expect(src).not.toContain('commissionStatement');
  });

  it('★ الإيراد والنقدية يبقيان منفصلين', async () => {
    const { runReport } = await import('@/services/report.service');
    const revenue = await runReport({ key: 'revenue' });
    const methods = await runReport({ key: 'payment-methods' });
    expect(revenue.notes).toContain(NOTES.insuranceNotRevenue);
    expect(methods.notes).toContain(NOTES.cashOnly);
  });
});

// ============================ D6 ============================

describe('D6 — مصدر واحد للأرقام بلا ازدواج', () => {
  it('★ التصدير يستدعي runReport نفسه', () => {
    const route = readFileSync('src/app/api/reports/export/route.ts', 'utf8');
    expect(route).toContain('runReport');
    // لا استعلام مباشر لقاعدة البيانات في مسار التصدير
    expect(route).not.toContain('prisma.');
  });

  it('★ Excel و PDF لا يستعلمان قاعدة البيانات', () => {
    const excel = readFileSync('src/lib/reports/excel.ts', 'utf8');
    const pdf = readFileSync('src/lib/reports/pdf.ts', 'utf8');
    for (const f of [excel, pdf]) {
      expect(f).not.toContain('prisma');
      expect(f).not.toContain('@/lib/db');
    }
  });

  it('★ التقارير قراءة فقط — صفر عملية كتابة', () => {
    const src = readFileSync('src/services/report.service.ts', 'utf8');
    for (const op of ['.create(', '.update(', '.delete(', '.upsert(',
                      'updateMany', 'deleteMany', '$executeRaw']) {
      expect(src).not.toContain(op);
    }
  });

  it('★ نفس الفلاتر تعطي نفس الأرقام في الشاشة والتصدير', async () => {
    const { runReport } = await import('@/services/report.service');
    const q = { key: 'revenue' as const, from: '2026-08-01', to: '2026-08-31' };
    const a = await runReport(q);
    const b = await runReport(q);
    expect(a.rows).toEqual(b.rows);
    expect(a.totals).toEqual(b.totals);
    expect(a.period).toBe(b.period);
  });
});
