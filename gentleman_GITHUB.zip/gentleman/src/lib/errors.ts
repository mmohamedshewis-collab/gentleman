/** أخطاء التطبيق — كل رسالة موجهة للمستخدم بالعربية، مع كود ثابت للتتبع. */
export class AppError extends Error {
  constructor(
    public readonly code: string,
    message: string,
    public readonly status = 400,
    public readonly details?: unknown,
  ) {
    super(message);
    this.name = 'AppError';
  }
}

export const Errors = {
  unauthenticated: () =>
    new AppError('AUTH_REQUIRED', 'يجب تسجيل الدخول للمتابعة.', 401),
  invalidCredentials: () =>
    new AppError('AUTH_INVALID', 'اسم المستخدم أو كلمة المرور غير صحيحة.', 401),
  /** رسالة القفل: تُعطى فقط بعد كلمة مرور صحيحة، فلا تكشف وجود المستخدم. */
  accountLocked: (minutes: number) =>
    new AppError(
      'AUTH_LOCKED',
      `تم قفل الحساب مؤقتًا بعد محاولات دخول فاشلة متكررة. حاول بعد ${minutes} دقيقة.`,
      429,
    ),
  accountDisabled: () =>
    new AppError('AUTH_DISABLED', 'هذا الحساب معطّل. راجع المدير.', 403),
  sessionExpired: () =>
    new AppError('AUTH_EXPIRED', 'انتهت صلاحية الجلسة. سجّل الدخول مرة أخرى.', 401),
  forbidden: (permission?: string) =>
    new AppError(
      'PERM_DENIED',
      'ليس لديك صلاحية لتنفيذ هذه العملية.',
      403,
      permission ? { permission } : undefined,
    ),
  notFound: (what = 'السجل') =>
    new AppError('NOT_FOUND', `${what} غير موجود.`, 404),
  validation: (details: unknown) =>
    new AppError('VALIDATION', 'البيانات المدخلة غير صحيحة.', 422, details),
  conflict: (message: string) => new AppError('CONFLICT', message, 409),
  rule: (message: string) => new AppError('BUSINESS_RULE', message, 400),
};
