import { describe, it, expect, vi, beforeEach } from 'vitest';
import {
  earnedForOperation, earnedForPeriod, periodVariance, computePayout,
  assertPayable, periodMonthOf, previousMonths, monthBounds,
} from '../src/lib/hr/commission';

const s = (v: { toString(): string }) => v.toString();

// ============================ الوحدة ============================

describe('Commission Earned — دالة على العملية', () => {
  it('يحسب من النسبة المجمَّدة على العملية', () => {
    expect(s(earnedForOperation({ kind: 'RENTAL', netAmount: 750, ratePct: 2, isVoided: false }))).toBe('15');
    expect(s(earnedForOperation({ kind: 'SALE', netAmount: 1300, ratePct: 3, isVoided: false }))).toBe('39');
  });

  it('★ العملية الملغاة عمولتها صفر بلا قيد عكسي', () => {
    expect(s(earnedForOperation({ kind: 'RENTAL', netAmount: 750, ratePct: 2, isVoided: true }))).toBe('0');
  });

  it('بلا نسبة مجمَّدة ⟹ صفر', () => {
    expect(s(earnedForOperation({ kind: 'SALE', netAmount: 1000, ratePct: null, isVoided: false }))).toBe('0');
  });

  it('★ تغيير نسبة الموظف لا يمس عملية سابقة — النسبة من العملية', () => {
    const old = earnedForOperation({ kind: 'RENTAL', netAmount: 1000, ratePct: 2, isVoided: false });
    const fresh = earnedForOperation({ kind: 'RENTAL', netAmount: 1000, ratePct: 5, isVoided: false });
    expect(s(old)).toBe('20');
    expect(s(fresh)).toBe('50');
  });
});

describe('Commission Earned — الفترة', () => {
  const ops = [
    { kind: 'RENTAL' as const, netAmount: 750, ratePct: 2, isVoided: false },
    { kind: 'SALE' as const, netAmount: 1300, ratePct: 3, isVoided: false },
    { kind: 'RENTAL' as const, netAmount: 500, ratePct: 2, isVoided: true },   // ملغاة
  ];

  it('يستبعد الملغى من الوعاء والعمولة (D1)', () => {
    const r = earnedForPeriod(ops);
    expect(s(r.rentalBase)).toBe('750');     // 500 الملغاة خارج الوعاء
    expect(s(r.salesBase)).toBe('1300');
    expect(s(r.rentalCommission)).toBe('15');
    expect(s(r.salesCommission)).toBe('39');
    expect(s(r.total)).toBe('54');
  });

  it('قائمة فارغة تعطي صفرًا', () => {
    expect(s(earnedForPeriod([]).total)).toBe('0');
  });
});

describe('آلية الفرق (Variance)', () => {
  it('الفرق = المستحق الآن − المصروف فعلًا', () => {
    const v = periodVariance({ periodMonth: '2026-03', earned: 39, paid: 54 });
    expect(s(v.variance)).toBe('-15');
  });

  it('★ السيناريو المعتمد: صُرف 54 ثم أُلغيت عملية ⟹ صرف أبريل 85', () => {
    const march = periodVariance({ periodMonth: '2026-03', earned: 39, paid: 54 });
    const payout = computePayout({ currentEarned: 100, priorVariances: [march.variance] });
    expect(s(march.variance)).toBe('-15');
    expect(s(payout.payable)).toBe('85');
    expect(s(payout.carryForward)).toBe('0');
  });

  it('D8: الفرق السالب يتجاوز عمولة الفترة ⟹ صفر ويُرحَّل', () => {
    const payout = computePayout({ currentEarned: 10, priorVariances: [-15] });
    expect(s(payout.rawPayout)).toBe('-5');
    expect(s(payout.payable)).toBe('0');
    expect(s(payout.carryForward)).toBe('-5');
  });

  it('بلا فروق: الصرف = عمولة الفترة', () => {
    const payout = computePayout({ currentEarned: 54, priorVariances: [] });
    expect(s(payout.payable)).toBe('54');
  });

  it('لا يُصرف مبلغ صفري', () => {
    expect(() => assertPayable(0)).toThrow();
    expect(() => assertPayable(54)).not.toThrow();
  });
});

describe('حدود الفترات', () => {
  it('يبني الشهر من التاريخ', () => {
    expect(periodMonthOf(new Date(Date.UTC(2026, 7, 12)))).toBe('2026-08');
  });
  it('يعيد الشهور السابقة', () => {
    expect(previousMonths('2026-01', 3)).toEqual(['2025-12', '2025-11', '2025-10']);
  });
  it('يحسب حدود الشهر', () => {
    expect(monthBounds('2026-02')).toEqual({ from: '2026-02-01', to: '2026-02-28' });
  });
});

// ============================ الخدمة ============================

const auditSpy = vi.fn();
let currentUser: { id: number; employeeId: number | null; permissions: Set<string> };
let commissionRow: Record<string, unknown> | null;
const created: Record<string, unknown[]> = {};
const record = (k: string) => (a: { data: Record<string, unknown> }) => {
  (created[k] ??= []).push(a.data);
  return { id: created[k].length, ...a.data };
};

const tx = {
  $executeRaw: vi.fn(async () => 1),
  commission: {
    findUnique: vi.fn(async () => commissionRow),
    create: vi.fn(record('commission')),
    update: vi.fn(async (a: any) => ({ id: 1, ...a.data })),
  },
  expense: { findFirst: vi.fn(async () => null), create: vi.fn(record('expense')) },
};

vi.mock('@/lib/db', () => ({
  prisma: {
    $transaction: (fn: any) => fn(tx),
    employee: {
      findUnique: vi.fn(async () => ({
        id: 1, fullName: 'محمد علي',
        rentalCommissionPct: { toString: () => '2' },
        salesCommissionPct: { toString: () => '3' },
      })),
      findMany: vi.fn(async () => []),
    },
    expenseCategory: { findFirst: vi.fn(async () => ({ id: 4, nameAr: 'عمولات' })) },
    commission: { findUnique: vi.fn(async () => commissionRow) },
    rental: { findMany: vi.fn(async () => [
      { netAmount: { toString: () => '750' }, commissionRatePct: { toString: () => '2' }, status: 'ACTIVE' },
    ]) },
    sale: { findMany: vi.fn(async () => [
      { netAmount: { toString: () => '1300' }, commissionRatePct: { toString: () => '3' }, status: 'COMPLETED' },
    ]) },
  },
}));

vi.mock('@/lib/audit', () => ({ writeAudit: (...a: any[]) => auditSpy(...a), redact: (x: any) => x }));

vi.mock('@/lib/auth/rbac', async (importOriginal) => {
  const actual = await importOriginal<typeof import('@/lib/auth/rbac')>();
  return {
    ...actual,
    requirePermission: async (perm: string) => {
      if (!currentUser.permissions.has(perm)) {
        const { Errors } = await import('@/lib/errors');
        throw Errors.forbidden(perm);
      }
      return currentUser as never;
    },
  };
});

beforeEach(() => {
  auditSpy.mockClear();
  for (const k of Object.keys(created)) delete created[k];
  for (const m of Object.values(tx)) {
    if (typeof m === 'object' && m !== null) {
      for (const f of Object.values(m)) if (typeof f === 'function' && 'mockClear' in f) (f as any).mockClear();
    } else if (typeof m === 'function' && 'mockClear' in m) (m as any).mockClear();
  }
  commissionRow = null;
  currentUser = {
    id: 1, employeeId: 1,
    permissions: new Set(['commissions.view', 'commissions.pay', 'employees.view']),
  };
});

describe('صرف العمولة', () => {
  it('★ ينشئ مصروفًا واحدًا وسجل صرف واحدًا مربوطًا به', async () => {
    const { payCommission } = await import('@/services/commission.service');
    const r = await payCommission({
      employeeId: 1, periodMonth: '2026-08', paymentMethodId: 1,
    });

    // 750×2% + 1300×3% = 54
    expect(r.paidAmount).toBe('54');
    expect(created.expense).toHaveLength(1);
    expect(created.commission).toHaveLength(1);
    expect(created.expense[0]).toMatchObject({
      amount: '54', cashPaidAmount: '54', employeeId: 1, categoryId: 4,
    });
    expect(created.commission[0]).toMatchObject({
      status: 'PAID', commissionAmount: '54', paidExpenseId: 1,
    });
  });

  it('★ المصروف هو نفسه التدفق النقدي — لا سجل ثانٍ', async () => {
    const { payCommission } = await import('@/services/commission.service');
    await payCommission({ employeeId: 1, periodMonth: '2026-08', paymentMethodId: 1 });
    const exp = created.expense[0] as Record<string, string>;
    expect(exp.amount).toBe(exp.cashPaidAmount);
  });

  it('★ يمنع صرف نفس العمولة مرتين', async () => {
    commissionRow = { id: 1, status: 'PAID', commissionAmount: '54' };
    const { payCommission } = await import('@/services/commission.service');
    await expect(payCommission({ employeeId: 1, periodMonth: '2026-08', paymentMethodId: 1 }))
      .rejects.toMatchObject({ code: 'CONFLICT' });
    expect(created.expense).toBeUndefined();
    expect(auditSpy).not.toHaveBeenCalled();
  });

  it('يحتاج صلاحية commissions.pay', async () => {
    currentUser = { id: 9, employeeId: 3, permissions: new Set(['commissions.view']) };
    const { payCommission } = await import('@/services/commission.service');
    await expect(payCommission({ employeeId: 1, periodMonth: '2026-08', paymentMethodId: 1 }))
      .rejects.toMatchObject({ code: 'PERM_DENIED', details: { permission: 'commissions.pay' } });
  });

  it('يجب اختيار الموظف', async () => {
    const { payCommissionSchema } = await import('@/services/commission.service');
    expect(payCommissionSchema.safeParse({ periodMonth: '2026-08', paymentMethodId: 1 }).success).toBe(false);
    expect(payCommissionSchema.safeParse({
      employeeId: 1, periodMonth: '2026-08', paymentMethodId: 1,
    }).success).toBe(true);
  });

  it('يرفض صيغة فترة خاطئة', async () => {
    const { payCommissionSchema } = await import('@/services/commission.service');
    expect(payCommissionSchema.safeParse({
      employeeId: 1, periodMonth: 'أغسطس', paymentMethodId: 1,
    }).success).toBe(false);
  });

  it('يسجّل تفاصيل الصرف في التدقيق', async () => {
    const { payCommission } = await import('@/services/commission.service');
    await payCommission({ employeeId: 1, periodMonth: '2026-08', paymentMethodId: 1 });
    expect(auditSpy.mock.calls[0][0]).toMatchObject({
      action: 'commission.pay',
      entityType: 'Commission',
      after: { periodMonth: '2026-08', paidAmount: '54', currentEarned: '54' },
    });
  });
});

describe('اختيار الموظف في شاشات الصرف', () => {
  it('يعيد الموظفين النشطين ببياناتهم', async () => {
    const { payableEmployees } = await import('@/services/commission.service');
    const list = await payableEmployees();
    expect(Array.isArray(list)).toBe(true);
  });

  it('يحتاج صلاحية employees.view', async () => {
    currentUser = { id: 9, employeeId: 3, permissions: new Set() };
    const { payableEmployees } = await import('@/services/commission.service');
    await expect(payableEmployees()).rejects.toMatchObject({ code: 'PERM_DENIED' });
  });
});

describe('D6/D7 — فصل صلاحيات المصروف', () => {
  it('★ expenses.void وحدها لا تتجاوز حد المصروف', async () => {
    const src = await import('node:fs').then((fs) =>
      fs.readFileSync('src/services/finance.service.ts', 'utf8'));
    // الحد يُفحص بالصلاحية المخصصة لا بصلاحية الإلغاء
    expect(src).toContain("can(actor, 'expenses.limit.override')");
    expect(src).not.toContain("can(actor, 'expenses.void')");
  });

  it('الصلاحيتان موجودتان في الكتالوج بغرضين منفصلين', async () => {
    const { PERMISSIONS } = await import('../src/lib/auth/permissions');
    const codes = PERMISSIONS.map((p) => p.code);
    expect(codes).toContain('expenses.void');
    expect(codes).toContain('expenses.limit.override');
    const voidPerm = PERMISSIONS.find((p) => p.code === 'expenses.void')!;
    const overridePerm = PERMISSIONS.find((p) => p.code === 'expenses.limit.override')!;
    expect(voidPerm.nameAr).toContain('إلغاء');
    expect(overridePerm.nameAr).toContain('تجاوز');
  });

  it('موظف الفرع لا يملك أيًّا منهما', async () => {
    const { BRANCH_STAFF_PERMISSIONS } = await import('../src/lib/auth/permissions');
    expect(BRANCH_STAFF_PERMISSIONS).not.toContain('expenses.void');
    expect(BRANCH_STAFF_PERMISSIONS).not.toContain('expenses.limit.override');
  });
});

describe('★ الفترة غير المصروفة ليست فرقًا (منع الصرف المتكرر)', () => {
  it('لا تُضاف الفترات غير المصروفة إلى صرف الفترة الحالية', async () => {
    // كل الشهور السابقة بلا سجل صرف ⟹ لا فروق ⟹ الصرف = عمولة الشهر فقط
    commissionRow = null;
    const { payCommission } = await import('@/services/commission.service');
    const r = await payCommission({ employeeId: 1, periodMonth: '2026-08', paymentMethodId: 1 });
    expect(r.paidAmount).toBe('54');
    expect(r.priorVariance).toBe('0');
  });
});
