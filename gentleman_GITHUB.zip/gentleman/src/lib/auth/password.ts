import bcrypt from 'bcryptjs';

const ROUNDS = 12;

export const hashPassword = (plain: string): Promise<string> =>
  bcrypt.hash(plain, ROUNDS);

export const verifyPassword = (plain: string, hash: string): Promise<boolean> =>
  bcrypt.compare(plain, hash);

/** سياسة كلمة المرور: 8 أحرف على الأقل، حرف ورقم. */
export function validatePasswordStrength(pw: string): string | null {
  if (pw.length < 8) return 'كلمة المرور يجب ألا تقل عن 8 أحرف.';
  if (!/[A-Za-z]/.test(pw)) return 'كلمة المرور يجب أن تحتوي على حرف واحد على الأقل.';
  if (!/[0-9]/.test(pw)) return 'كلمة المرور يجب أن تحتوي على رقم واحد على الأقل.';
  return null;
}
