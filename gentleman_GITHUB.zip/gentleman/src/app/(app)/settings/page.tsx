import { readSettings } from '@/services/settings.service';
import SettingsForm from '@/components/SettingsForm';
import { getSession } from '@/lib/auth/session';

export const dynamic = 'force-dynamic';

export default async function SettingsPage() {
  const settings = await readSettings();
  const session = await getSession();
  const canEdit = session?.permissions.has('settings.edit') ?? false;

  const groups = settings.reduce<Record<string, typeof settings>>((acc, s) => {
    (acc[s.group] ||= []).push(s);
    return acc;
  }, {});

  return (
    <div className="space-y-6">
      <div>
        <h1 className="section-title">الإعدادات</h1>
        <p className="text-sm text-slate-600 mt-1">
          كل قيمة مالية أو تشغيلية في النظام مصدرها هذه الشاشة — لا توجد قيم مثبتة داخل الكود.
        </p>
      </div>
      <SettingsForm groups={groups} canEdit={canEdit} />
    </div>
  );
}
