\set ON_ERROR_STOP off
\pset pager off
\t on

-- حارس مفقود في المحاكاة: رفض الإلغاء لسجل غير موجود
CREATE OR REPLACE FUNCTION do_void_return(p_ret int, p_reason text) RETURNS void AS $$
DECLARE r record; v_bal numeric; v_charges numeric := 0; v_rental int; v_voided boolean;
BEGIN
  SELECT rental_id, is_voided INTO v_rental, v_voided FROM returns WHERE id = p_ret FOR UPDATE;
  IF v_rental IS NULL THEN RAISE EXCEPTION 'عملية الإرجاع غير موجودة.'; END IF;
  IF v_voided THEN RAISE EXCEPTION 'عملية الإرجاع ملغاة بالفعل.'; END IF;

  FOR r IN SELECT * FROM return_items WHERE return_id = p_ret LOOP
    IF (SELECT status::text FROM product_items WHERE id=r.item_id) IN ('SOLD','DISPOSED') THEN
      RAISE EXCEPTION 'لا يمكن إلغاء الإرجاع بعد بيع القطعة أو استبعادها.';
    END IF;
    UPDATE rental_items SET status='OUT' WHERE id = r.rental_item_id;
    INSERT INTO item_status_history (item_id, from_status, to_status, reason, ref_type, ref_id, user_id)
    VALUES (r.item_id, (SELECT status FROM product_items WHERE id=r.item_id), 'RENTED',
            'إلغاء إرجاع: ' || p_reason, 'Return', p_ret, 1);
    UPDATE product_items SET status='RENTED' WHERE id = r.item_id;
    UPDATE item_bookings SET is_active=true WHERE item_id=r.item_id AND source_type='RENTAL' AND source_id=v_rental;
    v_charges := v_charges + r.late_fee + r.damage_fee + r.loss_fee;
    IF r.insurance_used > 0 THEN
      SELECT COALESCE((SELECT balance_after FROM insurance_transactions ORDER BY id DESC LIMIT 1),0) INTO v_bal;
      INSERT INTO insurance_transactions (type, rental_id, amount, balance_after, reason, created_by)
      VALUES ('COLLECTED', v_rental, r.insurance_used, v_bal + r.insurance_used,
              'عكس استخدام تأمين — إلغاء إرجاع', 1);
    END IF;
  END LOOP;

  UPDATE rentals SET extra_charges = extra_charges - v_charges,
                     total_due = total_due - v_charges,
                     remaining_amount = remaining_amount - v_charges,
                     status = 'ACTIVE'
   WHERE id = v_rental;
  UPDATE returns SET is_voided=true, void_reason=p_reason, voided_by=1, voided_at=now() WHERE id=p_ret;
  INSERT INTO audit_logs (user_id, action, entity_type, entity_id, before_json, after_json, reason)
  VALUES (1,'return.void','Return',p_ret::text, jsonb_build_object('is_voided',false),
          jsonb_build_object('is_voided',true), p_reason);
END;
$$ LANGUAGE plpgsql;

\echo '=== R8ب: تسوية صحيحة (تلف 900 + تأخير 300 = 1200، تأمين 1000، مستحق 200) ==='
CREATE TEMP TABLE rx AS SELECT id FROM returns WHERE return_no='RET-X';
SELECT 'رقم سجل الإرجاع=' || id FROM rx;
INSERT INTO return_items (return_id, rental_item_id, item_id, actual_return_date,
  late_fee, condition, damage_fee, insurance_used, insurance_refunded, extra_due_from_customer)
SELECT id, 3, 3, CURRENT_DATE, 300, 'DAMAGED', 900, 1000, 0, 200 FROM rx;
SELECT 'غرامات=' || (late_fee+damage_fee) || ' | مستخدم=' || insurance_used
       || ' مردود=' || insurance_refunded || ' | مستحق إضافي=' || extra_due_from_customer
  FROM return_items WHERE return_id = (SELECT id FROM rx);

-- محاكاة أثر الإرجاع على العقد والقطعة
UPDATE rentals SET extra_charges=1200, total_due=1700, remaining_amount=1700, status='CLOSED' WHERE id=2;
UPDATE rental_items SET status='RETURNED' WHERE id=3;
UPDATE product_items SET status='DAMAGED' WHERE id=3;
INSERT INTO insurance_transactions (type, rental_id, amount, balance_after, created_by)
VALUES ('DEDUCTED_DAMAGE', 2, 1000, 0, 1);

\echo ''
\echo '=== R10: إلغاء الإرجاع — الأثر يجب أن ينعكس بالكامل ==='
SELECT 'قبل: القطعة=' || (SELECT status FROM product_items WHERE id=3) ||
       ' | سطر=' || (SELECT status FROM rental_items WHERE id=3) ||
       ' | عقد=' || (SELECT status FROM rentals WHERE id=2) ||
       ' | مستحق=' || (SELECT total_due FROM rentals WHERE id=2) ||
       ' | تأمين=' || (SELECT balance_after FROM insurance_transactions ORDER BY id DESC LIMIT 1);
SELECT do_void_return((SELECT id FROM rx), 'خطأ في تسجيل التلف');
SELECT 'بعد: القطعة=' || (SELECT status FROM product_items WHERE id=3) ||
       ' | سطر=' || (SELECT status FROM rental_items WHERE id=3) ||
       ' | عقد=' || (SELECT status FROM rentals WHERE id=2) ||
       ' | مستحق=' || (SELECT total_due FROM rentals WHERE id=2) ||
       ' | تأمين=' || (SELECT balance_after FROM insurance_transactions ORDER BY id DESC LIMIT 1);
SELECT 'السجل محفوظ: ملغى=' || is_voided || ' السبب=' || void_reason FROM returns WHERE id=(SELECT id FROM rx);

\echo ''
\echo '=== R11: إلغاء مرة ثانية (يجب أن يُرفض) ==='
SELECT do_void_return((SELECT id FROM rx), 'محاولة ثانية');

\echo ''
\echo '=== R12: إعادة تفعيل إرجاع ملغى (يجب أن يُرفض) ==='
UPDATE returns SET is_voided = false WHERE id = (SELECT id FROM rx);

\echo ''
\echo '=== R13: حذف سجل إرجاع (يجب أن يُرفض) ==='
DELETE FROM returns WHERE id = (SELECT id FROM rx);

\echo ''
\echo '=== R14: إلغاء إرجاع غير موجود (يجب أن يُرفض) ==='
SELECT do_void_return(9999, 'غير موجود');

\echo ''
\echo '=== R15: سجل التدقيق ==='
SELECT action || ' | مرجع=' || entity_id || ' | سبب=' || COALESCE(reason,'—') FROM audit_logs ORDER BY id;
