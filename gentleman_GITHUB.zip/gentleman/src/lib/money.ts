import { Decimal } from 'decimal.js';

/**
 * كل الحسابات المالية تمر من هنا. ممنوع استخدام حساب عائم (float) في أي مكان.
 * التقريب: نصف لأعلى، منزلتان عشريتان (الجنيه المصري).
 */
Decimal.set({ precision: 20, rounding: Decimal.ROUND_HALF_UP });

export type Money = Decimal;

export const m = (v: Decimal.Value | null | undefined): Money =>
  new Decimal(v ?? 0);

export const round2 = (v: Decimal.Value): Money =>
  new Decimal(v).toDecimalPlaces(2, Decimal.ROUND_HALF_UP);

export const add = (...vals: Decimal.Value[]): Money =>
  round2(vals.reduce<Money>((a, b) => a.plus(b), new Decimal(0)));

export const sub = (a: Decimal.Value, b: Decimal.Value): Money =>
  round2(new Decimal(a).minus(b));

export const mul = (a: Decimal.Value, b: Decimal.Value): Money =>
  round2(new Decimal(a).times(b));

export const isNegative = (v: Decimal.Value): boolean => new Decimal(v).lt(0);

/** نسبة مئوية من مبلغ (تُستخدم للضريبة والعمولة). */
export const pct = (amount: Decimal.Value, ratePct: Decimal.Value): Money =>
  round2(new Decimal(amount).times(new Decimal(ratePct)).dividedBy(100));

/** الحالة الضريبية للمستند أو للسطر. */
export type VatStatus = 'NOT_APPLICABLE' | 'STANDARD' | 'ZERO_RATED' | 'EXEMPT';

export interface VatContext {
  /** VAT_ENABLED — يأتي من الإعدادات، ولا يُفترض أبدًا. */
  enabled: boolean;
  /** VAT_RATE — نسبة محفوظة، لا تُستخدم إطلاقًا ما لم يكن enabled = true. */
  rate: Decimal.Value;
}

export interface DocumentTotals {
  subtotal: Money;
  discount: Money;
  netAmount: Money;
  vatStatus: VatStatus;
  vatRate: Money | null;
  vatAmount: Money;
  grossAmount: Money;
}

/**
 * البوابة الوحيدة لحساب أي مستند مالي (تأجير / بيع / سطر فاتورة).
 *
 * الترتيب المعتمد:
 *   Subtotal → Discount → Net Amount → VAT → Grand Total
 *   Net Amount  = Subtotal − Discount
 *   VAT Amount  = Net Amount × VAT Rate      (فقط عند التفعيل)
 *   Grand Total = Net Amount + VAT Amount
 *
 * عندما يكون VAT_ENABLED = false:
 *   vatStatus = NOT_APPLICABLE، vatRate = null، vatAmount = 0،
 *   grossAmount = netAmount — ولا يُحصَّل من العميل أي مبلغ ضريبي.
 * النسبة لا تُقرأ ولا تُطبَّق في هذه الحالة مهما كانت قيمتها المخزَّنة.
 */
export function computeDocumentTotals(input: {
  subtotal: Decimal.Value;
  discount: Decimal.Value;
  vat?: VatContext | null;
  /** للسطور المعفاة أو صفرية النسبة عند تفعيل الضريبة مستقبلًا. */
  lineVatStatus?: Exclude<VatStatus, 'NOT_APPLICABLE'>;
}): DocumentTotals {
  const subtotal = round2(input.subtotal);
  const discount = round2(input.discount);
  if (discount.gt(subtotal)) throw new Error('DISCOUNT_EXCEEDS_SUBTOTAL');
  const netAmount = sub(subtotal, discount);

  // المحل غير خاضع للضريبة: لا حساب ولا تحصيل ولا التزام.
  if (!input.vat?.enabled) {
    return {
      subtotal, discount, netAmount,
      vatStatus: 'NOT_APPLICABLE',
      vatRate: null,
      vatAmount: round2(0),
      grossAmount: netAmount,
    };
  }

  const status: VatStatus = input.lineVatStatus ?? 'STANDARD';
  const rate = status === 'STANDARD' ? round2(input.vat.rate) : round2(0);
  if (rate.lt(0) || rate.gt(100)) throw new Error('VAT_RATE_OUT_OF_RANGE');

  const vatAmount = pct(netAmount, rate);
  return {
    subtotal, discount, netAmount,
    vatStatus: status,
    vatRate: rate,
    vatAmount,
    grossAmount: add(netAmount, vatAmount),
  };
}

/** لا ضريبة — تُستخدم في كل النظام ما دام VAT_ENABLED = false. */
export const VAT_DISABLED: VatContext = { enabled: false, rate: 0 };

/** تنسيق العرض بالجنيه المصري بأرقام لاتينية. */
export const formatEGP = (v: Decimal.Value): string =>
  new Intl.NumberFormat('ar-EG', {
    style: 'currency',
    currency: 'EGP',
    numberingSystem: 'latn',
    minimumFractionDigits: 2,
  }).format(new Decimal(v).toNumber());

export const formatNumber = (v: Decimal.Value, digits = 2): string =>
  new Intl.NumberFormat('ar-EG', {
    numberingSystem: 'latn',
    minimumFractionDigits: digits,
    maximumFractionDigits: digits,
  }).format(new Decimal(v).toNumber());
