'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function UserForm({ roles }: { roles: { id: number; nameAr: string }[] }) {
  const router = useRouter();
  const [form, setForm] = useState({ username: '', fullName: '', password: '', roleId: roles[0]?.id ?? 1 });
  const [msg, setMsg] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit() {
    setBusy(true); setMsg(null);
    const res = await fetch('/api/users', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...form, roleId: Number(form.roleId) }),
    });
    const json = await res.json();
    setBusy(false);
    if (!json.ok) { setMsg({ type: 'err', text: json.error?.message ?? 'تعذّر الحفظ.' }); return; }
    setMsg({ type: 'ok', text: 'تم إنشاء المستخدم بنجاح.' });
    setForm({ username: '', fullName: '', password: '', roleId: roles[0]?.id ?? 1 });
    router.refresh();
  }

  return (
    <div className="card">
      <div className="card-header">إضافة مستخدم جديد</div>
      <div className="p-5 grid grid-cols-1 md:grid-cols-4 gap-4">
        <div>
          <label className="label">اسم المستخدم</label>
          <input className="input" dir="ltr" value={form.username}
                 onChange={(e) => setForm({ ...form, username: e.target.value })} />
        </div>
        <div>
          <label className="label">الاسم الكامل</label>
          <input className="input" value={form.fullName}
                 onChange={(e) => setForm({ ...form, fullName: e.target.value })} />
        </div>
        <div>
          <label className="label">كلمة المرور</label>
          <input className="input" type="password" dir="ltr" value={form.password}
                 onChange={(e) => setForm({ ...form, password: e.target.value })} />
        </div>
        <div>
          <label className="label">الدور</label>
          <select className="input" value={form.roleId}
                  onChange={(e) => setForm({ ...form, roleId: Number(e.target.value) })}>
            {roles.map((r) => <option key={r.id} value={r.id}>{r.nameAr}</option>)}
          </select>
        </div>
      </div>
      <div className="px-5 pb-5 flex items-center gap-4">
        <button className="btn-primary" onClick={submit} disabled={busy}>
          {busy ? 'جارٍ الحفظ…' : 'حفظ'}
        </button>
        {msg && (
          <span className={`text-sm font-semibold ${msg.type === 'ok' ? 'text-ok' : 'text-danger'}`}>
            {msg.text}
          </span>
        )}
      </div>
    </div>
  );
}
