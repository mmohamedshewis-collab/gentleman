\set ON_ERROR_STOP off
\t on
\echo '=== K2: حالة PAID بلا مصروف مرتبط (تُرفض) ==='
INSERT INTO commissions (employee_id, period_month, commission_amount, status)
VALUES (1, '2026-08', 54, 'PAID');

\echo '=== K2ب: مبلغ سالب أو نسبة خارج النطاق (تُرفض) ==='
INSERT INTO commissions (employee_id, period_month, commission_amount, rental_rate_pct)
VALUES (1, '2026-09', -10, 2);
INSERT INTO commissions (employee_id, period_month, commission_amount, rental_rate_pct)
VALUES (1, '2026-09', 10, 150);

\echo '=== صرف صحيح ==='
INSERT INTO expenses (expense_no, category_id, amount, cash_paid_amount, payment_method_id, employee_id, created_by)
VALUES ('EXP-COMM', 4, 54, 54, 1, 1, 1);
INSERT INTO commissions (employee_id, period_month, commission_amount, rental_rate_pct, sales_rate_pct, status, paid_expense_id)
SELECT 1, '2026-08', 54, 2, 3, 'PAID', id FROM expenses WHERE expense_no='EXP-COMM';
SELECT 'صُرفت: ' || commission_amount || ' بمصروف ' ||
  (SELECT expense_no FROM expenses WHERE id=paid_expense_id) FROM commissions WHERE period_month='2026-08';

\echo ''
\echo '=== K1: ربط نفس المصروف بعمولة ثانية (يُرفض) ==='
INSERT INTO commissions (employee_id, period_month, commission_amount, status, paid_expense_id)
SELECT 1, '2026-09', 20, 'PAID', id FROM expenses WHERE expense_no='EXP-COMM';

\echo '=== تكرار صرف نفس الموظف لنفس الشهر (يُرفض) ==='
INSERT INTO expenses (expense_no, category_id, amount, cash_paid_amount, payment_method_id, employee_id, created_by)
VALUES ('EXP-COMM2', 4, 54, 54, 1, 1, 1);
INSERT INTO commissions (employee_id, period_month, commission_amount, status, paid_expense_id)
SELECT 1, '2026-08', 54, 'PAID', id FROM expenses WHERE expense_no='EXP-COMM2';

\echo ''
\echo '=== K3: إعادة فتح عمولة مصروفة (يُرفض) ==='
UPDATE commissions SET status='ACCRUED' WHERE period_month='2026-08';
\echo '=== K3ب: تعديل مبلغ عمولة مصروفة (يُرفض) ==='
UPDATE commissions SET commission_amount=999 WHERE period_month='2026-08';

\echo ''
\echo '=== K4: حذف سجل عمولة (يُرفض) ==='
DELETE FROM commissions WHERE period_month='2026-08';
