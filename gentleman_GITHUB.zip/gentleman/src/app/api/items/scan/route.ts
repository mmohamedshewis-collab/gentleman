import { route } from '@/lib/api';
import { scanItem, scanSchema } from '@/services/item.service';

/** أسرع مسار في النظام: مسح الباركود يعيد كل ما يحتاجه الموظف فورًا. */
export const GET = route({ schema: scanSchema, handler: ({ input }) => scanItem(input.barcode) });
