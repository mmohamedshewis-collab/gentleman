import Link from 'next/link';
import { getItemDetails, getItemHistory } from '@/services/item.service';
import { getSession } from '@/lib/auth/session';
import { STATUS_LABELS, type ItemStatus } from '@/lib/inventory/item-state';
import { formatDate, formatDateTime } from '@/lib/date';
import { formatEGP } from '@/lib/money';
import StatusBadge from '@/components/StatusBadge';
import ItemStatusForm from '@/components/ItemStatusForm';

export const dynamic = 'force-dynamic';

const TRX_LABELS: Record<string, string> = {
  PURCHASE: 'شراء وإضافة للمخزون',
  RENT_OUT: 'خروج للتأجير',
  RETURN_IN: 'إرجاع للمخزون',
  SALE: 'بيع',
  WRITE_OFF: 'إخراج من الخدمة',
  FOUND: 'العثور على القطعة',
  ADJUST: 'تسوية',
};

export default async function ItemPage({ params }: { params: { id: string } }) {
  const id = Number(params.id);
  const [details, history, session, upkeep] = await Promise.all([
    getItemDetails(id), getItemHistory(id), getSession(), itemUpkeepHistory({ itemId: id }),
  ]);
  const { item, status, showCost, availableTransitions } = details;
  const canOverride = session?.permissions.has('items.status.override') ?? false;
  const canManage = session?.permissions.has('items.manage') ?? false;
  const methods = canManage ? await listPaymentMethods() : [];

  // ربحية القطعة تشغيليًا: تكلفة الشراء تُستخدم للتحليل فقط
  const rentalRevenue = Number(item.totalRentalRevenue);
  const feesRevenue = Number(item.totalFeesRevenue);
  const maintenance = Number(item.totalMaintenanceCost);
  const cost = Number(item.purchaseCost);
  const recovery = cost > 0 ? ((rentalRevenue / cost) * 100).toFixed(1) : null;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="section-title">{item.product.nameAr}</h1>
          <p className="num text-sm text-slate-500 mt-1">{item.itemCode} · {item.barcode}</p>
        </div>
        <StatusBadge status={status} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <div className="card lg:col-span-2">
          <div className="card-header">بيانات القطعة</div>
          <dl className="p-5 grid grid-cols-2 md:grid-cols-3 gap-4 text-sm">
            <div><dt className="text-slate-500">التصنيف</dt><dd className="font-semibold">{item.product.category?.nameAr ?? '—'}</dd></div>
            <div><dt className="text-slate-500">الماركة</dt><dd className="font-semibold">{item.product.brand?.name ?? '—'}</dd></div>
            <div><dt className="text-slate-500">المقاس</dt><dd className="font-semibold">{item.product.size ?? '—'}</dd></div>
            <div><dt className="text-slate-500">اللون</dt><dd className="font-semibold">{item.product.color ?? '—'}</dd></div>
            <div><dt className="text-slate-500">سعر التأجير</dt><dd className="font-semibold num">{formatEGP(Number(item.rentalPrice ?? item.product.rentalPrice))}</dd></div>
            <div><dt className="text-slate-500">سعر البيع</dt><dd className="font-semibold num">{formatEGP(Number(item.salePrice ?? item.product.salePrice))}</dd></div>
            <div><dt className="text-slate-500">تاريخ الشراء</dt><dd className="font-semibold num">{item.purchaseDate ? formatDate(item.purchaseDate) : '—'}</dd></div>
            <div><dt className="text-slate-500">آخر تأجير</dt><dd className="font-semibold num">{item.lastRentalDate ? formatDate(item.lastRentalDate) : '—'}</dd></div>
            <div><dt className="text-slate-500">آخر إرجاع</dt><dd className="font-semibold num">{item.lastReturnDate ? formatDate(item.lastReturnDate) : '—'}</dd></div>
          </dl>
        </div>

        {showCost && (
          <div className="card">
            <div className="card-header">ربحية القطعة</div>
            <dl className="p-5 space-y-3 text-sm">
              <div className="flex justify-between"><dt className="text-slate-500">تكلفة الشراء</dt><dd className="font-semibold num">{formatEGP(cost)}</dd></div>
              <div className="flex justify-between"><dt className="text-slate-500">عدد مرات التأجير</dt><dd className="font-semibold num">{item.rentalCount}</dd></div>
              <div className="flex justify-between"><dt className="text-slate-500">إيراد التأجير التراكمي</dt><dd className="font-semibold num">{formatEGP(rentalRevenue)}</dd></div>
              <div className="flex justify-between"><dt className="text-slate-500">إيراد الرسوم</dt><dd className="font-semibold num">{formatEGP(feesRevenue)}</dd></div>
              <div className="flex justify-between"><dt className="text-slate-500">تكلفة الصيانة</dt><dd className="font-semibold num">{formatEGP(maintenance)}</dd></div>
              <div className="flex justify-between border-t pt-3">
                <dt className="font-bold">نسبة استرداد التكلفة</dt>
                <dd className="font-bold num text-brand">{recovery ? `${recovery}%` : '—'}</dd>
              </div>
            </dl>
          </div>
        )}
      </div>

      {canOverride && availableTransitions.length > 0 && (
        <ItemStatusForm
          itemId={item.id}
          currentLabel={STATUS_LABELS[status]}
          targets={availableTransitions.map((t) => ({ value: t, label: STATUS_LABELS[t as ItemStatus] }))}
        />
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <div className="card overflow-hidden">
          <div className="card-header">سجل الحالات</div>
          <table className="table">
            <thead><tr><th>التاريخ</th><th>من</th><th>إلى</th><th>السبب</th></tr></thead>
            <tbody>
              {history.statusHistory.map((h) => (
                <tr key={h.id}>
                  <td className="num">{formatDateTime(h.createdAt)}</td>
                  <td>{STATUS_LABELS[h.fromStatus as ItemStatus]}</td>
                  <td className="font-semibold">{STATUS_LABELS[h.toStatus as ItemStatus]}</td>
                  <td className="text-slate-600">{h.reason ?? '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="card overflow-hidden">
          <div className="card-header">حركات المخزون</div>
          <table className="table">
            <thead><tr><th>التاريخ</th><th>الحركة</th><th>ملاحظة</th></tr></thead>
            <tbody>
              {history.inventoryTrx.map((t) => (
                <tr key={t.id}>
                  <td className="num">{formatDate(t.trxDate)}</td>
                  <td className="font-semibold">{TRX_LABELS[t.type] ?? t.type}</td>
                  <td className="text-slate-600">{t.note ?? '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <Link href="/inventory" className="btn-secondary inline-flex">العودة إلى المخزون</Link>
      <UpkeepPanel
        itemId={item.id}
        history={upkeep}
        methods={methods.map((m) => ({ id: m.id, nameAr: m.nameAr }))}
        canManage={canManage}
      />

    </div>
  );
}
