import { formatCell, type ReportResult } from './report-types';

/**
 * تصدير PDF عبر صفحة طباعة عربية RTL.
 *
 * ★ لماذا صفحة طباعة لا مكتبة PDF؟
 *   تشكيل الحروف العربية واتجاه النص في مكتبات PDF يحتاج تضمين خط وإعادة تشكيل
 *   يدوية، وينتج غالبًا حروفًا منفصلة أو معكوسة. المتصفح يتولاهما بشكل صحيح،
 *   ويستخدم خط النظام نفسه (Cairo)، فيخرج الملف **مطابقًا للشاشة حرفيًا** —
 *   وهو المطلوب صراحةً. المستخدم يحفظ PDF من حوار الطباعة.
 */

const esc = (v: string): string =>
  v.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

export function reportToPrintableHtml(
  report: ReportResult,
  shop: { name: string; phone: string; address: string },
): string {
  const head = report.columns.map((c) => `<th>${esc(c.label)}</th>`).join('');

  const body = report.rows.map((row) => {
    const cells = report.columns.map((c) => {
      const text = formatCell(row[c.key], c.type);
      const cls = c.type === 'money' || c.type === 'number' ? ' class="num"' : '';
      return `<td${cls}>${esc(text)}</td>`;
    }).join('');
    return `<tr>${cells}</tr>`;
  }).join('');

  const totals = report.totals
    ? `<tfoot><tr>${report.columns.map((c) => {
        const raw = report.totals![c.key];
        const text = raw === null ? '' : formatCell(raw, c.type);
        const cls = c.type === 'money' || c.type === 'number' ? ' class="num"' : '';
        return `<td${cls}>${esc(text)}</td>`;
      }).join('')}</tr></tfoot>`
    : '';

  const filters = report.appliedFilters.length
    ? `<p class="filters">${report.appliedFilters
        .map((f) => `${esc(f.label)}: <strong>${esc(f.value)}</strong>`).join(' &nbsp;•&nbsp; ')}</p>`
    : '';

  const notes = report.notes.length
    ? `<div class="notes">${report.notes.map((n) => `<p>• ${esc(n)}</p>`).join('')}</div>`
    : '';

  return `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8">
<title>${esc(report.title)} — ${esc(report.period)}</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700&display=swap" rel="stylesheet">
<style>
  @page { size: A4 landscape; margin: 12mm; }
  * { box-sizing: border-box; }
  body { font-family: 'Cairo', Tahoma, sans-serif; color: #0f172a; margin: 0; padding: 16px; }
  header { text-align: center; border-bottom: 2px solid #002060; padding-bottom: 10px; margin-bottom: 14px; }
  h1 { color: #002060; font-size: 20px; margin: 0 0 4px; }
  h2 { font-size: 15px; margin: 6px 0 2px; }
  .meta, .filters { font-size: 11px; color: #475569; margin: 2px 0; }
  table { width: 100%; border-collapse: collapse; font-size: 11px; }
  thead th { background: #002060; color: #fff; font-weight: 700; padding: 7px 6px; text-align: right; border: 1px solid #002060; }
  tbody td { padding: 6px; border: 1px solid #e2e8f0; text-align: right; }
  tbody tr:nth-child(even) { background: #f8fafc; }
  tfoot td { padding: 7px 6px; border: 1px solid #cbd5e1; background: #E8EFF8; font-weight: 700; text-align: right; }
  .num { font-variant-numeric: tabular-nums; direction: ltr; unicode-bidi: embed; text-align: left; }
  .notes { margin-top: 14px; font-size: 10px; color: #64748b; border-top: 1px solid #e2e8f0; padding-top: 8px; }
  .notes p { margin: 3px 0; }
  .toolbar { text-align: center; margin-bottom: 14px; }
  .toolbar button { font-family: inherit; background: #002060; color: #fff; border: 0; border-radius: 8px; padding: 9px 22px; font-size: 13px; font-weight: 700; cursor: pointer; }
  @media print { .toolbar { display: none; } body { padding: 0; } }
</style>
</head>
<body>
  <div class="toolbar">
    <button onclick="window.print()">طباعة أو حفظ PDF</button>
  </div>
  <header>
    <h1>${esc(shop.name || 'Gentleman')}</h1>
    ${shop.address ? `<p class="meta">${esc(shop.address)}</p>` : ''}
    ${shop.phone ? `<p class="meta">${esc(shop.phone)}</p>` : ''}
    <h2>${esc(report.title)}</h2>
    <p class="meta">${esc(report.period)}</p>
    ${filters}
    <p class="meta">تاريخ الإصدار: ${esc(report.generatedAt)}</p>
  </header>
  <table>
    <thead><tr>${head}</tr></thead>
    <tbody>${body || `<tr><td colspan="${report.columns.length}" style="text-align:center;padding:20px">لا توجد بيانات في هذه الفترة.</td></tr>`}</tbody>
    ${totals}
  </table>
  ${notes}
  <script>window.addEventListener('load', () => setTimeout(() => window.print(), 400));</script>
</body>
</html>`;
}
