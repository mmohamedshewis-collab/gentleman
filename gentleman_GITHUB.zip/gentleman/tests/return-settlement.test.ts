import { describe, it, expect } from 'vitest';
import {
  computeLateFee, computeSettlement, assertSettlementInvariants, recognizedRevenue,
  itemStatusAfterReturn, rentalItemStatusAfterReturn, deriveRentalStatus, SettlementError,
} from '../src/lib/returns/settlement';
import { toBusinessDate } from '../src/lib/date';

const s = (v: { toString(): string }) => v.toString();
const d = (x: string) => toBusinessDate(x);

describe('أيام التأخير والغرامة', () => {
  const base = { feePerItemPerDay: 100 };

  it('الإرجاع في يوم الاستحقاق = صفر تأخير وصفر غرامة', () => {
    const r = computeLateFee({ ...base, expectedReturnDate: d('2026-08-10'), actualReturnDate: d('2026-08-10') });
    expect(r.daysLate).toBe(0);
    expect(s(r.cappedFee)).toBe('0');
  });

  it('الإرجاع المبكر لا يولّد غرامة ولا استردادًا', () => {
    const r = computeLateFee({ ...base, expectedReturnDate: d('2026-08-10'), actualReturnDate: d('2026-08-08') });
    expect(r.daysLate).toBe(0);
    expect(s(r.cappedFee)).toBe('0');
  });

  it('يومان تأخير × 100 = 200', () => {
    const r = computeLateFee({ ...base, expectedReturnDate: d('2026-08-10'), actualReturnDate: d('2026-08-12') });
    expect(r.daysLate).toBe(2);
    expect(s(r.cappedFee)).toBe('200');
  });

  it('يحترم السقف عند تجاوزه', () => {
    const r = computeLateFee({
      ...base, capPerItem: 500,
      expectedReturnDate: d('2026-08-01'), actualReturnDate: d('2026-08-20'),
    });
    expect(r.daysLate).toBe(19);
    expect(s(r.rawFee)).toBe('1900');
    expect(s(r.cappedFee)).toBe('500');
    expect(r.wasCapped).toBe(true);
  });

  it('سقف = 0 يعني بلا سقف', () => {
    const r = computeLateFee({
      ...base, capPerItem: 0,
      expectedReturnDate: d('2026-08-01'), actualReturnDate: d('2026-08-20'),
    });
    expect(s(r.cappedFee)).toBe('1900');
    expect(r.wasCapped).toBe(false);
  });

  it('يعمل عبر حدود الشهر', () => {
    const r = computeLateFee({ ...base, expectedReturnDate: d('2026-08-30'), actualReturnDate: d('2026-09-02') });
    expect(r.daysLate).toBe(3);
  });

  it('يرفض رسومًا سالبة', () => {
    expect(() => computeLateFee({
      feePerItemPerDay: -5, expectedReturnDate: d('2026-08-10'), actualReturnDate: d('2026-08-12'),
    })).toThrowError(SettlementError);
  });
});

describe('تسوية التأمين — الفصل بين الإيراد والسداد والالتزام', () => {
  it('سليمة بلا تأخير: التأمين يُرد كاملًا ولا إيراد', () => {
    const r = computeSettlement({ condition: 'GOOD', lateFee: 0, insuranceAvailable: 1000 });
    expect(s(r.insuranceRefunded)).toBe('1000');
    expect(s(r.insuranceUsed)).toBe('0');
    expect(s(r.extraDueFromCustomer)).toBe('0');
    expect(s(recognizedRevenue(r))).toBe('0');
    assertSettlementInvariants(r, 1000);
  });

  it('سليمة بتأخير 200 وتأمين 1000: يُستقطع 200 ويُرد 800', () => {
    const r = computeSettlement({ condition: 'GOOD', lateFee: 200, insuranceAvailable: 1000 });
    expect(s(r.insuranceUsed)).toBe('200');
    expect(s(r.insuranceRefunded)).toBe('800');
    expect(s(r.extraDueFromCustomer)).toBe('0');
    expect(s(recognizedRevenue(r))).toBe('200');
    assertSettlementInvariants(r, 1000);
  });

  it('★ تلف 250 وتأمين 1000: الإيراد 250 وليس 500 — لا ازدواج', () => {
    const r = computeSettlement({ condition: 'DAMAGED', lateFee: 0, damageFee: 250, insuranceAvailable: 1000 });
    expect(s(r.insuranceUsed)).toBe('250');
    expect(s(r.insuranceRefunded)).toBe('750');
    expect(s(recognizedRevenue(r))).toBe('250');
    // التأمين المستخدم ليس إيرادًا إضافيًا
    expect(recognizedRevenue(r).equals(r.totalCharges)).toBe(true);
    assertSettlementInvariants(r, 1000);
  });

  it('تلف 1500 وتأمين 1000: التأمين يُستهلك و500 مديونية', () => {
    const r = computeSettlement({ condition: 'DAMAGED', lateFee: 0, damageFee: 1500, insuranceAvailable: 1000 });
    expect(s(r.insuranceUsed)).toBe('1000');
    expect(s(r.insuranceRefunded)).toBe('0');
    expect(s(r.extraDueFromCustomer)).toBe('500');
    expect(s(recognizedRevenue(r))).toBe('1500');
    assertSettlementInvariants(r, 1000);
  });

  it('فقد بقيمة 6000 وتأمين 1000: 5000 مديونية', () => {
    const r = computeSettlement({ condition: 'LOST', lateFee: 0, lossFee: 6000, insuranceAvailable: 1000 });
    expect(s(r.insuranceUsed)).toBe('1000');
    expect(s(r.extraDueFromCustomer)).toBe('5000');
    expect(s(recognizedRevenue(r))).toBe('6000');
    assertSettlementInvariants(r, 1000);
  });

  it('تأخير وتلف معًا: يُجمعان قبل التوزيع', () => {
    const r = computeSettlement({ condition: 'DAMAGED', lateFee: 200, damageFee: 250, insuranceAvailable: 1000 });
    expect(s(r.totalCharges)).toBe('450');
    expect(s(r.insuranceUsed)).toBe('450');
    expect(s(r.insuranceRefunded)).toBe('550');
    expect(s(recognizedRevenue(r))).toBe('450');
    assertSettlementInvariants(r, 1000);
  });

  it('بلا تأمين وغرامة 200: كلها مديونية', () => {
    const r = computeSettlement({ condition: 'GOOD', lateFee: 200, insuranceAvailable: 0 });
    expect(s(r.insuranceUsed)).toBe('0');
    expect(s(r.extraDueFromCustomer)).toBe('200');
    assertSettlementInvariants(r, 0);
  });

  it('الغرامة تساوي التأمين بالضبط: لا رد ولا مديونية', () => {
    const r = computeSettlement({ condition: 'DAMAGED', lateFee: 0, damageFee: 1000, insuranceAvailable: 1000 });
    expect(s(r.insuranceUsed)).toBe('1000');
    expect(s(r.insuranceRefunded)).toBe('0');
    expect(s(r.extraDueFromCustomer)).toBe('0');
    assertSettlementInvariants(r, 1000);
  });
});

describe('اتساق الحالة مع المبالغ', () => {
  it('تالفة بلا قيمة تلف مرفوضة', () => {
    expect(() => computeSettlement({ condition: 'DAMAGED', lateFee: 0, damageFee: 0, insuranceAvailable: 100 }))
      .toThrowError(/قيمة التلف/);
  });
  it('مفقودة بلا تعويض مرفوضة', () => {
    expect(() => computeSettlement({ condition: 'LOST', lateFee: 0, lossFee: 0, insuranceAvailable: 100 }))
      .toThrowError(/الفقد/);
  });
  it('سليمة مع قيمة تلف مرفوضة', () => {
    expect(() => computeSettlement({ condition: 'GOOD', lateFee: 0, damageFee: 100, insuranceAvailable: 100 }))
      .toThrowError(SettlementError);
  });
  it('قيمة تلف مع حالة مفقودة مرفوضة', () => {
    expect(() => computeSettlement({ condition: 'LOST', lateFee: 0, lossFee: 500, damageFee: 100, insuranceAvailable: 0 }))
      .toThrowError(SettlementError);
  });
  it('مبالغ سالبة مرفوضة', () => {
    expect(() => computeSettlement({ condition: 'GOOD', lateFee: -1, insuranceAvailable: 0 }))
      .toThrowError(SettlementError);
  });
});

describe('ثوابت التسوية تكشف أي اختلال', () => {
  it('يرفض توزيعًا مفبركًا يخرق معادلة التأمين', () => {
    const bad = {
      lateFee: { toString: () => '0' } as never, damageFee: { toString: () => '0' } as never,
      lossFee: { toString: () => '0' } as never,
    };
    const r = computeSettlement({ condition: 'DAMAGED', lateFee: 0, damageFee: 250, insuranceAvailable: 1000 });
    const tampered = { ...r, insuranceRefunded: r.insuranceRefunded.plus(100) };
    expect(() => assertSettlementInvariants(tampered as never, 1000)).toThrowError(/اختلال في التأمين/);
    void bad;
  });

  it('يرفض مديونية لا تكمل الغرامات', () => {
    const r = computeSettlement({ condition: 'DAMAGED', lateFee: 0, damageFee: 1500, insuranceAvailable: 1000 });
    const tampered = { ...r, extraDueFromCustomer: r.extraDueFromCustomer.minus(100) };
    expect(() => assertSettlementInvariants(tampered as never, 1000)).toThrowError(/اختلال في التسوية/);
  });
});

describe('حالة القطعة وحالة العقد بعد الإرجاع', () => {
  it('سليمة → متاحة، أو تحت التنظيف عند تفعيله', () => {
    expect(itemStatusAfterReturn('GOOD', false)).toBe('AVAILABLE');
    expect(itemStatusAfterReturn('GOOD', true)).toBe('CLEANING');
  });
  it('تالفة → تالفة حتى لو فُعِّل التنظيف', () => {
    expect(itemStatusAfterReturn('DAMAGED', true)).toBe('DAMAGED');
  });
  it('مفقودة → مفقودة', () => {
    expect(itemStatusAfterReturn('LOST', true)).toBe('LOST');
  });
  it('حالة سطر العقد', () => {
    expect(rentalItemStatusAfterReturn('GOOD')).toBe('RETURNED');
    expect(rentalItemStatusAfterReturn('DAMAGED')).toBe('RETURNED');
    expect(rentalItemStatusAfterReturn('LOST')).toBe('LOST');
  });

  it('اشتقاق حالة العقد', () => {
    expect(deriveRentalStatus(['OUT', 'OUT'])).toBe('ACTIVE');
    expect(deriveRentalStatus(['RETURNED', 'OUT'])).toBe('PARTIALLY_RETURNED');
    expect(deriveRentalStatus(['RETURNED', 'RETURNED'])).toBe('CLOSED');
    expect(deriveRentalStatus(['RETURNED', 'LOST'])).toBe('CLOSED');
    expect(deriveRentalStatus(['RETURNED', 'VOIDED'])).toBe('CLOSED');
    expect(deriveRentalStatus(['OUT', 'VOIDED'])).toBe('ACTIVE');
  });
});
