\set ON_ERROR_STOP off
\pset pager off
\t on
INSERT INTO returns (return_no, rental_id, return_date, created_by) VALUES ('RET-X', 2, CURRENT_DATE, 1);

\echo '=== R5: خرق معادلة التسوية: مستخدم 500 + مستحق 0 ≠ غرامات 200 (يجب أن يُرفض) ==='
INSERT INTO return_items (return_id, rental_item_id, item_id, actual_return_date,
  late_fee, condition, damage_fee, insurance_used, insurance_refunded, extra_due_from_customer)
VALUES (3, 3, 3, CURRENT_DATE, 200, 'GOOD', 0, 500, 500, 0);

\echo '=== R6: حالة "تالفة" بقيمة تلف صفر (يجب أن يُرفض) ==='
INSERT INTO return_items (return_id, rental_item_id, item_id, actual_return_date,
  late_fee, condition, damage_fee, insurance_used, insurance_refunded, extra_due_from_customer)
VALUES (3, 3, 3, CURRENT_DATE, 0, 'DAMAGED', 0, 0, 0, 0);

\echo '=== R7: تلف مسجّل على قطعة "سليمة" (يجب أن يُرفض) ==='
INSERT INTO return_items (return_id, rental_item_id, item_id, actual_return_date,
  late_fee, condition, damage_fee, insurance_used, insurance_refunded, extra_due_from_customer)
VALUES (3, 3, 3, CURRENT_DATE, 0, 'GOOD', 300, 300, 0, 0);

\echo '=== R8: مبالغ سالبة (يجب أن تُرفض) ==='
INSERT INTO return_items (return_id, rental_item_id, item_id, actual_return_date,
  late_fee, condition, insurance_used, insurance_refunded, extra_due_from_customer)
VALUES (3, 3, 3, CURRENT_DATE, -100, 'GOOD', 0, 0, -100);

\echo '=== R8ب: تسوية صحيحة على نفس السطر (يجب أن تنجح) ==='
INSERT INTO return_items (return_id, rental_item_id, item_id, actual_return_date,
  late_fee, condition, damage_fee, insurance_used, insurance_refunded, extra_due_from_customer)
VALUES (3, 3, 3, CURRENT_DATE, 300, 'DAMAGED', 900, 1000, 0, 200);
SELECT 'سُجِّل: غرامات=' || (late_fee+damage_fee) || ' مستخدم=' || insurance_used
       || ' مردود=' || insurance_refunded || ' مستحق=' || extra_due_from_customer
  FROM return_items WHERE return_id=3;

\echo ''
\echo '=== R10: إلغاء الإرجاع (Void) ==='
CREATE OR REPLACE FUNCTION do_void_return(p_ret int, p_reason text) RETURNS void AS $$
DECLARE r record; v_bal numeric; v_charges numeric := 0; v_rental int;
BEGIN
  SELECT rental_id INTO v_rental FROM returns WHERE id = p_ret FOR UPDATE;
  IF (SELECT is_voided FROM returns WHERE id=p_ret) THEN
    RAISE EXCEPTION 'عملية الإرجاع ملغاة بالفعل.';
  END IF;
  FOR r IN SELECT * FROM return_items WHERE return_id = p_ret LOOP
    IF (SELECT status::text FROM product_items WHERE id=r.item_id) IN ('SOLD','DISPOSED') THEN
      RAISE EXCEPTION 'لا يمكن إلغاء الإرجاع بعد بيع القطعة أو استبعادها.';
    END IF;
    UPDATE rental_items SET status='OUT' WHERE id = r.rental_item_id;
    INSERT INTO item_status_history (item_id, from_status, to_status, reason, ref_type, ref_id, user_id)
    VALUES (r.item_id, (SELECT status FROM product_items WHERE id=r.item_id), 'RENTED',
            'إلغاء إرجاع: ' || p_reason, 'Return', p_ret, 1);
    UPDATE product_items SET status='RENTED' WHERE id = r.item_id;
    UPDATE item_bookings SET is_active=true WHERE item_id=r.item_id AND source_type='RENTAL' AND source_id=v_rental;
    v_charges := v_charges + r.late_fee + r.damage_fee + r.loss_fee;
    IF r.insurance_used > 0 THEN
      SELECT COALESCE((SELECT balance_after FROM insurance_transactions ORDER BY id DESC LIMIT 1),0) INTO v_bal;
      INSERT INTO insurance_transactions (type, rental_id, amount, balance_after, reason, created_by)
      VALUES ('COLLECTED', v_rental, r.insurance_used, v_bal + r.insurance_used,
              'عكس استخدام تأمين — إلغاء إرجاع', 1);
    END IF;
  END LOOP;
  UPDATE rentals SET extra_charges = extra_charges - v_charges,
                     total_due = total_due - v_charges,
                     remaining_amount = remaining_amount - v_charges,
                     status = 'ACTIVE'
   WHERE id = v_rental;
  UPDATE returns SET is_voided=true, void_reason=p_reason, voided_by=1, voided_at=now() WHERE id=p_ret;
  INSERT INTO audit_logs (user_id, action, entity_type, entity_id, before_json, after_json, reason)
  VALUES (1,'return.void','Return',p_ret::text, jsonb_build_object('is_voided',false),
          jsonb_build_object('is_voided',true), p_reason);
END;
$$ LANGUAGE plpgsql;

SELECT 'قبل: حالة القطعة=' || (SELECT status FROM product_items WHERE id=3) ||
       ' | عقد=' || (SELECT status FROM rentals WHERE id=2) ||
       ' | مستحق=' || (SELECT total_due FROM rentals WHERE id=2) ||
       ' | رصيد تأمين=' || (SELECT balance_after FROM insurance_transactions ORDER BY id DESC LIMIT 1);
UPDATE rentals SET extra_charges=1200, total_due=1700, remaining_amount=1700, status='CLOSED' WHERE id=2;
UPDATE rental_items SET status='RETURNED' WHERE id=3;
UPDATE product_items SET status='DAMAGED' WHERE id=3;
SELECT do_void_return(3, 'خطأ في تسجيل التلف');
SELECT 'بعد الإلغاء: حالة القطعة=' || (SELECT status FROM product_items WHERE id=3) ||
       ' | سطر العقد=' || (SELECT status FROM rental_items WHERE id=3) ||
       ' | عقد=' || (SELECT status FROM rentals WHERE id=2) ||
       ' | مستحق=' || (SELECT total_due FROM rentals WHERE id=2) ||
       ' | رصيد تأمين=' || (SELECT balance_after FROM insurance_transactions ORDER BY id DESC LIMIT 1);
SELECT 'سجل الإرجاع محفوظ لا محذوف: ملغى=' || is_voided || ' السبب=' || void_reason FROM returns WHERE id=3;

\echo ''
\echo '=== R11: إلغاء الإرجاع مرة ثانية (يجب أن يُرفض) ==='
SELECT do_void_return(3, 'محاولة ثانية');

\echo ''
\echo '=== R12: إعادة تفعيل إرجاع ملغى (يجب أن يُرفض) ==='
UPDATE returns SET is_voided = false WHERE id = 3;

\echo ''
\echo '=== R13: حذف سجل إرجاع (يجب أن يُرفض) ==='
DELETE FROM returns WHERE id = 3;
