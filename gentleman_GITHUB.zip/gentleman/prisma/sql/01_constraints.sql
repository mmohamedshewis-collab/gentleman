-- =====================================================================
-- Gentleman — قيود سلامة البيانات على مستوى قاعدة البيانات
-- تُطبَّق بعد كل migration:  npm run db:constraints
-- خط الدفاع الأخير: حتى لو أخطأ الكود، القاعدة ترفض.
-- =====================================================================

CREATE EXTENSION IF NOT EXISTS btree_gist;

-- ---------------------------------------------------------------------
-- 1) قطعة واحدة لا يمكن أن تكون في عقدين نشطين
-- ---------------------------------------------------------------------
DROP INDEX IF EXISTS ux_item_single_active_rental;
CREATE UNIQUE INDEX ux_item_single_active_rental
  ON rental_items (item_id) WHERE status = 'OUT';

-- ---------------------------------------------------------------------
-- 2) قطعة واحدة لا تُباع مرتين
-- ---------------------------------------------------------------------
-- ملاحظة: لا يصلح فهرس فريد بسيط هنا، لأن الفاتورة الملغاة يجب ألا تمنع
-- إعادة بيع القطعة. الشرط يعتمد على حالة الفاتورة في جدول آخر، لذا يُنفَّذ
-- عبر Trigger يفحص الفواتير غير الملغاة فقط.
DROP INDEX IF EXISTS ux_item_single_sale;

CREATE OR REPLACE FUNCTION prevent_double_sale() RETURNS trigger AS $$
DECLARE v_count int;
BEGIN
  SELECT count(*) INTO v_count
    FROM sale_items si
    JOIN sales s ON s.id = si.sale_id
   WHERE si.item_id = NEW.item_id
     AND s.status <> 'VOIDED'
     AND si.id <> COALESCE(NEW.id, -1);

  IF v_count > 0 THEN
    RAISE EXCEPTION 'هذه القطعة مباعة بالفعل في فاتورة سارية ولا يمكن بيعها مرة أخرى.';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_prevent_double_sale ON sale_items;
CREATE TRIGGER trg_prevent_double_sale
  BEFORE INSERT OR UPDATE ON sale_items
  FOR EACH ROW EXECUTE FUNCTION prevent_double_sale();

-- ---------------------------------------------------------------------
-- 3) ★ منع تعارض الحجز والتأجير زمنيًا لنفس القطعة
--    القطعة قد تكون متاحة اليوم لكنها محجوزة لتاريخ لاحق.
--    الرفض يأتي من القاعدة نفسها حتى مع طلبين متزامنين.
-- ---------------------------------------------------------------------
ALTER TABLE item_bookings DROP CONSTRAINT IF EXISTS ex_item_booking_overlap;
ALTER TABLE item_bookings
  ADD CONSTRAINT ex_item_booking_overlap
  EXCLUDE USING gist (
    item_id WITH =,
    daterange(start_date, end_date, '[]') WITH &&
  ) WHERE (is_active);

ALTER TABLE item_bookings DROP CONSTRAINT IF EXISTS ck_booking_dates;
ALTER TABLE item_bookings
  ADD CONSTRAINT ck_booking_dates CHECK (end_date >= start_date);

-- ---------------------------------------------------------------------
-- 4) صحة التواريخ
-- ---------------------------------------------------------------------
ALTER TABLE rentals DROP CONSTRAINT IF EXISTS ck_rental_dates;
ALTER TABLE rentals
  ADD CONSTRAINT ck_rental_dates CHECK (expected_return_date >= rental_date);

ALTER TABLE reservations DROP CONSTRAINT IF EXISTS ck_reservation_dates;
ALTER TABLE reservations
  ADD CONSTRAINT ck_reservation_dates CHECK (return_date >= pickup_date);

-- ---------------------------------------------------------------------
-- 5) صحة المبالغ
-- ---------------------------------------------------------------------
ALTER TABLE payments DROP CONSTRAINT IF EXISTS ck_payment_amount_positive;
ALTER TABLE payments
  ADD CONSTRAINT ck_payment_amount_positive CHECK (amount > 0);

ALTER TABLE rentals DROP CONSTRAINT IF EXISTS ck_rental_amounts;
ALTER TABLE rentals
  ADD CONSTRAINT ck_rental_amounts CHECK (
    discount >= 0
    AND discount <= subtotal
    AND net_amount = subtotal - discount
    AND vat_amount >= 0
    AND gross_amount = net_amount + vat_amount
    AND extra_charges >= 0
    AND total_due = gross_amount + extra_charges
    AND paid_amount >= 0
    AND remaining_amount = total_due - paid_amount
    AND insurance_amount >= 0
  );

ALTER TABLE sales DROP CONSTRAINT IF EXISTS ck_sale_amounts;
ALTER TABLE sales
  ADD CONSTRAINT ck_sale_amounts CHECK (
    discount >= 0
    AND discount <= subtotal
    AND net_amount = subtotal - discount
    AND vat_amount >= 0
    AND gross_amount = net_amount + vat_amount
  );

-- البيع يُدفع بالكامل قبل إتمامه
ALTER TABLE sales DROP CONSTRAINT IF EXISTS ck_sale_fully_paid;
ALTER TABLE sales
  ADD CONSTRAINT ck_sale_fully_paid CHECK (
    status = 'VOIDED' OR paid_amount = gross_amount
  );

-- ---------------------------------------------------------------------
-- 6) ★ ضريبة القيمة المضافة
--    ما دامت الحالة NOT_APPLICABLE فلا نسبة ولا مبلغ — يستحيل
--    تسجيل ضريبة على مستند غير خاضع لها حتى بخطأ برمجي.
-- ---------------------------------------------------------------------
DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['rentals','sales','rental_items','sale_items'] LOOP
    EXECUTE format('ALTER TABLE %I DROP CONSTRAINT IF EXISTS ck_vat_consistency;', t);
    EXECUTE format($f$
      ALTER TABLE %I ADD CONSTRAINT ck_vat_consistency CHECK (
        (vat_status = 'NOT_APPLICABLE' AND vat_rate IS NULL AND vat_amount = 0)
        OR
        (vat_status <> 'NOT_APPLICABLE' AND vat_rate IS NOT NULL
         AND vat_rate >= 0 AND vat_rate <= 100 AND vat_amount >= 0)
      );$f$, t);
  END LOOP;
END $$;

-- ---------------------------------------------------------------------
-- 7) ★ التأمين: أموال العملاء لا تختلط بإيرادات المحل
--    رصيد صندوق التأمين لا يجوز أن يصبح سالبًا،
--    والتحويل إلى المحل يتطلب اعتمادًا وسببًا.
-- ---------------------------------------------------------------------
ALTER TABLE insurance_transactions DROP CONSTRAINT IF EXISTS ck_insurance_amount;
ALTER TABLE insurance_transactions
  ADD CONSTRAINT ck_insurance_amount CHECK (amount > 0 AND balance_after >= 0);

ALTER TABLE insurance_transactions DROP CONSTRAINT IF EXISTS ck_insurance_approval;
ALTER TABLE insurance_transactions
  ADD CONSTRAINT ck_insurance_approval CHECK (
    type <> 'TRANSFERRED_TO_COMPANY'
    OR (approved_by IS NOT NULL AND reason IS NOT NULL)
  );

-- مدفوعة التأمين لا تكون إلا لغرض تأميني، والعكس صحيح
ALTER TABLE payments DROP CONSTRAINT IF EXISTS ck_payment_insurance_purpose;
ALTER TABLE payments
  ADD CONSTRAINT ck_payment_insurance_purpose CHECK (
    (is_insurance = true  AND purpose IN ('INSURANCE_COLLECT','INSURANCE_REFUND'))
    OR
    (is_insurance = false AND purpose NOT IN ('INSURANCE_COLLECT','INSURANCE_REFUND'))
  );

-- ---------------------------------------------------------------------
-- 8) الإرجاع: الرسوم والتأمين المستخدم قيم موجبة
-- ---------------------------------------------------------------------
ALTER TABLE return_items DROP CONSTRAINT IF EXISTS ck_return_amounts;
ALTER TABLE return_items
  ADD CONSTRAINT ck_return_amounts CHECK (
    days_late >= 0 AND late_fee >= 0 AND damage_fee >= 0 AND loss_fee >= 0
    AND insurance_used >= 0 AND insurance_refunded >= 0
    AND extra_due_from_customer >= 0
  );

-- ---------------------------------------------------------------------
-- 8ب) ★ المخزون: آلة حالة القطعة مطبَّقة داخل قاعدة البيانات
--      أي انتقال غير مسموح يُرفض حتى لو تجاوز أحدهم طبقة الخدمة.
-- ---------------------------------------------------------------------
ALTER TABLE product_items DROP CONSTRAINT IF EXISTS ck_item_costs;
ALTER TABLE product_items
  ADD CONSTRAINT ck_item_costs CHECK (
    purchase_cost >= 0
    AND (rental_price IS NULL OR rental_price >= 0)
    AND (sale_price IS NULL OR sale_price >= 0)
    AND rental_count >= 0
    AND total_rental_revenue >= 0
    AND total_fees_revenue >= 0
    AND total_maintenance_cost >= 0
  );

CREATE OR REPLACE FUNCTION assert_item_transition() RETURNS trigger AS $$
DECLARE
  allowed text[];
BEGIN
  IF NEW.status = OLD.status THEN
    -- إعادة ضبط نفس الحالة التشغيلية تعني عملية مكررة على قطعة مشغولة
    IF NEW.status::text IN ('RENTED','SOLD','RESERVED') THEN
      RAISE EXCEPTION 'القطعة بالفعل في حالة % — العملية مكررة.', NEW.status;
    END IF;
    RETURN NEW;
  END IF;

  -- ★ الاستثناء الوحيد للخروج من "مباعة": فاتورة البيع أُلغيت فعلًا.
  -- الشرط مبني على حالة البيانات نفسها، لا على عَلَم يمكن ضبطه من الجلسة.
  -- ويُشترط أن تكون الحالة الجديدة مطابقة تمامًا للحالة المحفوظة قبل البيع.
  IF OLD.status::text = 'SOLD' AND sold_exit_is_authorized(OLD.id, NEW.status::text) THEN
    RETURN NEW;
  END IF;

  allowed := CASE OLD.status::text
    WHEN 'AVAILABLE'   THEN ARRAY['RENTED','RESERVED','SOLD','CLEANING','MAINTENANCE','DAMAGED','LOST','DISPOSED']
    WHEN 'RESERVED'    THEN ARRAY['RENTED','AVAILABLE','CLEANING','MAINTENANCE']
    WHEN 'RENTED'      THEN ARRAY['AVAILABLE','OVERDUE','CLEANING','DAMAGED','LOST']
    WHEN 'OVERDUE'     THEN ARRAY['AVAILABLE','CLEANING','DAMAGED','LOST']
    WHEN 'CLEANING'    THEN ARRAY['AVAILABLE','DAMAGED','MAINTENANCE']
    WHEN 'MAINTENANCE' THEN ARRAY['AVAILABLE','CLEANING','DAMAGED','SOLD','DISPOSED']
    -- 'RENTED' مسار عكس إرجاع سُجِّل بالخطأ فقط (القطعة ما زالت مع العميل)
    WHEN 'DAMAGED'     THEN ARRAY['MAINTENANCE','SOLD','DISPOSED','RENTED']
    WHEN 'LOST'        THEN ARRAY['AVAILABLE','MAINTENANCE','DISPOSED','RENTED']
    ELSE ARRAY[]::text[]   -- SOLD و DISPOSED حالتان نهائيتان
  END;

  IF NOT (NEW.status::text = ANY(allowed)) THEN
    RAISE EXCEPTION 'انتقال حالة غير مسموح للقطعة %: من % إلى %',
      OLD.item_code, OLD.status, NEW.status;
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_item_transition ON product_items;
CREATE TRIGGER trg_item_transition
  BEFORE UPDATE OF status ON product_items
  FOR EACH ROW EXECUTE FUNCTION assert_item_transition();

-- كل تغيير حالة يجب أن يترك أثرًا في سجل الحالات
ALTER TABLE item_status_history DROP CONSTRAINT IF EXISTS ck_status_history_reason;
ALTER TABLE item_status_history
  ADD CONSTRAINT ck_status_history_reason CHECK (
    from_status = to_status OR reason IS NOT NULL
  );

-- ---------------------------------------------------------------------
-- 9) العميل النقدي وحيد لا يتكرر
-- ---------------------------------------------------------------------
DROP INDEX IF EXISTS ux_single_walkin_customer;
CREATE UNIQUE INDEX ux_single_walkin_customer
  ON customers ((is_walk_in)) WHERE is_walk_in = true;

-- ---------------------------------------------------------------------
-- 10) منع الحذف النهائي للعمليات — الإلغاء يتم بـ Void فقط
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION prevent_hard_delete() RETURNS trigger AS $$
BEGIN
  RAISE EXCEPTION 'الحذف النهائي غير مسموح لهذا السجل. استخدم الإلغاء (Void).';
END;
$$ LANGUAGE plpgsql;

DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY[
    'payments','insurance_transactions','rentals','sales',
    'returns','expenses','audit_logs'
  ] LOOP
    EXECUTE format('DROP TRIGGER IF EXISTS trg_no_delete ON %I;', t);
    EXECUTE format(
      'CREATE TRIGGER trg_no_delete BEFORE DELETE ON %I
       FOR EACH ROW EXECUTE FUNCTION prevent_hard_delete();', t);
  END LOOP;
END $$;

-- =====================================================================
-- M1 — قيود المخزون
-- =====================================================================

-- ---------------------------------------------------------------------
-- 11) الأسعار والتكاليف لا تكون سالبة
-- ---------------------------------------------------------------------
ALTER TABLE products DROP CONSTRAINT IF EXISTS ck_product_amounts;
ALTER TABLE products
  ADD CONSTRAINT ck_product_amounts CHECK (
    sale_price >= 0 AND rental_price >= 0 AND default_cost >= 0
  );

ALTER TABLE product_items DROP CONSTRAINT IF EXISTS ck_item_amounts;
ALTER TABLE product_items
  ADD CONSTRAINT ck_item_amounts CHECK (
    purchase_cost >= 0
    AND (rental_price IS NULL OR rental_price >= 0)
    AND (sale_price IS NULL OR sale_price >= 0)
    AND rental_count >= 0
    AND total_rental_revenue >= 0
    AND total_fees_revenue >= 0
    AND total_maintenance_cost >= 0
  );

-- ---------------------------------------------------------------------
-- 12) آلة حالة القطعة — معرّفة مرة واحدة فقط
-- ---------------------------------------------------------------------
-- ملاحظة: آلة حالة القطعة معرّفة مرة واحدة فقط أعلاه في assert_item_transition().
-- (أُزيلت نسخة مكرّرة كانت تحمل مصفوفة انتقالات مختلفة — مصدر تضارب.)

-- ---------------------------------------------------------------------
-- 13) لا تأجير ولا بيع لقطعة غير مؤهلة — فحص عند إنشاء سطر العملية
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION enforce_item_rentable() RETURNS trigger AS $$
DECLARE s text;
BEGIN
  SELECT status::text INTO s FROM product_items WHERE id = NEW.item_id;
  IF s IS NULL THEN
    RAISE EXCEPTION 'القطعة غير موجودة.';
  END IF;
  IF s <> 'AVAILABLE' AND s <> 'RESERVED' THEN
    RAISE EXCEPTION 'لا يمكن تأجير قطعة حالتها %', s;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_item_rentable ON rental_items;
CREATE TRIGGER trg_item_rentable
  BEFORE INSERT ON rental_items
  FOR EACH ROW EXECUTE FUNCTION enforce_item_rentable();

CREATE OR REPLACE FUNCTION enforce_item_sellable() RETURNS trigger AS $$
DECLARE s text;
BEGIN
  SELECT status::text INTO s FROM product_items WHERE id = NEW.item_id;
  IF s IS NULL THEN
    RAISE EXCEPTION 'القطعة غير موجودة.';
  END IF;
  IF s NOT IN ('AVAILABLE', 'DAMAGED', 'MAINTENANCE') THEN
    RAISE EXCEPTION 'لا يمكن بيع قطعة حالتها %', s;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_item_sellable ON sale_items;
CREATE TRIGGER trg_item_sellable
  BEFORE INSERT ON sale_items
  FOR EACH ROW EXECUTE FUNCTION enforce_item_sellable();

-- ---------------------------------------------------------------------
-- 14) سجل حالة القطعة لا يُحذف — تاريخ القطعة كامل ودائم
-- ---------------------------------------------------------------------
DROP TRIGGER IF EXISTS trg_no_delete ON item_status_history;
CREATE TRIGGER trg_no_delete BEFORE DELETE ON item_status_history
  FOR EACH ROW EXECUTE FUNCTION prevent_hard_delete();

DROP TRIGGER IF EXISTS trg_no_delete ON inventory_transactions;
CREATE TRIGGER trg_no_delete BEFORE DELETE ON inventory_transactions
  FOR EACH ROW EXECUTE FUNCTION prevent_hard_delete();

-- =====================================================================
-- M2 — قيود العملاء
-- =====================================================================

-- ---------------------------------------------------------------------
-- 15) رقم الجوال مخزَّن بصيغة موحّدة: 11 رقمًا يبدأ بـ 01
--     العميل النقدي وحده بلا رقم.
-- ---------------------------------------------------------------------
ALTER TABLE customers DROP CONSTRAINT IF EXISTS ck_customer_phone_format;
ALTER TABLE customers
  ADD CONSTRAINT ck_customer_phone_format CHECK (
    phone IS NULL OR phone ~ '^01[0125][0-9]{8}$'
  );

ALTER TABLE customers DROP CONSTRAINT IF EXISTS ck_customer_national_id;
ALTER TABLE customers
  ADD CONSTRAINT ck_customer_national_id CHECK (
    national_id IS NULL OR national_id ~ '^[0-9]{14}$'
  );

-- كل عميل عادي له رقم جوال — بدونه لا يمكن الوصول إليه ولا تتبّع تعاملاته
ALTER TABLE customers DROP CONSTRAINT IF EXISTS ck_customer_phone_required;
ALTER TABLE customers
  ADD CONSTRAINT ck_customer_phone_required CHECK (
    is_walk_in = true OR phone IS NOT NULL
  );

-- ---------------------------------------------------------------------
-- 16) العميل النقدي سجل نظامي: لا يُحذف ولا يُعطَّل
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION protect_walkin_customer() RETURNS trigger AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    IF OLD.is_walk_in THEN
      RAISE EXCEPTION 'العميل النقدي سجل ثابت في النظام ولا يمكن حذفه.';
    END IF;
    RETURN OLD;
  END IF;

  IF OLD.is_walk_in AND (NEW.is_active = false OR NEW.is_walk_in = false) THEN
    RAISE EXCEPTION 'العميل النقدي سجل ثابت في النظام ولا يمكن تعطيله.';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_protect_walkin ON customers;
CREATE TRIGGER trg_protect_walkin
  BEFORE UPDATE OR DELETE ON customers
  FOR EACH ROW EXECUTE FUNCTION protect_walkin_customer();

-- =====================================================================
-- M3 — قيود التأجير
-- =====================================================================

-- ---------------------------------------------------------------------
-- 17) ★ مزامنة المدفوع والمتبقي من الدفعات نفسها
--     لا يُحدَّثان بالكود إطلاقًا — تُحسبان من مجموع الدفعات غير الملغاة
--     وغير التأمينية. هذا يمنع أي انحراف بين العقد ودفعاته.
--     مبالغ التأمين مستبعدة تمامًا: لا تدخل المدفوع ولا تنقص المتبقي.
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION sync_rental_payment_totals() RETURNS trigger AS $$
DECLARE
  v_rental int := COALESCE(NEW.rental_id, OLD.rental_id);
  v_paid numeric(12,2);
BEGIN
  IF v_rental IS NULL THEN RETURN NULL; END IF;

  -- ★ قفل صف العقد قبل الحساب: يمنع سباق دفعتين متزامنتين على نفس العقد.
  -- بدونه تقرأ كل معاملة مجموعًا لا يرى دفعة الأخرى غير المعتمدة، فتمر
  -- الدفعتان معًا ويتجاوز المحصَّل قيمة العقد.
  PERFORM 1 FROM rentals WHERE id = v_rental FOR UPDATE;

  SELECT COALESCE(SUM(amount), 0) INTO v_paid
    FROM payments
   WHERE rental_id = v_rental
     AND is_voided = false
     AND is_insurance = false      -- ★ التأمين ليس دفعة على العقد
     AND direction = 'IN';

  UPDATE rentals
     SET paid_amount = v_paid,
         remaining_amount = total_due - v_paid
   WHERE id = v_rental;

  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_sync_rental_totals ON payments;
CREATE TRIGGER trg_sync_rental_totals
  AFTER INSERT OR UPDATE OR DELETE ON payments
  FOR EACH ROW EXECUTE FUNCTION sync_rental_payment_totals();

-- ---------------------------------------------------------------------
-- 18) العقد المغلق أو الملغى سجل تاريخي لا يُمس
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION protect_final_rental() RETURNS trigger AS $$
BEGIN
  -- العقد الملغى نهائي تمامًا
  IF OLD.status = 'VOIDED' AND NEW.status <> OLD.status THEN
    RAISE EXCEPTION 'العقد ملغى ولا يقبل أي تغيير في حالته.';
  END IF;
  -- العقد المغلق يُعاد فتحه فقط لحالة تشغيلية (عند إلغاء إرجاع)، ولا يُلغى
  IF OLD.status = 'CLOSED' AND NEW.status = 'VOIDED' THEN
    RAISE EXCEPTION 'لا يمكن إلغاء عقد مغلق — ألغِ عمليات الإرجاع أولًا.';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_protect_final_rental ON rentals;
CREATE TRIGGER trg_protect_final_rental
  BEFORE UPDATE ON rentals
  FOR EACH ROW EXECUTE FUNCTION protect_final_rental();

-- ---------------------------------------------------------------------
-- 19) العربون جزء من المدفوع ولا يتجاوز إجمالي العقد
-- ---------------------------------------------------------------------
ALTER TABLE rentals DROP CONSTRAINT IF EXISTS ck_rental_deposit;
ALTER TABLE rentals
  ADD CONSTRAINT ck_rental_deposit CHECK (
    deposit_amount >= 0 AND deposit_amount <= total_due
  );

-- ---------------------------------------------------------------------
-- 19ب) ★ منع السداد الزائد على العقد
--      المدفوع لا يتجاوز المستحق، والمتبقي لا يصبح سالبًا.
-- ---------------------------------------------------------------------
ALTER TABLE rentals DROP CONSTRAINT IF EXISTS ck_rental_no_overpay;
ALTER TABLE rentals
  ADD CONSTRAINT ck_rental_no_overpay CHECK (
    paid_amount <= total_due AND remaining_amount >= 0
  );

-- ---------------------------------------------------------------------
-- 20) دفعة مرتبطة بعقد لا تكون بمبلغ صفر أو سالب، ولها طريقة دفع
-- ---------------------------------------------------------------------
ALTER TABLE payments DROP CONSTRAINT IF EXISTS ck_payment_rental_link;
ALTER TABLE payments
  ADD CONSTRAINT ck_payment_rental_link CHECK (
    purpose <> 'RENTAL' OR rental_id IS NOT NULL
  );

-- =====================================================================
-- M4 — قيود الإرجاع
-- =====================================================================

-- ---------------------------------------------------------------------
-- 21) ★ منع الإرجاع المزدوج: سطر إرجاع واحد غير ملغى لكل سطر عقد
-- ---------------------------------------------------------------------
-- ملاحظة: لا يمكن استخدام استعلام فرعي في شرط الفهرس في PostgreSQL،
-- لذا يُنفَّذ المنع عبر Trigger يفحص الإرجاعات غير الملغاة.
CREATE OR REPLACE FUNCTION prevent_double_return() RETURNS trigger AS $$
DECLARE v_count int;
BEGIN
  SELECT count(*) INTO v_count
    FROM return_items ri
    JOIN returns r ON r.id = ri.return_id
   WHERE ri.rental_item_id = NEW.rental_item_id
     AND r.is_voided = false
     AND ri.id <> COALESCE(NEW.id, -1);

  IF v_count > 0 THEN
    RAISE EXCEPTION 'هذه القطعة أُرجعت بالفعل في هذا العقد ولا يمكن إرجاعها مرة أخرى.';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_prevent_double_return ON return_items;
CREATE TRIGGER trg_prevent_double_return
  BEFORE INSERT OR UPDATE ON return_items
  FOR EACH ROW EXECUTE FUNCTION prevent_double_return();

-- ---------------------------------------------------------------------
-- 22) ★ معادلة تسوية الإرجاع — الحارس ضد ازدواج الإيراد أو تسريب التأمين
--     التأمين المستخدم + المستحق الإضافي = مجموع الغرامات
-- ---------------------------------------------------------------------
ALTER TABLE return_items DROP CONSTRAINT IF EXISTS ck_return_settlement;
ALTER TABLE return_items
  ADD CONSTRAINT ck_return_settlement CHECK (
    insurance_used + extra_due_from_customer = late_fee + damage_fee + loss_fee
  );

-- ---------------------------------------------------------------------
-- 23) اتساق حالة القطعة مع المبالغ المسجّلة
-- ---------------------------------------------------------------------
ALTER TABLE return_items DROP CONSTRAINT IF EXISTS ck_return_condition_amounts;
ALTER TABLE return_items
  ADD CONSTRAINT ck_return_condition_amounts CHECK (
    (condition = 'GOOD'    AND damage_fee = 0 AND loss_fee = 0)
    OR
    (condition = 'DAMAGED' AND damage_fee > 0 AND loss_fee = 0)
    OR
    (condition = 'LOST'    AND loss_fee > 0   AND damage_fee = 0)
  );

-- ---------------------------------------------------------------------
-- 24) الإرجاع الملغى سجل تاريخي لا يُعاد تفعيله
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION protect_voided_return() RETURNS trigger AS $$
BEGIN
  IF OLD.is_voided = true AND NEW.is_voided = false THEN
    RAISE EXCEPTION 'عملية الإرجاع ملغاة ولا يمكن إعادة تفعيلها.';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_protect_voided_return ON returns;
CREATE TRIGGER trg_protect_voided_return
  BEFORE UPDATE ON returns
  FOR EACH ROW EXECUTE FUNCTION protect_voided_return();

-- ---------------------------------------------------------------------
-- 25) سطور الإرجاع لا تُحذف
-- ---------------------------------------------------------------------
DROP TRIGGER IF EXISTS trg_no_delete ON return_items;
CREATE TRIGGER trg_no_delete BEFORE DELETE ON return_items
  FOR EACH ROW EXECUTE FUNCTION prevent_hard_delete();

-- =====================================================================
-- M5 — قيود البيع
-- =====================================================================

-- ---------------------------------------------------------------------
-- 25) ★ الخروج من حالة "مباعة" مسموح فقط إذا كانت آخر فاتورة للقطعة ملغاة
--     والحالة المستعادة مطابقة للحالة المحفوظة قبل البيع.
--     لا يعتمد على أي عَلَم جلسة أو إعداد قابل للضبط من الخارج.
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION sold_exit_is_authorized(p_item int, p_new_status text)
RETURNS boolean AS $$
DECLARE v_pre text; v_sale_status text;
BEGIN
  SELECT si.pre_sale_status::text, s.status::text
    INTO v_pre, v_sale_status
    FROM sale_items si
    JOIN sales s ON s.id = si.sale_id
   WHERE si.item_id = p_item
   ORDER BY si.id DESC
   LIMIT 1;

  IF v_pre IS NULL THEN RETURN false; END IF;              -- لا فاتورة أصلًا
  IF v_sale_status <> 'VOIDED' THEN RETURN false; END IF;  -- الفاتورة سارية
  RETURN p_new_status = v_pre;                             -- الحالة المستعادة مطابقة
END;
$$ LANGUAGE plpgsql STABLE;

CREATE OR REPLACE FUNCTION enforce_sold_exit() RETURNS trigger AS $$
BEGIN
  IF OLD.status = 'SOLD' AND NEW.status <> 'SOLD' THEN
    IF NOT sold_exit_is_authorized(OLD.id, NEW.status::text) THEN
      RAISE EXCEPTION 'القطعة مباعة — لا تعود إلى المخزون إلا بإلغاء فاتورة بيعها، وإلى حالتها السابقة فقط.';
    END IF;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_sold_exit ON product_items;
CREATE TRIGGER trg_sold_exit
  BEFORE UPDATE OF status ON product_items
  FOR EACH ROW EXECUTE FUNCTION enforce_sold_exit();

-- ---------------------------------------------------------------------
-- 26) الحالة المحفوظة قبل البيع يجب أن تكون حالة قابلة للبيع أصلًا
-- ---------------------------------------------------------------------
ALTER TABLE sale_items DROP CONSTRAINT IF EXISTS ck_sale_pre_status;
ALTER TABLE sale_items
  ADD CONSTRAINT ck_sale_pre_status CHECK (
    pre_sale_status IN ('AVAILABLE','DAMAGED','MAINTENANCE')
  );

-- ---------------------------------------------------------------------
-- 27) اتساق سطر البيع: الصافي = السعر − الخصم، ولا قيم سالبة
-- ---------------------------------------------------------------------
ALTER TABLE sale_items DROP CONSTRAINT IF EXISTS ck_sale_item_amounts;
ALTER TABLE sale_items
  ADD CONSTRAINT ck_sale_item_amounts CHECK (
    unit_price >= 0 AND discount >= 0 AND discount <= unit_price
    AND net_price = unit_price - discount
    AND purchase_cost >= 0
    AND gross_amount = net_price + vat_amount
  );

-- ---------------------------------------------------------------------
-- 28) تكلفة الفاتورة = مجموع تكاليف سطورها (تُفحص عند نهاية المعاملة)
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION assert_sale_cost_matches() RETURNS trigger AS $$
DECLARE v_sale int := COALESCE(NEW.sale_id, OLD.sale_id); v_sum numeric; v_head numeric;
BEGIN
  SELECT COALESCE(SUM(purchase_cost),0) INTO v_sum FROM sale_items WHERE sale_id = v_sale;
  SELECT total_cost INTO v_head FROM sales WHERE id = v_sale;
  IF v_head IS NOT NULL AND v_head <> v_sum THEN
    RAISE EXCEPTION 'تكلفة الفاتورة % لا تطابق مجموع تكاليف سطورها %', v_head, v_sum;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_sale_cost_matches ON sale_items;
CREATE CONSTRAINT TRIGGER trg_sale_cost_matches
  AFTER INSERT OR UPDATE OR DELETE ON sale_items
  DEFERRABLE INITIALLY DEFERRED
  FOR EACH ROW EXECUTE FUNCTION assert_sale_cost_matches();

-- ---------------------------------------------------------------------
-- 29) الفاتورة الملغاة سجل تاريخي لا يُعاد تفعيله
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION protect_voided_sale() RETURNS trigger AS $$
BEGIN
  IF OLD.status = 'VOIDED' AND NEW.status <> 'VOIDED' THEN
    RAISE EXCEPTION 'الفاتورة ملغاة ولا يمكن إعادة تفعيلها.';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_protect_voided_sale ON sales;
CREATE TRIGGER trg_protect_voided_sale
  BEFORE UPDATE ON sales
  FOR EACH ROW EXECUTE FUNCTION protect_voided_sale();

-- ---------------------------------------------------------------------
-- 30) الفاتورة لا تُحذف — الإلغاء فقط
-- ---------------------------------------------------------------------
DROP TRIGGER IF EXISTS trg_no_delete ON sale_items;
CREATE TRIGGER trg_no_delete BEFORE DELETE ON sale_items
  FOR EACH ROW EXECUTE FUNCTION prevent_hard_delete();

-- =====================================================================
-- M6 — قيود المدفوعات والمصروفات والموظفين
-- =====================================================================

-- ---------------------------------------------------------------------
-- 31) المصروف مبلغ موجب ولا يكون بتاريخ مستقبلي
-- ---------------------------------------------------------------------
ALTER TABLE expenses DROP CONSTRAINT IF EXISTS ck_expense_amount;
ALTER TABLE expenses ADD CONSTRAINT ck_expense_amount CHECK (amount > 0);

ALTER TABLE expenses DROP CONSTRAINT IF EXISTS ck_expense_date;
ALTER TABLE expenses ADD CONSTRAINT ck_expense_date CHECK (expense_date <= CURRENT_DATE);

-- ---------------------------------------------------------------------
-- 32) المصروف الملغى والدفعة الملغاة سجلّان تاريخيان لا يُعادان
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION protect_voided_record() RETURNS trigger AS $$
BEGIN
  IF OLD.is_voided = true AND NEW.is_voided = false THEN
    RAISE EXCEPTION 'السجل ملغى ولا يمكن إعادة تفعيله.';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_protect_voided_expense ON expenses;
CREATE TRIGGER trg_protect_voided_expense
  BEFORE UPDATE ON expenses
  FOR EACH ROW EXECUTE FUNCTION protect_voided_record();

DROP TRIGGER IF EXISTS trg_protect_voided_payment ON payments;
CREATE TRIGGER trg_protect_voided_payment
  BEFORE UPDATE ON payments
  FOR EACH ROW EXECUTE FUNCTION protect_voided_record();

-- ---------------------------------------------------------------------
-- 33) العمولة: النسب بين 0 و100 والمبالغ غير سالبة
-- ---------------------------------------------------------------------
ALTER TABLE commissions DROP CONSTRAINT IF EXISTS ck_commission_amounts;
ALTER TABLE commissions
  ADD CONSTRAINT ck_commission_amounts CHECK (
    rental_rate_pct >= 0 AND rental_rate_pct <= 100
    AND sales_rate_pct >= 0 AND sales_rate_pct <= 100
    AND rental_base >= 0 AND sales_base >= 0 AND commission_amount >= 0
  );

ALTER TABLE employees DROP CONSTRAINT IF EXISTS ck_employee_rates;
ALTER TABLE employees
  ADD CONSTRAINT ck_employee_rates CHECK (
    monthly_salary >= 0
    AND rental_commission_pct >= 0 AND rental_commission_pct <= 100
    AND sales_commission_pct >= 0 AND sales_commission_pct <= 100
  );

-- ---------------------------------------------------------------------
-- 34) ★ منع صرف العمولة مرتين: مصروف واحد لكل سجل عمولة والعكس
-- ---------------------------------------------------------------------
DROP INDEX IF EXISTS ux_commission_paid_expense;
CREATE UNIQUE INDEX ux_commission_paid_expense
  ON commissions (paid_expense_id) WHERE paid_expense_id IS NOT NULL;

ALTER TABLE commissions DROP CONSTRAINT IF EXISTS ck_commission_paid_link;
ALTER TABLE commissions
  ADD CONSTRAINT ck_commission_paid_link CHECK (
    (status = 'PAID' AND paid_expense_id IS NOT NULL)
    OR (status = 'ACCRUED' AND paid_expense_id IS NULL)
  );

-- ---------------------------------------------------------------------
-- 35) المصروفات لا تُحذف
-- ---------------------------------------------------------------------
DROP TRIGGER IF EXISTS trg_no_delete ON commissions;
CREATE TRIGGER trg_no_delete BEFORE DELETE ON commissions
  FOR EACH ROW EXECUTE FUNCTION prevent_hard_delete();

-- =====================================================================
-- النقدية اليومية · السلف · الرد
-- لا رصيد افتتاحي · مركز الشركة مشتق · التأمين رصيد لا حركة
-- =====================================================================

-- ---------------------------------------------------------------------
-- C1) الجرد: الفرق محسوب لا مُدخَل، ولا مبالغ سالبة
-- ---------------------------------------------------------------------
ALTER TABLE daily_cash_closings DROP CONSTRAINT IF EXISTS ck_closing_amounts;
ALTER TABLE daily_cash_closings
  ADD CONSTRAINT ck_closing_amounts CHECK (
    expected_insurance_cash >= 0
    AND actual_counted >= 0
    AND expected_physical = expected_company_position + expected_insurance_cash
    AND variance = actual_counted - expected_physical
  );

-- الإغلاق يستلزم جردًا مكتملًا
ALTER TABLE daily_cash_closings DROP CONSTRAINT IF EXISTS ck_closing_requires_count;
ALTER TABLE daily_cash_closings
  ADD CONSTRAINT ck_closing_requires_count CHECK (
    status = 'OPEN' OR (counted_by IS NOT NULL AND counted_at IS NOT NULL)
  );

-- ---------------------------------------------------------------------
-- C2) ★ اليوم المغلق نهائي، ولا يُعاد فتحه، ولا يُعدَّل جرده
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION protect_closed_day() RETURNS trigger AS $$
BEGIN
  IF OLD.status = 'CLOSED' THEN
    IF NEW.status <> 'CLOSED' THEN
      RAISE EXCEPTION 'اليوم مغلق ولا يمكن إعادة فتحه.';
    END IF;
    IF NEW.actual_counted <> OLD.actual_counted
       OR NEW.variance <> OLD.variance
       OR NEW.expected_physical <> OLD.expected_physical THEN
      RAISE EXCEPTION 'لا يمكن تعديل جرد يوم مغلق. استخدم التصحيح النظامي بيوم مفتوح.';
    END IF;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_protect_closed_day ON daily_cash_closings;
CREATE TRIGGER trg_protect_closed_day
  BEFORE UPDATE ON daily_cash_closings
  FOR EACH ROW EXECUTE FUNCTION protect_closed_day();

-- ---------------------------------------------------------------------
-- C3) ★ منع أي حركة مالية بتاريخ يوم مغلق — حارس سلامة الجرد
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION assert_day_not_closed() RETURNS trigger AS $$
DECLARE
  v_date   date;
  v_status text;
BEGIN
  -- ملاحظة: PL/pgSQL يحلّ مراجع NEW.<field> وقت الترجمة لا وقت التنفيذ،
  -- فلا يصلح CASE على TG_TABLE_NAME. نقرأ العمود ديناميكيًا عبر to_jsonb
  -- واسم العمود يُمرَّر في TG_ARGV.
  v_date := (to_jsonb(NEW) ->> TG_ARGV[0])::date;
  IF v_date IS NULL THEN RETURN NEW; END IF;

  SELECT status::text INTO v_status
    FROM daily_cash_closings WHERE business_date = v_date;

  IF v_status = 'CLOSED' THEN
    RAISE EXCEPTION 'اليوم % مغلق: لا يمكن تسجيل أو تعديل حركة مالية بتاريخه.', v_date;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DO $$
DECLARE r record;
BEGIN
  FOR r IN SELECT * FROM (VALUES
      ('payments','payment_date'),
      ('expenses','expense_date'),
      ('insurance_transactions','trx_date'),
      ('employee_advances','advance_date'),
      ('employee_advance_repayments','repayment_date')
    ) AS t(tbl, col)
  LOOP
    EXECUTE format('DROP TRIGGER IF EXISTS trg_day_not_closed ON %I;', r.tbl);
    EXECUTE format(
      'CREATE TRIGGER trg_day_not_closed BEFORE INSERT OR UPDATE ON %I
       FOR EACH ROW EXECUTE FUNCTION assert_day_not_closed(%L);', r.tbl, r.col);
  END LOOP;
END $$;

-- ---------------------------------------------------------------------
-- C4) الترحيل: كامل إلزاميًا، بعد الإغلاق فقط، ولا يمس الفرق
-- ---------------------------------------------------------------------
ALTER TABLE cash_transfers DROP CONSTRAINT IF EXISTS ck_transfer_amount;
ALTER TABLE cash_transfers
  ADD CONSTRAINT ck_transfer_amount CHECK (amount >= 0);

CREATE OR REPLACE FUNCTION assert_full_transfer() RETURNS trigger AS $$
DECLARE
  v_status text; v_actual numeric(12,2); v_insurance numeric(12,2); v_required numeric(12,2);
BEGIN
  SELECT status::text, actual_counted, expected_insurance_cash
    INTO v_status, v_actual, v_insurance
    FROM daily_cash_closings WHERE id = NEW.closing_id;

  IF v_status IS NULL THEN
    RAISE EXCEPTION 'لا يمكن الترحيل بلا يوم مرتبط.';
  END IF;
  IF v_status <> 'CLOSED' THEN
    RAISE EXCEPTION 'لا يمكن الترحيل قبل إغلاق اليوم.';
  END IF;

  -- الترحيل الكامل إلزامي: كل كاش الشركة، ولا جنيه من التأمين
  v_required := v_actual - v_insurance;
  IF NEW.amount <> v_required THEN
    RAISE EXCEPTION 'الترحيل الكامل إلزامي: المطلوب % والمدخل %', v_required, NEW.amount;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_full_transfer ON cash_transfers;
CREATE TRIGGER trg_full_transfer
  BEFORE INSERT OR UPDATE ON cash_transfers
  FOR EACH ROW EXECUTE FUNCTION assert_full_transfer();

-- ---------------------------------------------------------------------
-- C5) سلف الموظفين: الرصيد محسوب، ولا سداد يتجاوزه
-- ---------------------------------------------------------------------
ALTER TABLE employee_advances DROP CONSTRAINT IF EXISTS ck_advance_amounts;
ALTER TABLE employee_advances
  ADD CONSTRAINT ck_advance_amounts CHECK (
    amount > 0
    AND repaid_amount >= 0
    AND repaid_amount <= amount
    AND balance = amount - repaid_amount
  );

ALTER TABLE employee_advances DROP CONSTRAINT IF EXISTS ck_advance_status;
ALTER TABLE employee_advances
  ADD CONSTRAINT ck_advance_status CHECK (
    (status = 'SETTLED' AND balance = 0)
    OR (status = 'OPEN' AND balance > 0)
    OR (status = 'CANCELLED' AND cancel_reason IS NOT NULL)
  );

ALTER TABLE employee_advance_repayments DROP CONSTRAINT IF EXISTS ck_repayment_amount;
ALTER TABLE employee_advance_repayments
  ADD CONSTRAINT ck_repayment_amount CHECK (amount > 0);

-- الخصم من الراتب يستلزم مصروف راتب مرتبطًا
ALTER TABLE employee_advance_repayments DROP CONSTRAINT IF EXISTS ck_repayment_salary_link;
ALTER TABLE employee_advance_repayments
  ADD CONSTRAINT ck_repayment_salary_link CHECK (
    method <> 'SALARY_DEDUCTION' OR expense_id IS NOT NULL
  );

-- مزامنة رصيد السلفة من سداداتها — ومنع تجاوز الرصيد
CREATE OR REPLACE FUNCTION sync_advance_balance() RETURNS trigger AS $$
DECLARE
  v_advance int := COALESCE(NEW.advance_id, OLD.advance_id);
  v_amount numeric(12,2); v_repaid numeric(12,2);
BEGIN
  -- قفل السلفة يمنع سباق سدادين متزامنين
  SELECT amount INTO v_amount FROM employee_advances WHERE id = v_advance FOR UPDATE;
  IF v_amount IS NULL THEN RETURN NULL; END IF;

  SELECT COALESCE(SUM(amount), 0) INTO v_repaid
    FROM employee_advance_repayments WHERE advance_id = v_advance;

  IF v_repaid > v_amount THEN
    RAISE EXCEPTION 'السداد يتجاوز رصيد السلفة: المبلغ % والمسدد %', v_amount, v_repaid;
  END IF;

  UPDATE employee_advances
     SET repaid_amount = v_repaid,
         balance = amount - v_repaid,
         status = CASE WHEN amount - v_repaid = 0 THEN 'SETTLED'::"AdvanceStatus" ELSE status END
   WHERE id = v_advance;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_sync_advance_balance ON employee_advance_repayments;
CREATE TRIGGER trg_sync_advance_balance
  AFTER INSERT OR UPDATE OR DELETE ON employee_advance_repayments
  FOR EACH ROW EXECUTE FUNCTION sync_advance_balance();

-- ---------------------------------------------------------------------
-- C6) الراتب مع خصم السلفة: الخروج النقدي لا يتجاوز المصروف
-- ---------------------------------------------------------------------
ALTER TABLE expenses DROP CONSTRAINT IF EXISTS ck_expense_cash_paid;
ALTER TABLE expenses
  ADD CONSTRAINT ck_expense_cash_paid CHECK (
    cash_paid_amount IS NULL
    OR (cash_paid_amount >= 0 AND cash_paid_amount <= amount)
  );

-- ---------------------------------------------------------------------
-- C7) رد العميل: مربوط بعملية ملغاة، وبحد المبلغ القابل للرد
-- ---------------------------------------------------------------------
-- D3: يقبل الرد أيضًا حجزًا ملغى — رد العربون كاملًا عند إلغاء المحل (Q4)
ALTER TABLE payments DROP CONSTRAINT IF EXISTS ck_refund_requires_source;
ALTER TABLE payments
  ADD CONSTRAINT ck_refund_requires_source CHECK (
    purpose <> 'CUSTOMER_REFUND'
    OR rental_id IS NOT NULL OR sale_id IS NOT NULL OR reservation_id IS NOT NULL
  );

CREATE OR REPLACE FUNCTION assert_refund_allowed() RETURNS trigger AS $$
DECLARE
  v_status text; v_collected numeric(12,2); v_refunded numeric(12,2); v_refundable numeric(12,2);
BEGIN
  IF NEW.purpose <> 'CUSTOMER_REFUND' THEN RETURN NEW; END IF;
  IF NEW.direction <> 'OUT' THEN
    RAISE EXCEPTION 'رد العميل يجب أن يكون خروجًا نقديًا.';
  END IF;

  IF NEW.rental_id IS NOT NULL THEN
    SELECT status::text INTO v_status FROM rentals WHERE id = NEW.rental_id FOR UPDATE;
    SELECT COALESCE(SUM(amount),0) INTO v_collected FROM payments
      WHERE rental_id = NEW.rental_id AND direction='IN'
        AND is_insurance=false AND is_voided=false;
    SELECT COALESCE(SUM(amount),0) INTO v_refunded FROM payments
      WHERE rental_id = NEW.rental_id AND direction='OUT'
        AND purpose='CUSTOMER_REFUND' AND is_voided=false
        AND id <> COALESCE(NEW.id, -1);

  ELSIF NEW.sale_id IS NOT NULL THEN
    SELECT status::text INTO v_status FROM sales WHERE id = NEW.sale_id FOR UPDATE;
    SELECT COALESCE(SUM(amount),0) INTO v_collected FROM payments
      WHERE sale_id = NEW.sale_id AND direction='IN'
        AND is_insurance=false AND is_voided=false;
    SELECT COALESCE(SUM(amount),0) INTO v_refunded FROM payments
      WHERE sale_id = NEW.sale_id AND direction='OUT'
        AND purpose='CUSTOMER_REFUND' AND is_voided=false
        AND id <> COALESCE(NEW.id, -1);

  ELSIF NEW.reservation_id IS NOT NULL THEN
    -- D3: رد عربون حجز ملغى — بنفس ضوابط منع التكرار والصرف الزائد
    SELECT status::text INTO v_status FROM reservations WHERE id = NEW.reservation_id FOR UPDATE;
    SELECT COALESCE(SUM(amount),0) INTO v_collected FROM payments
      WHERE reservation_id = NEW.reservation_id AND direction='IN'
        AND is_insurance=false AND is_voided=false;
    SELECT COALESCE(SUM(amount),0) INTO v_refunded FROM payments
      WHERE reservation_id = NEW.reservation_id AND direction='OUT'
        AND purpose='CUSTOMER_REFUND' AND is_voided=false
        AND id <> COALESCE(NEW.id, -1);

  ELSE
    RAISE EXCEPTION 'لا يمكن الرد بلا عملية أصلية.';
  END IF;

  IF v_status IS NULL THEN
    RAISE EXCEPTION 'لا يمكن الرد بلا عملية أصلية.';
  END IF;
  IF v_status <> 'VOIDED' AND v_status <> 'CANCELLED' THEN
    RAISE EXCEPTION 'لا يمكن الرد إلا على عملية ملغاة. حالتها الآن: %', v_status;
  END IF;

  v_refundable := v_collected - v_refunded;
  IF NEW.amount > v_refundable THEN
    RAISE EXCEPTION 'الرد يتجاوز المبلغ القابل للرد: المتاح % والمدخل %', v_refundable, NEW.amount;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_refund_allowed ON payments;
CREATE TRIGGER trg_refund_allowed
  BEFORE INSERT OR UPDATE ON payments
  FOR EACH ROW EXECUTE FUNCTION assert_refund_allowed();

-- ---------------------------------------------------------------------
-- C8) منع الحذف من جداول النقدية والسلف
-- ---------------------------------------------------------------------
DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY[
    'daily_cash_closings','cash_transfers',
    'employee_advances','employee_advance_repayments'
  ] LOOP
    EXECUTE format('DROP TRIGGER IF EXISTS trg_no_delete ON %I;', t);
    EXECUTE format(
      'CREATE TRIGGER trg_no_delete BEFORE DELETE ON %I
       FOR EACH ROW EXECUTE FUNCTION prevent_hard_delete();', t);
  END LOOP;
END $$;

-- =====================================================================
-- صرف العمولة — لا Commission Payable · لا صرف مزدوج
-- =====================================================================

-- ---------------------------------------------------------------------
-- K1) المصروف الواحد لا يُربط بصرفَي عمولة
-- ---------------------------------------------------------------------
DROP INDEX IF EXISTS ux_commission_paid_expense;
CREATE UNIQUE INDEX ux_commission_paid_expense
  ON commissions (paid_expense_id) WHERE paid_expense_id IS NOT NULL;

-- ---------------------------------------------------------------------
-- K2) حالة PAID تستلزم مصروفًا مرتبطًا ومبلغًا موجبًا
-- ---------------------------------------------------------------------
ALTER TABLE commissions DROP CONSTRAINT IF EXISTS ck_commission_paid_link;
ALTER TABLE commissions
  ADD CONSTRAINT ck_commission_paid_link CHECK (
    status <> 'PAID' OR (paid_expense_id IS NOT NULL AND commission_amount > 0)
  );

ALTER TABLE commissions DROP CONSTRAINT IF EXISTS ck_commission_amounts;
ALTER TABLE commissions
  ADD CONSTRAINT ck_commission_amounts CHECK (
    commission_amount >= 0 AND rental_base >= 0 AND sales_base >= 0
    AND rental_rate_pct BETWEEN 0 AND 100
    AND sales_rate_pct BETWEEN 0 AND 100
  );

-- ---------------------------------------------------------------------
-- K3) ★ العمولة المصروفة سجل تاريخي: لا يُعاد فتحه ولا يُغيَّر مبلغه
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION protect_paid_commission() RETURNS trigger AS $$
BEGIN
  IF OLD.status = 'PAID' THEN
    IF NEW.status <> 'PAID' THEN
      RAISE EXCEPTION 'العمولة مصروفة ولا يمكن إعادة فتحها. الفروق تُسوَّى في الفترة التالية.';
    END IF;
    IF NEW.commission_amount <> OLD.commission_amount
       OR NEW.paid_expense_id IS DISTINCT FROM OLD.paid_expense_id THEN
      RAISE EXCEPTION 'لا يمكن تعديل مبلغ عمولة مصروفة أو مصروفها المرتبط.';
    END IF;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_protect_paid_commission ON commissions;
CREATE TRIGGER trg_protect_paid_commission
  BEFORE UPDATE ON commissions
  FOR EACH ROW EXECUTE FUNCTION protect_paid_commission();

-- ---------------------------------------------------------------------
-- K4) لا حذف لسجل عمولة
-- ---------------------------------------------------------------------
DROP TRIGGER IF EXISTS trg_no_delete ON commissions;
CREATE TRIGGER trg_no_delete BEFORE DELETE ON commissions
  FOR EACH ROW EXECUTE FUNCTION prevent_hard_delete();


-- =====================================================================
-- M10 — الحجز المسبق
-- البنية موجودة منذ M0 · قيد منع التعارض ex_item_booking_overlap مطبَّق
-- =====================================================================

-- ---------------------------------------------------------------------
-- V1) منطق تواريخ الحجز: المناسبة لا تسبق الاستلام
--     (ck_reservation_dates لضمان return >= pickup موجود منذ M0)
-- ---------------------------------------------------------------------
ALTER TABLE reservations DROP CONSTRAINT IF EXISTS ck_reservation_event_date;
ALTER TABLE reservations
  ADD CONSTRAINT ck_reservation_event_date CHECK (event_date >= pickup_date);

ALTER TABLE reservations DROP CONSTRAINT IF EXISTS ck_reservation_deposit;
ALTER TABLE reservations
  ADD CONSTRAINT ck_reservation_deposit CHECK (deposit_amount >= 0);

-- ---------------------------------------------------------------------
-- V2) ★ الحجز المحوَّل أو الملغى نهائي — لا يُعاد فتحه
--     ولا تُكتب حالة EXPIRED إطلاقًا: «فائت» مشتقة عرضًا فقط (D2)
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION protect_final_reservation() RETURNS trigger AS $$
BEGIN
  IF OLD.status IN ('CONVERTED','CANCELLED') AND NEW.status <> OLD.status THEN
    RAISE EXCEPTION 'الحجز % ولا يمكن تغيير حالته.',
      CASE OLD.status WHEN 'CONVERTED' THEN 'محوَّل إلى تأجير' ELSE 'ملغى' END;
  END IF;

  IF NEW.status = 'EXPIRED' THEN
    RAISE EXCEPTION 'حالة «فائت» مشتقة للعرض ولا تُخزَّن في قاعدة البيانات.';
  END IF;

  IF NEW.status = 'CONVERTED' AND NEW.converted_rental_id IS NULL THEN
    RAISE EXCEPTION 'الحجز المحوَّل يجب أن يرتبط بعقد تأجير.';
  END IF;

  IF NEW.status = 'CANCELLED' AND (NEW.cancel_reason IS NULL OR NEW.cancel_reason = '') THEN
    RAISE EXCEPTION 'إلغاء الحجز يستلزم سببًا.';
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_protect_final_reservation ON reservations;
CREATE TRIGGER trg_protect_final_reservation
  BEFORE UPDATE ON reservations
  FOR EACH ROW EXECUTE FUNCTION protect_final_reservation();

-- منع إنشاء حجز بحالة EXPIRED مباشرةً
CREATE OR REPLACE FUNCTION reject_expired_on_insert() RETURNS trigger AS $$
BEGIN
  IF NEW.status = 'EXPIRED' THEN
    RAISE EXCEPTION 'حالة «فائت» مشتقة للعرض ولا تُخزَّن في قاعدة البيانات.';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_reject_expired_insert ON reservations;
CREATE TRIGGER trg_reject_expired_insert
  BEFORE INSERT ON reservations
  FOR EACH ROW EXECUTE FUNCTION reject_expired_on_insert();

-- ---------------------------------------------------------------------
-- V3) لا حذف للحجوزات — الإلغاء فقط
-- ---------------------------------------------------------------------
DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['reservations','reservation_items'] LOOP
    EXECUTE format('DROP TRIGGER IF EXISTS trg_no_delete ON %I;', t);
    EXECUTE format(
      'CREATE TRIGGER trg_no_delete BEFORE DELETE ON %I
       FOR EACH ROW EXECUTE FUNCTION prevent_hard_delete();', t);
  END LOOP;
END $$;


-- ---------------------------------------------------------------------
-- قفل الدخول: العدّاد لا يكون سالبًا
-- (كان في ملف الترحيل وحده، فلا يُطبَّق مع prisma db push.
--  موطنه الصحيح هنا مع بقية قيود CHECK.)
-- ---------------------------------------------------------------------
ALTER TABLE users DROP CONSTRAINT IF EXISTS ck_user_failed_attempts;
ALTER TABLE users
  ADD CONSTRAINT ck_user_failed_attempts CHECK (failed_attempts >= 0);
