import { z } from 'zod';
import { prisma } from '@/lib/db';
import { Errors } from '@/lib/errors';
import { writeAudit } from '@/lib/audit';
import { requirePermission } from '@/lib/auth/rbac';
import { SETTING_DEFS, type SettingKey } from '@/lib/settings.defs';

export const updateSettingsSchema = z.object({
  values: z.record(z.string(), z.union([z.string(), z.number(), z.boolean(), z.null()])),
  reason: z.string().optional(),
});

const DEF_BY_KEY = new Map(SETTING_DEFS.map((d) => [d.key, d]));

/** إعدادات تتطلب صلاحية إضافية بحكم أثرها المالي.  BR-16 / BR-21 */
const RESTRICTED: Record<string, 'settings.vat.manage'> = {
  'vat.enabled': 'settings.vat.manage',
  'vat.rate': 'settings.vat.manage',
};

function coerce(def: (typeof SETTING_DEFS)[number], raw: unknown) {
  switch (def.dataType) {
    case 'NUMBER': {
      const n = Number(raw);
      if (!Number.isFinite(n)) throw Errors.rule(`قيمة غير رقمية للإعداد: ${def.nameAr}`);
      if (n < 0) throw Errors.rule(`لا يمكن أن تكون قيمة "${def.nameAr}" سالبة.`);
      if (def.key.endsWith('_percent') || def.key === 'vat.rate') {
        if (n > 100) throw Errors.rule(`"${def.nameAr}" لا يمكن أن تتجاوز 100%.`);
      }
      return n;
    }
    case 'BOOLEAN':
      return raw === true || raw === 'true' || raw === 1 || raw === '1';
    case 'STRING':
      return raw == null ? '' : String(raw);
    default:
      return raw;
  }
}

export async function readSettings() {
  await requirePermission('settings.view');
  const rows = await prisma.setting.findMany({ orderBy: [{ group: 'asc' }, { key: 'asc' }] });
  return rows.map((r) => ({
    key: r.key,
    nameAr: r.nameAr,
    group: r.group,
    dataType: r.dataType,
    value: r.valueJson,
    updatedAt: r.updatedAt,
  }));
}

export async function updateSettings(input: z.infer<typeof updateSettingsSchema>) {
  const actor = await requirePermission('settings.edit');

  const keys = Object.keys(input.values) as SettingKey[];
  for (const key of keys) {
    if (!DEF_BY_KEY.has(key)) throw Errors.rule(`إعداد غير معروف: ${key}`);
    const extra = RESTRICTED[key];
    if (extra) await requirePermission(extra);
  }

  const before = await prisma.setting.findMany({ where: { key: { in: keys } } });
  const beforeMap = Object.fromEntries(before.map((b) => [b.key, b.valueJson]));

  await prisma.$transaction(async (tx) => {
    for (const key of keys) {
      const def = DEF_BY_KEY.get(key)!;
      const value = coerce(def, input.values[key]);
      await tx.setting.update({
        where: { key },
        data: { valueJson: value as never, updatedBy: actor.id },
      });
    }
    await writeAudit(
      {
        userId: actor.id,
        action: 'settings.update',
        entityType: 'Setting',
        entityId: keys.join(','),
        before: beforeMap,
        after: input.values,
        reason: input.reason ?? null,
      },
      tx,
    );
  });

  return { updated: keys.length };
}
