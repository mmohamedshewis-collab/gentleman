import { route } from '@/lib/api';
import { updateItemBarcode, updateBarcodeSchema } from '@/services/item.service';

export const PATCH = route({ schema: updateBarcodeSchema, handler: ({ input }) => updateItemBarcode(input) });
