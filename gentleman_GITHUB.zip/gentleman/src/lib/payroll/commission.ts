import { Decimal } from 'decimal.js';
import { round2, add, sub, mul, pct } from '@/lib/money';

/**
 * حسابات الموظفين — منطق خالص.
 * الغرامات والتأمين لا يدخلان وعاء العمولة (قرار معتمد).
 */

export class PayrollError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'PayrollError';
  }
}

/** الراتب المخصَّص للفترة = الراتب الشهري × (أيام الفترة ÷ أيام الشهر). */
export function allocatedSalary(
  monthlySalary: Decimal.Value,
  periodDays: number,
  daysInMonth: number,
): Decimal {
  const salary = round2(monthlySalary);
  if (salary.lt(0)) throw new PayrollError('الراتب لا يمكن أن يكون سالبًا.');
  if (!Number.isInteger(periodDays) || periodDays < 0) {
    throw new PayrollError('عدد أيام الفترة غير صالح.');
  }
  if (!Number.isInteger(daysInMonth) || daysInMonth <= 0) {
    throw new PayrollError('عدد أيام الشهر غير صالح.');
  }
  return round2(salary.times(periodDays).dividedBy(daysInMonth));
}

export interface CommissionInput {
  /** صافي التأجير بعد الخصم وقبل الضريبة — بلا غرامات وبلا تأمين. */
  netRentalSales: Decimal.Value;
  /** صافي البيع بعد الخصم وقبل الضريبة. */
  netProductSales: Decimal.Value;
  rentalRatePct: Decimal.Value;
  salesRatePct: Decimal.Value;
}

export interface CommissionResult {
  rentalBase: Decimal;
  salesBase: Decimal;
  employeeSales: Decimal;
  rentalCommission: Decimal;
  salesCommission: Decimal;
  commissionAmount: Decimal;
}

export function computeCommission(input: CommissionInput): CommissionResult {
  const rentalBase = round2(input.netRentalSales);
  const salesBase = round2(input.netProductSales);
  const rentalRate = round2(input.rentalRatePct);
  const salesRate = round2(input.salesRatePct);

  for (const [label, v] of [['صافي التأجير', rentalBase], ['صافي البيع', salesBase]] as const) {
    if (v.lt(0)) throw new PayrollError(`${label} لا يمكن أن يكون سالبًا.`);
  }
  for (const [label, v] of [['نسبة عمولة التأجير', rentalRate], ['نسبة عمولة البيع', salesRate]] as const) {
    if (v.lt(0) || v.gt(100)) throw new PayrollError(`${label} يجب أن تكون بين 0 و100.`);
  }

  const rentalCommission = pct(rentalBase, rentalRate);
  const salesCommission = pct(salesBase, salesRate);

  return {
    rentalBase,
    salesBase,
    employeeSales: add(rentalBase, salesBase),
    rentalCommission,
    salesCommission,
    commissionAmount: add(rentalCommission, salesCommission),
  };
}

export interface PerformanceInput {
  employeeSales: Decimal.Value;
  allocatedSalary: Decimal.Value;
  accruedCommission: Decimal.Value;
}

export interface PerformanceResult {
  employeeSales: Decimal;
  employeeCost: Decimal;
  /** null حين تكون التكلفة صفرًا — لا قسمة على صفر ولا رقم مضلل. */
  performance: Decimal | null;
  label: string;
}

export function computePerformance(input: PerformanceInput): PerformanceResult {
  const sales = round2(input.employeeSales);
  const cost = add(input.allocatedSalary, input.accruedCommission);

  if (cost.lte(0)) {
    return { employeeSales: sales, employeeCost: cost, performance: null, label: 'غير محسوب' };
  }
  const performance = round2(sales.dividedBy(cost));
  return {
    employeeSales: sales,
    employeeCost: cost,
    performance,
    label: `${performance.toString()}×`,
  };
}

/** المتبقي على العقد بعد دفعة جديدة. */
export function remainingAfterPayment(
  totalDue: Decimal.Value,
  alreadyPaid: Decimal.Value,
  newPayment: Decimal.Value,
): Decimal {
  const due = round2(totalDue);
  const paid = round2(alreadyPaid);
  const amount = round2(newPayment);

  if (amount.lte(0)) throw new PayrollError('مبلغ الدفعة يجب أن يكون أكبر من صفر.');
  const remaining = sub(due, add(paid, amount));
  if (remaining.lt(0)) {
    throw new PayrollError(
      `الدفعة تتجاوز المتبقي: المتبقي ${sub(due, paid).toString()} والمدفوع ${amount.toString()}.`,
    );
  }
  return remaining;
}

export const totalEmployeeCost = (salary: Decimal.Value, commission: Decimal.Value): Decimal =>
  add(salary, commission);
