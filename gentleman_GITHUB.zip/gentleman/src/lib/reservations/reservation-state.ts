import { businessToday } from '@/lib/date';

/**
 * حالة الحجز — MVP بحالة نشطة واحدة (D4 المعتمد).
 *
 * `PENDING` هي الحالة النشطة الوحيدة. لا تمييز بين معلّق ومؤكَّد.
 * `CONVERTED` و `CANCELLED` نهائيتان.
 * `EXPIRED` **معرَّفة في المخطط ولا تُكتب أبدًا** — «فائت» حالة مشتقة عرضًا فقط (D2).
 */

export type ReservationStatus = 'PENDING' | 'CONFIRMED' | 'CONVERTED' | 'CANCELLED' | 'EXPIRED';

/** الحالة الوحيدة التي تُكتب عند الإنشاء. */
export const ACTIVE_STATUS = 'PENDING' as const;

/** حالات لا خروج منها. */
export const TERMINAL_STATUSES: ReservationStatus[] = ['CONVERTED', 'CANCELLED'];

export const RESERVATION_LABELS: Record<ReservationStatus, string> = {
  PENDING: 'قائم',
  CONFIRMED: 'قائم',
  CONVERTED: 'محوَّل إلى تأجير',
  CANCELLED: 'ملغى',
  EXPIRED: 'فائت',
};

/** حالة العرض المشتقة — لا تُخزَّن ولا تُكتب في قاعدة البيانات (D2). */
export type DisplayStatus = ReservationStatus | 'OVERDUE_PICKUP';

export interface DisplayState {
  status: ReservationStatus;
  /** «فائت»: حجز قائم مضى موعد استلامه ولم يُحوَّل */
  isMissed: boolean;
  label: string;
}

/**
 * يشتق حالة العرض من الحالة المخزَّنة وتاريخ الاستلام.
 * ⛔ لا يكتب شيئًا — بنفس منهجية «متأخرة» في M9.
 */
export function displayState(
  status: ReservationStatus,
  pickupDate: Date,
  today: Date = businessToday(),
): DisplayState {
  const active = !TERMINAL_STATUSES.includes(status);
  const isMissed = active && pickupDate < today;
  return {
    status,
    isMissed,
    label: isMissed ? RESERVATION_LABELS.EXPIRED : RESERVATION_LABELS[status],
  };
}

export const isTerminal = (s: ReservationStatus): boolean => TERMINAL_STATUSES.includes(s);

/** التحويل والإلغاء لا يجوزان إلا على حجز قائم. */
export function assertActionable(status: ReservationStatus, action: 'convert' | 'cancel'): void {
  if (status === 'CONVERTED') {
    throw new Error(
      action === 'convert'
        ? 'الحجز محوَّل إلى تأجير بالفعل.'
        : 'لا يمكن إلغاء حجز محوَّل — ألغِ عقد التأجير الناتج عنه.',
    );
  }
  if (status === 'CANCELLED') {
    throw new Error('الحجز ملغى بالفعل.');
  }
}

/** تحقق التواريخ — الاستلام لا يسبق اليوم، والإرجاع لا يسبق الاستلام. */
export function assertReservationDates(input: {
  pickupDate: Date;
  returnDate: Date;
  eventDate: Date;
  today?: Date;
}): void {
  const today = input.today ?? businessToday();
  if (input.pickupDate < today) {
    throw new Error('لا يمكن الحجز بتاريخ استلام في الماضي.');
  }
  if (input.returnDate < input.pickupDate) {
    throw new Error('تاريخ الإرجاع لا يمكن أن يسبق تاريخ الاستلام.');
  }
  if (input.eventDate < input.pickupDate) {
    throw new Error('تاريخ المناسبة لا يمكن أن يسبق تاريخ الاستلام.');
  }
}

/** رقم الحجز: RES-2026-000001 */
export const buildReservationNo = (year: number, seq: number): string =>
  `RES-${year}-${String(seq).padStart(6, '0')}`;
