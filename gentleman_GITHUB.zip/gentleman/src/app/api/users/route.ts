import { route } from '@/lib/api';
import {
  listUsers,
  createUser,
  createUserSchema,
  updateUser,
  updateUserSchema,
} from '@/services/user.service';

export const GET = route({ handler: () => listUsers() });

export const POST = route({
  schema: createUserSchema,
  handler: ({ input }) => createUser(input),
});

export const PATCH = route({
  schema: updateUserSchema,
  handler: ({ input }) => updateUser(input),
});
