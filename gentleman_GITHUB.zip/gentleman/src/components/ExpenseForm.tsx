'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function ExpenseForm({
  categories, methods,
}: { categories: { id: number; nameAr: string }[]; methods: { id: number; nameAr: string }[] }) {
  const router = useRouter();
  const [form, setForm] = useState({
    categoryId: categories[0]?.id ?? 0,
    amount: '',
    paymentMethodId: methods[0]?.id ?? 0,
    description: '',
  });
  const [msg, setMsg] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  async function save() {
    setBusy(true); setMsg(null);
    const res = await fetch('/api/expenses', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...form, amount: Number(form.amount) }),
    });
    const json = await res.json();
    setBusy(false);
    if (!json.ok) { setMsg({ type: 'err', text: json.error?.message ?? 'تعذّر الحفظ.' }); return; }
    setMsg({ type: 'ok', text: 'تم تسجيل المصروف.' });
    setForm({ ...form, amount: '', description: '' });
    router.refresh();
  }

  return (
    <div className="card">
      <div className="card-header">تسجيل مصروف</div>
      <div className="p-5 grid grid-cols-1 md:grid-cols-4 gap-4">
        <div>
          <label className="label">التصنيف</label>
          <select className="input" value={form.categoryId}
                  onChange={(e) => setForm({ ...form, categoryId: Number(e.target.value) })}>
            {categories.map((c) => <option key={c.id} value={c.id}>{c.nameAr}</option>)}
          </select>
        </div>
        <div>
          <label className="label">المبلغ</label>
          <input className="input num" dir="ltr" inputMode="decimal" value={form.amount}
                 onChange={(e) => setForm({ ...form, amount: e.target.value })} />
        </div>
        <div>
          <label className="label">طريقة الدفع</label>
          <select className="input" value={form.paymentMethodId}
                  onChange={(e) => setForm({ ...form, paymentMethodId: Number(e.target.value) })}>
            {methods.map((m) => <option key={m.id} value={m.id}>{m.nameAr}</option>)}
          </select>
        </div>
        <div>
          <label className="label">الوصف</label>
          <input className="input" value={form.description}
                 onChange={(e) => setForm({ ...form, description: e.target.value })} />
        </div>
      </div>
      <div className="px-5 pb-5 flex items-center gap-4">
        <button className="btn-primary" onClick={save} disabled={busy || !form.amount}>
          {busy ? 'جارٍ الحفظ…' : 'حفظ'}
        </button>
        {msg && <span className={`text-sm font-semibold ${msg.type === 'ok' ? 'text-ok' : 'text-danger'}`}>{msg.text}</span>}
      </div>
    </div>
  );
}
