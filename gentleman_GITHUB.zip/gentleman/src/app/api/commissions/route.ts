import { route } from '@/lib/api';
import { commissionStatement, commissionQuerySchema } from '@/services/commission.service';

export const GET = route({
  schema: commissionQuerySchema,
  handler: ({ input }) => commissionStatement(input),
});
