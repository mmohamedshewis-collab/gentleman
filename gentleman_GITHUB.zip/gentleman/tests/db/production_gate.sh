#!/usr/bin/env bash
# ==========================================================
# بوابة الإنتاج — Gentleman
# تتوقف عند أول فشل ولا تطبع نجاحًا إلا بعد نجاح فعلي.
# الاستخدام: DATABASE_URL="postgres://..." ./tests/db/production_gate.sh
# ==========================================================
set -Eeuo pipefail

FAILED=0
step() { printf '\n▶ %s\n' "$1"; }
ok()   { printf '  ✅ %s\n' "$1"; }
die()  { printf '  ❌ %s\n' "$1"; exit 1; }

: "${DATABASE_URL:?DATABASE_URL غير مضبوط — لا يمكن المتابعة}"

step "1) الاتصال بقاعدة البيانات"
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -c 'SELECT 1' >/dev/null || die "تعذّر الاتصال"
ok "الاتصال ناجح"

step "2) الترحيلات"
npx prisma migrate deploy || die "فشل تطبيق الترحيلات"
ok "الترحيلات مطبَّقة"

step "3) ★ قيود الحماية المالية"
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f prisma/sql/01_constraints.sql >/dev/null \
  || die "فشل تطبيق 01_constraints.sql — الحماية المالية ناقصة"
ok "القيود مطبَّقة"

step "4) التحقق من سلامة النشر"
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f prisma/sql/verify_production.sql \
  || die "التحقق فشل — راجع الرسالة أعلاه"
ok "كل عناصر الحماية موجودة"

step "5) الاختبارات"
npm test -- --run >/dev/null || die "فشل في الاختبارات"
ok "كل الاختبارات ناجحة"

step "6) بناء الإنتاج"
npm run build >/dev/null || die "فشل بناء الإنتاج"
ok "البناء ناجح"

step "7) متغيرات البيئة الإلزامية"
for v in DATABASE_URL CRON_SECRET R2_ACCOUNT_ID R2_ACCESS_KEY_ID R2_SECRET_ACCESS_KEY R2_BUCKET; do
  if [ -z "${!v:-}" ]; then printf '  ⚠️  %s غير مضبوط\n' "$v"; FAILED=1; else ok "$v مضبوط"; fi
done
[ "$FAILED" -eq 0 ] || die "متغيرات مفقودة — النشر غير مكتمل"

printf '\n══════════════════════════════════\n'
printf '  ✅ بوابة الإنتاج: نجحت بالكامل\n'
printf '══════════════════════════════════\n'
