BEGIN;
SELECT pg_sleep(0.1);
INSERT INTO employee_advance_repayments (advance_id, amount, method, created_by)
SELECT id, 500, 'CASH', 1 FROM employee_advances WHERE advance_no='ADV-CONC';
COMMIT;
