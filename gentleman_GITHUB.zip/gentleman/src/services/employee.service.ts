import { z } from 'zod';
import { prisma } from '@/lib/db';
import { Errors } from '@/lib/errors';
import { writeAudit } from '@/lib/audit';
import { requirePermission } from '@/lib/auth/rbac';
import { periodBounds, toBusinessDate } from '@/lib/date';
import { round2, add } from '@/lib/money';
import { commission, employeePerformance } from '@/lib/finance';

/**
 * الموظفون والعمولات.
 *
 * ★ حدود هذه الوحدة في M6:
 * العمولة تُحسب **قراءةً فقط** من العمليات المكتملة، ولا تُصرف ولا تُسجَّل
 * كمصروف. صرف العمولة تدفّق نقدي خارج، وقراره معروض على المالك ولم يُعتمد بعد.
 */

const money = z.coerce.number().nonnegative('القيمة لا يمكن أن تكون سالبة');
const pctSchema = z.coerce.number().min(0).max(100, 'النسبة بين 0 و100');

export const createEmployeeSchema = z.object({
  code: z.string().trim().min(2).max(20).regex(/^[A-Za-z0-9-]+$/, 'الكود بحروف إنجليزية وأرقام'),
  fullName: z.string().trim().min(2, 'اسم الموظف مطلوب'),
  jobTitle: z.string().max(60).optional(),
  hireDate: z.string().optional(),
  monthlySalary: money.default(0),
  rentalCommissionPct: pctSchema.default(0),
  salesCommissionPct: pctSchema.default(0),
  userId: z.number().int().positive().nullable().optional(),
});

export const updateEmployeeSchema = createEmployeeSchema.partial().extend({
  id: z.number().int().positive(),
  status: z.enum(['ACTIVE', 'INACTIVE']).optional(),
});

export const performanceQuerySchema = z.object({
  from: z.string(),
  to: z.string(),
  employeeId: z.coerce.number().int().optional(),
});

export async function listEmployees() {
  await requirePermission('employees.view');
  return prisma.employee.findMany({
    include: { user: { select: { username: true, isActive: true } } },
    orderBy: { code: 'asc' },
  });
}

export async function createEmployee(input: z.infer<typeof createEmployeeSchema>) {
  const actor = await requirePermission('employees.manage');

  const code = input.code.trim().toUpperCase();
  if (await prisma.employee.findUnique({ where: { code } })) {
    throw Errors.conflict('كود الموظف مستخدم بالفعل.');
  }
  if (input.userId) {
    const taken = await prisma.employee.findUnique({ where: { userId: input.userId } });
    if (taken) throw Errors.conflict('هذا المستخدم مرتبط بموظف آخر.');
  }

  return prisma.$transaction(async (tx) => {
    const row = await tx.employee.create({
      data: {
        code,
        fullName: input.fullName.trim(),
        jobTitle: input.jobTitle,
        hireDate: input.hireDate ? toBusinessDate(input.hireDate) : null,
        monthlySalary: input.monthlySalary,
        rentalCommissionPct: input.rentalCommissionPct,
        salesCommissionPct: input.salesCommissionPct,
        userId: input.userId ?? null,
      },
    });
    await writeAudit(
      { userId: actor.id, action: 'employee.create', entityType: 'Employee', entityId: row.id, after: row },
      tx,
    );
    return row;
  });
}

export async function updateEmployee(input: z.infer<typeof updateEmployeeSchema>) {
  const actor = await requirePermission('employees.manage');

  const before = await prisma.employee.findUnique({ where: { id: input.id } });
  if (!before) throw Errors.notFound('الموظف');

  const { id, code, hireDate, ...rest } = input;
  const data: Record<string, unknown> = { ...rest };
  if (code) data.code = code.trim().toUpperCase();
  if (hireDate) data.hireDate = toBusinessDate(hireDate);

  const ratesChanged =
    (input.rentalCommissionPct !== undefined &&
      !before.rentalCommissionPct.equals(input.rentalCommissionPct)) ||
    (input.salesCommissionPct !== undefined &&
      !before.salesCommissionPct.equals(input.salesCommissionPct)) ||
    (input.monthlySalary !== undefined && !before.monthlySalary.equals(input.monthlySalary));

  return prisma.$transaction(async (tx) => {
    const after = await tx.employee.update({ where: { id }, data });
    await writeAudit(
      {
        userId: actor.id,
        // تغيير الراتب أو نسب العمولة حدث مالي حسّاس يُسجَّل بنوع مستقل
        action: ratesChanged ? 'employee.compensation_change' : 'employee.update',
        entityType: 'Employee',
        entityId: id,
        before: {
          monthlySalary: before.monthlySalary.toString(),
          rentalCommissionPct: before.rentalCommissionPct.toString(),
          salesCommissionPct: before.salesCommissionPct.toString(),
          status: before.status,
        },
        after: {
          monthlySalary: after.monthlySalary.toString(),
          rentalCommissionPct: after.rentalCommissionPct.toString(),
          salesCommissionPct: after.salesCommissionPct.toString(),
          status: after.status,
        },
      },
      tx,
    );
    return after;
  });
}

/**
 * أداء الموظف وعمولته خلال فترة — قراءة فقط.
 *
 * الوعاء = صافي التأجير + صافي البيع من العمليات **غير الملغاة** فقط.
 * لا يشمل: التأمين، غرامات التأخير، تعويضات التلف، الضريبة.
 */
export async function employeePerformanceReport(input: z.infer<typeof performanceQuerySchema>) {
  await requirePermission('commissions.view');
  const { start, end } = periodBounds(input.from, input.to);

  const employees = await prisma.employee.findMany({
    where: input.employeeId ? { id: input.employeeId } : { status: 'ACTIVE' },
    orderBy: { code: 'asc' },
  });

  const periodDays = Math.max(
    1,
    Math.round((end.getTime() - start.getTime()) / 86_400_000) + 1,
  );
  const monthDays = 30;

  const rows = [];
  for (const emp of employees) {
    const [rentalAgg, saleAgg] = await Promise.all([
      prisma.rental.aggregate({
        _sum: { netAmount: true },
        _count: { _all: true },
        where: { employeeId: emp.id, createdAt: { gte: start, lte: end }, status: { not: 'VOIDED' } },
      }),
      prisma.sale.aggregate({
        _sum: { netAmount: true },
        _count: { _all: true },
        where: { employeeId: emp.id, createdAt: { gte: start, lte: end }, status: 'COMPLETED' },
      }),
    ]);

    const netRental = round2(rentalAgg._sum.netAmount?.toString() ?? 0);
    const netSales = round2(saleAgg._sum.netAmount?.toString() ?? 0);

    const c = commission({
      netRental,
      netSales,
      rentalPct: emp.rentalCommissionPct.toString(),
      salesPct: emp.salesCommissionPct.toString(),
    });

    const perf = employeePerformance({
      netRental,
      netSales,
      monthlySalary: emp.monthlySalary.toString(),
      periodDays,
      monthDays,
      commissionAmount: c.total,
    });

    rows.push({
      employeeId: emp.id,
      code: emp.code,
      fullName: emp.fullName,
      rentalCount: rentalAgg._count._all,
      saleCount: saleAgg._count._all,
      netRental: netRental.toString(),
      netSales: netSales.toString(),
      base: c.base.toString(),
      rentalCommission: c.rentalCommission.toString(),
      salesCommission: c.salesCommission.toString(),
      commissionTotal: c.total.toString(),
      allocatedSalary: perf.allocatedSalary.toString(),
      totalCost: perf.cost.toString(),
      performanceIndex: perf.index ? perf.index.toString() : null,
    });
  }

  const totals = {
    netRental: add(...rows.map((r) => r.netRental)).toString(),
    netSales: add(...rows.map((r) => r.netSales)).toString(),
    commissionTotal: add(...rows.map((r) => r.commissionTotal)).toString(),
    totalCost: add(...rows.map((r) => r.totalCost)).toString(),
  };

  return {
    from: input.from,
    to: input.to,
    periodDays,
    rows,
    totals,
    // ★ تنبيه صريح: العمولة محسوبة ولم تُصرف ولم تُسجَّل كمصروف
    note: 'العمولة محسوبة للعرض فقط ولم تُصرف. صرف العمولة يتطلب قرار المالك.',
  };
}
