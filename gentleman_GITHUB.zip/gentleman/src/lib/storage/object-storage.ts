/**
 * تخزين الكائنات — واجهة مجرَّدة.
 * تُنفَّذ على Cloudflare R2 في الإنتاج، وبمحاكاة في الاختبار.
 */

export interface ObjectStorage {
  put(key: string, body: string | Buffer, contentType: string): Promise<void>;
  exists(key: string): Promise<boolean>;
}

/** تخزين في الذاكرة — للاختبار وللتشغيل بلا R2 مُهيّأ. */
export class MemoryStorage implements ObjectStorage {
  private readonly files = new Map<string, string | Buffer>();

  async put(key: string, body: string | Buffer): Promise<void> {
    this.files.set(key, body);
  }
  async exists(key: string): Promise<boolean> {
    return this.files.has(key);
  }
  get(key: string) {
    return this.files.get(key);
  }
  get size() {
    return this.files.size;
  }
}

/** هل تخزين R2 مُهيّأ؟ */
export const isR2Configured = (): boolean =>
  Boolean(
    process.env.R2_ACCOUNT_ID &&
    process.env.R2_ACCESS_KEY_ID &&
    process.env.R2_SECRET_ACCESS_KEY &&
    process.env.R2_BUCKET,
  );

/**
 * تخزين R2 عبر واجهة S3 المتوافقة.
 * يُحمَّل العميل عند الحاجة فقط حتى لا يفشل التشغيل بلا تهيئة.
 */
export class R2Storage implements ObjectStorage {
  async put(key: string, body: string | Buffer, contentType: string): Promise<void> {
    const { S3Client, PutObjectCommand } = await import('@aws-sdk/client-s3');
    const client = new S3Client({
      region: 'auto',
      endpoint: `https://${process.env.R2_ACCOUNT_ID}.r2.cloudflarestorage.com`,
      credentials: {
        accessKeyId: process.env.R2_ACCESS_KEY_ID!,
        secretAccessKey: process.env.R2_SECRET_ACCESS_KEY!,
      },
    });
    await client.send(new PutObjectCommand({
      Bucket: process.env.R2_BUCKET!,
      Key: key,
      Body: body,
      ContentType: contentType,
    }));
  }

  async exists(key: string): Promise<boolean> {
    const { S3Client, HeadObjectCommand } = await import('@aws-sdk/client-s3');
    const client = new S3Client({
      region: 'auto',
      endpoint: `https://${process.env.R2_ACCOUNT_ID}.r2.cloudflarestorage.com`,
      credentials: {
        accessKeyId: process.env.R2_ACCESS_KEY_ID!,
        secretAccessKey: process.env.R2_SECRET_ACCESS_KEY!,
      },
    });
    try {
      await client.send(new HeadObjectCommand({ Bucket: process.env.R2_BUCKET!, Key: key }));
      return true;
    } catch {
      return false;
    }
  }
}

let fallback: MemoryStorage | null = null;

/** التخزين الفعلي: R2 إن كان مُهيّأ، وإلا ذاكرة مؤقتة مع تسجيل ذلك. */
export function getStorage(): ObjectStorage {
  if (isR2Configured()) return new R2Storage();
  fallback ??= new MemoryStorage();
  return fallback;
}
