import { notFound } from 'next/navigation';
import { getCustomer } from '@/services/customer.service';
import { getSession } from '@/lib/auth/session';
import { formatDateTime } from '@/lib/date';
import CustomerForm from '@/components/CustomerForm';

export const dynamic = 'force-dynamic';

export default async function CustomerPage({ params }: { params: { id: string } }) {
  const id = Number(params.id);
  if (!Number.isFinite(id)) notFound();

  const customer = await getCustomer(id);
  const session = await getSession();
  const canEdit = (session?.permissions.has('customers.edit') ?? false) && !customer.isWalkIn;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="section-title">{customer.fullName}</h1>
        <p className="text-sm text-slate-600 mt-1 num">
          {customer.code} · {customer.phoneDisplay ?? 'بلا رقم'}
        </p>
      </div>

      <div className="card">
        <div className="card-header">بيانات العميل</div>
        <dl className="p-5 grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          <div><dt className="text-slate-500">الاسم</dt><dd className="font-semibold">{customer.fullName}</dd></div>
          <div><dt className="text-slate-500">رقم الجوال</dt><dd className="font-semibold num">{customer.phoneDisplay ?? '—'}</dd></div>
          <div><dt className="text-slate-500">الرقم القومي</dt><dd className="num">{customer.nationalId ?? '—'}</dd></div>
          <div><dt className="text-slate-500">الحالة</dt><dd>{customer.isActive ? 'مفعّل' : 'معطّل'}</dd></div>
          <div className="md:col-span-2"><dt className="text-slate-500">ملاحظات</dt><dd>{customer.notes ?? '—'}</dd></div>
          <div><dt className="text-slate-500">تاريخ التسجيل</dt><dd className="num">{formatDateTime(customer.createdAt)}</dd></div>
        </dl>
      </div>

      {canEdit && (
        <CustomerForm
          customer={{
            id: customer.id,
            fullName: customer.fullName,
            phone: customer.phone ?? '',
            nationalId: customer.nationalId ?? '',
            notes: customer.notes ?? '',
          }}
        />
      )}

      <div className="card">
        <div className="card-header">سجل تعاملات العميل</div>
        <p className="p-5 text-sm text-slate-600">
          يظهر هنا سجل التأجير والإرجاع والمبيعات والمدفوعات بعد بناء تلك الوحدات.
        </p>
      </div>
    </div>
  );
}
