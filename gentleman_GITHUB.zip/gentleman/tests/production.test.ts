import { describe, it, expect, vi, beforeEach } from 'vitest';
import { readFileSync, existsSync, readdirSync } from 'node:fs';
import { join } from 'node:path';
import {
  buildExportKey, buildManifest, validateExport, EXPORT_TABLES,
  EXCLUDED_TABLES, EXPORT_NOTICE,
} from '../src/lib/backup/export-plan';
import { parseCsv, MAX_IMPORT_ROWS, CSV_TEMPLATES } from '../src/lib/import/csv';
import { daysLateOf, overdueRentalWhere, overdueItemRefs, overdueMap } from '../src/lib/inventory/overdue';
import { MemoryStorage } from '../src/lib/storage/object-storage';

// ==================== D3: لا استعادة داخل التطبيق ====================

describe('★ D3 — لا توجد استعادة داخل التطبيق إطلاقًا', () => {
  const walk = (dir: string): string[] => {
    if (!existsSync(dir)) return [];
    return readdirSync(dir, { withFileTypes: true }).flatMap((e) => {
      const p = join(dir, e.name);
      return e.isDirectory() ? walk(p) : [p];
    });
  };
  const files = walk('src').filter((f) => f.endsWith('.ts') || f.endsWith('.tsx'));

  it('لا يوجد مسار API للاستعادة', () => {
    const routes = files.filter((f) => f.includes('/api/') && f.endsWith('route.ts'));
    const restoreRoutes = routes.filter((f) => /restore/i.test(f));
    expect(restoreRoutes).toEqual([]);
  });

  it('لا توجد خدمة استعادة', () => {
    const services = files.filter((f) => f.includes('/services/'));
    expect(services.filter((f) => /restore/i.test(f))).toEqual([]);
  });

  it('★ لا دالة استعادة في أي ملف', () => {
    const offenders = files.filter((f) => {
      const src = readFileSync(f, 'utf8');
      return /function\s+\w*[Rr]estore|restoreDatabase|restoreBackup/.test(src);
    });
    expect(offenders).toEqual([]);
  });

  it('★ صلاحية الاستعادة محذوفة من الكتالوج ولا تعود', async () => {
    const { ALL_PERMISSION_CODES } = await import('../src/lib/auth/permissions');
    expect(ALL_PERMISSION_CODES).not.toContain('backup.restore' as never);
    // التصدير باقٍ — الحذف طال الاستعادة وحدها
    expect(ALL_PERMISSION_CODES).toContain('backup.run' as never);
  });

  it('★ لا إشارة إلى صلاحية استعادة في أي ملف', () => {
    const offenders = files.filter((f) => readFileSync(f, 'utf8').includes('backup.restore'));
    expect(offenders).toEqual([]);
  });

  it('خدمة التصدير توثّق أن الاستعادة خارجية', () => {
    const src = readFileSync('src/services/backup.service.ts', 'utf8');
    expect(src).toContain('Neon PITR');
    expect(src).toContain('لا يوجد مسار استعادة');
  });
});

// ==================== D1: التصدير ====================

describe('D1 — تصدير البيانات لا نسخة احتياطية', () => {
  it('★ التسمية تمنع الخلط مع النسخة الاحتياطية', () => {
    expect(EXPORT_NOTICE).toContain('ليس نسخة احتياطية');
    expect(EXPORT_NOTICE).toContain('Neon PITR');
  });

  it('مفتاح الملف يحمل تاريخًا صالحًا للترتيب', () => {
    const key = buildExportKey(new Date('2026-08-13T09:30:00Z'));
    expect(key).toBe('data-exports/DATA-EXPORT-2026-08-13T09-30-00.json');
  });

  it('★ الجداول الحساسة مستبعدة من التصدير', () => {
    for (const t of EXCLUDED_TABLES) {
      expect(EXPORT_TABLES as readonly string[]).not.toContain(t);
    }
    expect(EXCLUDED_TABLES).toContain('users');
    expect(EXCLUDED_TABLES).toContain('userSessions');
  });

  it('يشمل الجداول المالية والتشغيلية', () => {
    for (const t of ['rentals', 'sales', 'payments', 'insuranceTransactions',
                     'expenses', 'dailyCashClosings']) {
      expect(EXPORT_TABLES as readonly string[]).toContain(t);
    }
  });

  it('★ التحقق يكشف جدولًا ناقصًا', () => {
    const m = buildManifest([{ name: 'rentals', rowCount: 2 }, { name: 'sales', rowCount: 1 }], new Date());
    const r = validateExport(m, ['rentals']);
    expect(r.ok).toBe(false);
    expect(r.message).toContain('sales');
  });

  it('★ التحقق يكشف عدّ سجلات غير متسق', () => {
    const m = buildManifest([{ name: 'rentals', rowCount: 2 }], new Date());
    m.totalRows = 99;
    const r = validateExport(m, ['rentals']);
    expect(r.ok).toBe(false);
    expect(r.message).toContain('غير متسق');
  });

  it('التحقق ينجح على تصدير سليم', () => {
    const m = buildManifest([{ name: 'rentals', rowCount: 2 }, { name: 'sales', rowCount: 3 }], new Date());
    const r = validateExport(m, ['rentals', 'sales']);
    expect(r.ok).toBe(true);
    expect(r.message).toContain('5');
  });

  it('التخزين المحاكى يحفظ الملف', async () => {
    const s = new MemoryStorage();
    await s.put('k', '{}', 'application/json');
    expect(await s.exists('k')).toBe(true);
    expect(s.size).toBe(1);
  });
});

// ==================== D2: التأخير ====================

describe('★ D2 — التأخير مصدر واحد بلا تكرار', () => {
  const today = new Date('2026-08-13T00:00:00Z');

  it('أيام التأخير تقويمية ولا تكون سالبة', () => {
    expect(daysLateOf(new Date('2026-08-10T00:00:00Z'), today)).toBe(3);
    expect(daysLateOf(new Date('2026-08-13T00:00:00Z'), today)).toBe(0);
    expect(daysLateOf(new Date('2026-08-20T00:00:00Z'), today)).toBe(0);
  });

  it('شرط العقد المتأخر يطابق القاعدة المعتمدة', () => {
    const w = overdueRentalWhere(today) as {
      status: { in: string[] }; expectedReturnDate: { lt: Date };
    };
    expect(w.status.in).toEqual(['ACTIVE', 'PARTIALLY_RETURNED']);
    expect(w.expectedReturnDate.lt).toBe(today);
  });

  it('★ التقرير وشاشة المخزون يستخدمان المصدر نفسه', () => {
    const report = readFileSync('src/services/report.service.ts', 'utf8');
    const inventory = readFileSync('src/services/inventory.service.ts', 'utf8');
    const item = readFileSync('src/services/item.service.ts', 'utf8');

    expect(report).toContain("from '@/lib/inventory/overdue'");
    expect(inventory).toContain("from '@/lib/inventory/overdue'");
    expect(item).toContain("from '@/lib/inventory/overdue'");

    // لا تعريف ثانٍ للشرط في أي منها
    expect(report).not.toContain("status: { in: ['ACTIVE', 'PARTIALLY_RETURNED'] }");
    expect(inventory).not.toContain("expectedReturnDate: { lt:");
  });

  it('يستخرج مراجع القطع المتأخرة من العقود', async () => {
    const db = {
      rental: {
        findMany: async () => [{
          id: 1, rentalNo: 'R-1',
          expectedReturnDate: new Date('2026-08-10T00:00:00Z'),
          items: [{ itemId: 5 }, { itemId: 6 }],
        }],
      },
    };
    const refs = await overdueItemRefs(db, today);
    expect(refs).toHaveLength(2);
    expect(refs[0]).toMatchObject({ itemId: 5, rentalNo: 'R-1', daysLate: 3 });
    expect(overdueMap(refs).get(6)!.daysLate).toBe(3);
  });

  it('★ لا يكتب حالة على القطعة — العرض فقط', () => {
    const src = readFileSync('src/lib/inventory/overdue.ts', 'utf8');
    for (const op of ['.update(', '.create(', 'updateMany', 'changeItemStatus']) {
      expect(src).not.toContain(op);
    }
    expect(src).toContain('لا يغيّر آلة الحالة');
  });

  it('★ آلة الحالة لم تتغيّر — OVERDUE ما زالت حالة معرَّفة', async () => {
    const { ALLOWED_TRANSITIONS, STATUS_LABELS } = await import('../src/lib/inventory/item-state');
    expect(STATUS_LABELS.OVERDUE).toBe('متأخرة');
    expect(ALLOWED_TRANSITIONS.RENTED).toContain('OVERDUE');
  });
});

// ==================== D5: الاستيراد ====================

describe('تحليل CSV', () => {
  it('يقرأ الرؤوس والصفوف', () => {
    const r = parseCsv('fullName,phone\nأحمد,01012345678\n', ['fullName', 'phone']);
    expect(r.error).toBeUndefined();
    expect(r.rows).toEqual([{ fullName: 'أحمد', phone: '01012345678' }]);
  });

  it('يكشف الأعمدة الناقصة', () => {
    const r = parseCsv('fullName\nأحمد\n', ['fullName', 'phone']);
    expect(r.error).toContain('phone');
  });

  it('يرفض الملف الفارغ أو بلا بيانات', () => {
    expect(parseCsv('', ['a']).error).toBeTruthy();
    expect(parseCsv('a,b\n', ['a']).error).toContain('بيانات');
  });

  it('يحترم الاقتباس المزدوج والفواصل داخله', () => {
    const r = parseCsv('fullName,notes\n"محمد, علي","ملاحظة ""مهمة"""\n', ['fullName']);
    expect(r.rows[0].fullName).toBe('محمد, علي');
    expect(r.rows[0].notes).toBe('ملاحظة "مهمة"');
  });

  it('يتجاهل BOM والأسطر الفارغة', () => {
    const r = parseCsv('\uFEFFa,b\n1,2\n\n3,4\n', ['a']);
    expect(r.rows).toHaveLength(2);
  });

  it('القوالب تحوي الأعمدة المطلوبة', () => {
    expect(parseCsv(CSV_TEMPLATES.items, ['productId', 'quantity', 'codePrefix', 'purchaseCost']).error).toBeUndefined();
    expect(parseCsv(CSV_TEMPLATES.customers, ['fullName', 'phone']).error).toBeUndefined();
  });

  it('حد أقصى معرَّف لعدد الصفوف', () => {
    expect(MAX_IMPORT_ROWS).toBeGreaterThan(0);
    expect(MAX_IMPORT_ROWS).toBeLessThanOrEqual(1000);
  });
});

// ==================== الخدمة: الاستيراد والتفويض ====================

const H = vi.hoisted(() => ({
  auditSpy: vi.fn(),
  createItemsSpy: vi.fn(),
  createCustomerSpy: vi.fn(),
}));
const { auditSpy, createItemsSpy, createCustomerSpy } = H;
let currentUser: { id: number; employeeId: number | null; permissions: Set<string> };

// عميل Prisma غير مولَّد في بيئة الاختبار — نستبدله حتى تُحلّ سلسلة الاستيراد
vi.mock('@/lib/db', () => ({ prisma: {} }));
vi.mock('@/services/item.service', () => ({ createItems: H.createItemsSpy }));
vi.mock('@/services/customer.service', () => ({ createCustomer: H.createCustomerSpy }));
vi.mock('@/lib/audit', () => ({ writeAudit: H.auditSpy, redact: (x: unknown) => x }));
vi.mock('@/lib/auth/rbac', async (importOriginal) => {
  const actual = await importOriginal<typeof import('@/lib/auth/rbac')>();
  return {
    ...actual,
    requirePermission: async (perm: string) => {
      if (!currentUser.permissions.has(perm)) {
        const { Errors } = await import('@/lib/errors');
        throw Errors.forbidden(perm);
      }
      return currentUser as never;
    },
  };
});

beforeEach(() => {
  auditSpy.mockClear();
  createItemsSpy.mockReset();
  createCustomerSpy.mockReset();
  currentUser = {
    id: 1, employeeId: 1,
    permissions: new Set(['items.manage', 'customers.create', 'backup.run']),
  };
});

describe('★ D5 — الاستيراد يمر بالخدمات ولا يتجاوزها', () => {
  it('★ لا كتابة مباشرة في قاعدة البيانات', () => {
    const src = readFileSync('src/services/import.service.ts', 'utf8');
    expect(src).not.toContain('prisma');
    expect(src).not.toContain('@/lib/db');
    expect(src).toContain("from '@/services/item.service'");
    expect(src).toContain("from '@/services/customer.service'");
  });

  it('يستدعي خدمة القطع لكل صف', async () => {
    createItemsSpy.mockResolvedValue({ items: [{ itemCode: 'SUIT-0001' }] });
    const { importItems } = await import('@/services/import.service');
    const r = await importItems({
      csv: 'productId,quantity,codePrefix,purchaseCost\n1,1,SUIT,6000\n1,1,SUIT,6000\n',
    });
    expect(createItemsSpy).toHaveBeenCalledTimes(2);
    expect(r.succeeded).toBe(2);
    expect(r.failed).toBe(0);
  });

  it('★ الصف الفاشل يُرفض بسببه ولا يُفسد الناجح', async () => {
    createItemsSpy
      .mockResolvedValueOnce({ items: [{ itemCode: 'SUIT-0001' }] })
      .mockRejectedValueOnce(new Error('الباركود مستخدم بالفعل'))
      .mockResolvedValueOnce({ items: [{ itemCode: 'SUIT-0003' }] });

    const { importItems } = await import('@/services/import.service');
    const r = await importItems({
      csv: 'productId,quantity,codePrefix,purchaseCost\n1,1,S,1\n1,1,S,1\n1,1,S,1\n',
    });
    expect(r.total).toBe(3);
    expect(r.succeeded).toBe(2);
    expect(r.failed).toBe(1);
    const failed = r.outcomes.find((o) => !o.ok)!;
    expect(failed.row).toBe(3);
    expect(failed.error).toContain('الباركود');
  });

  it('★ الاستيراد يحتاج صلاحية الوحدة نفسها', async () => {
    currentUser = { id: 9, employeeId: 3, permissions: new Set(['customers.create']) };
    const { importItems, importCustomers } = await import('@/services/import.service');

    await expect(importItems({ csv: 'productId,quantity,codePrefix,purchaseCost\n1,1,S,1\n' }))
      .rejects.toMatchObject({ code: 'PERM_DENIED', details: { permission: 'items.manage' } });

    createCustomerSpy.mockResolvedValue({ code: 'C-000001' });
    await expect(importCustomers({ csv: 'fullName,phone\nأحمد,01012345678\n' }))
      .resolves.toBeTruthy();
  });

  it('يرفض ملفًا يتجاوز الحد الأقصى', async () => {
    const rows = Array.from({ length: MAX_IMPORT_ROWS + 1 },
      () => '1,1,S,1').join('\n');
    const { importItems } = await import('@/services/import.service');
    await expect(importItems({ csv: `productId,quantity,codePrefix,purchaseCost\n${rows}\n` }))
      .rejects.toMatchObject({ code: 'BUSINESS_RULE' });
    expect(createItemsSpy).not.toHaveBeenCalled();
  });

  it('يسجّل نتيجة الاستيراد في التدقيق', async () => {
    createCustomerSpy.mockResolvedValue({ code: 'C-000001' });
    const { importCustomers } = await import('@/services/import.service');
    await importCustomers({ csv: 'fullName,phone\nأحمد,01012345678\n' });
    expect(auditSpy.mock.calls[0][0]).toMatchObject({
      action: 'import.customers',
      after: { total: 1, succeeded: 1, failed: 0 },
    });
  });

  it('يوضّح أن الاستيراد لم يتجاوز الخدمات', async () => {
    createCustomerSpy.mockResolvedValue({ code: 'C-000001' });
    const { importCustomers } = await import('@/services/import.service');
    const r = await importCustomers({ csv: 'fullName,phone\nأحمد,01012345678\n' });
    expect(r.note).toContain('لم تُكتب أي بيانات مباشرةً');
  });
});

// ==================== الأمان والنطاق ====================

describe('الأمان والنطاق', () => {
  it('★ مسار المهمة محمي بسر لا بصلاحية مستخدم', () => {
    const src = readFileSync('src/app/api/cron/data-export/route.ts', 'utf8');
    expect(src).toContain('CRON_SECRET');
    expect(src).toContain('401');
  });

  it('★ فحص الصحة لا يسرّب معلومات', () => {
    const src = readFileSync('src/app/api/health/route.ts', 'utf8');
    expect(src).toContain("status: 'ok'");
    expect(src).not.toContain('version');
    expect(src).not.toContain('count');
  });

  it('D4 — لا رفع صور في M9', () => {
    const walk = (dir: string): string[] =>
      existsSync(dir)
        ? readdirSync(dir, { withFileTypes: true }).flatMap((e) => {
            const p = join(dir, e.name);
            return e.isDirectory() ? walk(p) : [p];
          })
        : [];
    const routes = walk('src/app/api').filter((f) => /image|upload/i.test(f));
    expect(routes).toEqual([]);
  });

  it('D6 — لا فهارس أُضيفت', () => {
    const sql = readFileSync('prisma/sql/01_constraints.sql', 'utf8');
    expect(sql).not.toContain('backup_runs');
    expect(sql).not.toContain('idx_overdue');
  });

  it('D7 — لا منطق محاسبي جديد', () => {
    for (const f of ['src/services/backup.service.ts', 'src/services/import.service.ts',
                     'src/lib/inventory/overdue.ts']) {
      const src = readFileSync(f, 'utf8');
      expect(/journal|chart_of_accounts|double-entry/i.test(src)).toBe(false);
    }
  });
});

// ==================== M-1: مصدر واحد للتصدير ====================

describe('★ M-1 — مسار المهمة يستدعي خدمة التصدير نفسها', () => {
  const cron = readFileSync('src/app/api/cron/data-export/route.ts', 'utf8');

  it('★ يستدعي نواة التصدير المشتركة', () => {
    expect(cron).toContain('performDataExport');
    expect(cron).toContain("from '@/services/backup.service'");
  });

  it('★ لا يكرّر قائمة الجداول ولا النماذج', () => {
    expect(cron).not.toContain('EXPORT_TABLES');
    expect(cron).not.toContain('buildManifest');
    expect(cron).not.toContain('validateExport');
    expect(cron).not.toContain('buildExportKey');
  });

  it('★ لا يكتب في قاعدة البيانات مباشرة', () => {
    expect(cron).not.toContain('prisma');
    expect(cron).not.toContain('backupRun');
  });

  it('★ لا يشتق أسماء النماذج نصيًا — الهشاشة أُزيلت', () => {
    expect(cron).not.toContain("endsWith('s')");
    expect(cron).not.toContain('slice(0, -1)');
  });

  it('يحتفظ بمسؤولياته الأربع فقط', () => {
    expect(cron).toContain('CRON_SECRET');   // المصادقة
    expect(cron).toContain('401');           // الرفض
    expect(cron).toContain('performDataExport'); // الاستدعاء
    expect(cron).toContain('500');           // معالجة الخطأ
  });

  it('★ المساران يستخدمان النواة نفسها', () => {
    const svc = readFileSync('src/services/backup.service.ts', 'utf8');
    // النواة معرَّفة مرة واحدة
    expect((svc.match(/export async function performDataExport/g) ?? []).length).toBe(1);
    // التصدير اليدوي غلاف رقيق يفحص الصلاحية ثم يستدعيها
    expect(svc).toContain("requirePermission('backup.run')");
    expect(svc).toContain('return performDataExport(actor.id)');
  });

  it('★ قائمة الجداول معرَّفة في ملف واحد', () => {
    const walk = (dir: string): string[] =>
      existsSync(dir)
        ? readdirSync(dir, { withFileTypes: true }).flatMap((e) => {
            const p = join(dir, e.name);
            return e.isDirectory() ? walk(p) : [p];
          })
        : [];
    const definers = walk('src').filter((f) =>
      (f.endsWith('.ts') || f.endsWith('.tsx')) &&
      readFileSync(f, 'utf8').includes('EXPORT_TABLES ='));
    expect(definers).toEqual(['src/lib/backup/export-plan.ts']);
  });
});

// ==================== M-2: الصلاحيات الميتة ====================

describe('★ M-2 — صلاحيتان بلا تنفيذ حُذفتا', () => {
  it('★ لم تعودا في الكتالوج', async () => {
    const { ALL_PERMISSION_CODES } = await import('../src/lib/auth/permissions');
    expect(ALL_PERMISSION_CODES).not.toContain('expenses.approve_over_cap' as never);
    expect(ALL_PERMISSION_CODES).not.toContain('roles.manage' as never);
  });

  it('★ العدد الفعلي وقت التشغيل = 56', async () => {
    const { PERMISSIONS, ALL_PERMISSION_CODES } = await import('../src/lib/auth/permissions');
    expect(PERMISSIONS.length).toBe(56);
    expect(ALL_PERMISSION_CODES.length).toBe(56);
  });

  it('★ البديل المنفَّذ باقٍ — الحذف لم يمس وظيفة قائمة', async () => {
    const { ALL_PERMISSION_CODES } = await import('../src/lib/auth/permissions');
    expect(ALL_PERMISSION_CODES).toContain('expenses.limit.override' as never);
    expect(ALL_PERMISSION_CODES).toContain('expenses.void' as never);
    const fin = readFileSync('src/services/finance.service.ts', 'utf8');
    expect(fin).toContain("can(actor, 'expenses.limit.override')");
  });

  it('★ حارس: لا تعود صلاحية بلا تنفيذ إلى الكتالوج', async () => {
    const { PERMISSIONS } = await import('../src/lib/auth/permissions');
    const walk = (dir: string): string[] =>
      existsSync(dir)
        ? readdirSync(dir, { withFileTypes: true }).flatMap((e) => {
            const p = join(dir, e.name);
            return e.isDirectory() ? walk(p) : [p];
          })
        : [];
    const files = walk('src')
      .filter((f) => (f.endsWith('.ts') || f.endsWith('.tsx')) && !f.includes('permissions.ts'));
    const blob = files.map((f) => readFileSync(f, 'utf8')).join('\n');

    const dead = PERMISSIONS
      .map((p) => p.code)
      .filter((c) => !blob.includes(`'${c}'`));

    expect(dead, `صلاحيات بلا تنفيذ: ${dead.join(', ')}`).toEqual([]);
  });
});

// ==================== سكربتات النشر ====================

describe('★ سكربتات النشر تفشل بصوت عالٍ', () => {
  const pkg = JSON.parse(readFileSync('package.json', 'utf8')) as {
    scripts: Record<string, string>;
  };

  it('★ db:constraints ينفَّذ عبر Node لا psql — لأن psql غير موجود في بناء Vercel', () => {
    expect(pkg.scripts['db:constraints']).toContain('scripts/db-bootstrap.mjs');
    expect(pkg.scripts['db:constraints']).not.toContain('psql');
  });

  it('★ db:verify ينفَّذ عبر Node', () => {
    expect(pkg.scripts['db:verify']).toContain('scripts/db-bootstrap.mjs');
    expect(pkg.scripts['db:verify']).not.toContain('psql');
  });

  it('★ سكربت التهيئة يفشل بصوت عالٍ لا بصمت', () => {
    const src = readFileSync('scripts/db-bootstrap.mjs', 'utf8');
    // يخرج بغير صفر عند أي خطأ
    expect(src).toContain('process.exit(1)');
    expect(src).toContain('process.exitCode = 1');
    // يتحقق من العدّادات ويرفض النقص
    expect(src).toContain('throw new Error');
    expect(src).toContain('47');
    expect(src).toContain('44');
  });

  it('★ سكربت التهيئة لا يسرّب رابط الاتصال ولا الأسرار', () => {
    const src = readFileSync('scripts/db-bootstrap.mjs', 'utf8');
    expect(src).not.toContain('console.log(DATABASE_URL');
    expect(src).not.toContain('console.error(DATABASE_URL');
    expect(src).toContain('لا نطبع رابط الاتصال');
  });

  it('★ deploy:db يسلسل الخطوات بـ && فيتوقف عند أول فشل', () => {
    const s = pkg.scripts['deploy:db'];
    expect(s).toContain('&&');
    expect(s.indexOf('db push')).toBeLessThan(s.indexOf('db-bootstrap'));
  });

  it('★ vercel-build يهيّئ القاعدة قبل بناء التطبيق', () => {
    const v = pkg.scripts['vercel-build'];
    expect(v).toBeTruthy();
    // الترتيب: توليد ← مخطط ← قيود ← تهيئة ← بناء
    expect(v.indexOf('prisma generate')).toBeLessThan(v.indexOf('db push'));
    expect(v.indexOf('db push')).toBeLessThan(v.indexOf('db-bootstrap'));
    expect(v.indexOf('db-bootstrap')).toBeLessThan(v.indexOf('next build'));
    expect(v).toContain('&&');
  });

  it('★ التهيئة الأولية آمنة للتكرار — لا تفسد بيانات قائمة', () => {
    const src = readFileSync('scripts/seed-if-needed.mjs', 'utf8');
    expect(src).toContain('تخطّي التهيئة');
    expect(src).toContain('FROM roles');
  });

  it('★ سكربت التحقق يفحص عناصر الحماية المالية بالاسم', () => {
    const sql = readFileSync('prisma/sql/verify_production.sql', 'utf8');
    for (const c of ['ck_rental_no_overpay', 'ex_item_booking_overlap',
                     'ck_return_settlement', 'ck_refund_requires_source']) {
      expect(sql).toContain(c);
    }
    expect(sql).toContain('RAISE EXCEPTION');
  });

  it('★ بوابة الإنتاج fail-fast', () => {
    const gate = readFileSync('tests/db/production_gate.sh', 'utf8');
    expect(gate).toContain('set -Eeuo pipefail');
    expect(gate).toContain('DATABASE_URL:?');
    // لا echo نجاح بلا تحقق
    expect(gate).toContain('|| die');
  });

  it('★ .env.example بلا قيم حساسة', () => {
    const env = readFileSync('.env.example', 'utf8');
    expect(env).toMatch(/SEED_ADMIN_PASSWORD=""/);
    expect(env).toMatch(/DATABASE_URL=""/);
    expect(env).not.toContain('Admin@12345');
  });

  it('★ seed يرفض إنشاء مدير بلا كلمة مرور صريحة', () => {
    const seed = readFileSync('prisma/seed.ts', 'utf8');
    expect(seed).toContain('SEED_ADMIN_PASSWORD غير محددة');
    expect(seed).toContain('throw new Error');
  });

  it('★ جدولة Cron أسبوعية معرَّفة', () => {
    const v = JSON.parse(readFileSync('vercel.json', 'utf8')) as {
      crons: { path: string; schedule: string }[];
    };
    expect(v.crons[0].path).toBe('/api/cron/data-export');
    expect(v.crons[0].schedule).toBe('0 2 * * 0');
  });
});

// ==================== اعتماديات البناء ====================

describe('★ اعتماديات البناء الإنتاجي', () => {
  const pkg = JSON.parse(readFileSync('package.json', 'utf8')) as {
    dependencies: Record<string, string>;
    scripts: Record<string, string>;
  };

  it('★ @aws-sdk/client-s3 مُعلَن — وإلا فشل البناء على Vercel', () => {
    // object-storage.ts يستورده ديناميكيًا لرفع التصدير إلى R2.
    // غيابه من package.json يُنتج "Module not found" وقت البناء.
    const src = readFileSync('src/lib/storage/object-storage.ts', 'utf8');
    expect(src).toContain('@aws-sdk/client-s3');
    expect(pkg.dependencies['@aws-sdk/client-s3']).toBeTruthy();
  });

  it('★ postinstall يولّد عميل Prisma — وإلا فشل البناء', () => {
    // Vercel يشغّل postinstall بعد التثبيت. بدونه لا يُولَّد @prisma/client
    // فيفشل فحص الأنواع بـ "has no exported member 'PrismaClient'".
    expect(pkg.scripts.postinstall).toContain('prisma generate');
  });

  it('★ كل وحدة مستورَدة خارجيًا معلَنة في package.json', () => {
    const walk = (dir: string): string[] =>
      existsSync(dir)
        ? readdirSync(dir, { withFileTypes: true }).flatMap((e) => {
            const p = join(dir, e.name);
            return e.isDirectory() ? walk(p) : [p];
          })
        : [];
    const declared = new Set([
      ...Object.keys(pkg.dependencies),
      ...Object.keys((pkg as unknown as { devDependencies?: Record<string, string> })
        .devDependencies ?? {}),
    ]);

    const missing = new Set<string>();
    for (const f of walk('src').filter((x) => x.endsWith('.ts') || x.endsWith('.tsx'))) {
      const src = readFileSync(f, 'utf8');
      for (const m of src.matchAll(/from\s+'([^'@.][^']*)'|import\('([^'@.][^']*)'\)/g)) {
        const mod = (m[1] ?? m[2])!;
        const pkgName = mod.startsWith('node:') ? null : mod.split('/')[0];
        // وحدات Node المدمجة ليست حزمًا ولا تُعلَن في package.json
        const BUILTIN = ['crypto','fs','path','os','util','stream','buffer','url','http','https','zlib','events'];
        if (pkgName && !declared.has(pkgName) &&
            !['react', 'next'].includes(pkgName) && !BUILTIN.includes(pkgName)) {
          missing.add(pkgName);
        }
      }
      for (const m of src.matchAll(/from\s+'(@[^/]+\/[^']+)'|import\('(@[^/]+\/[^']+)'\)/g)) {
        const mod = (m[1] ?? m[2])!;
        const scoped = mod.split('/').slice(0, 2).join('/');
        if (!declared.has(scoped) && !scoped.startsWith('@/')) missing.add(scoped);
      }
    }
    expect([...missing], `وحدات مستورَدة وغير معلَنة: ${[...missing].join(', ')}`).toEqual([]);
  });
});
