import { route } from '@/lib/api';
import { importCustomers, importSchema } from '@/services/import.service';

export const POST = route({ schema: importSchema, handler: ({ input }) => importCustomers(input) });
