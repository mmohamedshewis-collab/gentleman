/**
 * تصدير البيانات — منطق خالص.
 *
 * ⚠ تسمية مقصودة: هذا **تصدير بيانات للأرشيف والتدقيق**، وليس نسخة احتياطية
 *   قابلة لاستعادة قاعدة البيانات. الاستعادة الفعلية تتم خارج التطبيق عبر
 *   Neon PITR. لا يوجد مسار استعادة داخل النظام إطلاقًا.
 */

/** الجداول المشمولة بالتصدير — بيانات تشغيلية ومالية بلا أسرار. */
export const EXPORT_TABLES = [
  'customers', 'products', 'productItems',
  'rentals', 'rentalItems', 'returns', 'returnItems',
  'sales', 'saleItems', 'payments', 'insuranceTransactions',
  'expenses', 'employees', 'commissions',
  'employeeAdvances', 'employeeAdvanceRepayments',
  'dailyCashClosings', 'cashTransfers',
  'itemStatusHistory', 'inventoryTransactions',
] as const;

export type ExportTable = (typeof EXPORT_TABLES)[number];

/** جداول لا تُصدَّر إطلاقًا: تحوي أسرارًا أو لا قيمة أرشيفية لها. */
export const EXCLUDED_TABLES = ['users', 'userSessions', 'roles', 'permissions'] as const;

export interface ExportManifest {
  generatedAt: string;
  tables: { name: string; rowCount: number }[];
  totalRows: number;
  /** ملاحظة تمنع الخلط بين التصدير والنسخة الاحتياطية */
  notice: string;
}

export const EXPORT_NOTICE =
  'تصدير بيانات للأرشيف والتدقيق — ليس نسخة احتياطية قابلة لاستعادة قاعدة البيانات. ' +
  'الاستعادة تتم عبر Neon PITR خارج النظام.';

/** DATA-EXPORT-2026-08-13T09-30-00.json */
export function buildExportKey(at: Date): string {
  const iso = at.toISOString().slice(0, 19).replace(/[:]/g, '-');
  return `data-exports/DATA-EXPORT-${iso}.json`;
}

export function buildManifest(
  counts: { name: string; rowCount: number }[],
  at: Date,
): ExportManifest {
  return {
    generatedAt: at.toISOString(),
    tables: counts,
    totalRows: counts.reduce((a, c) => a + c.rowCount, 0),
    notice: EXPORT_NOTICE,
  };
}

export interface ValidationOutcome {
  ok: boolean;
  message: string;
}

/**
 * التحقق من سلامة التصدير: كل جدول مطلوب حاضر، والعدّ متسق.
 * تصدير لم يُتحقَّق منه لا يُعتمد.
 */
export function validateExport(
  manifest: ExportManifest,
  payloadTables: string[],
): ValidationOutcome {
  const missing = manifest.tables
    .map((t) => t.name)
    .filter((name) => !payloadTables.includes(name));

  if (missing.length > 0) {
    return { ok: false, message: `جداول ناقصة في الملف: ${missing.join('، ')}` };
  }

  const sum = manifest.tables.reduce((a, t) => a + t.rowCount, 0);
  if (sum !== manifest.totalRows) {
    return { ok: false, message: `عدد السجلات غير متسق: ${sum} مقابل ${manifest.totalRows}` };
  }

  return { ok: true, message: `تم التحقق: ${manifest.tables.length} جدولًا و${manifest.totalRows} سجلًا.` };
}
