import { route } from '@/lib/api';
import { convertReservation, convertReservationSchema } from '@/services/reservation.service';

export const POST = route({ schema: convertReservationSchema, handler: ({ input }) => convertReservation(input) });
